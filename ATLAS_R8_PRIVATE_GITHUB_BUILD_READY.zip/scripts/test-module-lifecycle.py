#!/usr/bin/env python3
"""Execute the real pure lifecycle policy. Not Android/device acceptance."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='atlas-module-lifecycle-') as temp:
 d=Path(temp)
 harness=d/'ModuleLifecycleTest.java'
 harness.write_text("""import com.sbh.atlasos.ModuleLifecyclePolicy;
 public final class ModuleLifecycleTest {
  static int count;
  static void check(String name,boolean condition){if(!condition)throw new AssertionError(name);count++;System.out.println("PASS "+name);}
  public static void main(String[] args){
   check("ordinary background closes module",ModuleLifecyclePolicy.shouldFinishOnStop(false,false));
   check("own audio chooser remains for its result",!ModuleLifecyclePolicy.shouldFinishOnStop(false,true));
   check("configuration recreation retains original behavior",!ModuleLifecyclePolicy.shouldFinishOnStop(true,false));
   check("chooser completion restores default close behavior",ModuleLifecyclePolicy.shouldFinishOnStop(false,false));
   System.out.println("MODULE_LIFECYCLE_POLICY="+count+"/"+count);
  }
 }""")
 subprocess.run(['javac','-d',str(d),str(root/'app/src/main/java/com/sbh/atlasos/ModuleLifecyclePolicy.java'),str(harness)],check=True)
 subprocess.run(['java','-cp',str(d),'ModuleLifecycleTest'],check=True)
source=(root/'app/src/main/java/com/sbh/atlasos/AtlasModulesActivity.java').read_text()
assert 'ModuleLifecyclePolicy.shouldFinishOnStop(isChangingConfigurations(),pendingAudioFiles!=null)' in source
assert 'keyguard==null||keyguard.isDeviceLocked()' in source
assert 'pendingAudioFiles=null;' in source and 'FLAG_SECURE' in source
print('MODULE_LIFECYCLE_WIRING=PASS (source assertions only)')
