#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac -d "$TMP" \
 "$ROOT/app/src/main/java/com/sbh/atlasos/SeedImportPolicy.java" \
 "$ROOT/app/src/main/java/com/sbh/atlasos/TransactionalSeedImporter.java" \
 "$ROOT/app/src/main/java/com/sbh/atlasos/ZipCompletionGuard.java" \
 "$ROOT/app/src/test/java/com/sbh/atlasos/TransactionalSeedImporterTest.java"
java -cp "$TMP" com.sbh.atlasos.TransactionalSeedImporterTest
