#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, re, subprocess, tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REG=ROOT/'app/src/main/assets/atlas_commands/ATLAS_SEMANTIC_COMMAND_REGISTRY_V2_2026-10-10.json'
ACC=ROOT/'app/src/main/assets/atlas_commands/ATLAS_SEMANTIC_COMMAND_ACCEPTANCE_CASES_V2_2026-10-10.json'
CAT=ROOT/'app/src/main/java/com/sbh/atlasos/WorkflowCommandCatalog.java'
GEN=ROOT/'scripts/generate-semantic-command-catalog.py'

def sha(path:Path)->str:return hashlib.sha256(path.read_bytes()).hexdigest()
def require(ok:bool,msg:str):
    if not ok: raise SystemExit('FAIL '+msg)

registry=json.loads(REG.read_text())
acceptance=json.loads(ACC.read_text())
entries=registry.get('entries',[])
require(registry.get('total_entries')==92,'registry total_entries must be 92')
require(len(entries)==92,'registry entries must be 92')
require(len({e['id'] for e in entries})==92,'registry IDs must be unique')
require(len({e['canonical_command'] for e in entries})==92,'canonical names must be unique')
require(acceptance.get('case_count')==40 and len(acceptance.get('cases',[]))==40,'acceptance cases must be 40')
labels={e['canonical_command'] for e in entries}
for e in entries: labels.update(e.get('aliases',[]))
for i,c in enumerate(acceptance['cases'],1):
    require(c.get('expected_recognition') in {'🧭 MATCHED','🧩 COMBINED','🆕 CREATED','💬 NORMAL REQUEST','⚠️ PARTIAL MATCH'},f'case {i} recognition')
    require(all(x in labels for x in c.get('expected_stack',[])),f'case {i} stack label')
source=CAT.read_text()
require(f'REGISTRY_SHA256 = "{sha(REG)}"' in source,'generated catalog registry digest')
require('TOTAL_ENTRIES = 92' in source,'generated catalog count')
with tempfile.TemporaryDirectory(prefix='atlas-catalog-check-') as td:
    out=Path(td)/'WorkflowCommandCatalog.java'
    subprocess.run(['python',str(GEN),'--registry',str(REG),'--output',str(out)],check=True)
    require(out.read_bytes()==CAT.read_bytes(),'catalog must reproduce byte-for-byte from registry')
print('SEMANTIC_ASSETS=PASS entries=92 cases=40 registry_sha256='+sha(REG)+' acceptance_sha256='+sha(ACC))
