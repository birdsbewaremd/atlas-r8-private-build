#!/usr/bin/env python3
"""Conservative, non-Android static acceptance gate for the R7 new launcher.
Does NOT assert compiled APK, real Home-role eligibility or phone functionality.
"""
from pathlib import Path
from xml.etree import ElementTree
import re, sys, json, hashlib
root=Path(__file__).resolve().parents[1]
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
launcher=(root/'app/src/main/java/com/sbh/atlasos/AtlasLauncherActivity.java').read_text()
main=(root/'app/src/main/java/com/sbh/atlasos/MainActivity.java').read_text()
base=(root/'app/src/main/assets/www')
gradle=(root/'app/build.gradle').read_text()
checks=[]
def check(title,ok):
    checks.append({'title':title,'ok':bool(ok)})
    print(('PASS' if ok else 'FAIL')+' '+title)
try:
    ElementTree.fromstring(manifest);xml=True
except ElementTree.ParseError:xml=False
check('Manifest XML parses',xml)
ns='{http://schemas.android.com/apk/res/android}'
if xml:
    doc=ElementTree.fromstring(manifest)
    homes=[]
    for a in doc.findall('application/activity'):
        for filt in a.findall('intent-filter'):
            cats={c.get(ns+'name') for c in filt.findall('category')}
            acts={c.get(ns+'name') for c in filt.findall('action')}
            if 'android.intent.category.HOME' in cats: homes.append({'name':a.get(ns+'name'),'categories':cats,'actions':acts,'exported':a.get(ns+'exported')})
    check('Exactly one exported real Android HOME intent activity',len(homes)==1 and homes[0]['name']=='.AtlasLauncherActivity' and homes[0]['exported']=='true')
    check('HOME activity declares MAIN HOME DEFAULT',len(homes)==1 and {'android.intent.category.HOME','android.intent.category.DEFAULT'}<=homes[0]['categories'] and 'android.intent.action.MAIN' in homes[0]['actions'])
    check('Private MainActivity retains original launcher identity', '.MainActivity' in manifest and 'android.intent.category.LAUNCHER' in manifest)
else:check('One HOME activity',False)
check('Original 0.8.x namespace and app ID remain unchanged',"namespace 'com.sbh.atlasos'" in gradle and "applicationId 'com.sbh.atlasos'" in gradle)
check('R7 lineage remains with versionCode 44 or later', 'versionCode 44;' in gradle or 'versionCode 45;' in gradle)
check('Uses real LauncherApps API', 'launcherApps.getActivityList(null,user)' in launcher and 'launcherApps.startMainActivity(' in launcher)
check('Authorized work profile iteration', 'launcherApps.getProfiles()' in launcher and 'for(UserHandle user:profiles)' in launcher)
check('PackageManager fallback exists', 'queryIntentActivities(query,0)' in launcher)
check('No 200 app artificial cutoff in updated native source', 'out.length()>=200' not in main)
check('Search and local pinned app UI', 'addTextChangedListener(' in launcher and 'getStringSet("favorites"' in launcher)
check('Safe owner-tap-only Android HOME chooser', 'roles.createRequestRoleIntent(RoleManager.ROLE_HOME)' in launcher and '.setDefaultHome' not in launcher)
check('One UI HOME Settings restore control', 'Settings.ACTION_HOME_SETTINGS' in launcher)
check('Phone and preferred Google Messages available as external apps', 'Intent.ACTION_DIAL' in launcher and 'com.google.android.apps.messaging' in launcher)
check('ATLAS secure MainActivity launches separately', 'startActivity(new Intent(this,MainActivity.class))' in launcher)
check('No keyguard bypass or lock-screen spoofing',not any(x in launcher for x in ['setShowWhenLocked(', 'requestDismissKeyguard(', 'FLAG_DISMISS_KEYGUARD','FLAG_SHOW_WHEN_LOCKED','SYSTEM_ALERT_WINDOW']))
check('No surveillance or dangerous messaging grants added',not any(x in manifest for x in ['android.permission.QUERY_ALL_PACKAGES','android.permission.READ_SMS','android.permission.CALL_PHONE','android.permission.BIND_DEVICE_ADMIN','android.permission.SYSTEM_ALERT_WINDOW']))
check('R7 drawer files and references present',all((base/f).is_file() for f in ['atlas-installed-drawer.css','atlas-installed-drawer.js']) and 'atlas-installed-drawer.js' in (base/'index.html').read_text() and 'atlas-installed-drawer.css' in (base/'index.html').read_text())
check('R7 integrated app drawer attaches to existing drawer', "window.ATLASInstalledDrawer?.attach?." in (base/'app.js').read_text())
check('R7 drawer calls existing native owner API only',all(x in (base/'atlas-installed-drawer.js').read_text() for x in ["native.call('installedApps')","native.call('openInstalledApp'","const html="]))
check('No JS startup call opens a phone app without a click', 'grid.addEventListener(\'click\',onGrid)' in (base/'atlas-installed-drawer.js').read_text())
check('No automatic wallpaper or home role edits',not any(x in launcher for x in ['setBitmap(', 'setComponentEnabledSetting(', 'setWallpaper(', 'DISABLE_KEYGUARD']))
check('R7 service worker uses distinct cache identity', ('0.8.5-r7-real-launcher' in (base/'sw.js').read_text() or '0.8.6-r8-access-center' in (base/'sw.js').read_text()))
out={'summary':{'passed':sum(x['ok'] for x in checks),'total':len(checks),'sdk_compile':'NOT RUN','device_test':'NOT RUN'},'checks':checks}
receipt=root.parent/'receipts'/'R7_LAUNCHER_STATIC_QA.json';receipt.parent.mkdir(parents=True,exist_ok=True);receipt.write_text(json.dumps(out,indent=2))
print('RESULT '+str(out['summary']));sys.exit(0 if all(c['ok'] for c in checks) else 1)
