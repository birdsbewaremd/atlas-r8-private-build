#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
MODE="${1:-build}"
if [ "$MODE" != 'build' ] && [ "$MODE" != '--source-only' ]; then echo 'Usage: bash scripts/build-atlas-one.sh [--source-only]' >&2; exit 2; fi
python3 scripts/package-source.py --verify
bash scripts/test-java-syntax.sh
bash scripts/test-pure-java.sh
python3 scripts/test-app-android-stubs.py
python3 scripts/test-r1-native.py
python3 scripts/test-native-session.py
python3 scripts/test-module-lifecycle.py
python3 scripts/test-ci-build-workflow.py
python3 scripts/source-redteam.py
python3 scripts/test-omega-merge.py
python3 scripts/unified-source-gate.py
if [ "$MODE" = '--source-only' ]; then echo 'ATLAS_ONE_SOURCE_GATE=PASS; ANDROID_APK=NOT_BUILT'; exit 0; fi
if ! bash scripts/toolchain-doctor.sh; then echo 'BLOCKED: Android SDK/Gradle not ready' >&2; exit 34; fi
GRADLE_BIN="$(command -v gradle || true)"
if [ -z "$GRADLE_BIN" ] && [ -x .toolchains/gradle-8.11.1/bin/gradle ]; then GRADLE_BIN=.toolchains/gradle-8.11.1/bin/gradle; fi
"$GRADLE_BIN" --no-daemon lintDebug assembleDebug
APK=app/build/outputs/apk/debug/app-debug.apk
test -s "$APK"
sha256sum "$APK" | tee "$APK.sha256"
echo 'BUILT_DEBUG_APK=YES; DEVICE_TESTS=NOT_RUN'
