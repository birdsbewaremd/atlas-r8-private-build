#!/usr/bin/env bash
# Java 21 syntax parser only; does NOT compile Android code or exercise Keystore/SAF.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cat > "$TMP/CheckJavaSyntax.java" <<'JAVA'
import com.sun.source.util.JavacTask;
import java.util.List;
import javax.tools.*;
public final class CheckJavaSyntax {
  public static void main(String[] argv) throws Exception {
    JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
    if(compiler==null)throw new IllegalStateException("JDK required");
    DiagnosticCollector<JavaFileObject> errors=new DiagnosticCollector<>();
    try(StandardJavaFileManager files=compiler.getStandardFileManager(errors,null,null)){
      Iterable<? extends JavaFileObject> units=files.getJavaFileObjectsFromStrings(List.of(argv));
      JavacTask task=(JavacTask)compiler.getTask(null,files,errors,List.of("-proc:none"),null,units);
      int seen=0;for(var ignored:task.parse())seen++;
      long failures=errors.getDiagnostics().stream().filter(d->d.getKind()==Diagnostic.Kind.ERROR).count();
      for(Diagnostic<? extends JavaFileObject> d:errors.getDiagnostics())if(d.getKind()==Diagnostic.Kind.ERROR)System.err.println(d);
      if(failures>0||seen!=argv.length)throw new AssertionError("Java source parse failed");
      System.out.println("ANDROID_JAVA_SYNTAX="+seen+" source units PASS (parsing only)");
    }
  }
}
JAVA
javac -d "$TMP" "$TMP/CheckJavaSyntax.java"
mapfile -t JAVA_FILES < <(find "$ROOT/app/src/main/java" -name '*.java' -type f | sort)
java -cp "$TMP" CheckJavaSyntax "${JAVA_FILES[@]}"
