#!/usr/bin/env bash
# Host JCE/file/authorization tests; does not grant MediaProjection or use a device.
set -euo pipefail
ATLAS_TEST_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ATLAS_TEST_CLASSES="$(mktemp -d)"
trap 'rm -rf "$ATLAS_TEST_CLASSES"' EXIT
: "${ANDROID_JAR:?Set ANDROID_JAR to an Android API 35 android.jar}"
ATLAS_JAVAC="${JAVA_HOME:+$JAVA_HOME/bin/}javac"
ATLAS_JAVA="${JAVA_HOME:+$JAVA_HOME/bin/}java"
"$ATLAS_JAVAC" -encoding UTF-8 -source 8 -target 8 -cp "$ANDROID_JAR" -d "$ATLAS_TEST_CLASSES" \
  "$ATLAS_TEST_ROOT/app/src/main/java/com/sbh/atlasos/AtlasCaptureStore.java" \
  "$ATLAS_TEST_ROOT/app/src/test/java/com/sbh/atlasos/AtlasCaptureStoreTest.java"
"$ATLAS_JAVA" -cp "$ATLAS_TEST_CLASSES:$ANDROID_JAR" com.sbh.atlasos.AtlasCaptureStoreTest
