#!/usr/bin/env python3
"""Real filesystem/ZIP regression tests on synthetic temporary files only."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
import zipfile

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('atlas_package', HERE/'package-source.py')
pkg = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pkg)

class SourcePackageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.parent = Path(self.tmp.name)
        self.root = self.parent/'source'; self.root.mkdir()
        self.write('app/src/main/Example.java', b'final class Example {}\n')
        self.write('scripts/check.sh', b'#!/bin/sh\nexit 0\n')
        self.names = ['app/src/main/Example.java', 'scripts/check.sh']
        self.manifest()
    def write(self, name, value):
        p=self.root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(value)
    def manifest(self, names=None):
        records={}
        for name in self.names if names is None else names:
            data=(self.root/name).read_bytes()
            records[name]={'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}
        self.write(pkg.MANIFEST,json.dumps({'files':records},sort_keys=True).encode())
    def fail(self):
        with self.assertRaises(pkg.PackageError):pkg.snapshot(self.root)
    def test_deterministic_byte_identical_exports(self):
        a=self.parent/'a.zip';b=self.parent/'b.zip'
        self.assertEqual(pkg.package(self.root,a),3);pkg.package(self.root,b)
        self.assertEqual(a.read_bytes(),b.read_bytes())
    def test_archive_contains_only_allowlist_and_manifest(self):
        out=self.parent/'a.zip';pkg.package(self.root,out)
        with zipfile.ZipFile(out) as z:
            self.assertIsNone(z.testzip());self.assertEqual(set(z.namelist()),set(self.names+[pkg.MANIFEST]))
    def test_secrets_builds_toolchains_and_caches_are_excluded(self):
        names=['.env','.env.production','local.properties','key.properties','gradle.properties',
          '.netrc','sign.jks','sign.keystore','cert.pem','private.key','p.p12','p.pfx',
          'vault.atlasenc','app/src/main/.env.local','app/src/main/credentials.json',
          '.toolchains/sdk/secret','app/build/outputs/app.apk','.git/config',
          'test-output/screenshot.png','__pycache__/dummy.pyc','backups/private.txt']
        for name in names:self.write(name,b'SYNTHETIC_DO_NOT_EXPORT')
        out=self.parent/'a.zip';pkg.package(self.root,out)
        with zipfile.ZipFile(out) as z:self.assertEqual(set(z.namelist()),set(self.names+[pkg.MANIFEST]))
    def test_explicitly_manifested_secret_is_rejected(self):
        self.write('.env',b'SYNTHETIC');self.manifest(self.names+['.env']);self.fail()
    def test_tampered_source_is_rejected_before_output(self):
        self.write(self.names[0],b'changed')
        with self.assertRaises(pkg.PackageError):pkg.package(self.root,self.parent/'a.zip')
        self.assertFalse((self.parent/'a.zip').exists())
    def test_missing_file_is_rejected(self):
        (self.root/self.names[0]).unlink();self.fail()
    def test_unreviewed_source_is_rejected(self):
        self.write('app/src/main/New.java',b'new');self.fail()
    def test_symlink_file_is_rejected(self):
        path=self.root/self.names[0];value=path.read_bytes();path.unlink()
        outside=self.parent/'outside';outside.write_bytes(value);path.symlink_to(outside);self.fail()
    def test_symlink_parent_directory_is_rejected(self):
        p=self.root/'app/src/main';other=self.parent/'moved';p.rename(other);p.symlink_to(other,target_is_directory=True);self.fail()
    def test_hardlink_is_rejected(self):
        os.link(self.root/self.names[0],self.parent/'hardlink');self.fail()
    def test_duplicate_json_key_is_rejected(self):
        self.write(pkg.MANIFEST,b'{"files":{},"files":{}}');self.fail()
    def test_path_traversal_and_windows_paths_are_rejected(self):
        for name in ['../x','/x','app/../x','app//x','app/./x','C:/x','app\\x','x\n']:
            with self.subTest(name=name),self.assertRaises(pkg.PackageError):pkg.relative_name(name)
    def test_wrong_size_metadata_is_rejected(self):
        p=self.root/pkg.MANIFEST;o=json.loads(p.read_text());o['files'][self.names[0]]['size_bytes']+=1;p.write_text(json.dumps(o));self.fail()
    def test_wrong_hash_format_is_rejected(self):
        p=self.root/pkg.MANIFEST;o=json.loads(p.read_text());o['files'][self.names[0]]['sha256']='not a hash';p.write_text(json.dumps(o));self.fail()
    def test_output_in_source_tree_is_rejected(self):
        with self.assertRaises(pkg.PackageError):pkg.package(self.root,self.root/'new.zip')
    def test_existing_output_is_never_overwritten(self):
        out=self.parent/'a.zip';out.write_bytes(b'ORIGINAL')
        with self.assertRaises(pkg.PackageError):pkg.package(self.root,out)
        self.assertEqual(out.read_bytes(),b'ORIGINAL')
    def test_output_symlink_is_rejected(self):
        target=self.parent/'target';target.write_bytes(b'ORIGINAL');out=self.parent/'a.zip';out.symlink_to(target)
        with self.assertRaises(pkg.PackageError):pkg.package(self.root,out)
        self.assertEqual(target.read_bytes(),b'ORIGINAL')
    def test_manifest_cannot_hash_itself(self):
        self.manifest(self.names+[pkg.MANIFEST]);self.fail()
    def test_source_root_symlink_is_rejected(self):
        alias=self.parent/'alias';alias.symlink_to(self.root,target_is_directory=True)
        with self.assertRaises(pkg.PackageError):pkg.snapshot(alias)
    def test_verify_does_not_create_an_archive(self):
        self.assertEqual(set(pkg.snapshot(self.root)),set(self.names+[pkg.MANIFEST]));self.assertEqual(list(self.parent.glob('*.zip')),[])

if __name__=='__main__':unittest.main(verbosity=2)
