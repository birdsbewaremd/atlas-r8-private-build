#!/usr/bin/env python3
"""Execute extracted real MainActivity.onPause/onResume methods with fake Android host APIs.
The Android UI lifecycle is simulated; NOT device instrumentation.
"""
from pathlib import Path
import subprocess,sys,tempfile
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
source=(root/'app/src/main/java/com/sbh/atlasos/MainActivity.java').read_text()

def method(name):
    needle='  @Override protected void '+name+'(){'
    start=source.index(needle); opening=source.index('{',start);level=1;pos=opening+1
    while level:
        if source[pos]=='{': level+=1
        elif source[pos]=='}':level-=1
        pos+=1
    return source[start:pos]
fixtures={
'android/os/SystemClock.java':'package android.os; public class SystemClock{public static long now=1000L; public static long elapsedRealtime(){return now;}}',
'android/app/KeyguardManager.java':'package android.app; public class KeyguardManager{public boolean isDeviceLocked(){return false;}}',
'android/view/View.java':'package android.view; public final class View{public static final int VISIBLE=0,INVISIBLE=4;}',
'android/content/Context.java':'package android.content; public class Context{public static final String KEYGUARD_SERVICE="keyguard";public Object getSystemService(String s){return new android.app.KeyguardManager();}protected void onPause(){}protected void onResume(){}}',
'com/sbh/atlasos/MainActivity.java':r'''package com.sbh.atlasos;
import android.content.Context;import android.view.View;
public class MainActivity extends Context {
  boolean learningForeground=true, pageReady=true, rendererUnavailable=false, activityDestroyed=false;int stopped=0,cleared=0,lockedEvents=0,learningEvents=0,relockScripts=0;
  final WebView web = new WebView();
  boolean webUsable(WebView candidate){return candidate==web&&!rendererUnavailable&&!activityDestroyed;}
  static class WebView {int visibility=View.VISIBLE;void setVisibility(int v){visibility=v;}void evaluateJavascript(String js,java.util.function.Consumer<String> f){if(js.contains("atlas-owner-locked"))MainActivity.scriptCount++;if(f!=null)f.accept("");}}
  static int scriptCount=0;
  static class FakeDialog {boolean dismissed;void dismiss(){dismissed=true;}}
  FakeDialog bookmarkDialog=new FakeDialog();
  static class FakeBrain {int suspensions;void suspend(){suspensions++;}}
  FakeBrain brain=new FakeBrain();
  void stopPrivateMedia(){stopped++;}
  void dispatchEvent(String name,String data){if("atlas-owner-locked".equals(name))lockedEvents++;if("atlas-learning-locked".equals(name))learningEvents++;}
  void clearFakePlanner(){cleared++;}
  FakePlanner workflowPlanner = new FakePlanner(this);
  static class FakePlanner {MainActivity owner;FakePlanner(MainActivity a){owner=a;}void clear(){owner.clearFakePlanner();}}
  boolean ownerPinConfiguredNative(){return true;}
  boolean ownerRequired(){return OwnerSessionGate.isActive(this);}
'''+method('onPause')+'\n'+method('onResume')+r'''
  public static void main(String[]args) {
    int total=0,pass=0;
    MainActivity m=new MainActivity();
    OwnerSessionGate.clear();OwnerSessionGate.setForeground(true);OwnerSessionGate.setActive(true);
    boolean active=OwnerSessionGate.isActive(m);
    FakeDialog pendingDialog=m.bookmarkDialog;
    boolean[] checks=new boolean[10];
    checks[0]=active;
    m.onPause();
    checks[1]=!OwnerSessionGate.isActive(m);
    checks[2]=!OwnerSessionGate.isForeground();
    checks[3]=m.stopped>=1;
    checks[4]=m.web.visibility==View.INVISIBLE;
    checks[5]=m.lockedEvents>=1&&m.learningEvents>=1;
    m.onResume();
    checks[6]=OwnerSessionGate.isForeground()&&!OwnerSessionGate.isActive(m);
    checks[7]=scriptCount>=1;
    checks[8]=pendingDialog.dismissed&&m.bookmarkDialog==null;
    checks[9]=m.brain.suspensions>=1;
    String[] labels={"start authenticated","onPause immediately revokes authority","onPause marks foreground false","onPause stops voice and wake","onPause conceals private WebView","onPause emits lock and learning scrub signals","onResume restores foreground without restoring login","onResume requests re-lock UI before showing","onPause dismisses pending external-link confirmation","onPause suspends optional online Brain work"};
    for(int i=0;i<checks.length;i++){total++;if(checks[i])pass++;System.out.println((checks[i]?"PASS ":"FAIL ")+labels[i]);}
    System.out.println("PAUSE_PRIVACY_HOST="+pass+"/"+total+(pass==total?" PASS":" FAIL"));
    if(pass!=total)System.exit(2);
  }
}
'''
}
with tempfile.TemporaryDirectory(prefix='atlas-pause-privacy-') as tmp:
  d=Path(tmp); paths=[]
  for name,data in fixtures.items():
    p=d/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data);paths.append(str(p))
  paths.append(str(root/'app/src/main/java/com/sbh/atlasos/OwnerSessionGate.java'))
  subprocess.run(['javac','-d',str(d),*paths],check=True)
  raise SystemExit(subprocess.run(['java','-cp',str(d),'com.sbh.atlasos.MainActivity']).returncode)
