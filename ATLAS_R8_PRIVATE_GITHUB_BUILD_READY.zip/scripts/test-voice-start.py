#!/usr/bin/env python3
"""Execute the exact startVoiceTurn method against a deterministic host queue.
Uses the real OwnerSessionGate with fake Android lock/clock APIs. Not device audio.
Optional argument selects another source tree for before/after comparison.
"""
from pathlib import Path
import subprocess, sys, tempfile
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
source=(ROOT/'app/src/main/java/com/sbh/atlasos/MainActivity.java').read_text()
start=source.index('  private void startVoiceTurn(){')
brace=source.index('{',start);depth=1;end=brace+1
while depth:
    if source[end]=='{': depth+=1
    elif source[end]=='}': depth-=1
    end+=1
method=source[start:end]
fixtures={
'android/os/SystemClock.java':'package android.os; public class SystemClock {public static long now=1000;public static long elapsedRealtime(){return now;}}',
'android/app/KeyguardManager.java':'package android.app; public class KeyguardManager {public boolean locked;public boolean isDeviceLocked(){return locked;}}',
'android/content/Context.java':'package android.content; public class Context {public static final String KEYGUARD_SERVICE="keyguard";public Object service;public Object getSystemService(String name){return service;}}',
'com/sbh/atlasos/MainActivity.java':r'''package com.sbh.atlasos;
import java.util.*;import android.os.SystemClock;import android.app.KeyguardManager;import android.content.Context;
public class MainActivity extends Context {
 static int passed,total;static ArrayList<Runnable> queue=new ArrayList<>();
 static class Looper{static Looper getMainLooper(){return new Looper();}}
 static class Handler{Handler(Looper l){}void postDelayed(Runnable r,long delay){queue.add(r);}}
 static class Intent{Intent(String a){}Intent(Object c,Class<?> t){}void putExtra(String n,Object v){}}
 static class RecognizerIntent{static final String ACTION_RECOGNIZE_SPEECH="recognize",EXTRA_LANGUAGE_MODEL="lm",LANGUAGE_MODEL_FREE_FORM="free",EXTRA_PARTIAL_RESULTS="partial",EXTRA_MAX_RESULTS="max",EXTRA_PREFER_OFFLINE="offline",EXTRA_CALLING_PACKAGE="package";}
 static class AtlasWakeService{}
 static class Recognizer{int starts;void startListening(Intent i){starts++;}}
 static class Tts{boolean isSpeaking(){return false;}void stop(){}}
 static class Prefs{boolean getBoolean(String k,boolean fallback){return false;}}
 static final int MODE_PRIVATE=0;
 Recognizer voiceRecognizer=new Recognizer();Tts tts=new Tts();boolean resumeWakeAfterVoiceTurn;
 long voiceStartGeneration;boolean finishing,destroyed;int errors;
 Prefs getSharedPreferences(String n,int m){return new Prefs();}
 void stopService(Intent i){}String getPackageName(){return "com.sbh.atlasos.candidate";}
 boolean isFinishing(){return finishing;}boolean isDestroyed(){return destroyed;}
 void voiceEvent(String a,String b){if("ERROR".equals(a)||"LOCKED".equals(a))errors++;}
 void restoreWakeAfterVoiceTurn(){}
 '''+method+r'''
 static MainActivity fresh(){queue.clear();SystemClock.now=1000;OwnerSessionGate.clear();OwnerSessionGate.setForeground(true);OwnerSessionGate.setActive(true);MainActivity a=new MainActivity();a.service=new KeyguardManager();return a;}
 static void drain(){ArrayList<Runnable> jobs=new ArrayList<>(queue);queue.clear();for(Runnable r:jobs)r.run();}
 static void check(String name,boolean ok){total++;if(ok)passed++;System.out.println((ok?"PASS ":"FAIL ")+name);}
 public static void main(String[]args){MainActivity a;
 a=fresh();a.startVoiceTurn();check("recognition is deferred until queue execution",a.voiceRecognizer.starts==0);drain();check("authorized deferred recognition starts",a.voiceRecognizer.starts==1);
 a=fresh();OwnerSessionGate.clear();a.startVoiceTurn();drain();check("locked invocation cannot schedule microphone start",a.voiceRecognizer.starts==0);
 a=fresh();a.startVoiceTurn();OwnerSessionGate.clear();drain();check("lock before delayed execution prevents start",a.voiceRecognizer.starts==0);
 a=fresh();a.startVoiceTurn();OwnerSessionGate.setForeground(false);drain();check("background before delayed execution prevents start",a.voiceRecognizer.starts==0);
 a=fresh();a.startVoiceTurn();SystemClock.now+=900000;drain();check("expired login prevents delayed start",a.voiceRecognizer.starts==0);
 a=fresh();a.startVoiceTurn();((KeyguardManager)a.service).locked=true;drain();check("device lock prevents delayed start",a.voiceRecognizer.starts==0);
 a=fresh();a.startVoiceTurn();a.finishing=true;drain();check("finishing Activity prevents delayed start",a.voiceRecognizer.starts==0);
 a=fresh();a.startVoiceTurn();a.destroyed=true;drain();check("destroyed Activity prevents delayed start",a.voiceRecognizer.starts==0);
 a=fresh();a.startVoiceTurn();Recognizer saved=a.voiceRecognizer;a.voiceRecognizer=null;drain();check("destroyed recognizer is not dereferenced",saved.starts==0&&a.errors==0);
 a=fresh();a.startVoiceTurn();a.voiceStartGeneration++;drain();check("canceled ticket prevents delayed start",a.voiceRecognizer.starts==0);
 a=fresh();a.startVoiceTurn();a.startVoiceTurn();drain();check("new request supersedes previous queued request",a.voiceRecognizer.starts==1);
 a=fresh();a.startVoiceTurn();OwnerSessionGate.clear();OwnerSessionGate.setActive(true);drain();check("new login does not resurrect old queued work",a.voiceRecognizer.starts==0);
 a=fresh();a.startVoiceTurn();OwnerSessionGate.touch();drain();check("same-login activity preserves a valid request",a.voiceRecognizer.starts==1);
 a=fresh();a.finishing=true;a.startVoiceTurn();drain();check("finishing invocation schedules no recognition",a.voiceRecognizer.starts==0);
 System.out.println("VOICE_START_HOST="+passed+"/"+total);if(passed!=total)System.exit(1);
 }
}
'''}
with tempfile.TemporaryDirectory(prefix='atlas-deferred-voice-') as temporary:
    directory=Path(temporary);sources=[]
    for name,text in fixtures.items():
        path=directory/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text);sources.append(str(path))
    sources.append(str(ROOT/'app/src/main/java/com/sbh/atlasos/OwnerSessionGate.java'))
    subprocess.run(['javac','--release','8','-d',str(directory),*sources],check=True)
    raise SystemExit(subprocess.run(['java','-cp',str(directory),'com.sbh.atlasos.MainActivity']).returncode)
