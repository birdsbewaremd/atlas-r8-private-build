#!/usr/bin/env python3
"""GOD V4 input hardening source-level tripwires (not Android device proof)."""
from pathlib import Path
import json, sys
R=Path(__file__).resolve().parents[1]
java=R/'app/src/main/java/com/sbh/atlasos'
local=(java/'CommandParser.java').read_text()
workflow=(java/'WorkflowIntentParser.java').read_text()
god=(java/'GodCommandPolicy.java').read_text()
router=(java/'AuthenticatedInputRouter.java').read_text()
manifest=(R/'app/src/main/AndroidManifest.xml').read_text()
tests=(R/'scripts/test-pure-java.sh').read_text()
state=json.loads((R/'BUILD_STATE.json').read_text())
checks={
  'canonical shared Unicode format policy in local parser':'static boolean hasUnsafeControl' in local and 'Character.FORMAT' in local,
  'isolated UTF16 surrogate rejection':'Character.isHighSurrogate' in local and 'Character.isLowSurrogate' in local,
  'known blank spoof codepoints guarded':all(x in local for x in ('\\u034F','\\u3164','\\u2800')),
  'local parsing calls safety policy before normalizer':'hasUnsafeControl(raw)' in local and local.index('hasUnsafeControl(raw)')<local.index('String command = normalize(raw)'),
  'local post-normalization bounds guarded':'command.length() > MAX_COMMAND_CHARS' in local,
  'GOD calls same canonical policy':'CommandParser.hasUnsafeControl(s)' in god,
  'GOD post-normalization bounds guarded':'message.length() > MAX_INPUT_CHARS' in god,
  'workflow calls same canonical policy':'CommandParser.hasUnsafeControl(s)' in workflow,
  'workflow post-normalization bounds guarded':'text.length() > MAX_CHARS' in workflow,
  'dynamic 4970+ regression cases wired':'InputUnicodeHardeningTest' in tests and (R/'app/src/test/java/com/sbh/atlasos/InputUnicodeHardeningTest.java').exists(),
  'GOD still routes after independent owner/source/invalid checks':router.index('if (!authenticated)') < router.index('WorkflowIntentParser.State.SOURCE_DATA') < router.index('GodCommandPolicy.Result god') and router.index('WorkflowIntentParser.State.INVALID') < router.index('GodCommandPolicy.Result god'),
  'GOD remains recognition only':'Route.BRAIN_HANDOFF' in router and 'god_recognition_never_authorizes_execution' in router,
  'no INTERNET or high-risk permissions introduced':all(x not in manifest for x in ('android.permission.INTERNET','android.permission.SEND_SMS','android.permission.QUERY_ALL_PACKAGES','android.permission.MANAGE_EXTERNAL_STORAGE')),
  'versioned private source candidate only':state['version_code']==33 and state['version_name']=='0.4.1-first-run-preview' and state['atlas_one_parent']['version_code']==31 and state['atlas_one_parent']['version_name'].endswith('-godv4') and not state['canonical'] and not state['apk_compiled'] and not state['device_tested'],
  'parent rollback preserved':state['god_v4_hardening']['parent_zip_sha256']=='6aa6ffa373d37d3b597bd73a3268c98217516140ec51693d3ff09b81d832e83f',
}
for name,passed in checks.items():print(('PASS' if passed else 'FAIL')+' GODV4 '+name)
print(f'GOD_V4_SOURCE_GATES={sum(checks.values())}/{len(checks)} '+('PASS' if all(checks.values()) else 'FAIL'))
sys.exit(0 if all(checks.values()) else 2)
