#!/usr/bin/env python3
"""Chromium UI regression with synthetic native bridge, NOT Android acceptance.
Requires Playwright and a locally installed Chromium. Uses about:blank DOM
and storage fixtures; never navigates network/files, production, accounts,
microphones, or external providers. Not a browser-persistence test.
"""
import json, os, pathlib, re, shutil
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=pathlib.Path(os.environ.get('ATLAS_TEST_OUTPUT',str(ROOT/'test-output')))
OUT.mkdir(parents=True,exist_ok=True)
HTML=(ROOT/'app/src/main/assets/www/index.html').read_text()
HTML=re.sub(r'<script[^>]*>.*?</script>','',HTML,flags=re.S)
HTML=re.sub(r'<link[^>]*>','',HTML)
JS=(ROOT/'app/src/main/assets/www/app.js').read_text()
CSS=(ROOT/'app/src/main/assets/www/style.css').read_text() if (ROOT/'app/src/main/assets/www/style.css').exists() else ''
results=[]
def check(name,condition):
    results.append({'case':name,'pass':bool(condition)})
    if not condition: raise AssertionError(name)
def digits(pg,text):
    for c in text: pg.locator(f'[data-k="{c}"]').click()
mock=r'''window.__calls=[];let active=false;
window.ATLASNative={
  isNative:()=>true,deviceStatus:()=>'{"battery":50}',
  ownerPinConfigured:()=>localStorage.getItem('test.configured')==='1',
  configureOwnerPinConfirmed:(a,b)=>{__calls.push('configure');if(a!==b||localStorage.getItem('test.configured'))return false;localStorage.setItem('test.configured','1');active=true;return true;},
  lockOwnerSession:()=>{active=false;},ownerSessionActive:()=>active,
  unlockOwner:p=>{active=p==='123456';return active;},ownerLockoutSeconds:()=>0,
  ownerRecoveryConfigured:()=>false,
  beginOwnerRecovery:()=>__calls.push('recover'),
  beginOwnerRecoveryEnrollment:()=>__calls.push('enroll'),
  beginOwnerPinChange:()=>__calls.push('change'),heyAtlasEnabled:()=>false,
  routeTextInput:q=>{__calls.push('route:'+q);if(q.includes('repeatable command'))return JSON.stringify({route:'WORKFLOW_HANDOFF',statusLine:'⚠️ PARTIAL MATCH',recognition:'PARTIAL MATCH',commandStack:['ATLAS COMMANDIZE'],constraints:['command_creation_not_persisted'],outcome:'The reusable-command request was recognized, but no command was saved because durable persistence is not connected.',original:q,frame:'REAL_WORLD',requiresBackend:true,backendConnected:false,localResult:''});return JSON.stringify({route:'WORKFLOW_HANDOFF',statusLine:'🧩 COMBINED',recognition:'COMBINED',commandStack:['ATLAS MAX','ATLAS MESSAGE FORGE','ATLAS FINAL PASS'],constraints:['recognition_is_not_authorization'],outcome:'The command was recognized, but the authenticated ATLAS brain backend is not connected in this source candidate.',original:q,frame:'REAL_WORLD',requiresBackend:true,backendConnected:false,localResult:''});},
  semanticCommandCatalog:()=>JSON.stringify([{id:'atlas_max',command:'ATLAS MAX',category:'Quality',aliases:['MAX THIS']},{id:'price_this',command:'PRICE THIS',category:'Business',aliases:[]}]),
  runCommand:()=> 'NO_LOCAL_MATCH',classifyFrame:()=> 'REAL_WORLD',speak:t=>__calls.push('speak:'+t),listenOnce:()=>__calls.push('listen')
};'''
try:
 with sync_playwright() as pw:
  executable=os.environ.get('CHROMIUM_EXECUTABLE') or shutil.which('chromium') or shutil.which('google-chrome')
  if not executable: raise RuntimeError('Install a Chromium browser before this optional UI test')
  browser=pw.chromium.launch(executable_path=executable,headless=True,args=['--no-sandbox'])
  context=browser.new_context(viewport={'width':390,'height':844})
  errors=[]
  def load_page(saved=None):
    pg=context.new_page();pg.on('pageerror',lambda err: errors.append(str(err)))
    pg.set_content(HTML)
    pg.evaluate("""(saved)=>{const make=(data)=>({getItem:k=>Object.hasOwn(data,k)?data[k]:null,setItem:(k,v)=>{data[k]=String(v)},removeItem:k=>{delete data[k]},clear:()=>{for(const k of Object.keys(data))delete data[k]}});window.__saved=saved;Object.defineProperty(window,'localStorage',{value:make(saved),configurable:true});Object.defineProperty(window,'sessionStorage',{value:make({}),configurable:true});}""",saved or {})
    pg.evaluate(mock)
    if CSS:pg.add_style_tag(content=CSS)
    pg.evaluate(JS)
    pg.evaluate("""() => { window.__mediaCalls=0; window.__tracksStopped=0; Object.defineProperty(navigator,'mediaDevices',{configurable:true,value:{getUserMedia:async()=>{window.__mediaCalls++;return {getTracks:()=>[{stop:()=>window.__tracksStopped++}]}}}}); }""")
    return pg
  pg=load_page();pg.locator('#begin').click();pg.locator('#name').fill('Synthetic Tester');pg.locator('#next').click()
  check('new owner sees two-entry instruction','same six-digit code twice' in pg.locator('body').inner_text())
  digits(pg,'123');pg.locator('#next').click()
  check('incomplete entry does not persist',pg.evaluate('__calls.length')==0)
  digits(pg,'456');pg.locator('#next').click()
  check('first complete entry does not persist',pg.evaluate('__calls.length')==0)
  check('first entry advances only to confirmation','same code again' in pg.locator('#pinStage').inner_text())
  digits(pg,'654321');pg.locator('#next').click()
  check('mismatch does not invoke native setter',pg.evaluate('__calls.length')==0)
  check('mismatch resets the flow','Start again' in pg.locator('#pinStage').inner_text())
  digits(pg,'123456');pg.locator('#next').click();digits(pg,'123456');pg.locator('#next').click()
  check('confirmed pair invokes native setter exactly once',pg.evaluate('__calls')==['configure'])
  check('accepted enrollment advances to preferences','Meet Atlas.' in pg.locator('body').inner_text())
  pg.locator('#mic').click()
  check('native microphone permission UI does not call browser media',pg.evaluate('__mediaCalls')==0)
  pg.locator('#cam').click()
  check('native camera permission UI does not call browser media',pg.evaluate('__mediaCalls')==0)
  pg.evaluate("window.__nativeSaved=window.ATLASNative;delete window.ATLASNative;")
  pg.locator('#mic').click()
  check('standalone browser permission check still stops synthetic stream',pg.evaluate('__mediaCalls===1 && __tracksStopped===1'))
  pg.evaluate("window.ATLASNative=window.__nativeSaved")
  check('native enrollment does not copy PIN hash into browser lock storage',pg.evaluate("localStorage.getItem('atlas.lock.v1')") is None)
  saved=pg.evaluate('__saved');pg.close();pg=load_page(saved);pg.locator('#begin').click()
  check('interrupted setup returns to unlock, not re-enrollment',pg.locator('#ownerRecover').count()==1 and pg.locator('#pinStage').count()==0)
  pg.locator('#ownerRecover').click()
  check('locked recovery invokes native dialog without a token argument',pg.evaluate('__calls')==['recover'])
  digits(pg,'654321')
  check('wrong PIN stays on locked screen',pg.locator('#ownerRecover').count()==1)
  digits(pg,'123456')
  check('correct PIN enters home',pg.locator('#rail').count()==1)
  pg.locator('[data-app="atlas"]').first.click()
  semantic='Make this message 1 million times better and go over it again.'
  pg.locator('#atlasCmd').fill(semantic);pg.locator('#atlasRun').click()
  atlas_text=pg.locator('#atlasResult').inner_text()
  check('semantic UI submits through routeTextInput only',pg.evaluate("__calls.filter(x=>x.startsWith('route:')).slice(-1)[0]")==f'route:{semantic}')
  check('semantic UI renders status emoji and composed stack','🧩 COMBINED' in atlas_text and 'ATLAS MAX + ATLAS MESSAGE FORGE + ATLAS FINAL PASS' in atlas_text)
  check('semantic UI reports backend disconnection instead of completion','not connected' in atlas_text.lower())
  commandize='Make this a repeatable command called Clean Close.'
  pg.locator('#atlasCmd').fill(commandize);pg.locator('#atlasRun').click()
  commandize_text=pg.locator('#atlasResult').inner_text()
  check('unpersisted command creation stays partial','⚠️ PARTIAL MATCH' in commandize_text and 'no command was saved' in commandize_text.lower())
  pg.locator('#back').click()
  pg.locator('[data-app="commands"]').first.click()
  check('command inventory renders native semantic catalog','ATLAS MAX' in pg.locator('body').inner_text() and 'PRICE THIS' in pg.locator('body').inner_text())
  pg.locator('#commandSearch').fill('price')
  check('command inventory search filters aliases and names',pg.locator('[data-semantic]').count()==1 and 'PRICE THIS' in pg.locator('[data-semantic]').inner_text())
  pg.locator('#back').click()
  pg.locator('[data-app="camera"]').first.click()
  check('native camera displays privacy hold without starting a stream',pg.evaluate('__mediaCalls')==0 and 'Camera disabled in this candidate' in pg.locator('body').inner_text())
  pg.screenshot(path=str(OUT/'camera-privacy-hold-mobile.png'),full_page=True)
  pg.locator('#back').click()
  pg.locator('[data-app="settings"]').first.click();pg.get_by_text('Privacy & Security',exact=True).click()
  check('security page reaches effective recovery handler',pg.locator('#enrollRecovery').count()==1)
  pg.locator('#enrollRecovery').click();pg.locator('#changeOwnerPin').click()
  check('recovery enrollment and PIN change route only to native handlers',pg.evaluate('__calls.slice(-2)')==['enroll','change'])
  pg.screenshot(path=str(OUT/'owner-security-ui-mobile.png'),full_page=True)
  pg.evaluate("dispatchEvent(new CustomEvent('atlas-owner-credential-changed'))")
  check('credential change returns UI to locked state',pg.locator('#ownerRecover').count()==1 and pg.evaluate("sessionStorage.getItem('atlas.role')") is None)
  check('UI flows raise no JavaScript exceptions',not errors)
  context.close();browser.close()
finally:
 (OUT/'owner-ui-results.json').write_text(json.dumps({'scope':'Synthetic Chromium DOM + mocked native interface and storage; no Android dialogs, real storage persistence, or device acceptance','results':results,'passed':sum(r['pass'] for r in results),'total':len(results)},indent=2))
print(f'OWNER_UI={sum(r["pass"] for r in results)}/{len(results)} PASS')
