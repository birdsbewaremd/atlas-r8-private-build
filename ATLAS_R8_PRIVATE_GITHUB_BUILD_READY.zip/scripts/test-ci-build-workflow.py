#!/usr/bin/env python3
"""Static GitHub Actions CI safety preflight, not proof a runner/Android SDK executed."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
w=(ROOT/'.github/workflows/build-android.yml').read_text()
rows=[]
def check(label,good):
  rows.append((label,bool(good)))
  print(('PASS' if good else 'FAIL')+' CI '+label)

check('manual trigger only', bool(re.search(r'(?m)^on:\s*\n\s+workflow_dispatch:\s*$',w)) and not re.search(r'(?m)^\s+(?:push|pull_request|schedule):',w))
check('minimal GitHub token permissions', bool(re.search(r'(?m)^permissions:\s*\n\s+contents:\s+read\s*$',w)))
check('explicit privacy guard before checkout', w.find('Enforce private repository')<w.find('actions/checkout@') and 'ATLAS_REPOSITORY_PRIVATE' in w and "!= 'true'" in w)
check('checkout cannot persist token', 'persist-credentials: false' in w)
check('JDK 21 and supported pinned Gradle', "java-version: '21'" in w and "gradle-version: '8.11.1'" in w)
check('official Android setup action', 'android-actions/setup-android@v4' in w)
check('SDK 35 + build-tools 35 + ADB installed', all(x in w for x in ('platforms;android-35','build-tools;35.0.0','platform-tools')))
check('licenses only for previously approved SDK in isolated runner', "accept-android-sdk-licenses: 'yes'" in w)
check('pinned Playwright/browser for Python UI tests', "playwright==1.57.0" in w and 'playwright install --with-deps chromium' in w)
check('toolchain doctor runs before build script', w.find('scripts/toolchain-doctor.sh')<w.find('scripts/build-debug.sh'))
check('full source gates + native build attempt', 'bash ./scripts/build-debug.sh' in w)
check('enforces candidate package identity', "name='com.sbh.atlasos.candidate'" in w)
check('refuses unexpected INTERNET permission', 'android.permission.INTERNET' in w and 'exit 45' in w)
check('APK signature and checksum inspected', 'apksigner' in w and 'sha256sum "$APK"' in w)
check('artifacts retained briefly', 'retention-days: 3' in w and 'actions/upload-artifact@v4' in w)
check('no auto-install or production deploy', not any(k in w for k in ('adb install','gradle publish','firebase deploy','gh release create','fastlane supply')))
print('CI_BUILD_GATES=%d/%d %s'%(sum(v for _,v in rows),len(rows),'PASS' if all(v for _,v in rows) else 'FAIL'))
raise SystemExit(0 if all(v for _,v in rows) else 2)
