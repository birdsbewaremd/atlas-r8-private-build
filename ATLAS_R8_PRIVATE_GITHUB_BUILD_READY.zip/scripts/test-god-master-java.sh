#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)";trap 'rm -rf "$TMP"' EXIT
javac -d "$TMP" "$ROOT/app/src/main/java/com/sbh/atlasos/GodPrivateIndexPolicy.java" "$ROOT/app/src/test/java/com/sbh/atlasos/GodPrivateIndexPolicyTest.java"
if [[ -n "${ATLAS_GOD_PRIVATE_INDEX_JSON:-}" && -f "${ATLAS_GOD_PRIVATE_INDEX_JSON}" ]]; then
  java -cp "$TMP" com.sbh.atlasos.GodPrivateIndexPolicyTest "$ATLAS_GOD_PRIVATE_INDEX_JSON"
else
  java -cp "$TMP" com.sbh.atlasos.GodPrivateIndexPolicyTest
  echo "GOD_PINNED_PRIVATE_IMPORT_POSITIVE=NOT_RUN (provide owner-local ATLAS_GOD_PRIVATE_INDEX_JSON)"
fi
