#!/usr/bin/env python3
"""Wake generation anti-restart regression; real pure-Java class and service wiring checks.
Does not exercise Android microphones, OS service lifecycle or phone permissions.
"""
from pathlib import Path
import subprocess, tempfile, re
R=Path(__file__).resolve().parents[1]
wake=(R/'app/src/main/java/com/sbh/atlasos/AtlasWakeService.java').read_text()
main=(R/'app/src/main/java/com/sbh/atlasos/MainActivity.java').read_text()
checks={
 'only explicit ARM accepted': bool(re.search(r'if\(intent==null\|\|!ACTION_ARM\.equals\(intent\.getAction\(\)\)',wake)),
 'STOP remains permitted without authentication': wake.index('if(intent!=null&&ACTION_STOP.equals(intent.getAction()))') < wake.index('!wakePermit.arm(OwnerSessionGate.capture(this))'),
 'android service never sticky-restarts': 'START_STICKY' not in wake and wake.count('return START_NOT_STICKY;')>=3,
 'permission checks at start and retry': bool(re.search(r'private void startListening\(\)\{.*?if\(!hasWakeAuthority\(\)\)return;',wake,re.S)) and 'if(!hasWakeAuthority())return;\n    listening=false;' in wake,
 'owner check before final transcript/broadcast': bool(re.search(r'private boolean inspectFinal\(Bundle bundle\)\{\s*if\(!hasWakeAuthority\(\)\)return false;',wake)),
 'owner check before partial transcript': bool(re.search(r'private boolean inspectPartial\(Bundle bundle\)\{\s*if\(!hasWakeAuthority\(\)\)return false;',wake)),
 'owner check before results/retry': 'public void onResults(Bundle results){\n    if(!hasWakeAuthority())return;' in wake and 'public void onError(int error){\n    if(!hasWakeAuthority())return;' in wake,
 'revokes permit on service stop': 'wakePermit.revoke();' in wake,
 'activity starts with ARM and owner gate': 'setAction(AtlasWakeService.ACTION_ARM)' in main and bool(re.search(r'private void startWakeService\(boolean announce\)\{\s*if\(!ownerRequired\(\)\)return;',main)),
 'build source gate runs this test': 'test-wake-session.py' in (R/'scripts/build-debug.sh').read_text(),
 'watchdog checks expired owner without transcript callbacks': 'OWNER_WATCHDOG_MS=2000L' in wake and 'handler.postDelayed(ownerWatchdog,OWNER_WATCHDOG_MS);' in wake and 'handler.removeCallbacks(ownerWatchdog);' in wake and 'if(hasWakeAuthority())handler.postDelayed(this,OWNER_WATCHDOG_MS);' in wake,
}
for n,ok in checks.items():print(('PASS' if ok else 'FAIL')+' SERVICE '+n)
assert all(checks.values()),'Wake service integration regression failed'
java_source=r"""import com.sbh.atlasos.WakeSessionPolicy;
public final class WakeSessionCheck {
 static int checks=0;
 static void check(String name, boolean outcome){ checks++; if(!outcome)throw new AssertionError(name); System.out.println("PASS SESSION "+name); }
 public static void main(String[] args){
   WakeSessionPolicy gate=new WakeSessionPolicy();
   check("starts disarmed",!gate.mayListen(1));
   check("zero rejected",!gate.arm(0));
   check("negative rejected",!gate.arm(-1));
   check("positive generation can arm",gate.arm(101));
   check("current generation can listen",gate.mayListen(101));
   check("cannot silently rearm across sessions",!gate.arm(102));
   check("different generation denied",!gate.mayListen(102));
   check("zero current generation denied",!gate.mayListen(0));
   check("negative current generation denied",!gate.mayListen(-4));
   gate.revoke();check("stop revokes permit",!gate.mayListen(101));
   check("new owner session can arm",gate.arm(102));
   check("previous owner generation denied",!gate.mayListen(101));
   check("second owner generation valid",gate.mayListen(102));
   check("failed rearm clears earlier owner",!gate.arm(0)&&!gate.mayListen(102));
   check("restart without arm denied",!gate.mayListen(102));
   gate.arm(Long.MAX_VALUE);check("max generation valid",gate.mayListen(Long.MAX_VALUE));
   gate.revoke();check("revocation terminal until new arm",!gate.mayListen(Long.MAX_VALUE));
   System.out.println("WAKE_SESSION_JAVA="+checks+"/"+checks+" PASS");
 }
}"""
with tempfile.TemporaryDirectory(prefix='atlas-wake-') as t:
    test=Path(t)/'WakeSessionCheck.java';test.write_text(java_source)
    subprocess.run(['javac','-d',t,str(R/'app/src/main/java/com/sbh/atlasos/WakeSessionPolicy.java'),str(test)],check=True)
    subprocess.run(['java','-cp',t,'WakeSessionCheck'],check=True)
print(f'WAKE_SERVICE_WIRING={sum(checks.values())}/{len(checks)} PASS (source integration only)')
