#!/usr/bin/env python3
"""Offline source/receipt consistency check. NEVER authorizes installation or release.

Human approval and genuine on-device attestation must be checked outside this script.
It intentionally returns a nonzero code even when all supplied receipts appear
consistent. No network, device, credentials, publishing, or file mutations.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys

SCHEMA = "atlas.release-evidence.v1"
EXPECTED_APP_ID = "com.sbh.atlasos.candidate"
MAX_APK_BYTES = 80 * 1024 * 1024
MAX_RECEIPT_BYTES = 512 * 1024
REQUIRED_CHECKS = {
    "android_native_build": "NATIVE",
    "android_lint": "NATIVE",
    "apk_package_identity": "NATIVE",
    "apk_signature": "NATIVE",
    "foreground_owner_auth": "DEVICE",
    "pause_wake_microphone_stop": "DEVICE",
    "device_keystore": "DEVICE",
    "encrypted_backup_restore": "DEVICE",
    "fifty_two_case_acceptance": "DEVICE",
}

class GateError(ValueError):
    pass

def no_duplicate_keys(pairs):
    found = {}
    for key, value in pairs:
        if key in found:
            raise GateError("duplicate_json_key")
        found[key] = value
    return found

def safe_relative(name):
    if not isinstance(name, str) or not name or '\\' in name or ':' in name:
        raise GateError("bad_relative_path")
    p = PurePosixPath(name)
    if p.is_absolute() or p.as_posix() != name or any(s in ('', '.', '..') for s in p.parts):
        raise GateError("bad_relative_path")
    if any(ord(c) < 32 for c in name):
        raise GateError("bad_relative_path")
    return p

def read_checked(root: Path, name: str, maximum: int) -> bytes:
    p = root
    for part in safe_relative(name).parts:
        p = p / part
        if p.is_symlink():
            raise GateError("symlink_path")
    try:
        info = p.stat()
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > maximum:
            raise GateError("unsafe_or_large_file")
        with p.open('rb') as f:
            data = f.read(maximum + 1)
        if len(data) > maximum:
            raise GateError("unsafe_or_large_file")
        return data
    except OSError as exc:
        raise GateError("missing_or_unreadable_file") from exc

def parse_json(raw: bytes):
    try:
        obj = json.loads(raw.decode('utf-8'),object_pairs_hook=no_duplicate_keys)
        if not isinstance(obj,dict):
            raise GateError('bad_json_object')
        return obj
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise GateError('invalid_json') from exc

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def is_digest(value):
    return (isinstance(value,str) and len(value)==64
            and all(c in '0123456789abcdef' for c in value))

def review(root: Path, evidence_rel: str, apk_rel: str, manifest_rel='PACKAGE_MANIFEST.json') -> dict:
    """Read-only validation. Complete fixture means REVIEW REQUIRED, never APPROVED."""
    issues=[]
    def add(label):
        if label not in issues: issues.append(label)
    if root.is_symlink() or not root.is_dir():
        return {'verdict':'BLOCKED','release_authorization':'DENIED','issues':['unsafe_root']}
    root=root.resolve()
    try:
        evidence=parse_json(read_checked(root,evidence_rel,MAX_RECEIPT_BYTES))
    except GateError as e:
        return {'verdict':'BLOCKED','release_authorization':'DENIED','issues':[str(e)]}
    if evidence.get('schema') != SCHEMA: add('schema_mismatch')
    if evidence.get('app_id') != EXPECTED_APP_ID: add('app_identity_mismatch')
    if evidence.get('release_authorized') is not False: add('unexpected_release_authorization')
    if evidence.get('network_or_external_sends_enabled') is not False: add('unexpected_external_action')
    source_hash=evidence.get('source_manifest_sha256')
    apk_hash=evidence.get('apk_sha256')
    if not is_digest(source_hash): add('source_manifest_digest_invalid')
    if not is_digest(apk_hash): add('apk_digest_invalid')
    try:
        actual=sha256(read_checked(root,manifest_rel,MAX_RECEIPT_BYTES))
        if is_digest(source_hash) and source_hash!=actual: add('source_manifest_mismatch')
    except GateError as e: add('manifest_'+str(e))
    try:
        actual=sha256(read_checked(root,apk_rel,MAX_APK_BYTES))
        if is_digest(apk_hash) and apk_hash!=actual: add('apk_digest_mismatch')
    except GateError as e: add('apk_'+str(e))
    checks=evidence.get('checks')
    if not isinstance(checks,list) or len(checks)!=len(REQUIRED_CHECKS):
        add('required_checks_missing_or_extra')
        checks=checks if isinstance(checks,list) and len(checks)<=64 else []
    seen=set()
    for c in checks:
        if not isinstance(c,dict):
            add('malformed_check'); continue
        name=c.get('name')
        if not isinstance(name,str) or name not in REQUIRED_CHECKS:
            add('unknown_check'); continue
        if name in seen: add('duplicate_check'); continue
        seen.add(name)
        if c.get('status')!='PASS': add('check_not_passed')
        if c.get('proof_scope')!=REQUIRED_CHECKS[name]: add('wrong_proof_scope')
        digest=c.get('receipt_sha256')
        if not is_digest(digest): add('receipt_digest_invalid')
        try:
            receipt=read_checked(root,c.get('receipt_path'),MAX_RECEIPT_BYTES)
            if is_digest(digest) and sha256(receipt)!=digest: add('receipt_digest_mismatch')
        except GateError as e: add('receipt_'+str(e))
    if seen != set(REQUIRED_CHECKS): add('required_checks_missing_or_extra')
    if issues:
        return {'verdict':'BLOCKED','release_authorization':'DENIED','issues':sorted(issues)}
    return {'verdict':'EVIDENCE_CONSISTENT_REVIEW_REQUIRED',
            'release_authorization':'DENIED',
            'issues':['independent_device_attestation_and_owner_approval_not_verified']}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    p.add_argument('--evidence',default='test-output/release-evidence.json')
    p.add_argument('--apk',default='app/build/outputs/apk/debug/app-debug.apk')
    p.add_argument('--manifest',default='PACKAGE_MANIFEST.json')
    a=p.parse_args()
    result=review(a.root,a.evidence,a.apk,a.manifest)
    print(json.dumps(result,sort_keys=True))
    return 11 if result['verdict']=='EVIDENCE_CONSISTENT_REVIEW_REQUIRED' else 10

if __name__=='__main__':
    sys.exit(main())
