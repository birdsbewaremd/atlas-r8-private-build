#!/usr/bin/env python3
"""Compare the Java port with the recovered Python reference, offline.

Requires ATLAS_REFERENCE_ROOT prepared from the bundled original candidate,
Python's reference dependencies, and a JDK. No Android emulation or APK claim.
"""
from __future__ import annotations
import json, os, pathlib, subprocess, sys, tempfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
REF=pathlib.Path(os.environ['ATLAS_REFERENCE_ROOT']).resolve()
if not (REF/'src/atlas_core/human_learning.py').is_file():
    raise SystemExit('Prepare the pinned Python reference first; see README.md.')
sys.path.insert(0,str(REF/'src'))
from atlas_core.human_learning import CommunicationPreferences, ProgressUpdate, render_update, recognize_command, LESSONS
OUT=pathlib.Path(os.environ.get('ATLAS_TEST_OUTPUT',ROOT/'test-output'));OUT.mkdir(parents=True,exist_ok=True)
statements=[];fixtures=[]
def lit(x: str)->str:return json.dumps(x,ensure_ascii=True)
def add(name: str,expression: str,expected: str|None)->None:
    fixtures.append({'case':name,'expected':expected})
    want='null' if expected is None else lit(expected)
    statements.append(f'check({lit(name)}, {expression}, {want});')
for detail in ('brief','standard','detailed'):
    for status in ('completed','staged','blocked','unknown'):
        u=ProgressUpdate(status=status,outcome='Synthetic result.',next_action='Review this example.',
            evidence_refs=('Fixture receipt 01',),details=('Detail one','Detail two','Detail three'),
            blockers=('Device acceptance is not run.',),warnings=('Do not claim deployment.',),deadline='Synthetic deadline')
        java=(f'HumanLearningEngine.renderUpdate(new HumanLearningEngine.Preferences({lit(detail)},true,"optional"),'
              f'{lit(status)},"Synthetic result.","Review this example.",'
              'Arrays.asList("Fixture receipt 01"),Arrays.asList("Detail one","Detail two","Detail three"),'
              'Arrays.asList("Device acceptance is not run."),Arrays.asList("Do not claim deployment."),"Synthetic deadline")')
        add(f'render {detail}/{status}',java,render_update(u,CommunicationPreferences(detail=detail)))
for lesson_id,lesson in LESSONS.items():
    for field in ('goal','explain','example','practice','answer','retry'):
        add(f'lesson {lesson_id}/{field}',f'HumanLearningEngine.LESSONS.get({lit(lesson_id)}).{field}',lesson[field])
for text in ('atlas deep sync','Atlas deep sink','atlas deep sync everything',
             'ATLAS DEEP SINK EVERYTHING!!!','atlas red team forge','atlas red team forged',
             'do it','handle it','draft only','do not execute','do it and spend $100',
             '"do it"','send to Another Person',' \tAtlas  deep\nsink everything.  '):
    add(f'alias {text!r}',f'HumanLearningEngine.recognize({lit(text)})',recognize_command(text).intent)
source='''package com.sbh.atlasos;
import java.util.*;
public final class LearningContractTest {
 static int count=0;
 static void check(String name,Object got,Object expected){
   if(!Objects.equals(got,expected))throw new AssertionError(name+" differs from Python reference");
   count++;System.out.println("PASS "+name);
 }
 public static void main(String[] args)throws Exception{
'''+ '\n'.join(statements) + '''
 System.out.println("LEARNING_CONTRACT="+count+"/"+count+" PASS");
 }
}
'''
with tempfile.TemporaryDirectory(prefix='atlas-contract-') as td:
    base=pathlib.Path(td);java=base/'LearningContractTest.java';java.write_text(source)
    subprocess.run(['javac','-d',str(base),str(ROOT/'app/src/main/java/com/sbh/atlasos/HumanLearningEngine.java'),str(java)],check=True)
    run=subprocess.run(['java','-cp',str(base),'com.sbh.atlasos.LearningContractTest'],capture_output=True,text=True)
    (OUT/'learning-contract-console.txt').write_text(run.stdout+run.stderr)
    (OUT/'learning-contract-fixtures.json').write_text(json.dumps(fixtures,indent=2)+'\n')
    (OUT/'learning-contract-results.json').write_text(json.dumps({'cases':len(fixtures),'returncode':run.returncode,'passed':len(fixtures) if run.returncode==0 else None,'scope':'Bounded renderer/lesson/English-alias Java-to-Python parity; not storage, identity, Android or full Unicode equivalence.'},indent=2)+'\n')
    print(run.stdout,end='');print(run.stderr,end='',file=sys.stderr)
    raise SystemExit(run.returncode)
