#!/usr/bin/env python3
"""Offline source-level reconciliation/evidence assertions. NOT device/runtime proofs."""
from __future__ import annotations
from pathlib import Path
import json
import re
import sys
ROOT=Path(__file__).resolve().parents[1]
results=[]
def check(label, condition):
    results.append((label,bool(condition)))
    print(('PASS' if condition else 'FAIL')+' OMEGA '+label)

def read(path): return (ROOT/path).read_text(encoding='utf-8')

state=json.loads(read('BUILD_STATE.json'))
version=read('app/build.gradle')
app=read('app/src/main/assets/www/app.js')
main=read('app/src/main/java/com/sbh/atlasos/MainActivity.java')
manifest=read('app/src/main/AndroidManifest.xml')
worker=read('app/src/main/assets/www/sw.js')
index=read('app/src/main/assets/www/index.html')
build=read('scripts/build-debug.sh')
data=read('app/src/main/assets/www/safe-for-later-data.js')
pol=read('app/src/main/java/com/sbh/atlasos/StorageImportPolicy.java')
ledger=json.loads(read('research/ATLAS_OMEGA_COMPLAINT_LEDGER_2026-10-10.json'))
check('Version code/name consistent', state['version_code']==33 and state['version_name']=='0.4.1-first-run-preview' and "versionCode 33; versionName '0.4.1-first-run-preview'" in version and state['atlas_one_parent']['version_code']==31 and state['atlas_one_parent']['version_name']=='0.3.8-rc2-omega2-wakeguard1-appctx1-godv4')
check('Candidate not falsely marked deployed',state['canonical'] is False and state['apk_compiled'] is False and state['device_tested'] is False)
check('Internet/unrestricted filesystem permissions absent',all(x not in manifest for x in ('android.permission.INTERNET','android.permission.MANAGE_EXTERNAL_STORAGE','android.permission.READ_EXTERNAL_STORAGE','android.permission.WRITE_EXTERNAL_STORAGE')))
check('Network loads blocked, no background omnipotent permission', 'setBlockNetworkLoads(true)' in main and 'Intent.FLAG_GRANT_WRITE_URI_PERMISSION' not in main)
check('Owner-authorized confirmation before document import', 'if(!ownerRequired()){toast("Unlock Atlas OS first");return;}' in main and 'Confirm private document import' in main and 'if(!ownerRequired())throw new IOException("owner session ended")' in main)
check('Document bytes and disk reserve bounded', 'MAX_DOCUMENT_BYTES = 8L * 1024L * 1024L' in pol and 'MIN_FREE_HEADROOM_BYTES = 16L * 1024L * 1024L' in pol)
check('Owner-only Storage UI and no unlimited assertion', "if(id==='storage')return storageApp();" in app and "'storage'" in app[app.index('ownerOnly=new Set('):app.index('ownerOnly=new Set(')+250] and 'capacity is not unlimited' in app)
check('Safe for Later v0.3.4 untouched', data.startswith('/* Generated from ATLAS Safe for Later v0.3.4 metadata-only index.') and 'safe-for-later.css?v=4' in index)
check('Safe for Later exactly 29 metadata items',len(json.loads(re.search(r'Object\.freeze\((\[.*\])\);\s*$',data,re.S).group(1)))==29)
check('Current cache includes Files Search/Human Learning/Storage shell', 'atlas-phone-2026-10-10-omega2' in worker and all(n in worker for n in ('file-search.js','file-search.css','human-learning.js','human-learning.css','safe-for-later-data.js')) and 'storageApp' in app)
check('Unified6 Files UI and pinned-reference gates preserved',all(n in build for n in ('test-file-search-ui.py','ATLAS_REFERENCE_ROOT','REFERENCE_LEARNING_GATES=NOT_RUN','test-human-learning-java.sh','test-learning-contract.py')))
check('Storage1 Omega AND private-UI regressions wired into build',all(n in build for n in ('test-storage-source.py','test-storage-ui.py','test-java-syntax.sh','test-omega-merge.py','test-private-ui-storage.py')))
check('Research ledger 20 unique entries with allowed evidence classes',len(ledger['issues'])==20 and len({i['id'] for i in ledger['issues']})==20 and all(i['evidence_class'] and i['implementation_state'] and i['priority'] for i in ledger['issues']))
check('All research-linked sources exist and use HTTPS',all(k in ledger['sources'] and ledger['sources'][k].startswith('https://') for i in ledger['issues'] for k in i['source_ids']))
check('No untested competitor claims converted to measured wins',all(i['competitive_win']=='NOT_TESTED' for i in ledger['issues']) and ledger['verification_rules']['competitor_benchmarks']=='NOT_RUN')
check('No local LLM deployment, backup or real device acceptance falsely claimed', all(ledger['verification_rules'][x]=='NOT_RUN' for x in ('native_android','s20_ultra_device','real_offline_llm')))
check('Owner security policy classes maintained',all((ROOT/'app/src/main/java/com/sbh/atlasos'/p).is_file() for p in ('ExternalActionPolicy.java','UntrustedContentPolicy.java','ActionAuthorizationPolicy.java','ExternalTargetPolicy.java')))
print(f'OMEGA_SOURCE_GATES={sum(ok for _,ok in results)}/{len(results)} '+('PASS' if all(ok for _,ok in results) else 'FAIL'))
sys.exit(0 if all(ok for _,ok in results) else 2)
