#!/usr/bin/env python3
"""Compiles the real R7 Java launcher with minimal Android *stubs* on this host.
This is a compile/type smoke test, NOT an Android SDK build or device test.
"""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
stubs={
 'android/content/Context.java': '''package android.content;
public class Context {
 public static final String LAUNCHER_APPS_SERVICE="launcherapps",ROLE_SERVICE="role";
 public static final int MODE_PRIVATE=0;
 public Object getSystemService(String n){return null;}
 public android.content.pm.PackageManager getPackageManager(){return null;}
 public android.content.res.Resources getResources(){return null;}
 public SharedPreferences getSharedPreferences(String n,int m){return null;}
 public void startActivity(Intent i){}
 }''',
 'android/content/Intent.java':'''package android.content;
public class Intent {
 public static final String ACTION_MAIN="main",ACTION_DIAL="dial",ACTION_VIEW="view",CATEGORY_LAUNCHER="launcher",CATEGORY_APP_MESSAGING="messaging";
 public static final int FLAG_ACTIVITY_NEW_TASK=1,FLAG_ACTIVITY_RESET_TASK_IF_NEEDED=2;
 public Intent(String s){} public Intent(String s,android.net.Uri u){} public Intent(Context ctx,Class<?> c){}
 public Intent addCategory(String s){return this;}public Intent setComponent(ComponentName c){return this;}
 public Intent addFlags(int i){return this;}
 public static Intent makeMainSelectorActivity(String s,String c){return new Intent(s);}
 }''',
 'android/content/ComponentName.java':'''package android.content;
public class ComponentName {
 public ComponentName(String p,String c){} public String flattenToString(){return "";}public String getClassName(){return "";}public String getPackageName(){return "";}
 }''',
 'android/content/ActivityNotFoundException.java':'package android.content;public class ActivityNotFoundException extends RuntimeException{}',
 'android/content/SharedPreferences.java':'''package android.content;import java.util.*;
public interface SharedPreferences{Set<String> getStringSet(String s,Set<String> fallback);Editor edit();interface Editor{Editor putStringSet(String s,Set<String> val);void apply();}}''',
 'android/content/pm/LauncherActivityInfo.java':'''package android.content.pm;
public class LauncherActivityInfo{
 public android.content.ComponentName getComponentName(){return null;}public CharSequence getLabel(){return "";}
 public android.graphics.drawable.Drawable getIcon(int d){return null;}}''',
 'android/content/pm/LauncherApps.java':'''package android.content.pm;import java.util.*;
public class LauncherApps{
 public List<android.os.UserHandle> getProfiles(){return null;}
 public List<LauncherActivityInfo> getActivityList(String pkg,android.os.UserHandle u){return null;}
 public void startMainActivity(android.content.ComponentName c,android.os.UserHandle u,android.graphics.Rect rect,android.os.Bundle b){}
 }''',
 'android/content/pm/PackageManager.java':'''package android.content.pm;import java.util.*;
public class PackageManager{public List<ResolveInfo> queryIntentActivities(android.content.Intent i,int flags){return null;}}''',
 'android/content/pm/ResolveInfo.java':'''package android.content.pm;
public class ResolveInfo{public ActivityInfo activityInfo;
public CharSequence loadLabel(PackageManager p){return "";}public android.graphics.drawable.Drawable loadIcon(PackageManager p){return null;}}''',
 'android/content/pm/ActivityInfo.java':'package android.content.pm;public class ActivityInfo{public String name,packageName;public boolean enabled,exported;}',
 'android/app/Activity.java':'''package android.app;
public class Activity extends android.content.Context{
 protected void onCreate(android.os.Bundle b){}protected void onResume(){}
 public void onBackPressed(){}
 public android.view.Window getWindow(){return null;}
 public void setContentView(android.view.View v){}
 }''',
 'android/app/role/RoleManager.java':'''package android.app.role;
public class RoleManager {public static final String ROLE_HOME="home";
public boolean isRoleAvailable(String s){return false;}public boolean isRoleHeld(String s){return false;}
public android.content.Intent createRequestRoleIntent(String s){return null;}}''',
 'android/os/Bundle.java':'package android.os;public class Bundle{}',
 'android/os/UserHandle.java':'package android.os;public class UserHandle{}',
 'android/os/Process.java':'package android.os;public class Process{public static UserHandle myUserHandle(){return null;}}',
 'android/os/UserManager.java':'package android.os;public class UserManager{}',
 'android/os/Build.java':'package android.os;public class Build{public static final class VERSION{public static int SDK_INT=33;}}',
 'android/net/Uri.java':'package android.net;public class Uri{}',
 'android/provider/MediaStore.java':'package android.provider;public class MediaStore{public static final String INTENT_ACTION_STILL_IMAGE_CAMERA="camera";}',
 'android/provider/ContactsContract.java':'''package android.provider;public class ContactsContract{public static class Contacts{public static final android.net.Uri CONTENT_URI=null;}}''',
 'android/provider/Settings.java':'''package android.provider;public class Settings{public static final String ACTION_SETTINGS="settings",ACTION_HOME_SETTINGS="home",ACTION_WALLPAPER_SETTINGS="wallpaper";}''',
 'android/content/res/Resources.java':'''package android.content.res;public class Resources{public android.util.DisplayMetrics getDisplayMetrics(){return null;}}''',
 'android/util/DisplayMetrics.java':'package android.util;public class DisplayMetrics{public float density=1f;}',
 'android/graphics/Color.java':'''package android.graphics;public class Color{public static final int WHITE=0xffffffff,TRANSPARENT=0;
 public static int rgb(int r,int g,int b){return 0;}}''',
 'android/graphics/Typeface.java':'package android.graphics;public class Typeface{public static final Typeface DEFAULT=null;public static final int BOLD=1;}',
 'android/graphics/Rect.java':'package android.graphics;public class Rect{}',
 'android/graphics/drawable/Drawable.java':'package android.graphics.drawable;public class Drawable{}',
 'android/graphics/drawable/GradientDrawable.java':'''package android.graphics.drawable;public class GradientDrawable extends Drawable{
 public enum Orientation{TL_BR}public GradientDrawable(){}public GradientDrawable(Orientation o,int[] colors){}
 public void setColor(int c){}public void setCornerRadius(float radius){}
 }''',
 'android/view/View.java':'''package android.view;
public class View{
 public View(android.content.Context c){}
 public interface OnClickListener{void onClick(View v);}
 public void setOnClickListener(OnClickListener l){}
 public void setBackground(android.graphics.drawable.Drawable d){}public void setPadding(int a,int b,int c,int d){}
 public void setContentDescription(CharSequence s){}public void setTag(Object v){}
 }''',
 'android/view/ViewGroup.java':'''package android.view;public class ViewGroup extends View{
 public ViewGroup(android.content.Context c){super(c);}
 public static class LayoutParams{public LayoutParams(int a,int b){}public static final int MATCH_PARENT=-1,WRAP_CONTENT=-2;}
 }''',
 'android/view/Window.java':'package android.view;public class Window{public void setStatusBarColor(int c){}public void setNavigationBarColor(int c){}}',
 'android/view/Gravity.java':'package android.view;public class Gravity{public static final int CENTER_VERTICAL=1;}',
 'android/widget/LinearLayout.java':'''package android.widget;public class LinearLayout extends android.view.ViewGroup{
 public static final int VERTICAL=1,HORIZONTAL=0;
 public LinearLayout(android.content.Context c){super(c);}public void setOrientation(int i){}public void setGravity(int i){}
 public void addView(android.view.View v){}public void addView(android.view.View v,android.view.ViewGroup.LayoutParams p){}public void removeAllViews(){}
 public static class LayoutParams extends android.view.ViewGroup.LayoutParams {
 public int rightMargin;public LayoutParams(int w,int h){super(w,h);}public LayoutParams(int w,int h,float f){super(w,h);}
 }
 }''',
 'android/widget/TextView.java':'''package android.widget;public class TextView extends android.view.View{
 public TextView(android.content.Context c){super(c);}
 public void setText(CharSequence c){}public void setTextSize(float f){}public void setTextColor(int c){}
 public void setTypeface(android.graphics.Typeface f,int s){}public void setIncludeFontPadding(boolean b){}
 public void setHint(CharSequence c){}public void setHintTextColor(int c){}
 }''',
 'android/widget/Button.java':'''package android.widget;public class Button extends TextView{
 public Button(android.content.Context c){super(c);}public void setAllCaps(boolean b){}public void setMinHeight(int h){}
 }''',
 'android/widget/ImageView.java':'''package android.widget;public class ImageView extends android.view.View{
 public ImageView(android.content.Context c){super(c);}public void setImageDrawable(android.graphics.drawable.Drawable d){}
 }''',
 'android/widget/ScrollView.java':'''package android.widget;public class ScrollView extends android.view.ViewGroup{
 public ScrollView(android.content.Context c){super(c);}public void setFillViewport(boolean b){}public void addView(android.view.View v){}
 }''',
 'android/widget/AdapterView.java':'''package android.widget;
public class AdapterView<T> extends android.view.ViewGroup {
 public AdapterView(android.content.Context c){super(c);}
 public interface OnItemClickListener{void onItemClick(AdapterView<?> p,android.view.View v,int position,long id);}
 public interface OnItemLongClickListener{boolean onItemLongClick(AdapterView<?> p,android.view.View v,int position,long id);}
 }''',
 'android/widget/ListView.java':'''package android.widget;
public class ListView extends AdapterView<BaseAdapter>{
 public ListView(android.content.Context c){super(c);}
 public void setDividerHeight(int h){}public void setBackgroundColor(int c){}public void setCacheColorHint(int c){}
 public void setAdapter(BaseAdapter a){}public void setOnItemClickListener(OnItemClickListener l){}public void setOnItemLongClickListener(OnItemLongClickListener l){}
 }''',
 'android/widget/BaseAdapter.java':'''package android.widget;
public abstract class BaseAdapter {
 public abstract int getCount();public abstract Object getItem(int position);public abstract long getItemId(int position);
 public abstract android.view.View getView(int p,android.view.View reuse,android.view.ViewGroup parent);
 public void notifyDataSetChanged(){}
 }''',
 'android/widget/EditText.java':'''package android.widget;
public class EditText extends TextView{
 public EditText(android.content.Context c){super(c);}public void setSingleLine(boolean b){}
 public void addTextChangedListener(android.text.TextWatcher watcher){}public android.text.Editable getText(){return null;}
 }''',
 'android/widget/Toast.java':'''package android.widget;public class Toast{
 public static final int LENGTH_SHORT=0;
 public static Toast makeText(android.content.Context c,CharSequence s,int len){return new Toast();}
 public void show(){} }''',
 'android/text/Editable.java':'package android.text;public interface Editable extends CharSequence{}',
 'android/text/TextWatcher.java':'''package android.text;public interface TextWatcher{
 void beforeTextChanged(CharSequence s,int start,int count,int after);
 void onTextChanged(CharSequence s,int start,int before,int count);
 void afterTextChanged(Editable e);
 }''',
 'com/sbh/atlasos/MainActivity.java':'package com.sbh.atlasos;public class MainActivity extends android.app.Activity{}',
 'com/sbh/atlasos/AtlasAccessCenterActivity.java':'package com.sbh.atlasos; public class AtlasAccessCenterActivity extends android.app.Activity{}',
}
with tempfile.TemporaryDirectory(prefix='atlas-r7-host-javac-') as t:
    d=Path(t);java=[]
    for name,body in stubs.items():
        f=d/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(body);java.append(str(f))
    java.append(str(root/'app/src/main/java/com/sbh/atlasos/AtlasLauncherActivity.java'))
    args=['javac','-encoding','UTF-8','-Xlint:none','-d',str(d/'classes'),*java]
    r=subprocess.run(args,text=True,capture_output=True)
    print('R8_LAUNCHER_HOST_STUB_COMPILE '+('PASS' if r.returncode==0 else 'FAIL'))
    print(r.stderr[:5000])
    if r.returncode:
        raise SystemExit(r.returncode)
