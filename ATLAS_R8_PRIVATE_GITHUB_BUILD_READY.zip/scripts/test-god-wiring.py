#!/usr/bin/env python3
"""ATLAS GOD V3 source-wiring assertions, not a substitute for Android runtime tests."""
from pathlib import Path
import re,sys
R=Path(__file__).resolve().parents[1]
java=(R/'app/src/main/java/com/sbh/atlasos').resolve()
main=(java/'MainActivity.java').read_text()
auth=(java/'AuthenticatedInputRouter.java').read_text()
god=(java/'GodCommandPolicy.java').read_text()
manifest=(R/'app/src/main/AndroidManifest.xml').read_text()
checks={
 'classifier grants no authority': 'authorityGranted = false' in god,
 'classifier has no Android imports': 'import android.' not in god,
 'classifier never executes local Android router': 'CommandRouter.run' not in god,
 'locked state precedes GOD': auth.index('if (!authenticated)') < auth.index('GodCommandPolicy.Result god'),
 'untrusted source state precedes GOD': auth.index('WorkflowIntentParser.State.SOURCE_DATA') < auth.index('GodCommandPolicy.Result god'),
 'invalid state precedes GOD': auth.index('WorkflowIntentParser.State.INVALID') < auth.index('GodCommandPolicy.Result god'),
 'GOD intercept precedes local device action': auth.index('GodCommandPolicy.Result god') < auth.index('if (local.kind != CommandParser.Kind.UNKNOWN)'),
 'GOD routes only to brain': bool(re.search(r'if \(god\.activated\)\s*\{[\s\S]*?Route\.BRAIN_HANDOFF',auth)),
 'GOD cannot declare local execution eligible': 'true, false, true, backendConnected, false' in auth,
 'GOD cannot self-authorize writes': 'model_cannot_self_authorize_external_actions' in auth,
 'GOD cannot self-authorize physical control': 'god_has_no_local_device_or_physical_authority' in auth,
 'GOD JNI-level route remains authenticated': 'OwnerSessionGate.isActive(this)' in main and 'AuthenticatedInputRouter.route(' in main,
 'GOD metadata exposes no authority': 'godMode.put("authorityGranted",false)' in main and 'godMode.put("isExecution",false)' in main,
 'locked and reference origins cannot show GOD': 'routed.authenticated' in main and 'routed.origin != WorkflowIntentParser.Origin.REFERENCE_DATA' in main,
 'GOD runtime disconnected status is honest': 'GOD V3 recognized your command. The private ATLAS brain is disconnected; no work was performed.' in main,
 'no Internet permission introduced': 'android.permission.INTERNET' not in manifest,
 'no new app privileges introduced': 'MANAGE_EXTERNAL_STORAGE' not in manifest and 'BIND_ACCESSIBILITY_SERVICE' not in manifest,
 'standard Java suite invokes GOD tests': 'GodCommandPolicyTest' in (R/'scripts/test-pure-java.sh').read_text(),
}
for k,v in checks.items():print(('PASS' if v else 'FAIL')+' GOD '+k)
print(f'GOD_WIRING={sum(checks.values())}/{len(checks)} '+('PASS' if all(checks.values()) else 'FAIL'))
sys.exit(0 if all(checks.values()) else 2)
