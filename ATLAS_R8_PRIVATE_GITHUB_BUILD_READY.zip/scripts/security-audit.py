#!/usr/bin/env python3
"""Fail-closed static security audit for the disconnected ATLAS Android candidate.

This is a source tripwire, not a security certification. It checks that dangerous
capabilities are absent or explicitly constrained before native compilation.
"""
from __future__ import annotations
import json, re, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MANIFEST=ROOT/'app/src/main/AndroidManifest.xml'
JAVA_ROOT=ROOT/'app/src/main/java'
WEB_ROOT=ROOT/'app/src/main/assets/www'

def read(p:Path)->str: return p.read_text(encoding='utf-8',errors='replace')
def all_text(root:Path,suffixes:set[str])->str:
    return '\n'.join(read(p) for p in sorted(root.rglob('*')) if p.is_file() and p.suffix in suffixes)

def audit()->dict:
    manifest=read(MANIFEST)
    java=all_text(JAVA_ROOT,{'.java'})
    web=all_text(WEB_ROOT,{'.js','.html','.css','.md'})
    main=read(JAVA_ROOT/'com/sbh/atlasos/MainActivity.java')
    rows=[]
    def check(name,ok,detail): rows.append({'name':name,'ok':bool(ok),'detail':detail})

    check('android_backup_disabled','android:allowBackup="false"' in manifest,'Application backup must remain disabled for private vault state.')
    check('cleartext_disabled','android:usesCleartextTraffic="false"' in manifest,'Cleartext transport must remain disabled.')
    check('internet_permission_absent_while_backend_disconnected','android.permission.INTERNET' not in manifest,'Disconnected candidate has no in-app network permission; external sites open through the user browser.')
    check('webview_debugging_disabled','setWebContentsDebuggingEnabled(false)' in main and 'setWebContentsDebuggingEnabled(true)' not in main,'WebView remote debugging must be off.')
    check('webview_file_access_disabled','setAllowFileAccess(false)' in main and 'setAllowContentAccess(false)' in main and 'setAllowUniversalAccessFromFileURLs(false)' in main,'Local web UI cannot browse arbitrary files/content providers or bridge file origins to network origins.')
    check('external_navigation_exact_allowlist','ExternalTargetPolicy.isExactTargetAllowed(raw,SAFE_EXTERNAL_URLS)' in main and 'ExternalTargetPolicy.isExactTargetAllowed(u,SAFE_EXTERNAL_URLS)' in main,'Both WebView navigation and JS openUrl use the exact HTTPS allowlist.')
    check('external_navigation_owner_gated','if(!ownerRequired()){ toast("Unlock Atlas OS first"); return true; }' in main and 'if(!ownerRequired()){ toast("Unlock Atlas OS first"); return; }' in main,'External navigation from the private UI requires the native owner session.')

    forbidden_permissions=[
      'android.permission.SEND_SMS','android.permission.READ_SMS','android.permission.CALL_PHONE',
      'android.permission.READ_CONTACTS','android.permission.WRITE_CONTACTS',
      'android.permission.ACCESS_FINE_LOCATION','android.permission.ACCESS_COARSE_LOCATION',
      'android.permission.REQUEST_INSTALL_PACKAGES','android.permission.SYSTEM_ALERT_WINDOW',
      'android.permission.WRITE_SETTINGS','android.permission.MANAGE_EXTERNAL_STORAGE',
      'android.permission.QUERY_ALL_PACKAGES'
    ]
    present=[p for p in forbidden_permissions if p in manifest]
    check('dangerous_unused_permissions_absent',not present,'Unexpected high-risk manifest permissions: '+(', '.join(present) if present else 'none'))

    forbidden_apis=[
      'Runtime.getRuntime().exec','new ProcessBuilder(','DexClassLoader','PathClassLoader',
      'sendTextMessage(','Intent.ACTION_CALL','ACTION_INSTALL_PACKAGE','PackageInstaller',
      'setAllowUniversalAccessFromFileURLs(true)','setAllowFileAccess(true)','setAllowContentAccess(true)'
    ]
    hits=[x for x in forbidden_apis if x in java]
    check('dangerous_execution_apis_absent',not hits,'Unexpected high-risk APIs: '+(', '.join(hits) if hits else 'none'))

    secret_patterns={
      'private_key_block':r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
      'aws_access_key':r'AKIA[0-9A-Z]{16}',
      'github_pat':r'gh[pousr]_[A-Za-z0-9_]{20,}',
      'openai_key':r'sk-[A-Za-z0-9_-]{20,}',
      'google_api_key':r'AIza[0-9A-Za-z_-]{25,}'
    }
    secret_hits=[name for name,pat in secret_patterns.items() if re.search(pat,java+'\n'+web)]
    check('obvious_embedded_secrets_absent',not secret_hits,'Secret-pattern matches: '+(', '.join(secret_hits) if secret_hits else 'none'))

    check('model_has_no_direct_external_action_authority',(JAVA_ROOT/'com/sbh/atlasos/ExternalActionPolicy.java').is_file(),'ExternalActionPolicy must exist before any future real-world action lane is added.')
    check('untrusted_content_cannot_become_authority',(JAVA_ROOT/'com/sbh/atlasos/UntrustedContentPolicy.java').is_file(),'Retrieved/model/reference content must stay data-plane input.')
    check('fresh_action_authorization_policy_present',(JAVA_ROOT/'com/sbh/atlasos/ActionAuthorizationPolicy.java').is_file(),'High-impact approvals must bind to target, payload, generation and short TTL.')
    check('https_target_policy_present',(JAVA_ROOT/'com/sbh/atlasos/ExternalTargetPolicy.java').is_file(),'External destinations must pass the exact HTTPS target policy.')
    # onPause can occur without onStop (e.g. translucent overlay/permission UI).
    pause = main.split('  @Override protected void onPause(){',1)[1].split('  @Override protected void onStop(){',1)[0] if '  @Override protected void onPause(){' in main and '  @Override protected void onStop(){' in main else ''
    resume = main.split('  @Override protected void onResume(){',1)[1].split('  @Override protected void onPause(){',1)[0] if '  @Override protected void onResume(){' in main and '  @Override protected void onPause(){' in main else ''
    check('pause_immediately_revokes_native_owner_session', 'OwnerSessionGate.setForeground(false);' in pause and 'OwnerSessionGate.setForeground(true);' in resume, 'Do not leave owner session active while Activity is paused but not stopped.')
    check('pause_cancels_media_hides_web_and_invalidates_commands', all(s in pause for s in ('stopPrivateMedia();','web.setVisibility(android.view.View.INVISIBLE);','workflowPlanner.clear();','atlas-owner-locked','atlas-learning-locked')), 'Pause must stop microphone/wake, hide sensitive UI, clear commands, and notify JS lock handlers.')

    failures=[r for r in rows if not r['ok']]
    return {
      'schema':'atlas.android.static-security-audit.v1',
      'status':'PASS' if not failures else 'FAIL',
      'checks':rows,'failures':failures,
      'truth_boundary':'Static source tripwire only; PASS does not prove native runtime, device, provider, robot, or production security.'
    }

def main()->int:
    r=audit(); print(json.dumps(r,indent=2)); return 0 if r['status']=='PASS' else 2
if __name__=='__main__': raise SystemExit(main())
