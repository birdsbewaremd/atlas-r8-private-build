#!/usr/bin/env python3
"""Isolated browser simulation of the integrated real-app drawer; no Android access."""
import json,sys
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
base=root/'app/src/main/assets/www'
results=[]
def record(name,condition):
 results.append({'check':name,'passed':bool(condition)})
 print(('PASS' if condition else 'FAIL')+' '+name)
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [320,390,412,768]:
  page=browser.new_page(viewport={'width':width,'height':780})
  page.set_content('''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body>
<section class="appLibrary" id="library" style="display:flex;flex-direction:column;width:100%;max-width:100%;height:690px;background:#100b1c;color:white;box-sizing:border-box;">
<input id="libQ" aria-label="Search apps"><div id="libRail" style="height:160px">Existing ATLAS tools</div>
<div class="drawerFoot"><div id="libDots">●</div><small id="libCount">36 apps</small></div>
</section></body></html>''')
  page.add_style_tag(path=str(base/'atlas-installed-drawer.css'))
  page.add_script_tag(path=str(base/'atlas-installed-drawer.js'))
  mocked=[{'id':'com.google.android.apps.messaging/com.google.android.apps.messaging.MainActivity','label':'Messages','packageName':'com.google.android.apps.messaging','icon':'data:image/png;base64,QUJDRA=='},
   {'id':'com.android.chrome/.Main','label':'Chrome','packageName':'com.android.chrome'},
   {'id':'com.safe/.Name','label':'<img src=x onerror=alert(1)>','packageName':'com.safe','icon':'javascript:alert(1)'}]
  page.evaluate('''(mocked)=>{window.calls=[];window.native={available:()=>true,call:(method,id)=>{
   window.calls.push({method,id});if(method==='installedApps')return JSON.stringify(mocked);
   return undefined;
  }}; window.ATLASInstalledDrawer.attach({root:document.querySelector('#library'),native:window.native})}''',mocked)
  record(f'{width}: no early calls',page.evaluate('window.calls.length===0'))
  page.get_by_role('button',name='Installed phone apps').click()
  record(f'{width}: native discovery after owner tap',page.evaluate('window.calls.filter(x=>x.method==="installedApps").length===1'))
  record(f'{width}: three genuine app buttons',page.locator('[data-native-id]').count()==3)
  record(f'{width}: XSS as escaped text',page.locator('img[onerror]').count()==0)
  record(f'{width}: javascript icons never used',page.locator('img[src^="javascript:"]').count()==0)
  page.locator('#libQ').fill('Messages')
  record(f'{width}: local app search',page.locator('[data-native-id]').count()==1)
  page.get_by_role('button',name='Open installed Android app Messages').click()
  record(f'{width}: actual component launch only after click',page.evaluate('window.calls.filter(x=>x.method==="openInstalledApp").length===1 && window.calls.at(-1).id.startsWith("com.google.android.apps.messaging/")'))
  page.get_by_role('button',name='ATLAS tools').click()
  record(f'{width}: original ATLAS tools remain',page.locator('#libRail').is_visible())
  record(f'{width}: viewport no sideways overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+2'))
  page.close()
 # Native unavailable fail-open to browser preview with truthful message
 page=browser.new_page();page.set_content('<section id="library"><input id="libQ"><div id="libRail">Atlas</div><div id="libDots"></div><div id="libCount"></div></section>')
 page.add_script_tag(path=str(base/'atlas-installed-drawer.js'))
 page.evaluate('window.ATLASInstalledDrawer.attach({root:document.querySelector("#library"),native:{available:()=>false}})')
 page.get_by_role('button',name='Installed phone apps').click()
 record('Browser preview does not fabricate installed apps',page.get_by_text('Browser previews cannot read installed apps.',exact=False).count()==1)
 record('Browser preview never fabricates app buttons',page.locator('[data-native-id]').count()==0)
 browser.close()
receipt={'mode':'Chromium in-memory synthetic, no Android Phone','passed':sum(r['passed'] for r in results),'total':len(results),'results':results}
out=root.parent/'receipts/R7_DRAWER_BROWSER_QA.json';out.write_text(json.dumps(receipt,indent=2));print('SUMMARY',receipt['passed'],receipt['total']);sys.exit(0 if receipt['passed']==receipt['total'] else 1)
