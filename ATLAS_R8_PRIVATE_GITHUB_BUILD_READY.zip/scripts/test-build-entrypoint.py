#!/usr/bin/env python3
"""No-network synthetic build entrypoint regression, designed for Linux CI."""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
ENTRY=ROOT/'scripts/build-debug.sh'

class EntrypointSafetyTests(unittest.TestCase):
  def setUp(self):
    self.tmp=tempfile.TemporaryDirectory()
    self.addCleanup(self.tmp.cleanup)
    self.root=Path(self.tmp.name)
    scripts=self.root/'scripts'
    scripts.mkdir()
    shutil.copyfile(ENTRY,scripts/'build-debug.sh')
    (scripts/'toolchain-doctor.sh').write_text('''#!/usr/bin/env bash
printf 'doctor\\n' >> "$ATLAS_TEST_TRACE"
exit "${ATLAS_TEST_DOCTOR_RC:-10}"
''')
    (scripts/'package-source.py').write_text('''import os,sys
with open(os.environ['ATLAS_TEST_TRACE'],'a') as f:f.write('source\\n')
sys.exit(23)
''')
    self.trace=self.root/'trace.txt'
    self.env=os.environ.copy()
    self.env.update({'ATLAS_TEST_TRACE':str(self.trace),'ATLAS_TEST_DOCTOR_RC':'10'})
  def run_entry(self,*args):
    return subprocess.run(['bash',str(self.root/'scripts/build-debug.sh'),*args],
      cwd=self.root,env=self.env,capture_output=True,text=True,timeout=8)
  def events(self):
    return self.trace.read_text().splitlines() if self.trace.exists() else []
  def test_shell_syntax(self):
    self.assertEqual(subprocess.run(['bash','-n',str(ENTRY)]).returncode,0)
  def test_build_fails_fast_without_usable_toolchain(self):
    result=self.run_entry()
    self.assertEqual(result.returncode,10)
    self.assertEqual(self.events(),['doctor'])
    self.assertIn('NO_APK_ATTEMPT',result.stderr)
  def test_normal_build_reaches_source_only_after_doctor_success(self):
    self.env['ATLAS_TEST_DOCTOR_RC']='0'
    result=self.run_entry()
    self.assertEqual(result.returncode,23)
    self.assertEqual(self.events(),['doctor','source'])
  def test_source_only_does_not_invoke_doctor(self):
    result=self.run_entry('--source-only')
    self.assertEqual(result.returncode,23)
    self.assertEqual(self.events(),['source'])
    self.assertIn('NATIVE_BUILD_NOT_REQUESTED',result.stdout)
  def test_doctor_is_bounded_independent_command(self):
    result=self.run_entry('--doctor')
    self.assertEqual(result.returncode,10)
    self.assertEqual(self.events(),['doctor'])
  def test_help_has_no_side_effects(self):
    result=self.run_entry('--help')
    self.assertEqual(result.returncode,0)
    self.assertEqual(self.events(),[])
    self.assertIn('--source-only',result.stdout)
  def test_invalid_switch_fails_closed(self):
    result=self.run_entry('--upload')
    self.assertEqual(result.returncode,2)
    self.assertEqual(self.events(),[])
  def test_multiple_arguments_fail_closed(self):
    result=self.run_entry('--doctor','--source-only')
    self.assertEqual(result.returncode,2)
    self.assertEqual(self.events(),[])

if __name__=='__main__':unittest.main(verbosity=2)
