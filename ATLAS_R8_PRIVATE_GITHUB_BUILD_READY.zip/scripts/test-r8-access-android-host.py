#!/usr/bin/env python3
"""Compiles R8's real Android permission code against minimal fake Android APIs.
NOT official Android SDK compilation; catches Java/type errors in the new controller.
"""
import ast,tempfile,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'scripts/test-r8-launcher-java-host.py'
program=ast.parse(base.read_text())
values=next(ast.literal_eval(n.value) for n in program.body if isinstance(n,ast.Assign) and any(isinstance(k,ast.Name) and k.id=='stubs' for k in n.targets))
stubs=dict(values)
stubs.pop('com/sbh/atlasos/AtlasAccessCenterActivity.java',None)
stubs.update({
'android/Manifest.java':'''package android;public final class Manifest {public static final class permission{public static final String CAMERA="camera",RECORD_AUDIO="mic",POST_NOTIFICATIONS="notifications";}}''',
'android/content/Context.java':'''package android.content;
public class Context {
 public static final String LAUNCHER_APPS_SERVICE="launcherapps",ROLE_SERVICE="role",NOTIFICATION_SERVICE="notification";
 public static final int MODE_PRIVATE=0;
 public Object getSystemService(String n){return null;}
 public android.content.pm.PackageManager getPackageManager(){return null;}
 public android.content.res.Resources getResources(){return null;}
 public SharedPreferences getSharedPreferences(String n,int m){return null;}
 public int checkSelfPermission(String p){return -1;}
 public String getPackageName(){return "com.sbh.atlasos.candidate";}
 public void startActivity(Intent i){}
 public void startService(Intent i){}
 }''',
'android/content/Intent.java':'''package android.content;
public class Intent {
 public static final String ACTION_MAIN="main",ACTION_DIAL="dial",ACTION_VIEW="view",CATEGORY_LAUNCHER="launcher",CATEGORY_APP_MESSAGING="messaging";
 public static final int FLAG_ACTIVITY_NEW_TASK=1,FLAG_ACTIVITY_RESET_TASK_IF_NEEDED=2;
 public Intent(String s){} public Intent(String s,android.net.Uri u){} public Intent(Context ctx,Class<?> c){}
 public Intent addCategory(String s){return this;}public Intent setComponent(ComponentName c){return this;}
 public Intent setAction(String s){return this;}public Intent putExtra(String n,String v){return this;}
 public Intent addFlags(int i){return this;}
 public static Intent makeMainSelectorActivity(String s,String c){return new Intent(s);}
 }''',
'android/content/pm/PackageManager.java':'''package android.content.pm;import java.util.*;
public class PackageManager{public static final int PERMISSION_GRANTED=0;public List<ResolveInfo> queryIntentActivities(android.content.Intent i,int flags){return null;}}''',
'android/app/Activity.java':'''package android.app;
public class Activity extends android.content.Context{
 protected void onCreate(android.os.Bundle b){}protected void onResume(){}
 public void onBackPressed(){}
 public android.view.Window getWindow(){return null;}
 public void setContentView(android.view.View v){}
 public void requestPermissions(String[] p,int code){}
 public void onRequestPermissionsResult(int code,String[] names,int[] grants){}
 }''',
'android/app/NotificationManager.java':'package android.app;public class NotificationManager{public boolean areNotificationsEnabled(){return true;}}',
'android/app/AlertDialog.java':'''package android.app;
public class AlertDialog {
 public static class Builder{
  public Builder(android.content.Context c){}
  public Builder setTitle(CharSequence s){return this;}
  public Builder setMessage(CharSequence s){return this;}
  public Builder setNegativeButton(CharSequence t,android.content.DialogInterface.OnClickListener l){return this;}
  public Builder setPositiveButton(CharSequence t,android.content.DialogInterface.OnClickListener l){return this;}
  public AlertDialog show(){return new AlertDialog();}
 }
 }''',
'android/content/DialogInterface.java':'''package android.content;public interface DialogInterface{interface OnClickListener{void onClick(DialogInterface d,int which);}}''',
'android/app/role/RoleManager.java':'''package android.app.role;
public class RoleManager {public static final String ROLE_HOME="android.app.role.HOME",ROLE_ASSISTANT="android.app.role.ASSISTANT";
 public boolean isRoleAvailable(String s){return false;}public boolean isRoleHeld(String s){return false;}
 public android.content.Intent createRequestRoleIntent(String s){return null;}}''',
'android/net/Uri.java':'package android.net;public class Uri{public static Uri parse(String s){return null;}}',
'android/provider/Settings.java':'''package android.provider;public class Settings{
 public static final String ACTION_SETTINGS="settings",ACTION_HOME_SETTINGS="home",ACTION_WALLPAPER_SETTINGS="wallpaper";
 public static final String ACTION_APPLICATION_DETAILS_SETTINGS="appdetails",ACTION_MANAGE_DEFAULT_APPS_SETTINGS="defaults",ACTION_APP_NOTIFICATION_SETTINGS="notifs",ACTION_USAGE_ACCESS_SETTINGS="usage",ACTION_BLUETOOTH_SETTINGS="bt";
 public static final String EXTRA_APP_PACKAGE="package";
 }''',
'android/view/Window.java':'package android.view;public class Window{public void setStatusBarColor(int c){}public void setNavigationBarColor(int c){}public void addFlags(int f){}}',
'android/view/WindowManager.java':'package android.view;public class WindowManager{public static final class LayoutParams{public static final int FLAG_SECURE=1;}}',
'android/widget/ScrollView.java':'''package android.widget;public class ScrollView extends android.view.ViewGroup{
 public ScrollView(android.content.Context c){super(c);}public void setFillViewport(boolean b){}public void addView(android.view.View v){}public void setBackgroundColor(int c){}
 }''',
'android/widget/Toast.java':'''package android.widget;public class Toast{
 public static final int LENGTH_SHORT=0,LENGTH_LONG=1;
 public static Toast makeText(android.content.Context c,CharSequence s,int len){return new Toast();}public void show(){} }''',
'android/app/role/RoleManager.java':'''package android.app.role;
public class RoleManager {public static final String ROLE_HOME="android.app.role.HOME",ROLE_ASSISTANT="android.app.role.ASSISTANT";
public boolean isRoleAvailable(String s){return false;}public boolean isRoleHeld(String s){return false;}
public android.content.Intent createRequestRoleIntent(String s){return null;}}''',
'org/json/JSONObject.java':'''package org.json;
public class JSONObject {
 public JSONObject(){}
 public JSONObject put(String k,String v) throws JSONException {return this;}
 public String toString(){return "{}";}
}''',
'org/json/JSONException.java':'package org.json;public class JSONException extends Exception{}',
'com/sbh/atlasos/AtlasWakeService.java':'''package com.sbh.atlasos;public class AtlasWakeService{public static final String ACTION_STOP="STOP";}''',
'com/sbh/atlasos/AppUsageReader.java':'''package com.sbh.atlasos;
public class AppUsageReader{public static boolean hasSpecialAccess(android.content.Context c){return false;}}''',
})
source=root/'app/src/main/java/com/sbh/atlasos'
with tempfile.TemporaryDirectory(prefix='r8-access-fake-android-') as t:
 d=Path(t);files=[]
 for name,body in stubs.items():
  path=d/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(body);files.append(str(path))
 files.extend(str(source/n) for n in ['AtlasAccessCenterActivity.java','AtlasAccessStatus.java','AtlasLauncherActivity.java'])
 p=subprocess.run(['javac','-encoding','UTF-8','-Xlint:none','-d',str(d/'classes'),*files],capture_output=True,text=True)
 print('R8_ACCESS_HOST_STUB_JAVA_COMPILE '+('PASS' if p.returncode==0 else 'FAIL'))
 print(p.stderr[:6500]);raise SystemExit(p.returncode)
