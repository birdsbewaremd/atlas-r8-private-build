#!/usr/bin/env python3
"""Storage extension static tripwires (NOT a native build/device test)."""
from pathlib import Path
import re
p=Path(__file__).resolve().parents[1]
main=(p/'app/src/main/java/com/sbh/atlasos/MainActivity.java').read_text()
ui=(p/'app/src/main/assets/www/app.js').read_text()
manifest=(p/'app/src/main/AndroidManifest.xml').read_text()
pol=(p/'app/src/main/java/com/sbh/atlasos/StorageImportPolicy.java').read_text()
rows=[
 ('No bulk Android file permission',all(x not in manifest for x in ('MANAGE_EXTERNAL_STORAGE','READ_EXTERNAL_STORAGE','WRITE_EXTERNAL_STORAGE','INTERNET'))),
 ('Only owner can initiate document picker', '@JavascriptInterface public void importLocalDocument()' in main and 'if(!ownerRequired()){toast("Unlock Atlas OS first");return;}' in main),
 ('File picker is system scoped and read-only', 'Intent.ACTION_OPEN_DOCUMENT' in main and 'Intent.FLAG_GRANT_READ_URI_PERMISSION' in main and 'Intent.FLAG_GRANT_WRITE_URI_PERMISSION' not in main and 'takePersistableUriPermission' not in main),
 ('Picker result rejects arbitrary schemes', 'if(!"content".equalsIgnoreCase(uri.getScheme()))' in main),
 ('Owner must confirm chosen document after picker', 'private void offerPendingDocumentImport()' in main and 'Confirm private document import' in main and 'credentialDialog.getButton' not in main),
 ('Owner required before and during encrypt, and again before publish', 'encryptStreamLimited(in,part,StorageImportPolicy.MAX_DOCUMENT_BYTES)' in main and 'if(!ownerRequired())throw new IOException("owner session ended");' in main),
 ('Bounded 8MiB text file with 16MiB space reserve', 'MAX_DOCUMENT_BYTES = 8L * 1024L * 1024L' in pol and 'MIN_FREE_HEADROOM_BYTES = 16L * 1024L * 1024L' in pol),
 ('Only new encrypted ciphertext published atomically', 'pending.atlaspart' in main and 'StandardCopyOption.ATOMIC_MOVE' in main and 'target.exists()' in main),
 ('Existing original never deleted', 'getContentResolver().openInputStream(uri)' in main and 'getContentResolver().delete' not in main and 'Intent.FLAG_GRANT_WRITE_URI_PERMISSION' not in main),
 ('Storage report no private data when locked', '@JavascriptInterface public String storageStatus()' in main and 'if(!ownerRequired())return "{\\"status' in main),
 ('Storage UI owner-gated, no fake unlimited quota', "if(id==='storage')return storageApp();" in ui and 'if(!ownerUiActive())' in ui[ui.index('function storageApp(){'):ui.index('function shaunOS(){')] and 'capacity is not unlimited' in ui),
 ('Explicit device-bound vault recovery limitation', 'Android Keystore key' in ui and 'not a portable backup' in ui),
]
for name,good in rows:print(('PASS' if good else 'FAIL')+' '+name)
if not all(ok for _,ok in rows):raise SystemExit(1)
print('STORAGE_SOURCE=%d/%d PASS'%(len(rows),len(rows)))
