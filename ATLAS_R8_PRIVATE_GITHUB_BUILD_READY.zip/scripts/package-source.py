#!/usr/bin/env python3
"""Manifest-bound, deterministic PRIVATE source export. No network or credentials.

The reviewed manifest is an allowlist, not proof of authorship or malware safety.
Ordinary local secrets/build output are excluded. A manifest that explicitly names
one is rejected. Source changes require deliberate manifest review, not auto-repair.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = 'PACKAGE_MANIFEST.json'
FIXED_TIME = (2026, 10, 10, 0, 0, 0)
MAX_FILES = 2000
MAX_FILE_BYTES = 25 * 1024 * 1024
MAX_TOTAL_BYTES = 100 * 1024 * 1024
IGNORED_PARTS = {'.git', '.gradle', '.idea', '.toolchains', '.venv', 'venv',
    '__pycache__', '.pytest_cache', 'node_modules', 'build', 'test-output',
    '.ssh', '.aws', '.config', 'secrets', 'credentials', 'backups'}
IGNORED_NAMES = {'.ds_store', 'thumbs.db', 'local.properties', 'key.properties',
    'gradle.properties', '.netrc', '.npmrc', '.pypirc', '.git-credentials'}
IGNORED_SUFFIXES = {'.pyc', '.pyo', '.jks', '.keystore', '.pem', '.key', '.p12',
    '.pfx', '.atlasenc', '.db', '.sqlite', '.sqlite3', '.zip', '.apk', '.aab'}

class PackageError(ValueError):
    """A source or output failed a safety/integrity gate."""

def relative_name(name: str) -> PurePosixPath:
    if not isinstance(name, str) or not name or '\\' in name or ':' in name:
        raise PackageError('invalid manifest path')
    if any(ord(c) < 32 for c in name):
        raise PackageError('control character in manifest path')
    p = PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or p.as_posix() != name or name == '.':
        raise PackageError('unsafe or noncanonical manifest path')
    return p

def excluded(name: str) -> bool:
    p = relative_name(name)
    parts = [v.lower() for v in p.parts]
    return (any(v in IGNORED_PARTS for v in parts)
        or p.name.lower() in IGNORED_NAMES
        or p.name.lower().startswith('.env')
        or p.suffix.lower() in IGNORED_SUFFIXES
        or p.name.lower().startswith('credentials.')
        or p.name.lower().startswith('service-account'))

def unique_object(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise PackageError('duplicate JSON key in manifest')
        out[key] = value
    return out

def read_regular(root: Path, name: str) -> bytes:
    rel = relative_name(name)
    p = root
    for part in rel.parts:
        p = p / part
        if p.is_symlink():
            raise PackageError(f'symlink is forbidden: {name}')
    try:
        st = p.stat()
        if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1:
            raise PackageError(f'not an independent regular file: {name}')
        if st.st_size > MAX_FILE_BYTES:
            raise PackageError(f'file exceeds export limit: {name}')
        if not p.resolve().is_relative_to(root):
            raise PackageError(f'file escapes source root: {name}')
        data = p.read_bytes()
        if len(data) > MAX_FILE_BYTES:
            raise PackageError(f'file grew beyond export limit: {name}')
        return data
    except OSError as exc:
        raise PackageError(f'cannot read required file: {name}') from exc

def snapshot(root: Path) -> dict[str, bytes]:
    if root.is_symlink():
        raise PackageError('source root cannot be a symlink')
    root = root.resolve(strict=True)
    raw = read_regular(root, MANIFEST)
    try:
        obj = json.loads(raw, object_pairs_hook=unique_object)
    except (json.JSONDecodeError, UnicodeError) as exc:
        raise PackageError('invalid manifest JSON') from exc
    records = obj.get('files') if isinstance(obj, dict) else None
    if not isinstance(records, dict) or not 1 <= len(records) <= MAX_FILES:
        raise PackageError('invalid manifest file map')
    payload = {}
    for name, record in records.items():
        relative_name(name)
        if name == MANIFEST or excluded(name):
            raise PackageError(f'forbidden manifest entry: {name}')
        if (not isinstance(record, dict)
            or not isinstance(record.get('sha256'), str)
            or re.fullmatch(r'[0-9a-f]{64}', record['sha256']) is None
            or type(record.get('size_bytes')) is not int
            or not 0 <= record['size_bytes'] <= MAX_FILE_BYTES):
            raise PackageError(f'invalid integrity record: {name}')
        data = read_regular(root, name)
        if len(data) != record['size_bytes'] or hashlib.sha256(data).hexdigest() != record['sha256']:
            raise PackageError(f'integrity mismatch: {name}')
        payload[name] = data
    # Do not silently omit new source files. Excluded local/build material is not read.
    seen = set()
    for directory, dirs, names in os.walk(root, followlinks=False):
        d = Path(directory)
        keep = []
        for name in dirs:
            p = d / name; rel = p.relative_to(root).as_posix()
            if excluded(rel):
                continue
            if p.is_symlink():
                raise PackageError(f'symlink directory is forbidden: {rel}')
            keep.append(name)
        dirs[:] = keep
        for name in names:
            rel = (d / name).relative_to(root).as_posix()
            if rel == MANIFEST or excluded(rel):
                continue
            if (d / name).is_symlink():
                raise PackageError(f'symlink is forbidden: {rel}')
            seen.add(rel)
    if seen != set(records):
        raise PackageError('unreviewed or missing source file(s): ' + ', '.join(sorted(seen ^ set(records))))
    payload[MANIFEST] = raw
    if sum(map(len, payload.values())) > MAX_TOTAL_BYTES:
        raise PackageError('total source export exceeds limit')
    return payload

def package(root: Path, output: Path) -> int:
    payload = snapshot(root)
    root = root.resolve(strict=True)
    output = output.absolute()
    if output.is_symlink() or output.resolve().is_relative_to(root):
        raise PackageError('output must be outside source tree and not a symlink')
    created = False
    try:
        fd = os.open(output, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        created = True
        with os.fdopen(fd, 'wb') as stream:
            with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
                for name, data in sorted(payload.items()):
                    info = zipfile.ZipInfo(name, FIXED_TIME)
                    info.create_system = 3
                    mode = 0o755 if name.startswith('scripts/') else 0o644
                    info.external_attr = (stat.S_IFREG | mode) << 16
                    z.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        with zipfile.ZipFile(output) as z:
            if z.testzip() is not None or set(z.namelist()) != set(payload):
                raise PackageError('written archive failed verification')
        return len(payload)
    except (OSError, zipfile.BadZipFile, PackageError) as exc:
        if created:
            output.unlink(missing_ok=True)
        raise PackageError('export failed; existing outputs were not replaced') from exc

def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('output', nargs='?', type=Path)
    p.add_argument('--verify', action='store_true', help='Verify source without producing a ZIP')
    args = p.parse_args()
    if args.verify == (args.output is not None):
        p.error('provide OUTPUT.zip or --verify, not both')
    try:
        count = len(snapshot(ROOT)) if args.verify else package(ROOT, args.output)
        print(f'SOURCE_{"VERIFIED" if args.verify else "PACKAGED"}_FILES={count}')
        return 0
    except (PackageError, OSError) as exc:
        print(f'SOURCE_GATE=BLOCKED: {exc}', file=sys.stderr)
        return 2

if __name__ == '__main__':
    raise SystemExit(main())
