#!/usr/bin/env python3
"""Compile/run pure-Java R1 policy tests without Android SDK or hardware."""
import subprocess, tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='atlas-r1-javac-') as p:
    src=[root/'app/src/main/java/com/sbh/atlasos/RobotR1FramePolicy.java', root/'tests/R1FramePolicyHarness.java']
    subprocess.run(['javac','-encoding','UTF-8','-d',p,*map(str,src)],check=True)
    subprocess.run(['java','-cp',p,'R1FramePolicyHarness'],check=True)
