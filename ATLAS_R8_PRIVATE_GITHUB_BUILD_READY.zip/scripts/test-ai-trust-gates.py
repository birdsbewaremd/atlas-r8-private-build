#!/usr/bin/env python3
"""ATLAS AI trust source tripwire V3.

Static/source control only. It intentionally scans production source for
capability markers and keeps tests/docs from satisfying implementation gates.
"""
from __future__ import annotations
import argparse, json, re, sys
from pathlib import Path

TEXT_EXT={".java",".kt",".js"}

def text(path:Path)->str:
    return path.read_text(encoding="utf-8",errors="replace")

def production_text(root:Path)->str:
    parts=[]
    for rel in ("app/src/main/java","app/src/main/assets/www"):
        d=root/rel
        if not d.exists(): continue
        for p in d.rglob("*"):
            if p.is_file() and p.suffix in TEXT_EXT:
                parts.append(text(p))
    return "\n".join(parts)

def load_policy(root:Path)->dict:
    for name in ("ATLAS_AI_TRUST_RELEASE_GATE_V3.json","ATLAS_AI_TRUST_RELEASE_GATE_V2.json","ATLAS_AI_TRUST_RELEASE_GATE_V1.json"):
        p=root/"trust"/name
        if p.is_file():
            try: return json.loads(text(p))
            except Exception: return {}
    return {}

def audit(root:Path)->dict:
    main=text(root/"app/src/main/java/com/sbh/atlasos/MainActivity.java")
    air=text(root/"app/src/main/java/com/sbh/atlasos/AuthenticatedInputRouter.java")
    wip=text(root/"app/src/main/java/com/sbh/atlasos/WorkflowIntentParser.java")
    manifest=text(root/"app/src/main/AndroidManifest.xml")
    prod=production_text(root)
    policy=load_policy(root)
    scope=policy.get("current_source_scope") or {}

    rows=[]
    def add(name,ok,detail,kind="ALWAYS"):
        rows.append({"name":name,"ok":bool(ok),"kind":kind,"detail":detail})

    provider_class=(root/"app/src/main/java/com/sbh/atlasos/ProviderRoutePolicy.java").is_file()
    artifact_class=(root/"app/src/main/java/com/sbh/atlasos/ArtifactTrustPolicy.java").is_file()
    target_path=root/"app/src/main/java/com/sbh/atlasos/ExternalTargetPolicy.java"
    target_class=target_path.is_file()
    action_class=(root/"app/src/main/java/com/sbh/atlasos/ExternalActionPolicy.java").is_file()
    action_auth_class=(root/"app/src/main/java/com/sbh/atlasos/ActionAuthorizationPolicy.java").is_file()
    untrusted_class=(root/"app/src/main/java/com/sbh/atlasos/UntrustedContentPolicy.java").is_file()
    config_class=(root/"app/src/main/java/com/sbh/atlasos/AuthorityConfigPolicy.java").is_file()

    backend_enabled=bool(re.search(r"\bbackendConnected\s*=\s*true\b",main))
    network_clients=any(k in prod for k in ("OkHttpClient","Retrofit.Builder","HttpURLConnection","WebSocket("))
    model_loaders=any(k in prod for k in ("torch.load(","pickle.load(","onnxruntime","TensorFlowLite","Interpreter("))
    connector_markers=any(k in prod for k in ("ModelContextProtocol","McpClient","MCPClient","ExternalConnectorClient"))
    autonomous_markers=any(k in prod for k in ("AutonomousAgent","AgentLoop","BackgroundAgentExecutor","runAutonomously("))

    expected_backend=bool(scope.get("authenticated_brain_backend_expected",False))
    expected_artifacts=bool(scope.get("external_model_artifacts_expected",False))
    expected_connectors=bool(scope.get("external_agent_connectors_expected",False))
    expected_autonomous=bool(scope.get("autonomous_network_agent_expected",False))
    expected_side_effects=bool(scope.get("real_world_external_side_effects_expected",False))

    # Current always-on trust boundaries.
    add("workflow_recognition_never_grants_execution",
        "grantsExecution = false" in wip and "grantsExecution = false" in air,
        "WorkflowIntentParser and AuthenticatedInputRouter keep grantsExecution=false")
    add("reference_data_is_inert",
        "REFERENCE_DATA" in wip and "source_text_is_data" in wip,
        "Reference/source text stays data-plane input")
    add("local_device_execution_requires_owner_session",
        "routed.route==AuthenticatedInputRouter.Route.LOCAL_DEVICE" in main
        and "&&OwnerSessionGate.isActive(this)" in main,
        "Local device execution remains route + owner-session gated")
    add("webview_file_and_content_access_disabled",
        "setAllowFileAccess(false)" in main and "setAllowContentAccess(false)" in main,
        "WebView file/content access remains disabled")
    add("cleartext_and_android_backup_disabled",
        'android:usesCleartextTraffic="false"' in manifest and 'android:allowBackup="false"' in manifest,
        "Cleartext and Android backup remain disabled")
    target_src=text(target_path) if target_class else ""
    add("external_target_policy_is_https_only",
        target_class and '!"https".equalsIgnoreCase(scheme)' in target_src and 'MAX_REDIRECT_HOPS' in target_src,
        "External target policy rejects non-HTTPS targets and validates redirect chains")
    add("external_action_policy_present",action_class,
        f"ExternalActionPolicy.java present={action_class}")
    add("fresh_action_authorization_policy_present",action_auth_class,
        f"ActionAuthorizationPolicy.java present={action_auth_class}")
    add("untrusted_content_policy_present",untrusted_class,
        f"UntrustedContentPolicy.java present={untrusted_class}")

    # Intentional capability activation must match declared source scope.
    add("backend_activation_matches_declared_scope",
        backend_enabled == expected_backend,
        f"backend_enabled={backend_enabled}; expected={expected_backend}",
        "SCOPE")
    if not expected_backend:
        add("disconnected_backend_persistence_is_truthful",
            "backendConnected=false" in main and "persistenceConfirmed=false" in main,
            "Disconnected candidate must keep backend/persistence claims false")
    else:
        add("provider_route_policy_required_for_backend",provider_class,
            f"ProviderRoutePolicy.java present={provider_class}","CONDITIONAL")

    if model_loaders or expected_artifacts:
        add("artifact_supply_chain_policy_required",artifact_class,
            f"model_loaders={model_loaders}; expected_artifacts={expected_artifacts}; ArtifactTrustPolicy.java={artifact_class}",
            "CONDITIONAL")
    if connector_markers or expected_connectors:
        # V3 intentionally requires a dedicated production implementation, not a doc/schema string.
        impl=any((root/"app/src/main/java/com/sbh/atlasos"/n).is_file()
                 for n in ("ConnectorManifestPolicy.java","ToolManifestPolicy.java"))
        add("connector_manifest_policy_required",impl,
            f"connector_markers={connector_markers}; expected_connectors={expected_connectors}; implementation={impl}",
            "CONDITIONAL")
    if network_clients or expected_backend or connector_markers or expected_connectors or autonomous_markers or expected_autonomous or expected_side_effects:
        add("external_target_policy_required_for_network_authority",target_class,
            f"network_clients={network_clients}; backend={expected_backend}; connectors={expected_connectors}; autonomous={expected_autonomous}; side_effects={expected_side_effects}; target_policy={target_class}",
            "CONDITIONAL")
        add("external_action_broker_required_for_network_authority",action_class and action_auth_class,
            f"ExternalActionPolicy.java={action_class}; ActionAuthorizationPolicy.java={action_auth_class}",
            "CONDITIONAL")
        add("untrusted_content_boundary_required_for_network_authority",untrusted_class,
            f"UntrustedContentPolicy.java={untrusted_class}",
            "CONDITIONAL")

    # Authority-bearing config changes require the change-control helper once
    # any external backend/connector/autonomous surface is declared.
    if expected_backend or expected_connectors or expected_autonomous or expected_side_effects:
        add("authority_config_change_control_required",config_class,
            f"AuthorityConfigPolicy.java present={config_class}","CONDITIONAL")

    failures=[r for r in rows if not r["ok"]]
    return {
      "schema_version":"3.0",
      "status":"PASS" if not failures else "FAIL",
      "checks":rows,
      "failures":failures,
      "detected":{
        "backend_enabled_literal":backend_enabled,
        "network_client_markers_production_only":network_clients,
        "model_loader_markers_production_only":model_loaders,
        "connector_markers_production_only":connector_markers,
        "autonomous_agent_markers_production_only":autonomous_markers,
        "declared_scope":{
          "backend":expected_backend,
          "artifacts":expected_artifacts,
          "connectors":expected_connectors,
          "autonomous_network":expected_autonomous,
          "real_world_side_effects":expected_side_effects
        }
      },
      "truth_boundary":"Static source tripwire only. Tests/docs do not satisfy implementation gates. PASS is not Android/device/provider/security certification."
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("source_root")
    ap.add_argument("--json-out")
    args=ap.parse_args()
    r=audit(Path(args.source_root))
    s=json.dumps(r,indent=2)
    if args.json_out:
        destination = Path(args.json_out)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(s, encoding="utf-8")
    print(s)
    return 0 if r["status"]=="PASS" else 2

if __name__=="__main__":
    raise SystemExit(main())
