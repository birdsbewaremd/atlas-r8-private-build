#!/usr/bin/env python3
"""Synthetic negative and positive tests; do not represent native device acceptance."""
from __future__ import annotations
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
MODULE_PATH=ROOT/'scripts/atlas-release-evidence-gate.py'
spec=importlib.util.spec_from_file_location('atlas_release_evidence_gate',MODULE_PATH)
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

COUNTS=[0,0]
def case(name,condition):
    COUNTS[1]+=1
    if not condition:
        print('FAIL '+name)
        raise SystemExit(1)
    COUNTS[0]+=1
    print('PASS '+name)

def digest(blob):return hashlib.sha256(blob).hexdigest()

def put(root,name,data):
    path=root/name;path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(data)

def prepare(root):
    apk=b'PRIVATE_FAKE_APK_TEST_ONLY'
    manifest=b'{"test":true}'
    put(root,'a.apk',apk)
    put(root,'PACKAGE_MANIFEST.json',manifest)
    checks=[]
    for name,scope in mod.REQUIRED_CHECKS.items():
        data=f'SYNTHETIC TEST FOR {name}; NOT A DEVICE RECEIPT'.encode()
        rel='receipts/'+name+'.txt';put(root,rel,data)
        checks.append({'name':name,'proof_scope':scope,'status':'PASS',
                       'receipt_path':rel,'receipt_sha256':digest(data)})
    ev={'schema':mod.SCHEMA,'app_id':mod.EXPECTED_APP_ID,
        'release_authorized':False,'network_or_external_sends_enabled':False,
        'source_manifest_sha256':digest(manifest),'apk_sha256':digest(apk),
        'checks':checks}
    put(root,'evidence.json',json.dumps(ev).encode())
    return ev

def run(root,ev=None):
    if ev is not None:put(root,'evidence.json',json.dumps(ev).encode())
    return mod.review(root,'evidence.json','a.apk')

with tempfile.TemporaryDirectory() as td:
    root=Path(td)
    case('no evidence means blocked',run(root)['verdict']=='BLOCKED')
    ev=prepare(root)
    baseline=run(root)
    case('full synthetic data never authorizes release',baseline['release_authorization']=='DENIED')
    case('full synthetic data requires independent review',baseline['verdict']=='EVIDENCE_CONSISTENT_REVIEW_REQUIRED')
    cli=subprocess.run([sys.executable,str(MODULE_PATH),'--root',str(root),'--evidence','evidence.json','--apk','a.apk'],capture_output=True,text=True)
    case('CLI full evidence exits nonzero',cli.returncode==11 and 'DENIED' in cli.stdout)
    scenarios={
        'wrong app identity': lambda e:e.update(app_id='com.example.other'),
        'false release permission':lambda e:e.update(release_authorized=True),
        'external send enabled':lambda e:e.update(network_or_external_sends_enabled=True),
        'wrong apk digest':lambda e:e.update(apk_sha256='a'*64),
        'wrong source digest':lambda e:e.update(source_manifest_sha256='b'*64),
        'missing device check':lambda e:e['checks'].pop(),
        'duplicated device check':lambda e:e['checks'].__setitem__(1,copy.deepcopy(e['checks'][0])),
        'host test masquerading as device':lambda e:e['checks'][4].update(proof_scope='HOST_SIMULATION'),
        'unverified device test':lambda e:e['checks'][4].update(status='NOT_RUN'),
        'stale receipt hash':lambda e:e['checks'][4].update(receipt_sha256='f'*64),
        'receipt outside root':lambda e:e['checks'][0].update(receipt_path='../outside.txt'),
        'receipt absolute path':lambda e:e['checks'][0].update(receipt_path='/etc/passwd'),
        'missing proof':lambda e:e['checks'][4].pop('receipt_path'),
        'extra unknown check':lambda e:e['checks'].append({'name':'fake_pass','status':'PASS'}),
        'invalid schema':lambda e:e.update(schema='other'),
    }
    for label,mutator in scenarios.items():
        changed=copy.deepcopy(ev);mutator(changed)
        result=run(root,changed)
        case('reject '+label,result['verdict']=='BLOCKED' and result['release_authorization']=='DENIED')
    case('bad parse denied', (put(root,'evidence.json',b'{bad'),run(root)['verdict']=='BLOCKED')[1])
    case('duplicate JSON fields denied',(put(root,'evidence.json',b'{"schema":"a","schema":"b"}'),run(root)['verdict']=='BLOCKED')[1])
    run(root,ev)
    (root/'receipts'/'android_native_build.txt').unlink()
    (root/'receipts'/'android_native_build.txt').symlink_to('android_lint.txt')
    case('symlink receipt blocked',run(root)['verdict']=='BLOCKED')
    (root/'receipts'/'android_native_build.txt').unlink()
    put(root,'receipts/android_native_build.txt',b'SYNTHETIC TEST FOR android_native_build; NOT A DEVICE RECEIPT')
    (root/'a.apk').unlink()
    (root/'a.apk').symlink_to('receipts/android_native_build.txt')
    case('symlink APK blocked',run(root)['verdict']=='BLOCKED')
    (root/'a.apk').unlink()
    put(root,'a.apk',b'PRIVATE_FAKE_APK_TEST_ONLY')
    case('restored clean fixture still needs review',run(root)['verdict']=='EVIDENCE_CONSISTENT_REVIEW_REQUIRED')
    (root/'evidence.json').unlink()
    case('missing evidence fails CLI with block status',subprocess.run([sys.executable,str(MODULE_PATH),'--root',str(root),'--evidence','evidence.json','--apk','a.apk'],capture_output=True).returncode==10)
print('RELEASE_EVIDENCE_GUARD_TESTS=%d/%d PASS'%tuple(COUNTS))
