from playwright.sync_api import sync_playwright
from pathlib import Path
import re,json,os,shutil
from pathlib import Path
assets=Path(__file__).resolve().parents[1]/'app/src/main/assets/www'
html= (assets/'index.html').read_text()
def inline_style(m):
 rel=m.group(1).split('?')[0].removeprefix('./')
 return '<style>'+ (assets/rel).read_text() +'</style>'
def inline_js(m):
 rel=m.group(1).split('?')[0].removeprefix('./')
 return '<script>'+ (assets/rel).read_text().replace('</script>',r'<\/script>') +'</script>'
html=re.sub(r'<link rel="stylesheet" href="([^"]+)">',inline_style,html)
html=re.sub(r'<script src="([^"]+)"></script>',inline_js,html)
store="""(() => {function createStore(){const m=new Map();return {getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i]||null,get length(){return m.size}}}Object.defineProperty(window,'localStorage',{value:createStore(),configurable:true});Object.defineProperty(window,'sessionStorage',{value:createStore(),configurable:true})})();"""
N=56
fake=[{'id':f'G{i:02}', 'name':f'Goal {i:02}', 'lane':'ATLAS / owner', 'priority':'P0' if i<3 else 'P2','state':'active','evidence':'REPORTED','good':('<img src=x onerror=alert(1)>' if i==0 else f'Benefit {i}'),'bad':'Risk: failure or fraud','next':'Verify the source before making changes.'} for i in range(N)]
mock=json.dumps({'status':'ready','count':N,'goals':fake})
bootstrap=f'''(() => {{let unlocked=false;let status='ready';window.__test={{setStatus:s=>status=s,lock:()=>{{unlocked=false;window.dispatchEvent(new Event('atlas-owner-locked'))}},imported:0}};window.ATLASNative={{ownerPinConfigured:()=>true,unlockOwner:(pin)=>{{unlocked=(pin==='123456');return unlocked}},ownerSessionActive:()=>unlocked,lockOwnerSession:()=>{{unlocked=false}},godPrivateIndex:()=>status==='ready'?JSON.stringify({mock}):JSON.stringify({{status}}),importSeedZip:()=>{{window.__test.imported++}},routeTextInput:(text)=>JSON.stringify({{route:'BRAIN_HANDOFF',statusLine:'GOD recognized',original:text,commandStack:['GOD V3 recognized only'],outcome:'No backend available.',requiresBackend:true,backendConnected:false,frame:'REAL_WORLD'}}),deviceStatus:()=>JSON.stringify({{battery:90}}),heyAtlasEnabled:()=>false,ownerRecoveryConfigured:()=>true}};}})()'''
passed=0
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path=os.getenv('CHROMIUM_EXECUTABLE') or shutil.which('chromium'),args=['--no-sandbox','--disable-gpu','--disable-dev-shm-usage'])
 for width in [320,360,393,412,768,1280]:
  page=browser.new_page(viewport={'width':width,'height':850},device_scale_factor=1)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.evaluate(store)
  page.evaluate(bootstrap)
  page.set_content(html,wait_until='load')
  page.get_by_text('Enter Atlas OS',exact=True).click()
  for n in '123456':page.locator(f'button[data-k="{n}"]').click()
  assert page.locator('[data-app="god"]').count()>=1,(width,'no GOD entry')
  assert 'PRIVATE_GOAL_DO_NOT_PACKAGE' not in page.content()
  page.locator('.hero [data-app="god"]').click()
  assert page.locator('h1').first.inner_text().startswith('GOD')
  assert page.locator('.godGoal').count()==8,(width,page.locator('.godGoal').count())
  assert page.locator('.godGoalId').first.inner_text()=='G00'
  assert page.locator('img[src=x]').count()==0,(width,'XSS markup inserted')
  assert '&lt;img' in page.locator('.godGoal').first.inner_html(),(width,'danger not escaped')
  page.get_by_role('button',name='Risks',exact=True).click()
  assert page.locator('.godSide.risk').count()==8 and page.locator('.godSide:not(.risk)').count()==0
  page.get_by_role('button',name='Both sides',exact=True).click()
  assert page.locator('.godSide.risk').count()==8 and page.locator('.godSide:not(.risk)').count()==8
  page.locator('#godSearch').fill('Goal 17')
  assert page.locator('.godGoal').count()==1
  page.locator('#godSearch').fill('')
  page.locator('#godInput').fill('organize my goals')
  page.locator('#godRun').click()
  assert 'GOD recognized' in page.locator('#atlasResult').inner_text()
  page.evaluate('window.__test.lock()')
  assert page.locator('#godCards').count()==0,(width,'private goals survive lock')
  assert page.locator('.lock').count()==1,(width,'no lock after owner locked')
  assert not errors,(width,errors)
  overflow=page.evaluate('document.documentElement.scrollWidth > window.innerWidth')
  assert not overflow,(width,'horizontal overflow')
  if width==393:
   # fresh owner login to test missing-import branch
   for n in '123456':page.locator(f'button[data-k="{n}"]').click()
   page.evaluate("window.__test.setStatus('not_imported')")
   page.locator('.hero [data-app="god"]').click()
   assert 'Private goal pack not imported' in page.locator('.godEmpty').inner_text()
   assert page.locator('.godGoal').count()==0
   page.locator('#godImport').click()
   assert page.evaluate('window.__test.imported')==1
   # send native import event -> should refresh the data; synthetic data
   page.evaluate("window.__test.setStatus('ready');window.dispatchEvent(new Event('atlas-native-import'))")
   assert page.locator('.godGoal').count()==8
   # screenshot intentionally omitted from source/test for owner privacy
  passed+=1
  page.close()
 # Browser-only mode must NOT reveal private goals
 page=browser.new_page();page.evaluate(store);page.set_content(html,wait_until='load')
 assert 'GOD_PRIVATE_MASTER_V1.json' not in page.content()
 assert page.locator('.godGoal').count()==0
 browser.close()
 print(f'GOD browser UI PASS: {passed}/6 mobile/tablet/desktop widths; locked+owner+search+both sides+input+import+escaping; no page errors or horizontal overflow; browser-only hidden')
