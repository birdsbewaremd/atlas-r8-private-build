from pathlib import Path
import json,re,hashlib,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
module_root=root/'app/src/main/assets/atlas_modules'
catalog=json.loads((module_root/'catalog.json').read_text())
assert len(catalog)==14 and catalog[0]['slug']=='brain' and len({x['slug'] for x in catalog})==len(catalog)
assert {x['slug'] for x in catalog} == {'brain','life','forge','research','media','future','100years','school','tech','faith','quiet','fun','voice','features'}
for module in catalog:
    module_filename='START_ATLAS_SECOND_BRAIN.html' if module['slug']=='brain' else 'index.html'
    data=(module_root/module['slug']/module_filename).read_bytes()
    assert hashlib.sha256(data).hexdigest()==module['sha256'],module['slug']
    assert data.lstrip().lower().startswith(b'<!doctype html') or b'<html' in data[:1000].lower()
hub=(module_root/'hub/index.html').read_text()
for module in catalog:
    target='../brain/START_ATLAS_SECOND_BRAIN.html' if module['slug']=='brain' else '../'+module['slug']+'/index.html'
    assert target in hub
assert len(list((module_root/'brain'/'apps').glob('*.html')))==14
assert (module_root/'brain'/'START_ATLAS_SECOND_BRAIN.html').stat().st_size<8*1024*1024
index=json.loads((root/'UNIFIED_MODULE_INDEX.json').read_text())
assert index['module_count']==14 and index['modules']==catalog
manifest=root/'app/src/main/AndroidManifest.xml'
node=ET.fromstring(manifest.read_text());ns='{http://schemas.android.com/apk/res/android}'
permissions=[x.attrib.get(ns+'name') for x in node.findall('uses-permission')]
for forbidden in ['android.permission.INTERNET','android.permission.MANAGE_EXTERNAL_STORAGE','android.permission.READ_SMS','android.permission.QUERY_ALL_PACKAGES','android.permission.REQUEST_INSTALL_PACKAGES']:
    assert forbidden not in permissions,forbidden
activities=node.find('application').findall('activity')
for n in ('.AtlasCleanupActivity','.AtlasModulesActivity'):
    x=next(x for x in activities if x.attrib.get(ns+'name')==n)
    assert x.attrib.get(ns+'exported')=='false'
native=(root/'app/src/main/java/com/sbh/atlasos/MainActivity.java').read_text()
assert 'openAtlasCleanup' in native and 'openAtlasOne' in native
modules=(root/'app/src/main/java/com/sbh/atlasos/AtlasModulesActivity.java').read_text()
assert 'setBlockNetworkLoads(true)' in modules and 'setAllowFileAccess(false)' in modules
assert 'addJavascriptInterface' not in modules and 'confirmExternal' in modules
clean=(root/'app/src/main/java/com/sbh/atlasos/AtlasCleanupActivity.java').read_text()
assert 'ACTION_OPEN_DOCUMENT_TREE' in clean and 'FLAG_GRANT_READ_URI_PERMISSION' in clean
assert 'getCacheDir()' in clean and 'getExternalCacheDir()' in clean
assert 'getContentResolver().openInputStream' in clean
assert 'setPositiveButton("Clear cache"' in clean
assert 'DocumentsContract.deleteDocument' not in clean
assert 'MAX_HASH_FILE' in clean and 'MAX_HASH_TOTAL' in clean
print('ATLAS_ONE_STATIC_GATES=27/27 PASS + R1_CATALOG_GATES=5/5 PASS (offline source checks; Android build/device unverified)')
