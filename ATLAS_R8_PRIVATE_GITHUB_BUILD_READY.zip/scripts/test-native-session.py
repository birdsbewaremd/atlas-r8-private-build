#!/usr/bin/env python3
"""Execute the actual session-gate class using tiny host Android API fakes.
These tests are not Android lifecycle, instrumentation, or device acceptance.
"""
import argparse, pathlib, subprocess, tempfile
p=argparse.ArgumentParser();p.add_argument('--source-root',type=pathlib.Path)
a=p.parse_args();root=a.source_root or pathlib.Path(__file__).resolve().parents[1]
fixtures={
'android/os/SystemClock.java':'''package android.os; public final class SystemClock { public static long now=1000; public static long elapsedRealtime(){return now;} }''',
'android/app/KeyguardManager.java':'''package android.app; public class KeyguardManager { public boolean locked; public boolean fail; public boolean isDeviceLocked(){if(fail)throw new SecurityException("synthetic failure");return locked;} }''',
'android/content/Context.java':'''package android.content; public class Context { public static final String KEYGUARD_SERVICE="keyguard"; public Object service; public boolean fail; public Object getSystemService(String key){if(fail)throw new SecurityException("synthetic service failure");return service;} }''',
'GateTest.java':r'''import com.sbh.atlasos.OwnerSessionGate; import android.os.SystemClock; import android.app.KeyguardManager; import android.content.Context;
public class GateTest {
 static int total,failed; static Context c; static KeyguardManager k;
 static boolean foreground(boolean value){try{OwnerSessionGate.class.getMethod("setForeground",boolean.class).invoke(null,value);return true;}catch(NoSuchMethodException e){return false;}catch(Exception e){throw new RuntimeException(e);}}
 static void fresh(){OwnerSessionGate.clear();SystemClock.now=1000;c=new Context();k=new KeyguardManager();c.service=k;foreground(true);OwnerSessionGate.setActive(true);}
 static void check(String name,boolean ok){total++;if(!ok)failed++;System.out.println((ok?"PASS ":"FAIL ")+name);}
 public static void main(String[]args){
 fresh();check("unlocked foreground owner is active",OwnerSessionGate.isActive(c));
 fresh();OwnerSessionGate.clear();check("explicit lock denies access",!OwnerSessionGate.isActive(c));
 fresh();SystemClock.now+=900000;check("expiry boundary denies access",!OwnerSessionGate.isActive(c));
 fresh();SystemClock.now+=800000;OwnerSessionGate.touch();SystemClock.now+=200000;check("active touch extends timeout",OwnerSessionGate.isActive(c));
 fresh();SystemClock.now+=900000;OwnerSessionGate.touch();check("touch cannot resurrect an expired session",!OwnerSessionGate.isActive(c));
 fresh();k.locked=true;check("device lock denies access",!OwnerSessionGate.isActive(c));k.locked=false;check("device unlock does not resurrect old app login",!OwnerSessionGate.isActive(c));
 fresh();c.service=null;check("missing keyguard fails closed",!OwnerSessionGate.isActive(c));
 fresh();c.fail=true;check("service exception fails closed",!OwnerSessionGate.isActive(c));
 fresh();k.fail=true;check("keyguard exception fails closed",!OwnerSessionGate.isActive(c));
 fresh();check("null context fails closed",!OwnerSessionGate.isActive(null));
 fresh();SystemClock.now=500;check("monotonic-clock rollback invalidates session",!OwnerSessionGate.isActive(c));
 fresh();boolean lifecycle=foreground(false);check("background invalidates native session",lifecycle&&!OwnerSessionGate.isActive(c));
 foreground(true);check("foreground return requires fresh authentication",lifecycle&&!OwnerSessionGate.isActive(c));
 fresh();foreground(false);OwnerSessionGate.setActive(true);foreground(true);check("late auth cannot activate while backgrounded",lifecycle&&!OwnerSessionGate.isActive(c));
 fresh();long token=OwnerSessionGate.capture(c);check("captured login authorizes its own deferred work",token!=0&&OwnerSessionGate.isCurrent(c,token));
 OwnerSessionGate.clear();OwnerSessionGate.setActive(true);check("new login cannot revive a previous generation",!OwnerSessionGate.isCurrent(c,token)&&OwnerSessionGate.isActive(c));
 fresh();token=OwnerSessionGate.capture(c);foreground(false);foreground(true);OwnerSessionGate.setActive(true);check("pause and fresh unlock invalidate the old generation",!OwnerSessionGate.isCurrent(c,token));
 System.out.println("HOST_NATIVE_SESSION="+(total-failed)+"/"+total);if(failed>0)System.exit(1);
 }
}'''
}
with tempfile.TemporaryDirectory(prefix='atlas-session-test-') as tmp:
 d=pathlib.Path(tmp); sources=[]
 for name,text in fixtures.items():
  f=d/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(text);sources.append(str(f))
 sources.append(str(root/'app/src/main/java/com/sbh/atlasos/OwnerSessionGate.java'))
 subprocess.run(['javac','-d',str(d),*sources],check=True)
 raise SystemExit(subprocess.run(['java','-cp',str(d),'GateTest']).returncode)
