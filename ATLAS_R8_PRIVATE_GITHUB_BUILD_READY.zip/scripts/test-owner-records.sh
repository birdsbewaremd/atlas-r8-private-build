#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac --release 8 -encoding UTF-8 -d "$TMP" \
 "$ROOT/app/src/main/java/com/sbh/atlasos/OwnerRecordStore.java" \
 "$ROOT/app/src/main/java/com/sbh/atlasos/BookmarkedUrlPolicy.java" \
 "$ROOT/app/src/test/java/com/sbh/atlasos/OwnerRecordStoreTest.java"
java -cp "$TMP" com.sbh.atlasos.OwnerRecordStoreTest
