#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac -d "$TMP" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/CommandParser.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/GodCommandPolicy.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/WorkflowCommandCatalog.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/WorkflowIntentParser.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/AuthenticatedInputRouter.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/WorkflowPlanner.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/SeedImportPolicy.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/StorageImportPolicy.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/VoiceCommandParser.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/WakePhrasePolicy.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/WakeSessionPolicy.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/VoiceFrameClassifier.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/SpokenTextPolicy.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/TranscriptSelector.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/OwnerPinPolicy.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/OwnerRecoveryPolicy.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/ProviderRoutePolicy.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/ExternalTargetPolicy.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/ActionAuthorizationPolicy.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/ExternalActionPolicy.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/UntrustedContentPolicy.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/ArtifactTrustPolicy.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/AuthorityConfigPolicy.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/HumanInterfacePolicy.java" \
  "$ROOT/app/src/main/java/com/sbh/atlasos/RequestRecoveryPolicy.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/CommandParserTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/GodCommandPolicyTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/InputUnicodeHardeningTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/SeedImportPolicyTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/StorageImportPolicyTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/VoiceCommandParserTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/WakePhrasePolicyTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/VoiceFrameClassifierTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/SpokenTextPolicyTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/TranscriptSelectorTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/OwnerPinPolicyTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/OwnerRecoveryPolicyTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/WorkflowCommandCatalogTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/WorkflowIntentBoundaryTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/SemanticCommandAcceptanceTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/AuthenticatedInputRouterTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/WorkflowPlannerTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/ProviderRoutePolicyTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/ExternalTargetPolicyTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/ActionAuthorizationPolicyTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/ExternalActionPolicyTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/UntrustedContentPolicyTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/ArtifactTrustPolicyTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/AuthorityConfigPolicyTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/HumanInterfacePolicyTest.java" \
  "$ROOT/app/src/test/java/com/sbh/atlasos/RequestRecoveryPolicyTest.java"
for t in InputUnicodeHardeningTest GodCommandPolicyTest CommandParserTest SeedImportPolicyTest StorageImportPolicyTest VoiceCommandParserTest WakePhrasePolicyTest VoiceFrameClassifierTest SpokenTextPolicyTest TranscriptSelectorTest OwnerPinPolicyTest OwnerRecoveryPolicyTest WorkflowCommandCatalogTest WorkflowIntentBoundaryTest SemanticCommandAcceptanceTest AuthenticatedInputRouterTest WorkflowPlannerTest ProviderRoutePolicyTest ExternalTargetPolicyTest ActionAuthorizationPolicyTest ExternalActionPolicyTest UntrustedContentPolicyTest ArtifactTrustPolicyTest AuthorityConfigPolicyTest HumanInterfacePolicyTest RequestRecoveryPolicyTest; do
  java -cp "$TMP" "com.sbh.atlasos.$t"
done
