#!/usr/bin/env python3
"""Static gate for R8 scoped permission center, preserving R7. Does NOT verify an APK."""
from pathlib import Path
from xml.etree import ElementTree as ET
import re,json,hashlib,sys
root=Path(__file__).resolve().parents[1]
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
status=(root/'app/src/main/java/com/sbh/atlasos/AtlasAccessStatus.java').read_text()
center=(root/'app/src/main/java/com/sbh/atlasos/AtlasAccessCenterActivity.java').read_text()
main=(root/'app/src/main/java/com/sbh/atlasos/MainActivity.java').read_text()
launcher=(root/'app/src/main/java/com/sbh/atlasos/AtlasLauncherActivity.java').read_text()
js=(root/'app/src/main/assets/www/atlas-access.js').read_text()
gradle=(root/'app/build.gradle').read_text()
checks=[]
def check(name,ok):checks.append({'name':name,'pass':bool(ok)});print(('PASS' if ok else 'FAIL')+' '+name)
try: doc=ET.fromstring(manifest);valid=True
except ET.ParseError:doc=None;valid=False
check('Android XML manifest parses',valid)
ns='{http://schemas.android.com/apk/res/android}'
if valid:
 activities=doc.findall('application/activity')
 access=[a for a in activities if a.get(ns+'name')=='.AtlasAccessCenterActivity']
 check('New access activity internal/non-exported',len(access)==1 and access[0].get(ns+'exported')=='false')
 check('Access Center not auto-started by launcher intent',len(access)==1 and not access[0].findall('intent-filter'))
 homes=[a for a in activities if any(c.get(ns+'name')=='android.intent.category.HOME' for f in a.findall('intent-filter') for c in f.findall('category'))]
 check('Existing real HOME activity retained',len(homes)==1 and homes[0].get(ns+'name')=='.AtlasLauncherActivity' and homes[0].get(ns+'exported')=='true')
 check('Existing private MainActivity retained',any(a.get(ns+'name')=='.MainActivity' for a in activities))
 check('No new privileged wide-read manifest permissions',not any(x in manifest for x in ['QUERY_ALL_PACKAGES','READ_SMS','RECEIVE_SMS','READ_CALL_LOG','CALL_PHONE','MANAGE_EXTERNAL_STORAGE','SYSTEM_ALERT_WINDOW','BIND_ACCESSIBILITY_SERVICE','BIND_NOTIFICATION_LISTENER_SERVICE']))
else:check('Activity manifest check',False)
check('Version 45 source bump, same source namespace',"versionCode 45;" in gradle and "namespace 'com.sbh.atlasos'" in gradle and "applicationId 'com.sbh.atlasos'" in gradle)
check('R7 real app enumerator remains',all(v in launcher for v in ['launcherApps.getActivityList(null,user)','launcherApps.startMainActivity(', 'showApps()','favorites()']))
check('Native owner-tap Access Center entry visible in Universe', 'button("✧ Access Center' in launcher and 'setOnClickListener(v->openAccessCenter())' in launcher)
check('WebView native entry gated to authenticated owner', 'public void openAccessCenter()' in main and 'OwnerSessionGate.isCurrent(MainActivity.this,session)' in main)
check('WebView permissions snapshot gated to private session', 'if(!ownerRequired())return ' in main and 'AtlasAccessStatus.snapshot(MainActivity.this)' in main)
check('Permission status is read from OS, not hardcoded success', 'context.checkSelfPermission(' in status and 'n.areNotificationsEnabled()' in status and 'AppUsageReader.hasSpecialAccess(context)' in status)
check('Android roles read from official API', 'isRoleHeld(' in status and 'isRoleAvailable(' in status)
check('Runtime requests only after a user action plus explanation', 'setPositiveButton("Continue to Android",(d,w)->requestPermissions(' in center and 'setNegativeButton("Not now",null)' in center)
check('No request in onCreate/onResume',center.split('private void draw(){',1)[0].find('requestPermissions(')==-1)
check('No hidden audio or notification reader services added',not any(x in manifest for x in ['AtlasNotificationListener','AtlasAccessibilityService']))
check('Secure keyguard preserved',not any(x in center for x in ['setShowWhenLocked(', 'requestDismissKeyguard(', 'FLAG_DISMISS_KEYGUARD','DISABLE_KEYGUARD']))
check('No automatic Android settings mutation',not any(x in center for x in ['Settings.Secure.put','Settings.Global.put','setPermissionGrantState(', 'grantRuntimePermission(']))
check('Capability status JSON bridge available', 'public String accessStatusJson()' in main and 'accessStatusJson' in js)
check('Browser preview has explicit unavailable language', 'A compiled Android ATLAS app is required' in js)
check('User always has revoke App info shortcut', 'Settings.ACTION_APPLICATION_DETAILS_SETTINGS' in center)
check('No risky universal grant option', 'grantAll' not in center and 'Grant Everything' not in js and 'allowAll' not in js)
check('Android HOME/assistant roles remain manually selected', 'createRequestRoleIntent(name)' in center and 'setDefaultHome' not in center)
check('Phone/Messages external apps remain accessible', 'openMessages()' in center and 'Intent.ACTION_DIAL' in center)
check('No permission request for contacts or SMS', 'android.permission.READ_CONTACTS' not in manifest and 'android.permission.READ_SMS' not in manifest)
check('One offline storage picker remains available in ATLAS core', 'Library Transfer' in center and 'MANAGE_EXTERNAL_STORAGE' not in manifest)
check('R8 cache ID distinct', '0.8.6-r8-access-center-20261025' in (root/'app/src/main/assets/www/sw.js').read_text())
check('Status on activity resume rechecked without forced scroll reset', 'if (content != null) refreshStatuses();' in center)
receipt={'test':'R8 static source and privacy invariants','passed':sum(1 for r in checks if r['pass']),'total':len(checks),'all':checks,'sdk_build':'NOT_RUN','physical_android':'NOT_TESTED'}
p=root.parent/'receipts/R8_ACCESS_STATIC_QA.json';p.write_text(json.dumps(receipt,indent=2));print('RESULT',receipt['passed'],'/',receipt['total']);sys.exit(0 if receipt['passed']==receipt['total'] else 1)
