#!/usr/bin/env python3
"""Actual app HTML/JS in Chromium + real Python candidate service, SYNTHETIC owner gate.
Not Android WebView, Keystore, native JSON bridge, file persistence on a phone, or user acceptance.
Requires ATLAS_REFERENCE_ROOT pointing to prepared Python candidate; no network required.
"""
from pathlib import Path
import os, sys, json, re, shutil, secrets, tempfile, uuid
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
REFERENCE=Path(os.environ['ATLAS_REFERENCE_ROOT'])
sys.path.insert(0,str(REFERENCE/'src'))
from atlas_core.human_learning import HumanLearningService, CommunicationPreferences, ProgressUpdate, ConsentRequired, RevisionConflict
from atlas_core.models import AuthStrength
from atlas_core.runtime import AtlasRuntime
from atlas_core.session_store import EncryptedSessionRegistry
from atlas_core.vault import EncryptedVault
OUT=Path(os.environ.get('ATLAS_TEST_OUTPUT',ROOT/'test-output'));OUT.mkdir(parents=True,exist_ok=True)
results=[]
def check(name,passed):
    results.append({'case':name,'pass':bool(passed)})
    if not passed:raise AssertionError(name)
def digits(page,code):
    for x in code:page.locator(f'[data-k="{x}"]').click()
HTML=(ROOT/'app/src/main/assets/www/index.html').read_text()
HTML=re.sub(r'<script[^>]*>.*?</script>','',HTML,flags=re.S);HTML=re.sub(r'<link[^>]*>','',HTML)
NATIVE=r'''window.__active=false;window.__speeches=[];window.ATLASNative={
 isNative:()=>true,deviceStatus:()=>'{"battery":50}',ownerPinConfigured:()=>true,
 lockOwnerSession:()=>{window.__active=false;},ownerSessionActive:()=>window.__active,
 unlockOwner:p=>{window.__active=p==='123456';return window.__active;},ownerLockoutSeconds:()=>0,
 ownerRecoveryConfigured:()=>false,heyAtlasEnabled:()=>false,
 humanLearningRequest:q=>window.__learningRequest(q),speak:t=>window.__speeches.push(t)
};'''
with tempfile.TemporaryDirectory(prefix='atlas-ui-synthetic-') as tmp:
    base=Path(tmp);phrase=secrets.token_urlsafe(32)
    sessions=EncryptedSessionRegistry.initialize_or_open(base/'session.vault',phrase)
    core=AtlasRuntime.create(base/'core.sqlite',session_store=sessions);core.identity.initialize('synthetic-ui-learner')
    token,_=core.identity.issue_session(owner_id='synthetic-ui-learner',auth_strength=AuthStrength.PASSKEY)
    service=HumanLearningService(core.identity,EncryptedVault.initialize(base/'learning.vault',phrase))
    generation=None;calls=[];fault=None
    def public_profile(doc):
        return {'schema':1,'generation':generation,'revision':doc['revision'],'consent_active':doc['consent_active'],
                'sharing':'disabled','scope':'this-device-owner','preferences':doc['preferences'],'attempts':doc['attempts']}
    def request(raw):
        global generation,fault
        try:
            q=json.loads(raw);op=q['op'];calls.append(op)
            if fault:
                code=fault;fault=None;return json.dumps({'ok':False,'error':code})
            if op in ('update','consent','delete','submit') and q.get('generation')!=generation:raise RevisionConflict('generation')
            if op=='inspect':data=public_profile(service.inspect_profile(token))
            elif op=='create':
                doc=service.create_profile(token,consent=q['consent'],preferences=CommunicationPreferences(**q['preferences']));generation=str(uuid.uuid4());data=public_profile(doc)
            elif op=='update':data=public_profile(service.update_preferences(token,expected_revision=q['revision'],preferences=CommunicationPreferences(**q['preferences'])))
            elif op=='consent':data=public_profile(service.set_consent(token,active=q['active'],expected_revision=q['revision']))
            elif op=='delete':service.delete_profile(token,expected_revision=q['revision'],confirm=q['confirmed']);data={'deleted':True}
            elif op=='export':data={'profile':public_profile(json.loads(service.export_profile(token)))}
            elif op=='lesson':data=service.lesson(token,q['lesson_id'],urgent=q['urgent'])
            elif op=='submit':
                data=service.submit_answer(token,lesson_id=q['lesson_id'],answer=q['answer'],assisted=q['assisted'],attempt_id=q['attempt_id'],expected_revision=q['revision']);data['profile']=public_profile(service.inspect_profile(token))
            elif op=='progress':data=service.progress(token)
            elif op=='render':
                u=q['update'];data={'text':service.render(token,ProgressUpdate(status=u['status'],outcome=u['outcome'],next_action=u['next_action'],evidence_refs=tuple(u['evidence_refs']),details=tuple(u['details']),blockers=tuple(u['blockers']),warnings=tuple(u['warnings']),deadline=u['deadline']))}
            else:raise ValueError('operation')
            return json.dumps({'ok':True,'data':data})
        except ConsentRequired as e:code='NO_PROFILE' if 'no learner profile' in str(e) else 'CONSENT_REQUIRED'
        except RevisionConflict:code='REVISION_CONFLICT'
        except PermissionError:code='OWNER_UNLOCK_REQUIRED'
        except (ValueError,KeyError,TypeError):code='INVALID_INPUT'
        except Exception:code='STORAGE_UNAVAILABLE'
        return json.dumps({'ok':False,'error':code})
    try:
      with sync_playwright() as pw:
        browser=pw.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox'])
        context=browser.new_context(viewport={'width':390,'height':844});pg=context.new_page();errors=[];network=[]
        pg.on('pageerror',lambda e:errors.append(str(e)));pg.on('request',lambda r:network.append(r.url))
        pg.set_content(HTML)
        pg.evaluate("""()=>{const make=()=>{const data={};return {getItem:k=>Object.hasOwn(data,k)?data[k]:null,setItem:(k,v)=>{data[k]=String(v)},removeItem:k=>delete data[k],clear:()=>{for(const k in data)delete data[k]},dump:()=>data}};Object.defineProperty(window,'localStorage',{value:make(),configurable:true});Object.defineProperty(window,'sessionStorage',{value:make(),configurable:true});}""")
        pg.expose_function('__learningRequest',request);pg.evaluate(NATIVE)
        for name in ['style.css','atlas-v24.css','v26.css','v27.css','v28.css','v30.css','human-learning.css']:pg.add_style_tag(content=(ROOT/'app/src/main/assets/www'/name).read_text())
        pg.evaluate((ROOT/'app/src/main/assets/www/human-learning.js').read_text());pg.evaluate((ROOT/'app/src/main/assets/www/app.js').read_text())
        pg.locator('#begin').click();digits(pg,'123456');pg.locator('[data-app="settings"]').first.click();pg.get_by_text('Memory & Personalization',exact=True).click()
        pg.get_by_text('No learning profile exists. Nothing has been saved.',exact=True).wait_for()
        check('existing app settings open real learning screen',pg.locator('#humanLearning').count()==1)
        check('opening screen never opts in','create' not in calls)
        pg.locator('#hl-save').click();pg.get_by_text('Check the consent box first. Nothing was saved.',exact=True).wait_for()
        check('unchecked consent makes no create request','create' not in calls)
        pg.locator('#hl-optin').check();pg.locator('#hl-save').click();pg.locator('#hl-question').wait_for(state='visible')
        check('explicit optin persists through actual Python service',service.inspect_profile(token)['consent_active'])
        check('reply begins with source-not-deployed status',pg.locator('#hl-preview').inner_text().startswith('Prepared, not deployed:'))
        check('brief reply preserves warning blocker and evidence',all(x in pg.locator('#hl-preview').inner_text() for x in ['Warning:','Blocker:','Evidence:']))
        check('practice question present by default',pg.locator('#hl-practice-area').is_visible())
        pg.locator('#hl-answer').fill('200');pg.locator('#hl-submit').click();pg.get_by_text('Add the costs first: 50 + 30 + 20 = 100. Then subtract 100 from 400.',exact=True).wait_for()
        check('incorrect answer receives a different explanation','Add the costs first' in pg.locator('#hl-feedback').inner_text())
        pg.locator('#hl-answer').fill('300');pg.locator('#hl-submit').click();pg.get_by_text('Correct for this exercise. This does not establish mastery or real-world performance.',exact=True).wait_for()
        check('correct answer avoids mastery claim','does not establish mastery' in pg.locator('#hl-feedback').inner_text())
        check('progress uses actual service attempts',service.progress(token)['attempts']==2)
        pg.locator('#hl-submit').click();pg.wait_for_timeout(100)
        check('submission retry does not duplicate result',service.progress(token)['attempts']==2)
        pg.locator('#hl-urgent').check();pg.locator('#hl-practice-area').wait_for(state='hidden')
        check('urgent toggle hides practice',not pg.locator('#hl-practice-area').is_visible())
        pg.locator('#hl-urgent').uncheck();pg.locator('#hl-practice-area').wait_for(state='visible')
        pg.locator('#hl-detail').select_option('detailed');pg.locator('#hl-examples').uncheck();pg.locator('#hl-practice').select_option('off');pg.locator('#hl-save').click()
        pg.get_by_text('Your real-world learning outcomes have not been measured.',exact=False).first.wait_for()
        check('detail preference affects actual renderer','Your real-world learning outcomes have not been measured.' in pg.locator('#hl-preview').inner_text())
        check('examples off respected',pg.locator('#hl-example').inner_text()=='')
        check('practice off respected',not pg.locator('#hl-practice-area').is_visible())
        pg.locator('#hl-export').click();pg.locator('#hl-export-text').wait_for(state='visible');export=json.loads(pg.locator('#hl-export-text').input_value())
        check('export preview contains only learner profile',export['sharing']=='disabled' and export['preferences']['detail']=='detailed' and 'core' not in export)
        pg.locator('#hl-hide-export').click();check('hide clears exported text',pg.locator('#hl-export-text').input_value()=='' and not pg.locator('#hl-export-text').is_visible())
        pg.locator('#hl-consent').click();pg.get_by_text('Personalization is off. The existing record was not deleted.',exact=True).wait_for()
        check('revocation reaches actual service',service.inspect_profile(token)['consent_active'] is False)
        check('revocation hides all learning content',not pg.locator('#hl-lesson-card').is_visible() and not pg.locator('#hl-preview-card').is_visible())
        pg.locator('#hl-export').click();pg.locator('#hl-export-text').wait_for(state='visible');check('export remains accessible after revocation',json.loads(pg.locator('#hl-export-text').input_value())['consent_active'] is False)
        pg.locator('#hl-consent').click();pg.locator('#hl-lesson-card').wait_for(state='visible');check('explicit reconsent reenables',service.inspect_profile(token)['consent_active'] is True)
        pg.locator('#hl-read').click();pg.get_by_text('Speech requested from the device. Playback is not yet verified.',exact=True).wait_for();check('speech requires explicit button and is only requested',pg.evaluate('__speeches.length')==1)
        pg.locator('#hl-delete').click();pg.get_by_text('Confirm deletion first. Nothing was deleted.',exact=True).wait_for();check('unchecked deletion never touches service','delete' not in calls)
        fault='REVISION_CONFLICT';before=service.inspect_profile(token)['revision'];pg.locator('#hl-save').click();pg.get_by_text(messages:='The record changed. Refresh before trying again; nothing was overwritten.',exact=True).wait_for();check('stale conflict is shown without false success',service.inspect_profile(token)['revision']==before)
        pg.locator('#hl-refresh').click();pg.locator('#hl-lesson-card').wait_for(state='visible')
        # Capture the real integrated screen, with synthetic values only.
        pg.screenshot(path=str(OUT/'learning-screen-mobile.png'),full_page=True)
        check('learning screen fits phone width',pg.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'))
        pg.locator('#hl-export').click();pg.locator('#hl-export-text').wait_for(state='visible');pg.evaluate("dispatchEvent(new CustomEvent('atlas-learning-locked'))");pg.locator('#ownerRecover').wait_for()
        check('native lock signal removes learner data from DOM',pg.locator('#humanLearning').count()==0 and pg.locator('#hl-export-text').count()==0)
        digits(pg,'123456');pg.locator('[data-app="settings"]').first.click();pg.get_by_text('Model & Reply Behavior',exact=True).click();pg.locator('#hl-lesson-card').wait_for(state='visible')
        check('second settings route reaches same persistent profile',pg.locator('#hl-detail').input_value()=='detailed')
        pg.evaluate('window.__active=false');pg.locator('#ownerRecover').wait_for(timeout=2500);check('expired native session relocks visible screen',pg.locator('#humanLearning').count()==0)
        digits(pg,'123456');pg.locator('[data-app="settings"]').first.click();pg.get_by_text('Memory & Personalization',exact=True).click();pg.locator('#hl-lesson-card').wait_for(state='visible')
        pg.locator('#hl-delete-confirm').check();pg.locator('#hl-delete').click();pg.get_by_text('Deleted this device’s active learning record. Exported copies and backups were not erased.',exact=True).wait_for()
        try:service.inspect_profile(token);deleted=False
        except ConsentRequired:deleted=True
        check('confirmed deletion reaches actual encrypted service',deleted)
        check('deleted record disappears from UI',not pg.locator('#hl-controls').is_visible())
        saved=pg.evaluate('localStorage.dump()');check('new learner preferences never written to browser storage',not any('learning' in k or 'practice' in k for k in saved))
        check('no script exceptions in exercised flows',not errors)
        check('no web request made by test flow',not any(u.startswith(('http:','https:')) for u in network))
        context.close();browser.close()
    finally:
      (OUT/'learning-ui-results.json').write_text(json.dumps({'scope':'Actual Android app HTML/JS in desktop Chromium; real Python candidate reference service; mocked native owner bridge and speech; no Android runtime, Keystore, physical device, or human usefulness acceptance.','results':results,'passed':sum(x['pass'] for x in results),'total':len(results)},indent=2))
print(f'LEARNING_UI={sum(x["pass"] for x in results)}/{len(results)} PASS')
