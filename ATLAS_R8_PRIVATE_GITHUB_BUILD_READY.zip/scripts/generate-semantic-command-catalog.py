#!/usr/bin/env python3
"""Generate the immutable pure-Java ATLAS command catalog from the reviewed registry asset."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSET = ROOT / 'app/src/main/assets/atlas_commands/ATLAS_SEMANTIC_COMMAND_REGISTRY_V2_2026-10-10.json'
OUT = ROOT / 'app/src/main/java/com/sbh/atlasos/WorkflowCommandCatalog.java'


def j(value: str) -> str:
    return json.dumps(value, ensure_ascii=False).replace('\\/', '/')


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--registry', type=Path, default=ASSET)
    ap.add_argument('--output', type=Path, default=OUT)
    args = ap.parse_args()
    asset = args.registry
    output = args.output
    raw = asset.read_bytes()
    data = json.loads(raw)
    entries = data.get('entries')
    if not isinstance(entries, list) or len(entries) != data.get('total_entries'):
        raise SystemExit('registry entry count mismatch')
    seen = set()
    rows = []
    for e in entries:
        ident = e['id']
        if ident in seen:
            raise SystemExit(f'duplicate id: {ident}')
        seen.add(ident)
        aliases = e.get('aliases') or []
        rows.append(
            '    new Entry(%s, %s, %s, new String[]{%s})' % (
                j(ident), j(e['canonical_command']), j(e.get('category', '')),
                ', '.join(j(str(a)) for a in aliases)))
    src = f'''package com.sbh.atlasos;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Generated from the owner-reviewed 92-entry registry. It contains names and aliases only. */
public final class WorkflowCommandCatalog {{
  public static final String SCHEMA_VERSION = {j(str(data.get('schema_version', '')))};
  public static final String RECORD_ID = {j(str(data.get('record_id', '')))};
  public static final String REGISTRY_SHA256 = {j(hashlib.sha256(raw).hexdigest())};
  public static final int TOTAL_ENTRIES = {len(entries)};

  public static final class Entry {{
    public final String id;
    public final String canonical;
    public final String category;
    public final List<String> aliases;
    private Entry(String id, String canonical, String category, String[] aliases) {{
      this.id = id;
      this.canonical = canonical;
      this.category = category;
      List<String> copy = new ArrayList<String>();
      if (aliases != null) Collections.addAll(copy, aliases);
      this.aliases = Collections.unmodifiableList(copy);
    }}
  }}

  private static final Entry[] DATA = new Entry[]{{
{',\n'.join(rows)}
  }};
  private static final Map<String, Entry> BY_ID;
  private static final List<Entry> ALL;
  static {{
    LinkedHashMap<String, Entry> map = new LinkedHashMap<String, Entry>();
    ArrayList<Entry> all = new ArrayList<Entry>();
    for (Entry e : DATA) {{ map.put(e.id, e); all.add(e); }}
    BY_ID = Collections.unmodifiableMap(map);
    ALL = Collections.unmodifiableList(all);
    if (BY_ID.size() != TOTAL_ENTRIES) throw new IllegalStateException("catalog count mismatch");
  }}

  private WorkflowCommandCatalog() {{}}
  public static Entry byId(String id) {{ return BY_ID.get(id); }}
  public static List<Entry> all() {{ return ALL; }}

  /** Exact or clause-start catalog lookup. Canonical names outrank overlapping aliases. */
  public static Entry exactOrAnchored(String raw) {{
    String text = normalize(raw);
    if (text.isEmpty()) return null;
    for (Entry e : DATA) if (exact(text, e.canonical)) return e;
    for (Entry e : DATA) for (String alias : e.aliases) if (exact(text, alias)) return e;
    for (Entry e : DATA) if (anchored(text, e.canonical)) return e;
    for (Entry e : DATA) for (String alias : e.aliases) if (anchored(text, alias)) return e;
    return null;
  }}

  private static boolean exact(String text, String candidate) {{
    String c = normalize(candidate);
    return !c.isEmpty() && text.equals(c);
  }}

  private static boolean anchored(String text, String candidate) {{
    String c = normalize(candidate);
    return c.length() >= 7 && c.indexOf(' ') >= 0 && text.startsWith(c + " ");
  }}

  public static String normalize(String raw) {{
    if (raw == null) return "";
    String s = Normalizer.normalize(raw, Normalizer.Form.NFKC).toLowerCase(Locale.ROOT)
      .replace('\u2019', (char)39).replace('\u2018', (char)39)
      .replace('\u201c', (char)34).replace('\u201d', (char)34)
      .replace('\u2014', '-').replace('\u2013', '-');
    return s.replaceAll("\\\\s+", " ").trim();
  }}
}}
'''
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(src, encoding='utf-8')
    print(f'GENERATED_ENTRIES={len(entries)}')
    print(f'REGISTRY_SHA256={hashlib.sha256(raw).hexdigest()}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
