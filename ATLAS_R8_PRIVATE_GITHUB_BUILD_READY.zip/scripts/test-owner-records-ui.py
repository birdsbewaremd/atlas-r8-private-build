#!/usr/bin/env python3
"""Synthetic browser UI tests; fake native persistence, not Android Keystore/device acceptance."""
from pathlib import Path
import os,re,json,shutil
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
WWW=ROOT/'app/src/main/assets/www'
OUT=Path(os.getenv('ATLAS_RECORDS_TEST_OUTPUT',str(ROOT/'test-output/owner-records-ui')))
OUT.mkdir(parents=True,exist_ok=True)
html=re.sub(r'<script[^>]*>.*?</script>|<link[^>]*>','',(WWW/'index.html').read_text(),flags=re.S)
results=[];errors=[]
def check(name,ok):
 results.append({'case':name,'pass':bool(ok)});print(('PASS ' if ok else 'FAIL ')+name,flush=True)
MOCK=r'''()=>{
 const ls={'atlas.setup.complete':'1'},ss={};
 const store=data=>({getItem:k=>Object.hasOwn(data,k)?data[k]:null,setItem:(k,v)=>data[k]=String(v),removeItem:k=>delete data[k],clear:()=>{for(const k of Object.keys(data))delete data[k]}});
 Object.defineProperty(window,'localStorage',{configurable:true,value:store(ls)});
 Object.defineProperty(window,'sessionStorage',{configurable:true,value:store(ss)});
 window.__webStorage={ls,ss};window.__active=false;window.__records={};window.__calls=[];window.__handoffs=[];window.__failRead=null;window.__failWrite=null;
 window.ATLASNative={ownerPinConfigured:()=>true,deviceStatus:()=>'{}',ownerSessionActive:()=>__active,
  unlockOwner:p=>(__active=p==='123456'),lockOwnerSession:()=>{__active=false},ownerLockoutSeconds:()=>0,
  ownerRecordsRequest:raw=>{
   const q=JSON.parse(raw);__calls.push(q);
   if(!__active)return JSON.stringify({status:'locked'});
   if(q.op==='read')return JSON.stringify(__failRead?{status:__failRead}:(__records[q.key]||{status:'ok',value:null,revision:0}));
   if(__failWrite){if(__failWrite==='locked')__active=false;return JSON.stringify({status:__failWrite})}
   const old=__records[q.key]||{revision:0};
   if(old.revision!==q.expectedRevision)return JSON.stringify({status:'conflict'});
   const saved={status:'ok',value:q.value,revision:old.revision+1};__records[q.key]=saved;return JSON.stringify({status:'ok',revision:saved.revision});
  },openBookmarkedUrl:url=>{if(__active)__handoffs.push(url)}
 };
}'''
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path=os.getenv('CHROMIUM_EXECUTABLE') or shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 context=browser.new_context(viewport={'width':390,'height':844});context.set_default_timeout(5000)
 context.route('**/*',lambda route:route.abort())
 page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(html);page.evaluate(MOCK)
 for css in ['style.css','atlas-v24.css','v26.css','v27.css','v28.css','v30.css','owner-records.css']:page.add_style_tag(content=(WWW/css).read_text())
 for name in ['owner-records.js','app.js']:page.evaluate((WWW/name).read_text())
 def unlock():
  for digit in '123456':page.locator(f'[data-k="{digit}"]').click()
 def app(name):page.locator(f'[data-app="{name}"]').first.evaluate('(element)=>element.click()')
 def back():page.locator('#back').click()
 page.locator('#begin').click();unlock();app('notes')
 check('Notes opens through original app catalog',page.locator('#noteArea').count()==1)
 check('No record falsely reported as loaded', 'No saved record yet' in page.locator('#recordStatus').inner_text())
 note='PRIVATE NOTE <img src=x onerror="window.__injected=1"> 🦉'
 page.locator('#noteArea').fill(note)
 check('Unsaved note visibly marked',page.locator('#recordStatus').get_attribute('data-state')=='unsaved')
 check('Typing does not claim or perform a save',page.evaluate('__calls.filter(x=>x.op==="write").length')==0)
 page.locator('#noteSave').click()
 check('Explicit save writes native record and displays acknowledgement',page.evaluate('JSON.parse(__records.notes.value).text')==note and page.locator('#recordStatus').get_attribute('data-state')=='saved')
 check('Private note absent from browser storage',page.evaluate('JSON.stringify(__webStorage)').find('PRIVATE NOTE')<0)
 page.evaluate("dispatchEvent(new CustomEvent('atlas-owner-locked'))")
 check('Lock removes private editor and text from DOM',page.locator('#noteArea').count()==0 and 'PRIVATE NOTE' not in page.locator('body').inner_text())
 unlock();app('notes')
 check('Saved note returns after lock and reopen',page.locator('#noteArea').input_value()==note)
 check('Hostile note renders as plain text',page.evaluate('window.__injected||0')==0 and page.locator('#ownerRecords img').count()==0)
 page.evaluate("__failWrite='unavailable'");page.locator('#noteArea').fill('UNSAVED NEW VALUE');page.locator('#noteSave').click()
 check('Storage failure never reports Saved',page.locator('#recordStatus').get_attribute('data-state')=='error' and 'Nothing was saved' in page.locator('#recordStatus').inner_text())
 check('Failed save preserves edit and prior native value',page.locator('#noteArea').input_value()=='UNSAVED NEW VALUE' and page.evaluate('JSON.parse(__records.notes.value).text')==note)
 page.evaluate('__failWrite=null;__records.notes.revision+=1');page.locator('#noteSave').click()
 check('Revision conflict prevents overwriting', 'changed elsewhere' in page.locator('#recordStatus').inner_text() and page.evaluate('JSON.parse(__records.notes.value).text')==note)
 before=page.evaluate('__calls.length');page.locator('#noteSave').click();check('Conflict requires reload before another write',page.evaluate('__calls.length')==before)
 back();app('tasks');page.locator('#taskin').fill('Call a customer');page.locator('#taskadd').click()
 check('Task saves after add',page.evaluate('JSON.parse(__records.tasks.value).items[0].text')=='Call a customer')
 page.locator('#taskin').fill('Pending task input');page.locator('[data-ti="0"]').click();check('Completion preserves an unsubmitted new task',page.locator('#taskin').input_value()=='Pending task input');check('Completion persists without deleting task',page.evaluate('JSON.parse(__records.tasks.value).items[0].done') is True)
 page.evaluate("__failWrite='unavailable'");page.locator('#taskin').fill('NOT SAVED TASK');page.locator('#taskadd').click()
 check('Failed task save keeps input and existing list',page.locator('#taskin').input_value()=='NOT SAVED TASK' and page.locator('[data-ti]').count()==1 and page.locator('#recordStatus').get_attribute('data-state')=='error')
 page.evaluate('__failWrite=null');back();app('mail')
 check('Mail says disconnected and has no Send control','mailbox disconnected' in page.locator('body').inner_text() and page.get_by_role('button',name='Send',exact=True).count()==0)
 page.locator('#draftTo').fill('customer@example.com');page.locator('#draftSubject').fill('PRIVATE DRAFT');page.locator('#draftBody').fill('Hello <script>window.__injected=2</script>');page.locator('#draftSave').click()
 check('Mail draft saved without send or external handoff',page.evaluate('JSON.parse(__records.mailDrafts.value).items[0].subject')=='PRIVATE DRAFT' and page.evaluate('__handoffs.length')==0 and 'No email was sent' in page.locator('#recordStatus').inner_text())
 back();app('mail');page.locator('[data-draft="0"]').click()
 check('Saved draft reopens with original text',page.locator('#draftBody').input_value()=='Hello <script>window.__injected=2</script>' and page.evaluate('window.__injected||0')==0)
 page.locator('#draftBody').fill('UNSAVED DRAFT EDIT');page.locator('#draftNew').click()
 check('New draft does not silently discard unsaved editor',page.locator('#draftBody').input_value()=='UNSAVED DRAFT EDIT' and 'Save this draft' in page.locator('#recordStatus').inner_text())
 page.locator('#draftSave').click();back();app('browser')
 check('Browser scope explicitly limited to bookmarks','does not yet provide web tabs' in page.locator('body').inner_text())
 page.locator('#bookmarkTitle').fill('Unsafe');page.locator('#bookmarkUrl').fill('javascript:alert(1)');page.locator('#bookmarkSave').click()
 check('Unsafe URL rejected without native save',page.evaluate('!__records.bookmarks') and page.locator('#recordStatus').get_attribute('data-state')=='error')
 page.locator('#bookmarkUrl').fill('https://user:password@example.com');page.locator('#bookmarkSave').click()
 check('Credential-bearing URL rejected',page.evaluate('!__records.bookmarks'))
 page.locator('#bookmarkTitle').fill('<img src=x onerror=alert(1)> Documentation');page.locator('#bookmarkUrl').fill('https://example.com/docs');page.locator('#bookmarkSave').click()
 check('HTTPS bookmark saved without opening a website',page.evaluate('JSON.parse(__records.bookmarks.value).items[0].url')=='https://example.com/docs' and page.evaluate('__handoffs.length')==0)
 check('Hostile bookmark label escaped',page.locator('#bookmarkRows img').count()==0)
 page.locator('#bookmarkSearch').fill('documentation');check('Saved bookmark is searchable',page.locator('[data-bookmark]').count()==1)
 page.locator('[data-bookmark="0"]').click();check('Explicit Open requests native confirmation handoff',page.evaluate('__handoffs')==['https://example.com/docs'] and 'not been marked as opened' in page.locator('#recordStatus').inner_text())
 page.locator('#bookmarkSearch').fill('no match');check('Bookmark search does not alter stored list',page.locator('[data-bookmark]').count()==0 and page.evaluate('JSON.parse(__records.bookmarks.value).items.length')==1)
 check('No private record text persisted in WebStorage',all(t not in page.evaluate('JSON.stringify(__webStorage)') for t in ['PRIVATE NOTE','PRIVATE DRAFT','customer@example.com','example.com/docs']))
 back();page.evaluate("__failRead='corrupt'");app('notes')
 check('Corrupt read has no editor or overwrite action',page.locator('#noteArea').count()==0 and page.locator('#noteSave').count()==0 and 'Nothing was replaced' in page.locator('body').inner_text())
 back();page.evaluate("__failRead=null;__records.notes={status:'ok',value:'{broken',revision:7}");app('notes')
 check('Malformed stored schema fails closed',page.locator('#noteArea').count()==0 and 'No empty record' in page.locator('body').inner_text())
 back();page.evaluate("delete __records.notes;__failRead='unavailable'");app('notes');check('Unavailable read cannot overwrite a hidden record',page.locator('#noteSave').count()==0)
 back();page.evaluate('__failRead=null');app('notes');page.locator('#noteArea').fill('LOCK DURING SAVE');page.evaluate("__failWrite='locked'");page.locator('#noteSave').click()
 check('Lock returned during save clears private UI',page.locator('#noteArea').count()==0 and page.locator('#ownerRecover').count()==1)
 page.evaluate('__failWrite=null');unlock();app('mail');page.locator('[data-draft="0"]').click()
 page.evaluate('window.__active=false');page.wait_for_function("document.querySelector('#ownerRecover')!==null")
 check('Native session expiry clears loaded draft',page.locator('#draftBody').count()==0 and 'UNSAVED DRAFT EDIT' not in page.locator('body').inner_text())
 unlock();back_exists=page.locator('#back').count();app('notes')
 page.evaluate('delete ATLASNative.ownerRecordsRequest');back();app('notes')
 check('Missing native records API does not fall back to WebStorage',page.locator('#noteArea').count()==0 and 'will not save private' in page.locator('body').inner_text())
 # Restore API with new isolated page and check narrow layouts for each real surface.
 page2=context.new_page();page2.on('pageerror',lambda e:errors.append(str(e)));page2.set_content(html);page2.evaluate(MOCK)
 for css in ['style.css','atlas-v24.css','v26.css','v27.css','v28.css','v30.css','owner-records.css']:page2.add_style_tag(content=(WWW/css).read_text())
 for name in ['owner-records.js','app.js']:page2.evaluate((WWW/name).read_text())
 page2.locator('#begin').click()
 for digit in '123456':page2.locator(f'[data-k="{digit}"]').click()
 for width in [320,390,412]:
  page2.set_viewport_size({'width':width,'height':844})
  for name in ['notes','tasks','mail','browser']:
   page2.locator(f'[data-app="{name}"]').first.evaluate('(element)=>element.click()')
   check(f'{name} fits {width}px viewport',page2.evaluate('document.documentElement.scrollWidth<=innerWidth'))
   page2.locator('#back').click()
 check('No JavaScript runtime errors',not errors)
 context.close();browser.close()
result={'scope':'Synthetic Chromium with mocked native record store; no Android execution','passed':sum(x['pass'] for x in results),'total':len(results),'results':results,'errors':errors}
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print('OWNER_RECORDS_UI=%d/%d'%(result['passed'],result['total']))
raise SystemExit(0 if all(x['pass'] for x in results) else 1)
