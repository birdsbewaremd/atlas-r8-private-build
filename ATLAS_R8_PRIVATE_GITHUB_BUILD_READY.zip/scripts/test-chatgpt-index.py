#!/usr/bin/env python3
"""Host index tests using a Gson adapter for Android JsonReader's used methods.
This executes the actual indexer and AES-GCM codec, not Android lifecycle or
Android Keystore. The separate instrumentation probe exercises real Android.
Set ATLAS_TEST_GSON_JAR to the locally cached Gson jar; no downloads occur.
"""
import os
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
gson = Path(os.environ['ATLAS_TEST_GSON_JAR'])
wrapper = '''package android.util;
import java.io.*;
public final class JsonReader implements Closeable {
 private final com.google.gson.stream.JsonReader r;
 public JsonReader(Reader input){r=new com.google.gson.stream.JsonReader(input);}
 public void setLenient(boolean v){r.setLenient(v);}
 public JsonToken peek()throws IOException{return JsonToken.valueOf(r.peek().name());}
 public void beginArray()throws IOException{r.beginArray();}public void endArray()throws IOException{r.endArray();}
 public void beginObject()throws IOException{r.beginObject();}public void endObject()throws IOException{r.endObject();}
 public boolean hasNext()throws IOException{return r.hasNext();}
 public String nextName()throws IOException{return r.nextName();}public String nextString()throws IOException{return r.nextString();}
 public void nextNull()throws IOException{r.nextNull();}public void skipValue()throws IOException{r.skipValue();}
 public void close()throws IOException{r.close();}
}'''
test = r'''package com.sbh.atlasos;
import java.io.*;import java.nio.file.*;import java.nio.charset.StandardCharsets;import java.util.*;import javax.crypto.*;
public final class ChatGptIndexHostTest {
 static int passed;static Path root;static File vault;static SecretKey key;
 static void check(boolean b,String label){if(!b)throw new AssertionError(label);passed++;System.out.println("PASS "+label);}
 static InputStream input(String value){return new ByteArrayInputStream(value.getBytes(StandardCharsets.UTF_8));}
 static TransactionalSeedImporter.EncryptedWriter writer=(in,out,limit)->VaultFileCodec.encryptNew(in,out,key,limit,()->true);
 static ChatGptTextIndexer.Result index(String value)throws Exception{return ChatGptTextIndexer.index(input(value),root.toFile(),vault,writer,()->true);}
 static long count()throws Exception{try(java.util.stream.Stream<Path> files=Files.walk(vault.toPath())){return files.count();}}
 static void rejected(String value,String label)throws Exception{
  long before=count();boolean rejected=false;try{index(value);}catch(Exception expected){rejected=true;}
  check(rejected,label);check(count()==before,label+" preserves all committed output");
  try(DirectoryStream<Path> files=Files.newDirectoryStream(root,".atlas-chat-index-*")){check(!files.iterator().hasNext(),label+" removes only its staging");}
 }
 public static void main(String[]args)throws Exception{
  root=Files.createTempDirectory("atlas-chat-index-host-");vault=root.resolve("vault").toFile();vault.mkdir();
  KeyGenerator generator=KeyGenerator.getInstance("AES");generator.init(256);key=generator.generateKey();
  try{
   String json="[{\"id\":\"conversation-1\",\"title\":\"Unicode 🌎\",\"mapping\":{\"later\":{\"parent\":\"first\",\"message\":{\"id\":\"assistant-message\",\"create_time\":20,\"author\":{\"role\":\"assistant\"},\"content\":{\"parts\":[\"SECOND_REPLY\"]}}},\"first\":{\"parent\":null,\"message\":{\"id\":\"user-message\",\"create_time\":10,\"author\":{\"role\":\"user\"},\"content\":{\"parts\":[\"EXACT 🌎 line\\nnext\",{\"asset_pointer\":\"image retained\"}]}}}}}]";
   ChatGptTextIndexer.Result result=index(json);
   check(result.conversations==1&&result.messages==2&&result.files==1&&result.nonTextParts==1,"conversation, message, chunk and non-text counts");
   File output=new File(new File(vault,result.directory),"chat-00001-part-001.txt.atlasenc");
   byte[] bytes;try(InputStream in=new FileInputStream(output)){bytes=VaultFileCodec.decrypt(in,key,VaultSearchReader.MAX_TEXT_BYTES,()->true);}
   String text=new String(bytes,StandardCharsets.UTF_8);Arrays.fill(bytes,(byte)0);
   check(text.contains("EXACT 🌎 line\nnext"),"Unicode and source newline preserved");
   check(text.contains("Role: user")&&text.contains("Message ID: user-message")&&text.contains("Parent node: first"),"role and branch metadata retained");
   check(text.indexOf("EXACT")<text.indexOf("SECOND_REPLY"),"message order follows timestamps across exported map order");
   check(!new String(Files.readAllBytes(output.toPath()),StandardCharsets.ISO_8859_1).contains("EXACT"),"plaintext absent from encrypted index files");
   String large="[{\"mapping\":{\"node\":{\"message\":{\"id\":\"large\",\"content\":{\"parts\":[\""+String.join("",Collections.nCopies(100000,"x"))+"\"]}}}}}]";
   ChatGptTextIndexer.Result split=index(large);check(split.files>=3,"large conversation split into bounded searchable chunks");
   for(File file:new File(vault,split.directory).listFiles())check(file.length()<=VaultSearchReader.MAX_TEXT_BYTES+53,"encrypted chunk respects reader limit");
   rejected("[{\"unknown\":\""+String.join("",Collections.nCopies(140000,"x"))+"\"}]","oversized token rejected even inside unknown content");
   rejected("[{\"mapping\":{","truncated export rejected");
   rejected("[{\"unknown\":"+String.join("",Collections.nCopies(70,"["))+"0"+String.join("",Collections.nCopies(70,"]"))+"}]","excessive JSON nesting rejected");
   rejected("[{\"title\":\"Unknown export shape\",\"messages\":[]}]","unsupported conversation schema does not become a misleading empty index");
   long before=count();boolean locked=false;try{ChatGptTextIndexer.index(input(json),root.toFile(),vault,writer,()->false);}catch(IOException expected){locked=true;}
   check(locked&&before==count(),"locked request cannot mutate index");
   final boolean[] active={true};boolean expired=false;try{ChatGptTextIndexer.index(input(json),root.toFile(),vault,(in,out,limit)->{long saved=writer.write(in,out,limit);active[0]=false;return saved;},()->active[0]);}catch(IOException expected){expired=true;}
   check(expired&&count()==before,"session ending before commit preserves existing index");
   System.out.println("CHATGPT_INDEX_HOST="+passed+"/"+passed+" PASS (Gson JsonReader adapter + JCE; not Android device)");
  }finally{Files.walkFileTree(root,new SimpleFileVisitor<Path>(){public FileVisitResult visitFile(Path p,java.nio.file.attribute.BasicFileAttributes a)throws IOException{Files.delete(p);return FileVisitResult.CONTINUE;}public FileVisitResult postVisitDirectory(Path p,IOException e)throws IOException{Files.delete(p);return FileVisitResult.CONTINUE;}});}
 }
}'''
with tempfile.TemporaryDirectory(prefix='atlas-chat-index-compile-') as temporary:
    directory = Path(temporary)
    files = {
        'android/util/JsonReader.java': wrapper,
        'android/util/JsonToken.java': 'package android.util; public enum JsonToken { BEGIN_ARRAY, END_ARRAY, BEGIN_OBJECT, END_OBJECT, NAME, STRING, NUMBER, BOOLEAN, NULL, END_DOCUMENT }',
        'com/sbh/atlasos/ChatGptIndexHostTest.java': test,
    }
    sources = []
    for filename, content in files.items():
        path = directory / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)
        sources.append(str(path))
    for filename in ['ChatGptTextIndexer', 'TransactionalSeedImporter', 'SeedImportPolicy', 'ZipCompletionGuard', 'VaultFileCodec', 'VaultSearchReader']:
        sources.append(str(root / 'app/src/main/java/com/sbh/atlasos' / (filename + '.java')))
    subprocess.run(['javac', '-encoding', 'UTF-8', '-cp', str(gson), '-d', str(directory), *sources], check=True)
    subprocess.run(['java', '-cp', str(directory) + os.pathsep + str(gson), 'com.sbh.atlasos.ChatGptIndexHostTest'], check=True)
