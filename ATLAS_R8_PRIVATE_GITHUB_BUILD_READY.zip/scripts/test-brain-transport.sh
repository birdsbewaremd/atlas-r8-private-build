#!/usr/bin/env bash
set -euo pipefail
: "${JAVA_HOME:?Set JAVA_HOME to the build JDK}"
: "${JSON_JAR:?Set JSON_JAR to org.json:json:20240303 (official Maven Central)}"
atlas_brain_test_root="$(cd "$(dirname "$0")/.." && pwd)"
atlas_brain_test_dir="$(mktemp -d)"
trap 'rm -rf "$atlas_brain_test_dir"' EXIT
"$JAVA_HOME/bin/javac" -encoding UTF-8 -source 8 -target 8 -cp "$JSON_JAR" -d "$atlas_brain_test_dir" \
  "$atlas_brain_test_root/app/src/main/java/com/sbh/atlasos/AtlasBrainTransport.java" \
  "$atlas_brain_test_root/app/src/main/java/com/sbh/atlasos/AtlasBrainProfile.java" \
  "$atlas_brain_test_root/app/src/test/java/com/sbh/atlasos/BrainTransportTest.java" \
  "$atlas_brain_test_root/app/src/test/java/com/sbh/atlasos/BrainProfileTest.java"
"$JAVA_HOME/bin/java" -cp "$atlas_brain_test_dir:$JSON_JAR" com.sbh.atlasos.BrainTransportTest
"$JAVA_HOME/bin/java" -cp "$atlas_brain_test_dir:$JSON_JAR" com.sbh.atlasos.BrainProfileTest

