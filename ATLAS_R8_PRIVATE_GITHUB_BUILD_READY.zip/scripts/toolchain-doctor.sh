#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BLOCKERS=0

say(){ printf '%s\n' "$1"; }

if command -v java >/dev/null 2>&1; then
  JAVA_LINE="$(java -version 2>&1 | head -1)"
  JAVA_MAJOR="$(java -version 2>&1 | sed -n '1s/.*version "\([0-9][0-9]*\).*/\1/p')"
  say "JAVA=FOUND ${JAVA_LINE}"
  if [ -z "${JAVA_MAJOR:-}" ] || [ "$JAVA_MAJOR" != "21" ]; then say 'BLOCKER=JAVA_21_REQUIRED'; BLOCKERS=$((BLOCKERS+1)); fi
else
  say 'JAVA=MISSING'; say 'BLOCKER=JAVA_21_REQUIRED'; BLOCKERS=$((BLOCKERS+1))
fi

GRADLE_BIN=""
if command -v gradle >/dev/null 2>&1; then GRADLE_BIN="$(command -v gradle)";
elif [ -x "$ROOT/.toolchains/gradle-8.11.1/bin/gradle" ]; then GRADLE_BIN="$ROOT/.toolchains/gradle-8.11.1/bin/gradle"; fi
if [ -n "$GRADLE_BIN" ]; then
  GV="$($GRADLE_BIN --version 2>/dev/null | sed -n 's/^Gradle //p' | head -1)"
  say "GRADLE=FOUND ${GV:-UNKNOWN} $GRADLE_BIN"
  if [ "$GV" != "8.11.1" ]; then say 'BLOCKER=GRADLE_8_11_1_REQUIRED'; BLOCKERS=$((BLOCKERS+1)); fi
else
  say 'GRADLE=MISSING'; say 'BLOCKER=GRADLE_8_11_1_REQUIRED'; BLOCKERS=$((BLOCKERS+1))
fi

SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "$SDK_ROOT" ] && [ -d "$ROOT/.toolchains/android-sdk" ]; then SDK_ROOT="$ROOT/.toolchains/android-sdk"; fi
if [ -n "$SDK_ROOT" ]; then
  say "ANDROID_SDK=FOUND $SDK_ROOT"
  if [ -f "$SDK_ROOT/platforms/android-35/android.jar" ]; then say 'ANDROID_PLATFORM_35=FOUND'; else say 'ANDROID_PLATFORM_35=MISSING'; say 'BLOCKER=ANDROID_PLATFORM_35_REQUIRED'; BLOCKERS=$((BLOCKERS+1)); fi
  if [ -x "$SDK_ROOT/build-tools/35.0.0/aapt2" ] && [ -x "$SDK_ROOT/build-tools/35.0.0/apksigner" ]; then
    say 'ANDROID_BUILD_TOOLS=FOUND 35.0.0'
  else
    say 'ANDROID_BUILD_TOOLS_35_0_0=MISSING_OR_INCOMPLETE'; say 'BLOCKER=ANDROID_BUILD_TOOLS_35_0_0_REQUIRED'; BLOCKERS=$((BLOCKERS+1))
  fi
  if [ -x "$SDK_ROOT/platform-tools/adb" ]; then ADB="$SDK_ROOT/platform-tools/adb"; else ADB="$(command -v adb 2>/dev/null || true)"; fi
else
  say 'ANDROID_SDK=MISSING'; say 'BLOCKER=ANDROID_SDK_REQUIRED'; BLOCKERS=$((BLOCKERS+1)); ADB="$(command -v adb 2>/dev/null || true)"
fi

if [ -n "${ADB:-}" ]; then
  say "ADB=FOUND $ADB"
  DEVICES="$($ADB devices 2>/dev/null | awk 'NR>1 && $2=="device"{c++} END{print c+0}')"
  say "ADB_CONNECTED_DEVICES=$DEVICES"
else
  say 'ADB=MISSING'
  say 'ADB_CONNECTED_DEVICES=UNKNOWN'
fi

say "BLOCKER_COUNT=$BLOCKERS"
if [ "$BLOCKERS" -eq 0 ]; then say 'BUILD_TOOLCHAIN=READY'; exit 0; fi
say 'BUILD_TOOLCHAIN=BLOCKED'; exit 10
