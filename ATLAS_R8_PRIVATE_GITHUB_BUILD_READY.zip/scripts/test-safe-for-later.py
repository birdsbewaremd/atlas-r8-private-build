#!/usr/bin/env python3
from pathlib import Path
import json,re,sys
ROOT=Path(__file__).resolve().parents[1]
data=(ROOT/'app/src/main/assets/www/safe-for-later-data.js').read_text()
app=(ROOT/'app/src/main/assets/www/app.js').read_text()
html=(ROOT/'app/src/main/assets/www/index.html').read_text()
assert data.startswith('/* Generated from ATLAS Safe for Later v0.3.4 metadata-only index.')
m=re.search(r'Object\.freeze\((\[.*\])\);\s*$',data,re.S); assert m
items=json.loads(m.group(1)); assert len(items)==29
assert len({x['id'] for x in items})==29
allowed={'id','title','area','status','priority','auto_resume','next_action','blocker'}
assert all(set(x)<=allowed for x in items)
assert all(isinstance(x.get('title'),str) and isinstance(x.get('next_action'),str) for x in items)
assert 'source_refs' not in data and 'raw_vault' not in data and 'ciphertext' not in data
assert './safe-for-later.css' in html and 0 <= html.index('./safe-for-later-data.js') < html.index('./app.js')
assert 'function safeForLater()' in app and "'safefor'" in app
s=app[app.index('function safeForLater()'):app.index('function filesApp()')]
assert 'Native.call(' not in s and 'runAtlasCommand(' not in s and 'atlasConsole(' not in s
assert 'atlas.safeLater.reviewed.v1' in s
print('SAFE_FOR_LATER=10/10 PASS')
