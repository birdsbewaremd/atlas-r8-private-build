#!/usr/bin/env python3
from pathlib import Path
import collections, re, sys
ROOT=Path(__file__).resolve().parents[1]
js=(ROOT/'app/src/main/assets/www/app.js').read_text()
records=(ROOT/'app/src/main/assets/www/owner-records.js').read_text()
index=(ROOT/'app/src/main/assets/www/index.html').read_text()
checks=[]
def check(name,ok):checks.append((name,bool(ok)))
names=collections.defaultdict(list)
for m in re.finditer(r'(?m)^function\s+([A-Za-z_$][\w$]*)\s*\(',js):
    names[m.group(1)].append(js.count('\n',0,m.start())+1)
duplicates={k:v for k,v in names.items() if len(v)>1}
check('No shadowed duplicate top-level UI function declarations',not duplicates)
check('Native private store selects sessionStorage', 'function privateStore(){return Native.available()?sessionStorage:localStorage}' in js)
check('Native lock clears private session content',
      re.search(r'function lock\(\)\{[^\n]*clearNativePrivateSession\(\)',js) is not None)
check('Native lock disposes rendered durable records first',
      'function lock(){disposeOwnerRecords();clearNativePrivateSession();' in js)
for key in ('atlas.msgs.','atlas.note','atlas.tasks','atlas.lastPhoto'):
    check('No direct persistent localStorage access for '+key,
          re.search(r"localStorage\.(?:getItem|setItem)\([^)]*"+re.escape(key),js) is None)
check('Messages use private helper',"privateGet('atlas.msgs.'+role)" in js and "privateSet('atlas.msgs.'+role" in js)
check('Notes route to native records screen',"function notes(){return ownerRecordsApp('notes')}" in js)
check('Tasks route to native records screen',"function tasks(){return ownerRecordsApp('tasks')}" in js)
check('Durable record UI is bundled before app shell',
      index.index('./owner-records.js') < index.index('./app.js'))
check('Durable record UI has no WebStorage read or write fallback',
      re.search(r'(?:localStorage|sessionStorage)\s*\.',records) is None)
check('Durable record UI uses native read/write revisions',
      'ownerRecordsRequest(JSON.stringify(data))' in records
      and "request({op:'read',key})" in records
      and "request({op:'write',key,value,expectedRevision:revision})" in records)
check('Durable plaintext model and fields are discarded on disposal',
      'alive=false;record=null;currentDraft=null;dirty=false;clearForm();host.replaceChildren()' in records)
check('Photos use private helper',"privateGet('atlas.lastPhoto')" in js and "privateSet('atlas.lastPhoto'" in js)
check('Delayed chat callback refuses post-lock repopulation',"sessionStorage.getItem('atlas.role')!==messageRole" in js and "!Native.call('ownerSessionActive')" in js)
check('Saved and unsaved record behavior is disclosed',
      'Saved records stay encrypted on this phone after lock.' in records
      and 'Unsaved edits clear when you leave or lock.' in records)
check('Device-bound persistence is not presented as portable backup',
      'portable backup is not yet available.' in records)
check('Malformed reads block empty-record replacement',
      "errorScreen('corrupt')" in records and 'No empty record will overwrite saved data.' in records)
check('Save failures are not labeled saved',
      "if(commit(next))status('Saved encrypted on this phone.','saved')" in records
      and "status(failText(response.status),'error');return false;" in records)
check('Messages explicitly disclose session-only local preview','Local preview messages only. Cleared when ATLAS locks or leaves the foreground. Nothing is sent to a person or AI service.' in js)
for name,ok in checks: print(('PASS' if ok else 'FAIL')+' '+name)
if duplicates: print('DUPLICATES='+repr(duplicates))
passed=sum(ok for _,ok in checks)
print(f'PRIVATE_UI_STORAGE={passed}/{len(checks)} PASS' if passed==len(checks) else f'PRIVATE_UI_STORAGE={passed}/{len(checks)} FAIL')
sys.exit(0 if passed==len(checks) else 2)
