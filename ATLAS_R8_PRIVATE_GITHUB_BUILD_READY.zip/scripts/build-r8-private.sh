#!/usr/bin/env bash
# R8 Android source-to-debug APK: manual, owner private, never installs or changes Android permissions.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 scripts/test-r8-access-source.py
bash scripts/test-java-syntax.sh
node --check app/src/main/assets/www/atlas-access.js
node --check app/src/main/assets/www/atlas-installed-drawer.js
node --check app/src/main/assets/www/app.js
node --check app/src/main/assets/www/sw.js
if [ "${1:-}" = '--source-check-only' ]; then
  echo 'R8_SOURCE_AND_STATIC_CHECKS=PASS; APK=NOT_BUILT'; exit 0
fi
if ! bash scripts/toolchain-doctor.sh; then
  echo 'BLOCKED: missing official Android SDK/Gradle toolchain. No APK compiled.' >&2; exit 34
fi
GRADLE_BIN="$(command -v gradle || true)"
if [ -z "$GRADLE_BIN" ]; then GRADLE_BIN="$ROOT/.toolchains/gradle-8.11.1/bin/gradle"; fi
"$GRADLE_BIN" --no-daemon lintDebug assembleDebug
APK='app/build/outputs/apk/debug/app-debug.apk'
test -s "$APK"
SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$ROOT/.toolchains/android-sdk}}"
TOOLS="$SDK_ROOT/build-tools/35.0.0"
"$TOOLS/apksigner" verify --verbose --print-certs "$APK"
"$TOOLS/aapt" dump badging "$APK" | tee "$APK.badging.txt"
grep -q "package: name='com.sbh.atlasos.candidate'" "$APK.badging.txt"
"$TOOLS/aapt" dump xmltree "$APK" AndroidManifest.xml | tee "$APK.manifest.txt"
grep -q 'AtlasLauncherActivity' "$APK.manifest.txt"
grep -q 'AtlasAccessCenterActivity' "$APK.manifest.txt"
"$TOOLS/aapt" dump permissions "$APK" | tee "$APK.permissions.txt"
for forbidden in 'android.permission.READ_SMS' 'android.permission.RECEIVE_SMS' 'android.permission.CALL_PHONE' 'android.permission.QUERY_ALL_PACKAGES' 'android.permission.SYSTEM_ALERT_WINDOW' 'android.permission.MANAGE_EXTERNAL_STORAGE'; do
  if grep -q "$forbidden" "$APK.permissions.txt"; then echo "REFUSED unexpected permission $forbidden" >&2; exit 51; fi
done
OUT="$ROOT/ATLAS_ONE_R8_PRIVATE_DEBUG_TEST.apk"
cp "$APK" "$OUT"
sha256sum "$OUT" > "$OUT.sha256"
echo "APK_BUILT_DEBUG_ONLY=$OUT; UPDATE_SIGNER_UNVERIFIED; DEVICE_TESTS_NOT_RUN; NO_PERMISSION_GRANTED"
