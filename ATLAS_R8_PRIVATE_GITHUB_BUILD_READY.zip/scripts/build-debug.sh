#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
# Direct local build entrypoint must fail fast when there is no usable Android
# toolchain. CI already checks its toolchain separately; this is a second guard.
# Source-only runs the same tests WITHOUT claiming to produce an APK.
usage(){ printf '%s\n' 'Usage: bash scripts/build-debug.sh [--source-only | --doctor | --help]'; }
if [ "$#" -gt 1 ]; then usage >&2; exit 2; fi
MODE="build"
case "${1:-}" in
  '') ;;
  --source-only) MODE="source-only";;
  --doctor) exec bash ./scripts/toolchain-doctor.sh;;
  --help|-h) usage; exit 0;;
  *) usage >&2; exit 2;;
esac
if [ "$MODE" = 'build' ]; then
  echo 'ATLAS_ENTRYPOINT=BUILD_PREFLIGHT'
  if bash ./scripts/toolchain-doctor.sh; then
    echo 'BUILD_TOOLCHAIN_PREFLIGHT=PASS'
  else
    result=$?
    echo 'BUILD_ABORTED=TOOLCHAIN_NOT_READY; NO_APK_ATTEMPT; use --source-only for source tests' >&2
    exit "$result"
  fi
else
  echo 'ATLAS_ENTRYPOINT=SOURCE_ONLY; NATIVE_BUILD_NOT_REQUESTED'
fi
python3 ./scripts/package-source.py --verify
python3 ./scripts/test-source-package.py
python3 ./scripts/test-build-entrypoint.py
python3 ./scripts/test-ci-build-workflow.py
python3 ./scripts/check-semantic-command-assets.py
node --check app/src/main/assets/www/app.js
bash ./scripts/test-pure-java.sh
node ./scripts/test-file-search.js
bash ./scripts/test-vault-search.sh
python3 ./scripts/test-file-search-ui.py
bash ./scripts/test-human-learning-java.sh
python3 ./scripts/test-learning-source.py
if [ -n "${ATLAS_REFERENCE_ROOT:-}" ] && [ -f "${ATLAS_REFERENCE_ROOT}/src/atlas_core/human_learning.py" ]; then
  python3 ./scripts/test-learning-contract.py
  python3 ./scripts/test-human-learning-ui.py
  echo 'REFERENCE_LEARNING_GATES=PASS'
else
  echo 'REFERENCE_LEARNING_GATES=NOT_RUN (set ATLAS_REFERENCE_ROOT to the verified pinned Python candidate)'
fi
python3 ./scripts/test-native-session.py
python3 scripts/test-module-lifecycle.py
python3 ./scripts/test-pause-privacy.py
python3 ./scripts/test-release-evidence-gate.py
bash ./scripts/test-transactional-import.sh
bash ./scripts/test-vault-crypto.sh
python3 ./scripts/test-voice-start.py
python3 ./scripts/test-wake-session.py
python3 ./scripts/test-app-awareness.py
python3 ./scripts/test-app-android-stubs.py
python3 ./scripts/test-god-wiring.py
python3 ./scripts/test-god-v3-convergence.py
python3 ./scripts/test-god-v4-hardening.py
python3 ./scripts/test-safe-for-later.py
python3 ./scripts/test-storage-source.py
bash ./scripts/test-java-syntax.sh
python3 ./scripts/test-storage-ui.py
python3 ./scripts/test-omega-merge.py
python3 ./scripts/test-god-master-source.py
bash ./scripts/test-god-master-java.sh
python3 ./scripts/test-god-master-ui.py
python3 ./scripts/test-private-ui-storage.py
mkdir -p ./test-output
python3 ./scripts/test-ai-trust-gates.py . --json-out ./test-output/ai-trust-build-gate.json
python3 ./scripts/source-redteam.py
python3 ./scripts/security-audit.py
if [ "$MODE" = 'source-only' ]; then
  echo 'ATLAS_SOURCE_GATES=PASS; ANDROID_APK=NOT_BUILT; DEVICE_TESTS=NOT_RUN'
  exit 0
fi
GRADLE_BIN="$(command -v gradle 2>/dev/null || true)"
if [ -z "$GRADLE_BIN" ] && [ -x "$ROOT/.toolchains/gradle-8.11.1/bin/gradle" ]; then GRADLE_BIN="$ROOT/.toolchains/gradle-8.11.1/bin/gradle"; fi
SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "$SDK_ROOT" ] && [ -d "$ROOT/.toolchains/android-sdk" ]; then SDK_ROOT="$ROOT/.toolchains/android-sdk"; fi
export ANDROID_HOME="$SDK_ROOT" ANDROID_SDK_ROOT="$SDK_ROOT"
"$GRADLE_BIN" --no-daemon clean lintDebug assembleDebug
APK=app/build/outputs/apk/debug/app-debug.apk
if [ ! -s "$APK" ]; then echo 'FAILED: APK not produced' >&2; exit 8; fi
sha256sum "$APK" | tee "$APK.sha256"
