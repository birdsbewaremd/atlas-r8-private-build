#!/usr/bin/env python3
"""No secrets loaded: test wiring, native-only access and source-only package boundary."""
from pathlib import Path
import re,sys
r=Path(__file__).resolve().parents[1]
def read(p):return (r/p).read_text(encoding='utf-8')
app=read('app/src/main/assets/www/app.js')
index=read('app/src/main/assets/www/index.html')
java=read('app/src/main/java/com/sbh/atlasos/MainActivity.java')
god=read('app/src/main/java/com/sbh/atlasos/GodPrivateIndexPolicy.java')
worker=read('app/src/main/assets/www/sw.js')
manifest=read('app/src/main/AndroidManifest.xml')
checks={
'owner GOD entry in catalog': "['god','GOD · Master Chat'" in app,
'owner GOD entry enforced by owner set': "ownerOnly=new Set(['learning'" in app and "'storage','god']" in app,
'GOD master uses Native owner session': "!Native.available()||!Native.call('ownerSessionActive')" in app,
'GOD master uses native index only': "Native.call('godPrivateIndex')" in app,
'GOD master NEVER saves private records to localStorage': not re.search(r"localStorage\.(?:setItem|getItem)\([^)]*(?:godPrivate|godGoals|god\.private)",app,re.I),
'GOD master accepts 56 native goals exactly': "answer.goals.length===56" in app,
'GOD both sides and search': all(n in app for n in ('data-god-mode="BOTH"','godSearch','godNext','x.good','x.bad')),
'GOD user text escaped': 'esc(x.good)' in app and 'esc(x.bad' in app and 'esc(x.next' in app,
'GOD main pinned hero': "data-app=\"${role==='owner'?'god':'atlas'}\"" in app,
'GOD native import behind confirmation': 'Native.call(\'importSeedZip\')' in app and 'Confirm private import' in java,
'GOD native reader behind owner gate': 'final long session=OwnerSessionGate.capture(MainActivity.this);' in java,
'GOD native read bound to session generation': 'OwnerSessionGate.isCurrent(MainActivity.this,session)' in java,
'GOD content hash pinned': 'GodPrivateIndexPolicy.trustedContent(value)' in java and 'EXPECTED_SHA256' in god,
'GOD native parser rejects duplicate goal IDs': '!ids.add(row.optString("id"))' in java,
'GOD private data is not bundled as source asset': not (r/'app/src/main/assets/god').exists() and not (r/'app/src/main/assets/www/GOD_PRIVATE_MASTER_V1.json').exists(),
'GOD is NOT a new permission': 'android.permission.INTERNET' not in manifest and 'android.permission.MANAGE_EXTERNAL_STORAGE' not in manifest,
'GOD style offline cached': 'god-master.css' in worker and 'god-master.css' in index,
'GOD keeps command recognition-only': 'return routeAuthenticatedInput(command,WorkflowIntentParser.Origin.UI_TEXT);' in java and 'GodCommandPolicy.parse' in java,
'GOD does not grant automatic external actions': 'Nothing sends or operates a device without separate authority' in app,
'GOD future native APK claim absent': 'NOT installed or deployed' in read('GOD_MASTER_CHAT_V1_README.md') or 'not installed or deployed' in read('GOD_MASTER_CHAT_V1_README.md'),
}
for name,ok in checks.items():print(('PASS' if ok else 'FAIL')+' GODMASTER '+name)
print(f'GOD_MASTER_SOURCE={sum(checks.values())}/{len(checks)} '+('PASS' if all(checks.values()) else 'FAIL'))
sys.exit(0 if all(checks.values()) else 2)
