#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac -encoding UTF-8 -d "$TMP" "$ROOT/app/src/main/java/com/sbh/atlasos/HumanLearningEngine.java" "$ROOT/app/src/main/java/com/sbh/atlasos/LearningCipher.java" "$ROOT/app/src/test/java/com/sbh/atlasos/HumanLearningEngineTest.java"
java -cp "$TMP" com.sbh.atlasos.HumanLearningEngineTest
