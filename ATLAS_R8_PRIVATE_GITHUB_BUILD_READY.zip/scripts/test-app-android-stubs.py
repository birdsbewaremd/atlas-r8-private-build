#!/usr/bin/env python3
"""Host-only Android API fakes. Tests actual AppUsageReader control flow, NOT a phone."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
fixtures={
'android/content/Context.java':'''package android.content;
public class Context {
 public static final String APP_OPS_SERVICE="ops", USER_SERVICE="user", USAGE_STATS_SERVICE="usage";
 public Object ops,user,usage;
 public String getPackageName(){return "com.sbh.atlasos.candidate";}
 public Object getSystemService(String x){return x.equals(APP_OPS_SERVICE)?ops:x.equals(USER_SERVICE)?user:x.equals(USAGE_STATS_SERVICE)?usage:null;}
}''',
'android/os/Process.java':'''package android.os; public final class Process { public static int myUid(){return 1000;} }''',
'android/os/UserManager.java':'''package android.os; public class UserManager {public boolean unlocked=true;public boolean isUserUnlocked(){return unlocked;} }''',
'android/app/AppOpsManager.java':'''package android.app; public class AppOpsManager {public static final int MODE_ALLOWED=0;public static final String OPSTR_GET_USAGE_STATS="GET_USAGE_STATS"; public int mode=0;public int checkOpNoThrow(String x,int uid,String pkg){return mode;} }''',
'android/app/usage/UsageEvents.java':'''package android.app.usage;
import java.util.*;
public class UsageEvents {
 public static class Event {public static final int ACTIVITY_RESUMED=1,MOVE_TO_FOREGROUND=1;
  private String pkg;private long when;private int type;
  public Event(){} public Event(String p,long t,int k){pkg=p;when=t;type=k;}
  public String getPackageName(){return pkg;} public long getTimeStamp(){return when;} public int getEventType(){return type;}
  public void copy(Event e){pkg=e.pkg;when=e.when;type=e.type;}
 }
 public final List<Event> events;public int index=0,revokeAt=-1;
 public UsageEvents(List<Event> rows){events=rows;}
 public boolean hasNextEvent(){return index<events.size();}
 public boolean getNextEvent(Event out){if(!hasNextEvent())return false;out.copy(events.get(index++));if(index==revokeAt)com.sbh.atlasos.OwnerSessionGate.allowed=false;return true;}
}''',
'android/app/usage/UsageStatsManager.java':'''package android.app.usage;
public class UsageStatsManager {public UsageEvents events;public UsageEvents queryEvents(long from,long to){return events;} }''',
'com/sbh/atlasos/OwnerSessionGate.java':'''package com.sbh.atlasos;import android.content.Context;
public final class OwnerSessionGate {public static boolean allowed=true;public static boolean isCurrent(Context c,long gen){return allowed&&gen==101L;} }''',
'AppUsageReaderHarness.java':r'''import android.content.Context;import android.app.AppOpsManager;import android.os.UserManager;
import android.app.usage.*;import com.sbh.atlasos.*;import java.util.*;
public class AppUsageReaderHarness {
 static int checks=0;
 static Context c;static AppOpsManager ops;static UserManager user;static UsageStatsManager usage;
 static UsageEvents events(UsageEvents.Event... rows){return new UsageEvents(Arrays.asList(rows));}
 static UsageEvents.Event e(String name,long at){return new UsageEvents.Event(name,at,1);}
 static void fresh(){c=new Context();ops=new AppOpsManager();user=new UserManager();usage=new UsageStatsManager();c.ops=ops;c.user=user;c.usage=usage;OwnerSessionGate.allowed=true;usage.events=events();}
 static void check(String s,boolean ok){checks++;if(!ok)throw new AssertionError(s);System.out.println("PASS APPCTX STUB "+s);}
 public static void main(String[] a){
  fresh();check("manual usage access grant is separately required",AppUsageReader.hasSpecialAccess(c));
  fresh();ops.mode=1;check("missing special access denied",!AppUsageReader.hasSpecialAccess(c)&&AppUsageReader.readOnce(c,101).isEmpty());
  fresh();user.unlocked=false;check("screen user locked denied",AppUsageReader.readOnce(c,101).isEmpty());
  fresh();OwnerSessionGate.allowed=false;check("revoked owner session denied",AppUsageReader.readOnce(c,101).isEmpty());
  fresh();check("stale owner generation denied",AppUsageReader.readOnce(c,102).isEmpty());
  fresh();usage.events=null;check("missing usage events fail closed",AppUsageReader.readOnce(c,101).isEmpty());
  long now=System.currentTimeMillis();
  fresh();usage.events=events(e("org.example.b",now-30),e("org.example.a",now-10),e("com.sbh.atlasos.candidate",now));
  check("recent package names only, sorted, exclude Atlas",AppUsageReader.readOnce(c,101).equals(Arrays.asList("org.example.a","org.example.b")));
  fresh();usage.events=events(e("org.example.a",now-1),e("org.example.b",now));usage.events.revokeAt=1;
  check("mid-read revocation returns nothing",AppUsageReader.readOnce(c,101).isEmpty());
  fresh();List<UsageEvents.Event> huge=new ArrayList<>();for(int i=0;i<2600;i++)huge.add(new UsageEvents.Event("org.example.ignore",now,5));usage.events=new UsageEvents(huge);
  check("oversized raw event stream fails closed",AppUsageReader.readOnce(c,101).isEmpty());
  fresh();c.ops=null;check("missing AppOps service fails closed",!AppUsageReader.hasSpecialAccess(c));
  System.out.println("APPCTX_ANDROID_STUBS="+checks+"/"+checks+" PASS");
 }
}'''
}
with tempfile.TemporaryDirectory(prefix='atlas-appctx-stub-') as temp:
 d=Path(temp);files=[]
 for name,content in fixtures.items():
  p=d/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content);files.append(str(p))
 java=root/'app/src/main/java/com/sbh/atlasos'
 files.extend([str(java/'AppAwarenessPolicy.java'),str(java/'AppUsageReader.java')])
 subprocess.run(['javac','-d',str(d),*files],check=True)
 subprocess.run(['java','-cp',str(d),'AppUsageReaderHarness'],check=True)
