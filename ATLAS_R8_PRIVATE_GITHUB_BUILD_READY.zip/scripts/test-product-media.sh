#!/usr/bin/env bash
set -euo pipefail
ATLAS_TEST_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ATLAS_TEST_CLASSES="$(mktemp -d)"
trap 'rm -rf "$ATLAS_TEST_CLASSES"' EXIT
: "${ANDROID_JAR:?Set ANDROID_JAR to Android API35 android.jar}"
"${JAVA_HOME:+$JAVA_HOME/bin/}javac" -encoding UTF-8 -source 8 -target 8 -cp "$ANDROID_JAR" -d "$ATLAS_TEST_CLASSES" \
 "$ATLAS_TEST_ROOT/app/src/main/java/com/sbh/atlasos/AtlasProductMediaStore.java" \
 "$ATLAS_TEST_ROOT/app/src/main/java/com/sbh/atlasos/OwnerSessionGate.java" \
 "$ATLAS_TEST_ROOT/app/src/main/java/com/sbh/atlasos/VaultFileCodec.java" \
 "$ATLAS_TEST_ROOT/app/src/main/java/com/sbh/atlasos/SeedImportPolicy.java" \
 "$ATLAS_TEST_ROOT/app/src/test/java/com/sbh/atlasos/ProductMediaPolicyTest.java"
"${JAVA_HOME:+$JAVA_HOME/bin/}java" -cp "$ATLAS_TEST_CLASSES:$ANDROID_JAR" com.sbh.atlasos.ProductMediaPolicyTest
