#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac --release 8 -d "$TMP" \
 "$ROOT/app/src/main/java/com/sbh/atlasos/SeedImportPolicy.java" \
 "$ROOT/app/src/main/java/com/sbh/atlasos/TransactionalSeedImporter.java" \
 "$ROOT/app/src/main/java/com/sbh/atlasos/ZipCompletionGuard.java" \
 "$ROOT/app/src/main/java/com/sbh/atlasos/VaultFileCodec.java" \
 "$ROOT/app/src/test/java/com/sbh/atlasos/VaultFileCodecTest.java"
java -cp "$TMP" com.sbh.atlasos.VaultFileCodecTest
