#!/usr/bin/env python3
"""Regression tests for appctx1: executable pure Java and source-wiring tripwires.
NOT Android compilation or permission/device acceptance.
"""
from pathlib import Path
import re, subprocess, tempfile
R=Path(__file__).resolve().parents[1]
app=R/'app/src/main/java/com/sbh/atlasos'
java=(app/'AppAwarenessPolicy.java')
reader=(app/'AppUsageReader.java').read_text()
main=(app/'MainActivity.java').read_text()
manifest=(R/'app/src/main/AndroidManifest.xml').read_text()
js=(R/'app/src/main/assets/www/app.js').read_text()
build=(R/'scripts/build-debug.sh').read_text()
checks={
 'explicit non-runtime special access declared': 'android.permission.PACKAGE_USAGE_STATS' in manifest,
 'no QUERY_ALL_PACKAGES scope': 'android.permission.QUERY_ALL_PACKAGES' not in manifest,
 'no new INTERNET permission': 'android.permission.INTERNET' not in manifest,
 'native app-op exact check': 'checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS' in reader,
 'fresh owner generation at reader entry': 'OwnerSessionGate.isCurrent(c, ownerGeneration)' in reader,
 'revocation rechecked in event loop': reader.count('OwnerSessionGate.isCurrent(c, ownerGeneration)') >= 3,
 'user-unlocked required': 'manager.isUserUnlocked()' in reader,
 'explicit foreground-only usage events': 'Event.ACTIVITY_RESUMED' in reader and 'Event.MOVE_TO_FOREGROUND' in reader,
 'bounded, on-demand query': 'queryEvents(' in reader and 'MAX_EVENTS' in reader and 'MAX_MINUTES' in reader,
 'no persistent usage tracking': not any(s in reader for s in ['SharedPreferences','SQLite','HttpURLConnection','AlarmManager','WorkManager','FileOutputStream']),
 'fresh PIN demanded in native flow': 'credentialField(box,"Confirm current Atlas PIN",true)' in main and 'unlockOwnerNative(pin)' in main,
 'owner session before native flow': 'if(!ownerPinConfiguredNative()||!ownerRequired())' in main,
 'bridge has no raw usage data return': '@JavascriptInterface public void showRecentAppsOnce()' in main and not re.search(r'@JavascriptInterface public String (?:readApps|readUsage|showRecentAppsOnce)',main),
 'system grant requires manual settings': 'Settings.ACTION_USAGE_ACCESS_SETTINGS' in main and not any(x in main for x in ['grantUsagePermission','setMode(AppOpsManager']),
 'JS owner-only opt-in with explanatory UI': "if(role!=='owner'||!ownerUiActive())" in js and "Native.call('showRecentAppsOnce')" in js,
 'no hidden UI background poll': js.count("Native.call('showRecentAppsOnce')") == 1,
 'source build invokes app awareness tests': 'test-app-awareness.py' in build,
}
for name, ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' APPCTX '+name)
if not all(checks.values()): raise SystemExit(2)
test=r'''import com.sbh.atlasos.AppAwarenessPolicy;
import java.util.*;
public class AppCtxHarness {
  static int checks = 0;
  static void ok(String message, boolean value){ checks++; if(!value)throw new AssertionError(message);System.out.println("PASS APPCTX JAVA "+message); }
  static AppAwarenessPolicy.EventRow e(String pkg,long at){return new AppAwarenessPolicy.EventRow(pkg,at);}
  static List<String> run(List<AppAwarenessPolicy.EventRow> x,long now,int m){return AppAwarenessPolicy.recentPackages(x,now,m,"com.sbh.atlasos.candidate");}
  public static void main(String[] args){
    long now=2_000_000;
    ok("null events fail closed",run(null,now,15).isEmpty());
    ok("zero minutes denied",run(Arrays.asList(e("org.example.app",now)),now,0).isEmpty());
    ok("overly broad window denied",run(Arrays.asList(e("org.example.app",now)),now,16).isEmpty());
    ok("negative window denied",run(Arrays.asList(e("org.example.app",now)),now,-1).isEmpty());
    ok("negative clock denied",run(Arrays.asList(e("org.example.app",now)),-1,15).isEmpty());
    ok("own package omitted",run(Arrays.asList(e("com.sbh.atlasos.candidate",now)),now,15).isEmpty());
    ok("valid foreground app kept",run(Arrays.asList(e("org.example.app",now)),now,15).equals(Arrays.asList("org.example.app")));
    ok("old events omitted",run(Arrays.asList(e("org.example.app",now-900_001)),now,15).isEmpty());
    ok("15-minute boundary accepted",run(Arrays.asList(e("org.example.app",now-900_000)),now,15).size()==1);
    ok("future timestamps omitted",run(Arrays.asList(e("org.example.app",now+1)),now,15).isEmpty());
    ok("invalid package rejected",run(Arrays.asList(e("../../data",now),e("org.\u202eevil",now),e("org.example.app",now)),now,15).size()==1);
    ok("null row and null package safe",run(Arrays.asList(null,e(null,now)),now,15).isEmpty());
    ok("dedupe per package",run(Arrays.asList(e("org.example.app",now),e("org.example.app",now-2)),now,15).size()==1);
    ok("sort by latest event not first",run(Arrays.asList(e("org.example.a",now-10),e("org.example.b",now-100),e("org.example.b",now-1)),now,15).get(0).equals("org.example.b"));
    ok("deterministic tie ordering",run(Arrays.asList(e("org.example.b",now),e("org.example.a",now)),now,15).get(0).equals("org.example.a"));
    List<AppAwarenessPolicy.EventRow> many=new ArrayList<>(); for(int i=0;i<40;i++)many.add(e("org.example.app"+i,now-i));
    ok("list capped",run(many,now,15).size()==AppAwarenessPolicy.MAX_RESULTS);
    while(many.size()<=AppAwarenessPolicy.MAX_EVENTS)many.add(e("org.example.app0",now));
    ok("oversized query refused entirely",run(many,now,15).isEmpty());
    ok("valid package rule",AppAwarenessPolicy.isValidPackage("org.example.app")&&!AppAwarenessPolicy.isValidPackage("1.com")&&!AppAwarenessPolicy.isValidPackage("org..example"));
    System.out.println("APPCTX_JAVA="+checks+"/"+checks+" PASS");
  }
}'''
with tempfile.TemporaryDirectory(prefix='atlas-appctx1-') as tmp:
 d=Path(tmp);p=d/'AppCtxHarness.java';p.write_text(test)
 subprocess.run(['javac','-d',str(d),str(java),str(p)],check=True)
 subprocess.run(['java','-cp',str(d),'AppCtxHarness'],check=True)
print('APPCTX_SOURCE_WIRING='+str(len(checks))+'/'+str(len(checks))+' PASS')
