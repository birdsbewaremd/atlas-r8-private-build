#!/usr/bin/env python3
"""Host test of the real owner-record JavaScript bridge's credential boundary.

Requires JAVA_HOME (or javac/java on PATH) and JSON_JAR pointing to the host
org.json library. Executes an exact source-extracted bridge method with real
OwnerRecordStore and OwnerSessionGate. Android services and encrypted-blob
storage are host fixtures. No Android UI, Android Keystore or network claims.
"""
from pathlib import Path
import hashlib
import os
import re
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / 'app/src/main/java/com/sbh/atlasos'


def extract_method(source, signature):
    """Keep the real method byte-for-byte; ignore braces in Java literals/comments."""
    positions = [match.start() for match in re.finditer(re.escape(signature), source)]
    if len(positions) != 1:
        raise RuntimeError('Expected one real method: ' + signature)
    start = positions[0]
    opening = source.index('{', start)
    depth = 0
    state = 'code'
    index = opening
    while index < len(source):
        char = source[index]
        following = source[index + 1] if index + 1 < len(source) else ''
        if state in ('string', 'char'):
            if char == '\\':
                index += 2
                continue
            if char == ('"' if state == 'string' else "'"):
                state = 'code'
        elif state == 'line':
            if char == '\n':
                state = 'code'
        elif state == 'block':
            if char == '*' and following == '/':
                state = 'code'
                index += 2
                continue
        elif char == '/' and following == '/':
            state = 'line'
            index += 2
            continue
        elif char == '/' and following == '*':
            state = 'block'
            index += 2
            continue
        elif char == '"':
            state = 'string'
        elif char == "'":
            state = 'char'
        elif char == '{':
            depth += 1
        elif char == '}':
            depth -= 1
            if depth == 0:
                return source[start:index + 1]
        index += 1
    raise RuntimeError('Unterminated real method: ' + signature)


ANDROID = {
    'android/app/KeyguardManager.java': '''package android.app;
public final class KeyguardManager {
  public boolean locked;
  public boolean isDeviceLocked(){return locked;}
}
''',
    'android/content/Context.java': '''package android.content;
public class Context {
  public static final String KEYGUARD_SERVICE="keyguard";
  public final android.app.KeyguardManager keyguard=new android.app.KeyguardManager();
  public Object getSystemService(String name){return KEYGUARD_SERVICE.equals(name)?keyguard:null;}
}
''',
    'android/os/SystemClock.java': '''package android.os;
public final class SystemClock {
  public static long now=1000L;
  public static long elapsedRealtime(){return now;}
}
''',
    'android/webkit/JavascriptInterface.java': '''package android.webkit;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@java.lang.annotation.Target(java.lang.annotation.ElementType.METHOD)
public @interface JavascriptInterface {}
'''
}

TEST = r'''
package com.sbh.atlasos;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import org.json.JSONObject;

/** Real bridge/store/session code with synthetic encrypted data and Android services. */
public final class BrainBridgeHostTest {
  static int passed;
  static void check(boolean ok,String name){
    if(!ok)throw new AssertionError(name);
    passed++;System.out.println("PASS "+name);
  }
  static final class Keys implements OwnerRecordStore.KeySource {
    SecretKey key;boolean unavailable;int calls,creates;
    public SecretKey get(boolean create)throws Exception{
      calls++;
      if(unavailable)throw new IOException("synthetic key unavailable");
      if(key==null){
        if(!create)throw new IOException("synthetic key missing");
        KeyGenerator generator=KeyGenerator.getInstance("AES");generator.init(256);
        key=generator.generateKey();creates++;
      }
      return key;
    }
  }
  static final class Blobs implements OwnerRecordStore.BlobStore {
    final Map<String,byte[]> data=new HashMap<>();
    int reads,writes;boolean failRead,failCommit;
    Runnable duringRead,beforeCommit;
    public byte[] read(String key)throws Exception{
      reads++;
      if(failRead)throw new IOException("synthetic read failure");
      byte[] bytes=data.get(key),copy=bytes==null?null:bytes.clone();
      if(duringRead!=null){Runnable run=duringRead;duringRead=null;run.run();}
      return copy;
    }
    public void write(String key,byte[] bytes,OwnerRecordStore.Access access)throws Exception{
      writes++;
      if(beforeCommit!=null){Runnable run=beforeCommit;beforeCommit=null;run.run();}
      OwnerRecordStore.require(access);
      if(failCommit)throw new IOException("synthetic precommit failure");
      data.put(key,bytes.clone());
    }
  }
  static void login(MainActivity activity){
    activity.keyguard.locked=false;activity.learningForeground=true;
    OwnerSessionGate.setForeground(true);OwnerSessionGate.setActive(true);
  }
  static JSONObject read(MainActivity.Bridge bridge,String key)throws Exception{
    return new JSONObject(bridge.ownerRecordsRequest(new JSONObject().put("op","read").put("key",key).toString()));
  }
  static JSONObject write(MainActivity.Bridge bridge,String key,String value,Object revision)throws Exception{
    return new JSONObject(bridge.ownerRecordsRequest(new JSONObject().put("op","write").put("key",key)
      .put("value",value).put("expectedRevision",revision).toString()));
  }
  static void error(JSONObject response,String expected,String name)throws Exception{
    check(expected.equals(response.getString("status"))&&!response.has("value")&&!response.has("revision"),name);
  }
  public static void main(String[] args)throws Exception{
    Keys keys=new Keys();Blobs blobs=new Blobs();OwnerRecordStore records=new OwnerRecordStore(blobs,keys);
    MainActivity activity=new MainActivity(records);MainActivity.Bridge bridge=activity.new Bridge();login(activity);
    String privateName=AtlasBrainController.PRIVATE_RECORD;
    String secretMarker="SYNTHETIC_ONLY_NOT_A_REAL_API_CREDENTIAL";
    String nativeConfig=new JSONObject().put("schema",1).put("key",secretMarker)
      .put("model","synthetic-model").put("enabled",true).toString();
    OwnerRecordStore.Result seeded=records.write(privateName,nativeConfig,0,()->true);
    check("ok".equals(seeded.status)&&seeded.revision==1,"native-only setup seeds encrypted connection record");
    byte[] originalConfig=blobs.data.get(privateName).clone();
    check(!new String(originalConfig,StandardCharsets.ISO_8859_1).contains(secretMarker),"synthetic credential is absent from ciphertext");

    JSONObject absent=read(bridge,"assistantProfile");
    check("ok".equals(absent.getString("status"))&&absent.getLong("revision")==0&&absent.isNull("value"),"assistantProfile read reports absence without writing");
    String profile=new JSONObject().put("schema",1).put("displayName","Synthetic owner")
      .put("responseStyle","short").put("priorities","Host test only").put("instructions","Keep replies clear.").toString();
    JSONObject saved=write(bridge,"assistantProfile",profile,0);
    check("ok".equals(saved.getString("status"))&&saved.getLong("revision")==1&&!saved.has("value"),"explicit profile write commits expected revision without reflecting private data");
    JSONObject loaded=read(bridge,"assistantProfile");
    check("ok".equals(loaded.getString("status"))&&loaded.getLong("revision")==1&&profile.equals(loaded.getString("value")),"profile read returns exact saved value and revision");
    byte[] originalProfile=blobs.data.get("assistantProfile").clone();
    error(write(bridge,"assistantProfile","stale edit",0),"conflict","stale profile revision refuses overwrite");
    check(Arrays.equals(originalProfile,blobs.data.get("assistantProfile"))&&Arrays.equals(originalConfig,blobs.data.get(privateName)),"profile conflict preserves profile and native connection ciphertext");

    int reads=blobs.reads,writes=blobs.writes,keyCalls=keys.calls;
    error(read(bridge,privateName),"invalid","bridge rejects native connection reads without value or revision");
    error(write(bridge,privateName,"replacement",1),"invalid","bridge rejects native connection writes even with correct revision");
    error(write(bridge,privateName,"replacement",0),"invalid","bridge rejects native connection writes with stale revision");
    String escaped="{\"op\":\"read\",\"key\":\"brainConnec"+"\\u0074"+"ion\"}";
    error(new JSONObject(bridge.ownerRecordsRequest(escaped)),"invalid","JSON Unicode escape cannot bypass reserved namespace");
    check(blobs.reads==reads&&blobs.writes==writes&&keys.calls==keyCalls,"reserved namespace is rejected before any blob or key access");
    check(Arrays.equals(originalConfig,blobs.data.get(privateName)),"blocked bridge requests cannot change encrypted native configuration");
    error(read(bridge,"brainConnection/../assistantProfile"),"invalid","path-like namespace cannot reach a record");
    error(read(bridge,"brainConnection "),"invalid","namespace suffix cannot alias private configuration");
    error(write(bridge,"assistantProfile","bad",-1),"invalid","negative expectedRevision is rejected");
    error(write(bridge,"assistantProfile","bad",0.5),"invalid","fractional expectedRevision is rejected");
    error(write(bridge,"assistantProfile","bad",Long.toString(1)),"invalid","string expectedRevision is rejected");
    error(write(bridge,"assistantProfile","bad",OwnerRecordStore.MAX_REVISION),"invalid","out-of-range expectedRevision is rejected");
    error(new JSONObject(bridge.ownerRecordsRequest("{broken")),"invalid","malformed request yields no private data");

    OwnerSessionGate.clear();reads=blobs.reads;writes=blobs.writes;
    error(read(bridge,"assistantProfile"),"locked","locked profile read yields no value");
    error(write(bridge,"assistantProfile","locked mutation",1),"locked","locked profile write is denied");
    error(read(bridge,privateName),"locked","locked private namespace read remains denied");
    check(blobs.reads==reads&&blobs.writes==writes,"locked requests cannot reach encrypted storage");
    login(activity);activity.learningForeground=false;
    error(read(bridge,"assistantProfile"),"locked","Activity foreground gate denies background access");
    login(activity);activity.keyguard.locked=true;
    error(read(bridge,"assistantProfile"),"locked","real OwnerSessionGate respects simulated locked keyguard");

    login(activity);long firstGeneration=OwnerSessionGate.capture(activity);
    blobs.duringRead=()->{OwnerSessionGate.clear();OwnerSessionGate.setActive(true);};
    error(read(bridge,"assistantProfile"),"locked","read captured before fresh login cannot return decrypted profile afterward");
    check(OwnerSessionGate.isActive(activity)&&OwnerSessionGate.capture(activity)!=firstGeneration,"fresh owner login is active but has a different real session generation");
    blobs.beforeCommit=()->{OwnerSessionGate.clear();OwnerSessionGate.setActive(true);};
    error(write(bridge,"assistantProfile","stale-session mutation",1),"locked","old-session write cannot commit during a fresh login");
    check(Arrays.equals(originalProfile,blobs.data.get("assistantProfile"))&&Arrays.equals(originalConfig,blobs.data.get(privateName)),"session races preserve both committed ciphertexts");
    check(profile.equals(read(bridge,"assistantProfile").getString("value")),"new login can explicitly read unchanged profile afterward");

    blobs.failRead=true;
    error(read(bridge,"assistantProfile"),"unavailable","blob read failure returns no profile plaintext");
    error(write(bridge,"assistantProfile","failed read mutation",1),"unavailable","unreadable profile is not replaced as absent");
    reads=blobs.reads;error(read(bridge,privateName),"invalid","private read stays blocked while storage fails");
    check(blobs.reads==reads,"private rejection does not probe unavailable storage");blobs.failRead=false;
    blobs.failCommit=true;
    error(write(bridge,"assistantProfile","failed commit mutation",1),"unavailable","precommit storage error is reported without success");
    check(Arrays.equals(originalProfile,blobs.data.get("assistantProfile"))&&Arrays.equals(originalConfig,blobs.data.get(privateName)),"precommit failure preserves existing profile and configuration");blobs.failCommit=false;
    keys.unavailable=true;int creates=keys.creates;
    error(read(bridge,"assistantProfile"),"unavailable","missing encryption key does not expose or reset a record");
    error(write(bridge,"assistantProfile","key failure mutation",1),"unavailable","missing encryption key denies replacement write");
    check(keys.creates==creates&&Arrays.equals(originalProfile,blobs.data.get("assistantProfile"))&&Arrays.equals(originalConfig,blobs.data.get(privateName)),"key failure creates no replacement key and preserves ciphertexts");keys.unavailable=false;

    byte[] corrupted=originalProfile.clone();corrupted[corrupted.length-1]^=1;blobs.data.put("assistantProfile",corrupted);
    error(read(bridge,"assistantProfile"),"corrupt","authenticated profile corruption returns no value");
    error(write(bridge,"assistantProfile","corrupt replacement",1),"corrupt","corrupt profile cannot be silently overwritten");
    check(Arrays.equals(corrupted,blobs.data.get("assistantProfile"))&&Arrays.equals(originalConfig,blobs.data.get(privateName)),"corrupt bytes remain recoverable and native connection stays unchanged");
    blobs.data.put("assistantProfile",originalProfile);
    String revisedProfile=new JSONObject(profile).put("responseStyle","balanced").toString();
    JSONObject revised=write(bridge,"assistantProfile",revisedProfile,1);
    check("ok".equals(revised.getString("status"))&&revised.getLong("revision")==2,"current expectedRevision permits an explicit second profile save");
    check(revisedProfile.equals(read(bridge,"assistantProfile").getString("value"))&&Arrays.equals(originalConfig,blobs.data.get(privateName)),"valid updated profile reopens while private connection ciphertext stays unchanged");
    OwnerRecordStore.Result finalConfig=records.read(privateName,()->true);
    check("ok".equals(finalConfig.status)&&finalConfig.revision==1&&nativeConfig.equals(finalConfig.value),"native caller still reads the exact original encrypted connection after every bridge attempt");
    check(bridge.getClass().getMethod("ownerRecordsRequest",String.class).isAnnotationPresent(android.webkit.JavascriptInterface.class),"extracted callable keeps the real JavascriptInterface annotation");
    System.out.println("BRAIN_BRIDGE_HOST="+passed+"/"+passed+" PASS");
    System.out.println("Scope: exact bridge method + real OwnerRecordStore/OwnerSessionGate; host JCE, in-memory blobs and Android service stubs. No Android UI, Android Keystore, real credential or network.");
  }
}
'''


def main():
    json_jar = Path(os.environ.get('JSON_JAR', ''))
    if not json_jar.is_file():
        raise RuntimeError('Set JSON_JAR to a host org.json jar (tested: org.json:json:20240303).')
    java_home = os.environ.get('JAVA_HOME')
    javac = str(Path(java_home) / 'bin/javac') if java_home else shutil.which('javac')
    java = str(Path(java_home) / 'bin/java') if java_home else shutil.which('java')
    if not javac or not java:
        raise RuntimeError('Set JAVA_HOME or put javac and java on PATH.')
    source = (JAVA / 'MainActivity.java').read_text()
    bridge_method = extract_method(source, '@JavascriptInterface public String ownerRecordsRequest(String request)')
    required = extract_method(source, 'private boolean ownerRequired()')
    capture = extract_method(source, 'private long captureOwnerSession()')
    if source.index(bridge_method) < source.index('public class Bridge {'):
        raise RuntimeError('The extracted method is not inside the real Bridge source region.')
    constants = re.findall(r'public static final String PRIVATE_RECORD\s*=\s*"[^"\n]+"\s*;', (JAVA / 'AtlasBrainController.java').read_text())
    if len(constants) != 1:
        raise RuntimeError('Expected exactly one real private-record constant.')
    print('Real ownerRecordsRequest SHA256=' + hashlib.sha256(bridge_method.encode()).hexdigest(), flush=True)
    for name in ['OwnerRecordStore.java', 'OwnerSessionGate.java']:
        print(name + ' SHA256=' + hashlib.sha256((JAVA / name).read_bytes()).hexdigest(), flush=True)
    with tempfile.TemporaryDirectory(prefix='atlas-brain-bridge-') as temporary:
        work = Path(temporary)
        fixture = '''package com.sbh.atlasos;
import org.json.JSONObject;
import android.webkit.JavascriptInterface;
public final class MainActivity extends android.content.Context {
  private final OwnerRecordStore ownerRecords;
  boolean learningForeground=true,rendererUnavailable=false,activityDestroyed=false;
  MainActivity(OwnerRecordStore records){ownerRecords=records;}
  boolean isFinishing(){return false;}
  boolean isDestroyed(){return false;}
''' + required + '\n' + capture + '\npublic class Bridge {\n' + bridge_method + '\n}\n}\n'
        sources = dict(ANDROID)
        sources['com/sbh/atlasos/MainActivity.java'] = fixture
        sources['com/sbh/atlasos/AtlasBrainController.java'] = 'package com.sbh.atlasos; public final class AtlasBrainController {' + constants[0] + '}\n'
        sources['com/sbh/atlasos/BrainBridgeHostTest.java'] = TEST
        for name, contents in sources.items():
            target = work / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(contents)
        classes = work / 'classes'
        classes.mkdir()
        compile_sources = [str(work / name) for name in sources] + [str(JAVA / name) for name in ['OwnerRecordStore.java', 'OwnerSessionGate.java']]
        subprocess.run([javac, '--release', '8', '-encoding', 'UTF-8', '-cp', str(json_jar), '-d', str(classes), *compile_sources], check=True)
        subprocess.run([java, '-cp', str(classes) + os.pathsep + str(json_jar), 'com.sbh.atlasos.BrainBridgeHostTest'], check=True)


if __name__ == '__main__':
    main()
