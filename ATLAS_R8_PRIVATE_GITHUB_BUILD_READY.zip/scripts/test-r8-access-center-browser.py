#!/usr/bin/env python3
"""Isolated Chromium functional checks for R8 WebView panel; no Android permissions exercised."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,sys
root=Path(__file__).resolve().parents[1]
web=root/'app/src/main/assets/www'
rows=[]
def check(label,ok):
 rows.append({'name':label,'ok':bool(ok)})
 if not ok: print('FAIL',label)
with sync_playwright() as browser_tools:
 browser=browser_tools.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [320,390,412,768]:
  page=browser.new_page(viewport={'width':width,'height':820});errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
  page.set_content('<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body style="background:#0b0a14;color:#fff;margin:0"><section id="outer"><div class="content" id="frame"></div></section></body></html>')
  page.add_style_tag(path=str(web/'atlas-access.css'))
  page.add_script_tag(path=str(web/'atlas-access.js'))
  page.evaluate('''() => {window.requests=[];window.auth=true;window.testNative={available:()=>true,call:(method,...args)=>{
    window.requests.push({method,args});if(method==='ownerSessionActive')return window.auth;
    if(method==='accessStatusJson')return JSON.stringify({home:'REVIEW',microphone:'ALLOWED',camera:'REVIEW',notifications:'ALLOWED',usage:'REVIEW',assistant:'REVIEW'});
    return undefined;
  }};window.ATLASAccessCenter.open({native:window.testNative,frame:(title,html,name)=>{const root=document.querySelector('#outer');root.className=name;document.querySelector('#frame').innerHTML=html;},open:id=>window.requests.push({method:'open',args:[id]})});}''')
  check(f'{width}: no Android action at page opening',page.evaluate('window.requests.length===0'))
  check(f'{width}: native Setup control visible',page.get_by_role('button',name='Open Native Android Access Setup').is_visible())
  check(f'{width}: no dangerous allow-all button',page.get_by_role('button',name='Allow Everything').count()==0)
  check(f'{width}: grouped local options exist',page.locator('.ax-card').count()>=9)
  page.get_by_role('button',name='Check live status').click()
  check(f'{width}: permission state read only after owner action',page.evaluate('window.requests.some(a=>a.method==="accessStatusJson")'))
  check(f'{width}: live Allowed marker updated',page.locator('.ax-state',has_text='ALLOWED').count()>=2)
  page.get_by_role('button',name='Open Native Android Access Setup').click()
  check(f'{width}: native setup launch only on tap',page.evaluate('window.requests.filter(a=>a.method==="openAccessCenter").length===1'))
  check(f'{width}: no direct permission-grant API used',page.evaluate('window.requests.every(a=>a.method!=="grantAccess"&&a.method!=="grantAll")'))
  check(f'{width}: no JS exceptions',len(errors)==0)
  check(f'{width}: no horizontal viewport overflow',page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+2'))
  page.close()
 page=browser.new_page();page.set_content('<section id="outer"><div class="content" id="frame"></div></section>');page.add_script_tag(path=str(web/'atlas-access.js'))
 page.evaluate('''() => {window.requests=[];window.ATLASAccessCenter.open({native:{available:()=>false,call:(a)=>window.requests.push(a)},frame:(title,html,name)=>document.querySelector('#frame').innerHTML=html,open:()=>window.requests.push('open')})}''')
 page.get_by_role('button',name='Open Native Android Access Setup').click()
 check('Browser preview cannot request phone permissions',page.get_by_text('A compiled Android ATLAS app is required.',exact=False).count()==1)
 check('Browser preview never invokes any native action',page.evaluate('window.requests.length===0'))
 page.close()
 page=browser.new_page();page.set_content('<section id="outer"><div class="content" id="frame"></div></section>');page.add_script_tag(path=str(web/'atlas-access.js'))
 page.evaluate('''() => {window.requests=[];window.ATLASAccessCenter.open({native:{available:()=>true,call:(a)=>{window.requests.push(a);return a==='ownerSessionActive'?false:''}},frame:(title,html,name)=>document.querySelector('#frame').innerHTML=html,open:()=>window.requests.push('open')})}''')
 page.get_by_role('button',name='Open Native Android Access Setup').click()
 check('Owner lock denies native setup',page.get_by_text('Unlock ATLAS owner access first.',exact=False).count()==1)
 check('Owner lock does not launch native access center',page.evaluate('!window.requests.includes("openAccessCenter")'))
 page.close();browser.close()
receipt={'test_mode':'Synthetic in-memory Chromium (NOT physical phone/permission test)','checks':rows,'passed':sum(int(r['ok']) for r in rows),'total':len(rows)}
out=root.parent/'receipts'/'R8_ACCESS_BROWSER_QA.json';out.write_text(json.dumps(receipt,indent=2))
print('R8 Browser',receipt['passed'],'/',receipt['total']);sys.exit(0 if receipt['passed']==receipt['total'] else 1)
