#!/usr/bin/env python3
"""Storage screen in synthetic Chromium: no real Android SAF/Keystore/device execution."""
from pathlib import Path
import os,re,json,shutil
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
html=re.sub(r'<script[^>]*>.*?</script>|<link[^>]*>','',(root/'app/src/main/assets/www/index.html').read_text(),flags=re.S)
js=(root/'app/src/main/assets/www/app.js').read_text()
rows=[]
def check(name,good):
    rows.append((name,bool(good))); print(('PASS ' if good else 'FAIL ')+name)
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path=os.getenv('CHROMIUM_EXECUTABLE') or shutil.which('chromium'),headless=True,args=['--no-sandbox'])
    context=browser.new_context(viewport={'width':390,'height':844})
    page=context.new_page()
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(html)
    page.evaluate('''() => {
      let memory={'atlas.setup.complete':'1','atlas.profile.owner':'{"name":"Synthetic Owner"}'};
      let make=(data)=>({getItem:k=>Object.hasOwn(data,k)?data[k]:null,setItem:(k,v)=>{data[k]=String(v)},removeItem:k=>delete data[k],clear:()=>{Object.keys(data).forEach(k=>delete data[k])}});
      Object.defineProperty(window,'localStorage',{configurable:true,value:make(memory)});
      Object.defineProperty(window,'sessionStorage',{configurable:true,value:make({})});
      window.__isOwner=false;
      window.__imports=0;
      window.__n=5;
      window.ATLASNative={isNative:()=>true,ownerPinConfigured:()=>true,
        ownerSessionActive:()=>__isOwner,lockOwnerSession:()=>{__isOwner=false},
        unlockOwner:s=>(__isOwner=s==='123456'),ownerLockoutSeconds:()=>0,
        ownerRecoveryConfigured:()=>true,deviceStatus:()=>'{}',
        storageStatus:()=>JSON.stringify({status:__isOwner?'ok':'locked',localFinite:true,availableBytes:10737418240,totalBytes:34359738368,vaultEncryptedBytes:1048576,vaultFiles:__n,vaultTruncated:false,backupPortable:false}),
        importLocalDocument:()=>{if(__isOwner)__imports++},listVaultForSearch:()=>'{"status":"ok","paths":[]}'
      };
    }''')
    page.evaluate(js)
    page.locator('#begin').click()
    for digit in '123456':page.locator(f'[data-k="{digit}"]').click()
    check('Owner reaches Home screen',page.locator('#rail').count()==1)
    page.locator('[data-app="settings"]').first.click()
    page.locator('[data-set="Storage"]').click()
    check('Storage screen shows verified mock finite capacity', '10.00 GiB available' in page.locator('body').inner_text())
    check('Vault shows encrypted bytes and count','5 files' in page.locator('body').inner_text())
    check('Limit and nonportable backup warning present','8 MiB maximum' in page.locator('body').inner_text() and 'not a portable backup' in page.locator('body').inner_text())
    check('No autonomous file selection before tap',page.evaluate('__imports')==0)
    page.locator('#docImport').click()
    check('Tap invokes native picker once',page.evaluate('__imports')==1)
    page.evaluate('window.__n=6;window.dispatchEvent(new CustomEvent("atlas-document-import"))')
    check('Native saved event refreshes displayed vault count','6 files' in page.locator('body').inner_text() and page.evaluate('__imports')==1)
    page.evaluate('window.__isOwner=false;window.dispatchEvent(new CustomEvent("atlas-owner-locked"))')
    check('Native lock hides Storage screen',page.locator('#docImport').count()==0 and page.locator('#ownerRecover').count()==1)
    check('Native lock clears browser role',page.evaluate("sessionStorage.getItem('atlas.role')") is None)
    check('No JavaScript errors',not errors)
    context.close();browser.close()
print('STORAGE_UI=%d/%d PASS'%(sum(x[1] for x in rows),len(rows)))
raise SystemExit(0 if all(x[1] for x in rows) else 1)
