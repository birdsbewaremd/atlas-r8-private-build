#!/usr/bin/env python3
"""Bounded structural checks only. These do not compile Android-dependent code."""
import json, os, pathlib, re, xml.etree.ElementTree as ET
ROOT=pathlib.Path(__file__).resolve().parents[1]
JAVA=ROOT/'app/src/main/java/com/sbh/atlasos';WWW=ROOT/'app/src/main/assets/www'
read=lambda p:p.read_text()
bridge=read(JAVA/'HumanLearningBridge.java');store=read(JAVA/'AndroidLearningStore.java')
main=read(JAVA/'MainActivity.java');gate=read(JAVA/'OwnerSessionGate.java')
js=read(WWW/'human-learning.js');app=read(WWW/'app.js');index=read(WWW/'index.html')
manifest=ET.parse(ROOT/'app/src/main/AndroidManifest.xml').getroot()
checks={
 'learning script loads before app router':index.index('human-learning.js')<index.index('app.js'),
 'both existing settings routes connect to learning screen':all(x in app for x in ["name==='Memory & Personalization'","name==='Model & Reply Behavior'","window.AtlasLearning.mount"]),
 'learning bridge is a real JavascriptInterface':bool(re.search(r'@JavascriptInterface\s+public String humanLearningRequest',main)),
 'bridge requires foreground and existing native owner session':'learningForeground && OwnerSessionGate.isActive(this)' in main,
 'background event clears learning view':'learningForeground=false;' in main and 'dispatchEvent("atlas-learning-locked"' in main and "root.addEventListener('atlas-learning-locked',revokeView)" in js,
 'owner lock-state failures deny access':'km == null || km.isDeviceLocked()' in gate and bool(re.search(r'catch \(Exception [^)]+\) \{ clear\(\); return false; \}',gate)),
 'bridge serializes requests across activity instances':'static final Object PROCESS_LOCK' in bridge and 'synchronized(PROCESS_LOCK)' in bridge,
 'bridge authorizes before parse and before success':bridge.index('authorize();')<bridge.index('new JSONObject(raw)') and 'authorize();\n      return new JSONObject().put("ok",true)' in bridge,
 'request sizes and exact fields are bounded':'raw.length()>16000' in bridge and 'q.length()!=set.size()' in bridge,
 'strict boolean and integer revision input':'instanceof Boolean' in bridge and 'instanceof Integer' in bridge and 'instanceof Long' in bridge,
 'unknown operations fail closed':'default:throw new HumanLearningEngine.Failure("INVALID_INPUT")' in bridge,
 'command recognition cannot authorize execution':'.put("authority","none")' in bridge,
 'new store is isolated in no-backup area':'getNoBackupFilesDir()' in store and 'human_learning_v1.enc' in store and 'atlas_human_learning_key_v1' in store,
 'AES key is generated in Android Keystore with randomized encryption':'KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")' in store and '.setRandomizedEncryptionRequired(true).setKeySize(256)' in store,
 'atomic writes are read back before claiming success':'file.startWrite()' in store and 'file.finishWrite(out)' in store and 'Arrays.equals(plain,persisted)' in store,
 'incomplete atomic artifacts do not mean absent profile':'if(hasArtifacts())throw e;return null;' in store and 'base.getPath()+".bak"' in store and 'base.getPath()+".new"' in store,
 'failed deletion artifacts prevent false success':'file.delete();if(hasArtifacts())throw new IOException("delete failed")' in store,
 'no new learning browser-storage calls':not re.search(r'(?:localStorage|sessionStorage)\s*[.\[]',js),
 'no new screen network clients':not re.search(r'\b(?:fetch|WebSocket|XMLHttpRequest|sendBeacon)\s*\(',js),
 'returned data is rendered as text':'el.textContent=s' in js and 'JSON.stringify(data.profile,null,2)' in js,
 'exports are explicitly previews only':'No file or message was sent.' in js,
 'profile creation is explicit consent':'if(!by(\'hl-optin\').checked)' in js and "op:'create',consent:true" in js,
 'process is single-process in manifest':all('{http://schemas.android.com/apk/res/android}process' not in e.attrib for e in manifest.iter()),
}
OUT=pathlib.Path(os.environ.get('ATLAS_TEST_OUTPUT',ROOT/'test-output'));OUT.mkdir(parents=True,exist_ok=True)
for name,ok in checks.items():print(('PASS ' if ok else 'FAIL ')+name)
result={'scope':'Structural source assertions; not Android compilation, native bridge penetration testing or device acceptance.','passed':sum(checks.values()),'total':len(checks),'checks':checks}
(OUT/'learning-source-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(f'LEARNING_SOURCE={sum(checks.values())}/{len(checks)} '+('PASS' if all(checks.values()) else 'FAIL'))
raise SystemExit(0 if all(checks.values()) else 1)
