#!/usr/bin/env python3
"""Synthetic Chromium integration; no Android lifecycle, real vault, or real customers."""
import argparse,json,os,pathlib,re,shutil
parser=argparse.ArgumentParser();parser.add_argument("--group",choices=["all","main","limits","lifecycle","errors"],default="all");args=parser.parse_args()
from playwright.sync_api import sync_playwright
r=pathlib.Path(__file__).resolve().parents[1];w=r/'app/src/main/assets/www'
html=re.sub(r'<script[^>]*>.*?</script>|<link[^>]*>','',(w/'index.html').read_text(),flags=re.S)
js=(w/'app.js').read_text();module=(w/'file-search.js').read_text();rows=[]
def check(name,ok):
 rows.append({'case':name,'pass':bool(ok)});print(('PASS ' if ok else 'FAIL ')+name)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path=os.getenv('CHROMIUM_EXECUTABLE') or shutil.which('chromium'),headless=True,args=['--no-sandbox'])
 context=browser.new_context(viewport={'width':390,'height':844});context.set_default_timeout(5000);context.route('**/*',lambda route:route.abort())
 def page():
  pg=context.new_page();pg.set_content(html)
  for css in ['style.css','atlas-v24.css','v26.css','v27.css','v28.css','v30.css','file-search.css']:pg.add_style_tag(content=(w/css).read_text())
  pg.evaluate(r'''() => {
    window.__writes=0;window.__network=0;window.__reads=[];window.__pwned=0;
    const make=data=>({getItem:k=>Object.hasOwn(data,k)?data[k]:null,setItem:(k,v)=>{__writes++;data[k]=String(v)},removeItem:k=>{delete data[k]}});
    Object.defineProperty(window,'localStorage',{value:make({'atlas.setup.complete':'1','atlas.profile.owner':'{"name":"Synthetic Test Owner"}'}),configurable:true});
    Object.defineProperty(window,'sessionStorage',{value:make({}),configurable:true});
    window.__active=false;
    window.__paths=['BirdsBeware/clients.md','Birds Beware/estimates.csv','images/example.jpg','documents/notes.md','documents/large.txt','documents/<img onerror=__pwned=1>.md'];
    window.__text={'BirdsBeware/clients.md':'SYNTHETIC FIXTURE — NOT CUSTOMER DATA\nClient Example\nStatus: verification pending',
     'Birds Beware/estimates.csv':'client,status\nExample,pending',
     'documents/notes.md':'Synthetic notes\nThe sentinel keyword is orchid',
     'documents/<img onerror=__pwned=1>.md':'<img src=x onerror="__pwned=2"><script>__pwned=3</script>'};
    window.ATLASNative={isNative:()=>true,deviceStatus:()=>'{}',ownerPinConfigured:()=>true,
     lockOwnerSession:()=>{__active=false;},ownerSessionActive:()=>__active,unlockOwner:p=>(__active=p==='123456'),ownerLockoutSeconds:()=>0,
     ownerRecoveryConfigured:()=>false,heyAtlasEnabled:()=>false,
     listVaultForSearch:()=>JSON.stringify({status:__active?'ok':'locked',paths:__paths}),
     readVaultTextForSearch:path=>{__reads.push(path);return JSON.stringify(!__active?{status:'locked'}:path.endsWith('large.txt')?{status:'too_large'}:{status:'ok',text:__text[path]||''});},
     importSeedZip:()=>{window.__imports=(window.__imports||0)+1;}};
    window.fetch=()=>{__network++;throw new Error('network forbidden')};
  }''')
  pg.evaluate(module);pg.evaluate(js);pg.locator('#begin').click()
  for digit in '123456':pg.locator(f'[data-k="{digit}"]').click()
  pg.locator('[data-app="files"]').first.click();pg.wait_for_function("document.querySelector('#vaultSearchStatus').textContent.includes('filenames indexed')")
  return pg
 def search(pg,q,text=False):
  pg.locator('#vaultQuery').fill(q);pg.locator('#vaultScanText').set_checked(text);pg.locator('#vaultSearch').click();pg.wait_for_function("!document.querySelector('#vaultSearchStatus').textContent.includes('Scanning')")
 if args.group in ("all","main"):
  pg=page();check('existing Files icon opens real search surface',pg.locator('#vaultQuery').count()==1)
  check('initial listing metadata only',pg.evaluate('__reads.length')==0)
  writes=pg.evaluate('__writes');search(pg,'show me Birds Beware clients')
  check('business customer aliases retrieve source filename',pg.locator('#vaultResults button').count()==1 and 'clients.md' in pg.locator('#vaultResults').inner_text())
  pg.locator('#vaultResults button').click();pg.wait_for_selector('#vaultPreview pre')
  check('source preview includes exact path and original text','BirdsBeware/clients.md' in pg.locator('#vaultPreview').inner_text() and 'verification pending' in pg.locator('#vaultPreview pre').inner_text())
  check('search and preview add no persistent storage writes',pg.evaluate('__writes')==writes)
  check('search makes no fetch calls',pg.evaluate('__network')==0)
  screenshot=os.getenv('ATLAS_FILE_SEARCH_SCREENSHOT')
  if screenshot:pg.screenshot(path=screenshot,full_page=True)
  search(pg,'orchid');check('content not silently scanned',pg.locator('#vaultResults button').count()==0)
  search(pg,'orchid',True);check('bounded content search finds source',pg.locator('#vaultResults button').count()==1)
  check('content result cites the matching line','Line 2:' in pg.locator('#vaultResults').inner_text())
  check('unsupported images never sent to text bridge',pg.evaluate("!__reads.some(x=>x.endsWith('.jpg'))"))
  check('unavailable text counted, not treated as empty', '1 unavailable' in pg.locator('#vaultSearchStatus').inner_text())
  search(pg,'onerror');pg.locator('#vaultResults button').click();pg.wait_for_selector('#vaultPreview pre')
  check('hostile filename rendered only as text',pg.locator('#vaultResults img').count()==0)
  check('hostile file body not executed or interpreted',pg.locator('#vaultPreview img, #vaultPreview script').count()==0 and pg.evaluate('__pwned')==0)
  pg.locator('#vaultImport').click();check('Import routes to native ZIP workflow',pg.evaluate('__imports')==1)
  pg.locator('#back').click();check('navigation disposes file-search session',pg.evaluate('window.__atlasFileSearchDispose===null'))
  pg.close()
 if args.group in ("all","limits"):
  pg=page();pg.evaluate("window.__paths=Array.from({length:121},(_,i)=>'documents/'+i+'.md');__text={};__reads=[]");pg.locator('#vaultRefresh').click();pg.wait_for_timeout(50);search(pg,'notpresent',True)
  check('content file-count budget enforced',pg.evaluate('__reads.length')==120)
  check('partial scan clearly disclosed','partial, limit reached' in pg.locator('#vaultSearchStatus').inner_text());pg.close()
  pg=page();pg.evaluate("window.__paths=Array.from({length:20},(_,i)=>'documents/'+i+'.md');__text=Object.fromEntries(__paths.map(p=>[p,'x'.repeat(262144)]));__reads=[]");pg.locator('#vaultRefresh').click();pg.wait_for_timeout(50);search(pg,'notpresent',True)
  check('aggregate text budget enforced',pg.evaluate('__reads.length')==16)
  check('aggregate cap disclosed as partial','partial, limit reached' in pg.locator('#vaultSearchStatus').inner_text());pg.close()
 if args.group in ("all","lifecycle"):
  pg=page();pg.evaluate("() => {ATLASNative.readVaultTextForSearch=()=>new Promise(resolve=>window.__resolveRead=resolve);}");pg.locator('#vaultResults button').first.click();pg.wait_for_function('!!window.__resolveRead');pg.evaluate("__active=false;dispatchEvent(new CustomEvent('atlas-owner-locked'));__resolveRead(JSON.stringify({status:'ok',text:'NEVER_SHOW_LATE_PRIVATE_TEXT'}))");pg.wait_for_timeout(100)
  check('late private preview discarded after lock','NEVER_SHOW_LATE_PRIVATE_TEXT' not in pg.locator('body').inner_text())
  check('lock removes search surface and memory reference',pg.locator('#vaultQuery').count()==0 and pg.evaluate('window.__atlasFileSearchDispose===null'));pg.close()
  pg=page();pg.evaluate("Object.defineProperty(document,'hidden',{value:true,configurable:true});document.dispatchEvent(new Event('visibilitychange'))")
  check('backgrounding clears private result UI',pg.locator('#vaultResults').count()==0);pg.close()
  pg=page();pg.evaluate("__active=false");pg.wait_for_timeout(1150)
  check('session expiry masks results without explicit event',pg.locator('#vaultQuery').count()==0 and pg.locator('#ownerRecover').count()==1);pg.close()
 if args.group in ("all","errors"):
  pg=page();pg.evaluate("ATLASNative.listVaultForSearch=()=>JSON.stringify({status:'unreadable'})");pg.locator('#vaultRefresh').click();pg.wait_for_timeout(50)
  check('read error not misreported as an empty vault','No empty-vault' in pg.locator('#vaultSearchStatus').inner_text());pg.close()
  pg=page();pg.evaluate("ATLASNative.listVaultForSearch=()=>JSON.stringify({status:'ok',paths:['../escape.md','safe.md'],truncated:true})");pg.locator('#vaultRefresh').click();pg.wait_for_timeout(50)
  check('unsafe entry omitted with coverage warning',pg.locator('#vaultResults button').count()==1 and 'excluded' in pg.locator('#vaultSearchStatus').inner_text())
  check('partial native manifest disclosed','Partial manifest' in pg.locator('#vaultSearchStatus').inner_text());pg.close()
  pg=page();pg.locator('#vaultQuery').fill('large');pg.locator('#vaultSearch').click();pg.locator('#vaultResults button').click();pg.wait_for_timeout(50)
  check('oversized text explicitly refused without partial preview',pg.locator('#vaultPreview pre').count()==0 and '256 KiB' in pg.locator('#vaultPreview').inner_text());pg.close()
  pg=page();pg.evaluate("__text['BirdsBeware/clients.md']='x'.repeat(40000)");search(pg,'clients');pg.locator('#vaultResults button').click();pg.wait_for_selector('#vaultPreview pre')
  check('long preview bounded and disclosed',len(pg.locator('#vaultPreview pre').inner_text())==30000 and 'shortened' in pg.locator('#vaultPreview').inner_text());pg.close()
 context.close();browser.close()
result={'group':args.group,'scope':'Synthetic Chromium + fake native bridge; no Android integration, real vault or customer data','passed':sum(x['pass'] for x in rows),'total':len(rows),'results':rows}
print(json.dumps(result,indent=2));output=os.getenv('ATLAS_FILE_SEARCH_OUTPUT')
if output:pathlib.Path(output).write_text(json.dumps(result,indent=2))
raise SystemExit(0 if result['passed']==result['total'] else 1)
