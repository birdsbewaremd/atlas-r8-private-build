#!/usr/bin/env python3
"""Synthetic Chromium callback/storage regressions, not Android device tests."""
import argparse,json,os,pathlib,re,shutil
from playwright.sync_api import sync_playwright
parser=argparse.ArgumentParser();parser.add_argument('--source-root',type=pathlib.Path);args=parser.parse_args()
root=args.source_root or pathlib.Path(__file__).resolve().parents[1]
html=re.sub(r'<script[^>]*>.*?</script>|<link[^>]*>','',(root/'app/src/main/assets/www/index.html').read_text(),flags=re.S)
js=(root/'app/src/main/assets/www/app.js').read_text()
rows=[]
def check(name,ok):rows.append({'case':name,'pass':bool(ok)});print(('PASS ' if ok else 'FAIL ')+name)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path=os.getenv('CHROMIUM_EXECUTABLE') or shutil.which('chromium') or shutil.which('google-chrome'),headless=True,args=['--no-sandbox'])
 context=browser.new_context(viewport={'width':390,'height':844})
 def page():
  pg=context.new_page();pg.set_content(html)
  pg.evaluate(r'''() => {
    const make=(data)=>({getItem:k=>Object.hasOwn(data,k)?data[k]:null,setItem:(k,v)=>{data[k]=String(v)},removeItem:k=>{delete data[k]}});
    Object.defineProperty(window,'localStorage',{value:make({'atlas.setup.complete':'1','atlas.profile.owner':'{"name":"Synthetic Tester"}'}),configurable:true});
    Object.defineProperty(window,'sessionStorage',{value:make({}),configurable:true});
    window.__active=false;window.__commands=0;
    window.ATLASNative={isNative:()=>true,deviceStatus:()=>'{}',ownerPinConfigured:()=>true,
      lockOwnerSession:()=>{__active=false;},ownerSessionActive:()=>__active,unlockOwner:p=>(__active=p==='123456'),
      ownerLockoutSeconds:()=>0,ownerRecoveryConfigured:()=>false,heyAtlasEnabled:()=>false,
      runCommand:()=>{__commands++;return __active?'NO_LOCAL_MATCH':'OWNER_UNLOCK_REQUIRED';},classifyFrame:()=>'REAL_WORLD'};
  }''')
  pg.evaluate(js);pg.locator('#begin').click()
  for digit in '123456':pg.locator(f'[data-k="{digit}"]').click()
  return pg
 pg=page()
 exposed=pg.evaluate("""() => {__active=false;dispatchEvent(new CustomEvent('atlas-voice',{detail:{state:'RESULT',text:'SYNTHETIC_PRIVATE_LATE_TRANSCRIPT'}}));return document.body.innerText.includes('SYNTHETIC_PRIVATE_LATE_TRANSCRIPT') || !!document.querySelector('#atlasCmd');}""")
 check('expired-session voice result does not render command surface',not exposed)
 pg.wait_for_timeout(400);check('late voice result triggers no native command',pg.evaluate('__commands')==0);pg.close()
 pg=page();pg.evaluate("dispatchEvent(new CustomEvent('atlas-owner-locked'))")
 check('native lock callback renders lock screen',pg.locator('#ownerRecover').count()==1)
 check('native lock callback clears browser role',pg.evaluate("sessionStorage.getItem('atlas.role')") is None);pg.close()
 pg=page();pg.evaluate("Object.defineProperty(document,'hidden',{value:true,configurable:true});document.dispatchEvent(new Event('visibilitychange'))")
 check('background visibility clears browser role',pg.evaluate("sessionStorage.getItem('atlas.role')") is None)
 check('background visibility masks private UI',pg.locator('#ownerRecover').count()==1);pg.close()
 pg=page();pg.evaluate("window.__photoPwned=0;localStorage.setItem('atlas.lastPhoto','data:image/png;base64,AAAA\\\" onerror=\\\"window.__photoPwned=1')")
 pg.locator('[data-app="photos"]').first.click();pg.wait_for_timeout(100)
 check('stored photo cannot create an event-handler attribute',pg.locator('.photoTile[onerror]').count()==0)
 check('stored photo cannot execute the supplied handler',pg.evaluate('__photoPwned')==0)
 pg.close();context.close();browser.close()
result={'scope':'Synthetic Chromium DOM/storage/native callbacks; no Android UI, device permissions, or production data','passed':sum(x['pass'] for x in rows),'total':len(rows),'results':rows}
output=os.getenv('ATLAS_SECURITY_UI_OUTPUT')
if output:pathlib.Path(output).write_text(json.dumps(result,indent=2))
print('SECURITY_UI=%s/%s'%(result['passed'],result['total']))
raise SystemExit(0 if result['passed']==result['total'] else 1)
