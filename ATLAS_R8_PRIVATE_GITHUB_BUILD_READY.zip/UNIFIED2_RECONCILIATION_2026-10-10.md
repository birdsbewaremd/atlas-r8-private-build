# ATLAS Android unified2 reconciliation — 2026-10-10

Status: PRIVATE SOURCE RECONCILIATION CANDIDATE / NOT CANONICAL / NATIVE BUILD NOT VERIFIED.

## Purpose
Resolve parallel branch drift discovered during Deep Sync. `unified1-sec1` carried the strongest routing/HI/Safe-for-Later/security controls; `integrated2` carried Files search, Human Learning, non-executing WorkflowPlanner continuation and stricter embedded WebView network blocking. A later `hi1-route1-sfl2` refreshed Safe for Later to v0.3.1 / 29 metadata items.

## Merge rule
Three-way merge against the preserved `trust1` lineage. No whole-file replacement of overlapping `MainActivity`, `app.js`, parser or release scripts without intent-level reconciliation. Originals remain preserved.

## Preserved from unified1-sec1
- route1 frozen-52 routing repair;
- bounded HumanInterfacePolicy;
- ActionAuthorizationPolicy, ExternalActionPolicy and UntrustedContentPolicy;
- strict ExternalTargetPolicy and owner-gated exact HTTPS allowlist;
- no INTERNET permission while backend/network scope is disconnected;
- Trust Gate V3 and security audit;
- Safe for Later UI.

## Reconciled from integrated2
- owner-gated bounded VaultSearchReader + Files search UI;
- Human Learning native bridge/store/UI and source tests;
- in-memory WorkflowPlanner continuation with no execution authority;
- WebView `setBlockNetworkLoads(true)` and exact packaged-home navigation;
- related host tests.

## Refreshed from sfl2
- Safe for Later v0.3.1 with 29 metadata-only records and corresponding regression.

## Truth boundary
This source merge is not an APK, install, device acceptance, backend, pilot, production deployment or security certification.
