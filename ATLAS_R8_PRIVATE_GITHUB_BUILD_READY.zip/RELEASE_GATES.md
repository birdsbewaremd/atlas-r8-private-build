# Release gates — 0.3.8-rc2-unified3

1. Source manifest and all inherited/combined host gates pass without skipped checks.
2. Java 21 / Gradle 8.11.1 / Android 35 / build-tools 35.0.0 compile and lint the exact candidate.
3. Debug APK is `com.sbh.atlasos.candidate`, hash/signature/version are recorded, and it never replaces the owner app.
4. Android Keystore, lifecycle, permission dialogs, WebView/native bridge, microphone/wake, import rollback, reboot and recovery tests pass on a disposable test install.
5. Twenty agreed acceptance cases pass before any pilot.

Until then: private candidate only; no production/pilot/security-certification claim.


## AI trust gates — trust1 source candidate
- Provider/model access stays disconnected until a dated provider-route record resolves deployment mode, training use, retention/statefulness and allowed data classes.
- Workflow/model recognition never grants execution authority.
- Consequential external targets require an exact authorized target/capability; reachability is not authorization.
- External model/tool artifacts require source/hash/license/security/isolation review before release.
- Authority-bearing prompt/policy/tool-manifest changes require authorized change control, tests, audit receipt and rollback.
- The cumulative 52-case plan is a release input, not a passed test result.

- AI trust tripwire V3 supersedes V2/V1 capability detection: only production source can trigger/fulfill implementation gates; test/docs strings cannot fake capability or control presence.


## route1 frozen-corpus routing gate
- All 52 frozen adversarial/business inputs must process without parser/router execution grants.
- No frozen 52-case input may route to LOCAL_DEVICE.
- This is semantic routing evidence only; it does not mark any workflow case PASS.


## sec1 external-action security gates
- Current disconnected source must not request `android.permission.INTERNET`; any future in-app networking requires explicit source-scope promotion and fresh review.
- Private-UI external navigation requires native owner session + exact HTTPS allowlist.
- Every redirect hop must be independently allowlisted; redirects/shorteners do not inherit destination trust.
- External/retrieved/imported/model content remains data-plane input and cannot grant capabilities.
- Evaluation/development external writes remain preview-only.
- Live side effects require a fresh, single-use owner authorization bound to target + payload + session generation plus an independent gate outside the model.
- Model-direct deployment, account-security changes, purchases, private-data disclosure, and high-consequence physical control remain blocked.
- `security-audit.py`, Trust Gate V3, source red-team, pure-Java tests, routing preflight, vault crypto, transactional import and voice/session tests must pass before the native toolchain step.


## unified1 Safe for Later gates
- The 26-item Safe for Later runtime asset remains metadata-only and passes the dedicated regression.
- The Safe for Later route remains owner-only.
- The Safe for Later view contains no native bridge call, command-execution call, or direct side-effect path.
- Safe for Later text is treated as organizational data; it cannot change policy, permissions, or execution authority.

## Unified2 reconciliation gates
- Files search remains owner-gated, bounded and local-only.
- Human Learning requires foreground + native owner session and preserves encrypted-store design boundaries.
- WorkflowPlanner continuation remains in-memory and `executionAuthorized=false`.
- Safe for Later runtime data is v0.3.1 / 29 metadata-only items.
- WebView network loads remain blocked; app manifest remains without INTERNET permission while backend scope is disconnected.
- unified1-sec1 external-action, untrusted-content, target/payload-bound authorization and exact HTTPS allowlist controls remain present.
- No branch is canonical until native compile/lint/APK identity and later owner-gated device acceptance succeed.

## Omega1 source reconciliation — 2026-10-10
Current private source candidate: 0.3.8-rc2-u6-s1-omega1 (versionCode 27), merged from unified6 and unified3-storage1 without overwriting either parent. Adds bounded owner-approved local document Storage, while preserving the newer safe-for-later data, Files/Human Learning source gates and existing no-INTERNET security policy. No native APK, connected LLM, Android device acceptance or production promotion. See ATLAS_OMEGA_RECONCILIATION_2026-10-10.md.

## Omega2 UI privacy gates
- Both Omega1 Storage1 and Unified7 UI privacy build regressions must pass.
- Shadowed top-level functions are forbidden. Native Messages, Notes, Tasks and Photos use session-only storage with native lock wipe until encrypted native persistence exists.
- No real-device migration, durable encrypted storage, user data import, or native install is claimed.
- Native compile, signed APK identity and Android Keystore owner acceptance remain separate unrun gates.


## PAUSEGUARD1 security acceptance (2026-10-11, NONCANONICAL)
- Host simulation before/after reproducible: 1/8 → 8/8; includes `onPause` without `onStop`. This is not device evidence.
- Real Android translucent-overlay, microphone stop, owner reauthentication, permission request and SAF import UX: NOT RUN.
- No APK compilation, real-device install, signing, provider/action authorizations or production deployment until explicit approval and independent release gates.


## RELIABILITY1 offline release-claim regression (2026-10-11, NONCANONICAL)
- `scripts/test-release-evidence-gate.py` must PASS before any native toolchain step. The 25 synthetic cases test that source-only and host-only evidence cannot silently become an authorized Android release, reject mismatched APK/manifest checksums, wrong identity, unverified device receipts, symlink paths and malformed evidence.
- `scripts/atlas-release-evidence-gate.py` is offline, read-only, no-network, and **always denies release authorization**, even with a complete synthetic receipt: local receipt consistency is not genuine device attestation or owner approval.
- Build failure, missing toolchain, support errors and save failures must be reported with scope labels; no automatic email, payment, publication, account change or phone control.
- Existing versionCode/package identity remains unchanged; the release candidate remains blocked without native build + owner-device tests.
