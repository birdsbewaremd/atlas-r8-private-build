# ATLAS Android 0.3.8-rc1 semantic-routing reconciliation — October 10, 2026

Status: PRIVATE SOURCE CANDIDATE. Not compiled, installed, promoted, or deployed.

## Parent and preserved rollback

This candidate was copied from `ATLAS_ANDROID_SOURCE_v0.3.7-rc2_PRIVATE_2026-10-10.zip`, SHA-256 `e871b65e8c75b9f3f1b328beae5d7ae459a2fe3fabef290221148765680ca7b5`. The canonical source baseline remains 0.3.6, SHA-256 `30c1f0fe7c03c50e022e0512dd17b0da770df30950fcc70dedcde53f721e1aed`.

No parent archive was overwritten. The 0.3.7-rc2 offline-recovery, source-packaging, WebView media hold, and rollback notes remain inherited unless this document explicitly changes them.

## Merged semantic artifacts

- Registry: 92 entries; SHA-256 `628ed9adb7e8f5f996873f5242a55e396cb2deccdcc172b675d57bed9d5e7ee9`.
- Acceptance specification: 40 cases; SHA-256 `37bd2c84e1c3e428ce763b7fcb5234a910171ac577dbfaa06aa31e9d1caa76f7`.
- Generated catalog: `WorkflowCommandCatalog.java`.
- Recognition policy: `WorkflowIntentParser.java`.
- Authenticated route policy: `AuthenticatedInputRouter.java`.
- UI/native integration: `MainActivity.java` and `app.js`.

The older recognition patch was used as reviewed evidence and design input. Its 85-entry catalog was not copied over the newer owner-reviewed 92-entry registry.

## Integration result

Typed UI input calls a one-argument native `routeTextInput` bridge; JavaScript cannot submit a claimed origin. One-shot voice and wake transcripts enter the same native gateway with fixed native origins. The router distinguishes workflow handoff, normal brain handoff, source data, invalid input, locked input, and deterministic local-device commands.

Semantic workflows cannot fall through into device actions. The one `CommandRouter.run(...)` call site sits behind an active native owner session, a `LOCAL_DEVICE` result, and a second owner-session check.

The UI displays the semantic status emoji and command stack. The source explicitly reports that the brain backend and durable command-persistence service are disconnected. Therefore command creation is not reported as completed and recognized workflows are not represented as executed.

## Remaining release blockers

1. Gradle 8.11.1, Android SDK/platform 35, build-tools 35.0.0 and ADB are unavailable in the current working environment.
2. The registered build host is offline, and connected GitHub returned no repositories.
3. No APK was compiled, signed, installed, or inspected.
4. No real Samsung Galaxy S20 Ultra test, Android lifecycle test, native voice/wake test, or 20-case device workflow acceptance was performed.
5. No authenticated ATLAS brain backend or durable semantic-command persistence is connected.
6. Browser `localStorage` remains outside the encrypted native-vault boundary.
7. Existing WebView/private-storage and release-gate issues remain open.

No public website, production branch, account, credential, phone setting, automation, external message, or physical device was changed by this source work.
