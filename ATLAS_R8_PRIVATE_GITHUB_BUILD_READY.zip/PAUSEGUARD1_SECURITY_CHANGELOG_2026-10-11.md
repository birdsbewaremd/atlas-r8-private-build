# ATLAS PAUSEGUARD1 — Owner Session and Media Privacy Hold

CLASSIFICATION: PRIVATE, source-only development candidate. NONCANONICAL / NOT A RELEASE.
Parent source archive SHA-256: `3156746a90b828e625a3dba60cb9e5b02671c5409df0aa44bc50f2792d7b31e1`. Parent is preserved unchanged.

## Source finding (source inspection, not a demonstrated device exploit)
`MainActivity.onPause()` previously emitted only a Human Learning lock event. The stronger native owner-session reset, microphone/wake cancellation, WebView hiding and native command-planner clearing happened only in `onStop()`. Android may call onPause without onStop for a translucent screen or UI. Private operations could therefore remain authorized while the activity was paused.

## Minimal correction
* `onPause()` now immediately revokes `OwnerSessionGate`, clears workflow plans, stops private speech/wake, conceals WebView, and requests owner+learning view scrubbing.
* `onResume()` restores the process foreground flag but never restores authentication; the existing relock UI path runs for configured owners.
* `test-pause-privacy.py` uses real extracted lifecycle methods with synthetic fake Android lifecycle APIs. Added to build-debug acceptance gates. Static source audit requires the critical lines in `onPause()`; do not rely on onStop-only tests.
* No Android permissions, remote actions, Internet capability, model authority, production UI, vault/key format or versionCode changed.

## Before and after evidence
Before in host simulation: 1/8 expected properties; after: 8/8. The exact prepatch failure output is kept in the external audit packet, not included in APK assets. This simulated host test does **not** prove a phone lifecycle, Android biometric/Keystore behavior, or prevent every overlay attack.

## Real-device release tests STILL REQUIRED
1. Unlock, open private UI, invoke translucent app/notification overlay where `onPause` occurs without `onStop`; verify private UI hidden, private API and vault locked, microphone actually stopped.
2. Return to ATLAS; require fresh PIN and ensure stale media callbacks never execute; check network/service/policy logs have no transcript leak.
3. Repeat with system file picker, Assistant role request, microphone runtime-permission sheet, screen lock/unlock, split-screen and configuration rotation.
4. Verify pinned ownership, recovery, backup restore, 52-case acceptance, debug build identity and release signing separately.

Tradeoff: reauthentication after a permission dialog / file picker is expected until lifecycle usability is verified on a real device. If this becomes unusable, refine with an explicit narrowly bound owner authorization flow; **never** silently reinstate a stale login.

Rollback: retain exact parent archive; do not overwrite the canonical source. Restore parent before any future merge or rollout only after verified approval.
