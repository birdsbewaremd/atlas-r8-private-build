import com.sbh.atlasos.VaultSearchReader;
import java.io.*;import java.nio.file.*;import java.nio.charset.StandardCharsets;import java.util.*;import java.util.concurrent.atomic.AtomicInteger;
import javax.crypto.*;import javax.crypto.spec.*;

/** Real host AES-GCM/filesystem tests; deliberately not Android Keystore/device tests. */
public class VaultSearchReaderTest {
  interface Work{void run()throws Exception;}
  static int passed=0,total=0;static File root;static SecretKey key;
  static void test(String name,Work work){total++;try{work.run();passed++;System.out.println("PASS "+name);}catch(Exception|AssertionError ex){System.out.println("FAIL "+name+": "+ex);}}
  static void eq(Object actual,Object expected){if(!Objects.equals(actual,expected))throw new AssertionError(actual+" != "+expected);}
  static void reject(String status,Work work)throws Exception{try{work.run();throw new AssertionError("accepted");}catch(VaultSearchReader.Rejected ex){eq(ex.status,status);}}
  static File put(String path,byte[] bytes)throws Exception{File f=new File(root,path+".atlasenc");f.getParentFile().mkdirs();byte[] iv=new byte[12];new java.security.SecureRandom().nextBytes(iv);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key,new GCMParameterSpec(128,iv));try(FileOutputStream out=new FileOutputStream(f)){out.write(new byte[]{'A','T','L','1',12});out.write(iv);out.write(c.doFinal(bytes));}return f;}
  static String read(String path)throws Exception{return VaultSearchReader.read(root,path,key,()->true);}
  public static void main(String[]args)throws Exception{
    root=Files.createTempDirectory("atlas-search-test-").toFile();KeyGenerator kg=KeyGenerator.getInstance("AES");kg.init(256);key=kg.generateKey();
    try{
      test("nested encrypted text reads exactly",()->{put("Birds Beware/clients.md","line1\nclients\n".getBytes(StandardCharsets.UTF_8));eq(read("Birds Beware/clients.md"),"line1\nclients\n");});
      test("reader does not change source bytes",()->{File f=new File(root,"Birds Beware/clients.md.atlasenc");byte[] before=Files.readAllBytes(f.toPath());read("Birds Beware/clients.md");eq(Arrays.equals(before,Files.readAllBytes(f.toPath())),true);});
      test("empty text is distinct from read failure",()->{put("empty.txt",new byte[0]);eq(read("empty.txt"),"");});
      test("UTF-8 accents preserved",()->{put("unicode.md","café λ".getBytes(StandardCharsets.UTF_8));eq(read("unicode.md"),"café λ");});
      test("locked read denied",()->reject("locked",()->VaultSearchReader.read(root,"empty.txt",key,()->false)));
      test("throwing auth fails closed",()->reject("locked",()->VaultSearchReader.read(root,"empty.txt",key,()->{throw new RuntimeException();})));
      test("missing auth fails closed",()->reject("locked",()->VaultSearchReader.read(root,"empty.txt",key,null)));
      test("authorization loss mid-read returns no text",()->{AtomicInteger calls=new AtomicInteger();reject("locked",()->VaultSearchReader.read(root,"empty.txt",key,()->calls.incrementAndGet()<3));});
      test("parent traversal rejected",()->reject("unsupported",()->read("../secret.md")));
      test("absolute path rejected",()->reject("unsupported",()->read("/secret.md")));
      test("backslash path rejected",()->reject("unsupported",()->read("a\\b.md")));
      test("empty segments rejected",()->reject("unsupported",()->read("a//b.md")));
      test("hidden credential-like path excluded",()->reject("unsupported",()->read(".env.md")));
      test("control-character path excluded",()->reject("unsupported",()->read("a\nb.md")));
      test("HTML execution-bearing file type excluded",()->reject("unsupported",()->read("a.html")));
      test("image excluded from text reader",()->reject("unsupported",()->read("a.jpg")));
      test("missing text reports unreadable",()->reject("unreadable",()->read("missing.txt")));
      test("text size boundary accepted",()->{byte[] b=new byte[VaultSearchReader.MAX_TEXT_BYTES];Arrays.fill(b,(byte)'x');put("max.txt",b);eq(read("max.txt").length(),b.length);});
      test("text boundary plus one rejected",()->{byte[] b=new byte[VaultSearchReader.MAX_TEXT_BYTES+1];Arrays.fill(b,(byte)'x');put("over.txt",b);reject("too_large",()->read("over.txt"));});
      test("oversized raw ciphertext rejected before decrypt",()->{File f=new File(root,"huge.txt.atlasenc");try(RandomAccessFile x=new RandomAccessFile(f,"rw")){x.setLength(10*1024*1024);}reject("too_large",()->read("huge.txt"));});
      test("tampered GCM authentication tag rejected",()->{File f=put("tamper.txt","secret".getBytes());byte[] b=Files.readAllBytes(f.toPath());b[b.length-1]^=1;Files.write(f.toPath(),b);reject("unreadable",()->read("tamper.txt"));});
      test("wrong key rejected",()->{KeyGenerator g=KeyGenerator.getInstance("AES");g.init(256);SecretKey wrong=g.generateKey();reject("unreadable",()->VaultSearchReader.read(root,"empty.txt",wrong,()->true));});
      test("truncated ciphertext rejected",()->{File f=put("short.txt","secret".getBytes());byte[] b=Files.readAllBytes(f.toPath());Files.write(f.toPath(),Arrays.copyOf(b,b.length-3));reject("unreadable",()->read("short.txt"));});
      test("wrong envelope magic rejected",()->{File f=put("magic.txt",new byte[0]);byte[] b=Files.readAllBytes(f.toPath());b[0]='X';Files.write(f.toPath(),b);reject("unreadable",()->read("magic.txt"));});
      test("invalid IV length rejected",()->{File f=put("iv.txt",new byte[0]);byte[] b=Files.readAllBytes(f.toPath());b[4]=2;Files.write(f.toPath(),b);reject("unreadable",()->read("iv.txt"));});
      test("invalid UTF-8 rejected rather than replacement",()->{put("encoding.txt",new byte[]{(byte)0xC3,(byte)0x28});reject("unreadable",()->read("encoding.txt"));});
      test("NUL binary content rejected",()->{put("binary.txt",new byte[]{65,0,66});reject("unsupported",()->read("binary.txt"));});
      test("symlink file denied",()->{Files.createSymbolicLink(new File(root,"linked.txt.atlasenc").toPath(),new File(root,"empty.txt.atlasenc").toPath());reject("unreadable",()->read("linked.txt"));});
      test("symlink directory denied",()->{Files.createSymbolicLink(new File(root,"linkdir").toPath(),new File(root,"Birds Beware").toPath());reject("unreadable",()->read("linkdir/clients.md"));});
      test("manifest is sorted and strips only envelope suffix",()->{VaultSearchReader.Listing m=VaultSearchReader.list(root,()->true);eq(m.paths.contains("Birds Beware/clients.md"),true);List<String> ordered=new ArrayList<>(m.paths);Collections.sort(ordered);eq(m.paths,ordered);});
      test("manifest excludes symlink entries and reports skip",()->{VaultSearchReader.Listing m=VaultSearchReader.list(root,()->true);eq(m.paths.stream().anyMatch(x->x.startsWith("link")),false);eq(m.skipped>=2,true);});
      test("locked manifest denied",()->reject("locked",()->VaultSearchReader.list(root,()->false)));
      test("manifest authorization loss denied",()->{AtomicInteger n=new AtomicInteger();reject("locked",()->VaultSearchReader.list(root,()->n.incrementAndGet()<4));});
      test("manifest hard cap reported",()->{File many=new File(root,"many");many.mkdir();for(int i=0;i<5001;i++)Files.write(new File(many,i+".txt.atlasenc").toPath(),new byte[0]);VaultSearchReader.Listing m=VaultSearchReader.list(many,()->true);eq(m.paths.size(),5000);eq(m.truncated,true);});
      test("manifest depth cap reported",()->{File deep=new File(root,"deep");File cur=deep;for(int i=0;i<35;i++)cur=new File(cur,"d");cur.mkdirs();Files.write(new File(cur,"x.md.atlasenc").toPath(),new byte[0]);VaultSearchReader.Listing m=VaultSearchReader.list(deep,()->true);eq(m.paths.isEmpty(),true);eq(m.truncated,true);});
      test("unsupported type and path checks stable",()->{for(String p:Arrays.asList(null,"","a.exe","a.svg","a/.secret/key.txt","a:dir/x.txt"))eq(VaultSearchReader.textPath(p),false);eq(VaultSearchReader.textPath("Archive/A.JSONL"),true);});
      System.out.println("HOST_VAULT_SEARCH="+passed+"/"+total+"; REAL_HOST_AES_GCM; NO_ANDROID_KEYSTORE_OR_DEVICE");
    }finally{try(java.util.stream.Stream<Path>s=Files.walk(root.toPath())){s.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(IOException ignored){}});}}
    if(passed!=total)System.exit(1);
  }
}
