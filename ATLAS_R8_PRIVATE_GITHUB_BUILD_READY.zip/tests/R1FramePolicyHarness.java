import com.sbh.atlasos.RobotR1FramePolicy;
import com.sbh.atlasos.RobotR1FramePolicy.Session;
import com.sbh.atlasos.RobotR1FramePolicy.Decision;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class R1FramePolicyHarness {
    static int passed=0,failed=0;
    static void yes(boolean cond,String name) {
        if(!cond){ failed++;System.err.println("FAIL " + name); }
        else { passed++;System.out.println("PASS " + name); }
    }
    static String body(String verb,String arg) {
        return "R1|0001|ATLAS|PICO|"+verb+"|"+arg;
    }
    static String xor(String body) {
        int n=0;for(byte b:body.getBytes(StandardCharsets.UTF_8)) n^=b&255;
        return body+"|"+String.format(Locale.ROOT,"%02X",n);
    }
    static boolean accepted(String packet){return new Session().accept(packet).accepted;}
    public static void main(String[] unused){
        Session s=new Session();
        String one=RobotR1FramePolicy.encode(1,"SAY","HELLO FROM ATLAS");
        String two=RobotR1FramePolicy.encode(2,"LED","CYAN");
        String three=RobotR1FramePolicy.encode(3,"MOVE","FORWARD 2");
        yes(one.contains("HELLO%20FROM%20ATLAS"),"encodeURIComponent spaces");
        yes(s.accept(one).accepted,"SAY accepted");
        yes(s.accept(two).accepted,"LED accepted");
        yes(s.accept(three).accepted,"MOVE accepted");
        yes(!s.accept(three).accepted,"replay rejected");
        yes(!s.accept(two).accepted,"reorder rejected");
        yes(s.accept(RobotR1FramePolicy.encode(4,"TURN","RIGHT 90")).accepted,"TURN accepted");
        yes(s.accept(RobotR1FramePolicy.encode(5,"SCAN","")).accepted,"SCAN accepted");
        yes(s.accept(RobotR1FramePolicy.encode(6,"WAIT","200")).accepted,"WAIT accepted");
        yes(s.accept(RobotR1FramePolicy.encode(7,"PING","")).accepted,"PING accepted");
        yes(s.accept(RobotR1FramePolicy.encode(8,"STOP","")).accepted,"STOP accepted");
        yes(s.isHalted(),"STOP latches simulation");
        yes(!s.accept(RobotR1FramePolicy.encode(9,"SCAN","")).accepted,"post STOP rejected");
        yes(!accepted(one.replace("ATLAS|PICO","EVIL|PICO")),"spoofed source rejected");
        yes(!accepted(one.replace("R1|","RX|")),"corrupted version rejected");
        yes(!accepted(one.replace("|ATLAS|","|AI|")),"wrong source rejected");
        yes(!accepted(one.substring(0,one.length()-1)+"0"),"corrupt checksum rejected");
        yes(!accepted(xor(body("MOVE","FORWARD%206"))),"move >5 rejected");
                yes(accepted(xor(body("MOVE","BACKWARD%201"))),"backward allowed");
        yes(!accepted(xor(body("SAY","HELLO+THERE"))),"noncanonical plus rejected");
        yes(!accepted(xor(body("SAY","HELLO%2"))),"malformed percent rejected");
        yes(!accepted(xor(body("SAY","%C3%28"))),"invalid UTF-8 rejected");
        yes(!accepted(xor(body("SAY","%41"))),"noncanonical percent for A rejected");
        yes(!accepted(xor(body("SAY","HELLO%0A"))),"newlines rejected");
        yes(!accepted(xor(body("WAIT","1001"))),"wait over max rejected");
        yes(!accepted(xor(body("LED","BLUE"))),"LED not allowlisted rejected");
        yes(!accepted(xor(body("PING","ANYTHING"))),"no-arg verb enforced");
        yes(!accepted(xor(body("DEPLOY","-"))),"unapproved verb blocked");
        yes(!accepted(xor("R1|0000|ATLAS|PICO|PING|-")),"sequence zero rejected");
        yes(!accepted(xor("R2|0001|ATLAS|PICO|PING|-")),"unknown protocol version rejected");
        yes(!accepted(xor("R1|0001|ATLAS|BIRD|PING|-")),"destination rejected");
        yes(!accepted(xor(body("SAY","-"))),"empty SAY rejected");
        yes(!accepted(xor(body("STOP","HELLO"))),"STOP arg rejected");
        yes(!accepted(xor(body("SAY","%F0%9F%92%A1")))==false,"UTF-8 emoji accepted");
        yes(!accepted("  "+one),"leading whitespace rejected");
        yes(!accepted(null),"null frame rejected");
        System.out.println("ATLAS_R1_NATIVE="+passed+"/"+(passed+failed)+" PASSING");
        if(failed>0) System.exit(1);
    }
}
