package com.sbh.atlasos;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
public final class CleanupScanEngineTest {
 static int passed;
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);passed++;}
 static CleanupScanEngine.Item file(String id,String content){byte[] b=content.getBytes(java.nio.charset.StandardCharsets.UTF_8);return new CleanupScanEngine.Item(id,id,b.length,()->new ByteArrayInputStream(b));}
 public static void main(String[] args){
  CleanupScanEngine.Result r=CleanupScanEngine.inspect(Arrays.asList(file("a","same"),file("b","same"),file("c","else"),file("a","same")),16,128,()->false);
  check(r.listed==3&&r.repeatedIdentities==1,"same URI must not inflate duplicate count");
  check(r.groups.size()==1&&r.groups.get(0).size()==2&&r.reclaimableBytes==4,"only excess matching copies reclaimable");
  check(r.hashed==3&&r.bytesRead==12,"actual reads recorded");
  r=CleanupScanEngine.inspect(Arrays.asList(file("a","12345"),file("b","12345")),4,128,()->false);
  check(r.groups.isEmpty()&&r.largeSkipped==2&&r.bytesRead==0,"oversized files not opened");
  r=CleanupScanEngine.inspect(Arrays.asList(new CleanupScanEngine.Item("a","a",3,()->new ByteArrayInputStream("xxxx".getBytes())),file("b","xxx")),16,128,()->false);
  check(r.errors==1&&r.groups.isEmpty()&&r.bytesRead==7,"changed-size stream rejected and charged");
  AtomicInteger reads=new AtomicInteger();
  CleanupScanEngine.Item failed=new CleanupScanEngine.Item("a","a",4,()->new InputStream(){int at;public int read()throws IOException{if(at++==2)throw new IOException();reads.incrementAndGet();return 1;}public int read(byte[] b,int o,int l)throws IOException{if(at++==0){b[o]=1;b[o+1]=1;reads.addAndGet(2);return 2;}throw new IOException();}});
  r=CleanupScanEngine.inspect(Arrays.asList(failed,file("b","same"),file("c","same")),16,5,()->false);
  check(r.bytesRead==2&&r.errors==1&&r.budgetSkipped==2,"failed reads consume global budget");
  r=CleanupScanEngine.inspect(Arrays.asList(file("a","same"),file("b","same")),16,128,()->true);
  check(r.cancelled&&r.bytesRead==0&&r.groups.isEmpty(),"cancel precedes stream access");
  r=CleanupScanEngine.inspect(Arrays.asList(new CleanupScanEngine.Item("u","u",-1,()->{throw new AssertionError();}),file("a",""),file("b","")),16,128,()->false);
  check(r.unknown==1&&r.hashed==0&&r.reclaimableBytes==0,"unknown and empty files not treated as junk");
  r=CleanupScanEngine.inspect(Arrays.asList(file("a","same"),file("b","same"),file("c","same")),16,9,()->false);
  check(r.bytesRead<=9&&r.groups.size()==1&&r.reclaimableBytes==4,"global read limit never exceeded");
  r=CleanupScanEngine.inspect(Arrays.asList(file("a","same"),file("b","same")),16,8,()->false);
  check(r.bytesRead==8&&r.hashed==1&&r.groups.isEmpty()&&r.budgetSkipped==1,"exact budget boundary stays conservative without EOF proof");
  check(CleanupScanEngine.saturatingAdd(Long.MAX_VALUE-2,5)==Long.MAX_VALUE,"listed size overflow bounded");
  System.out.println(passed+" cleanup engine tests passed");
 }
}
