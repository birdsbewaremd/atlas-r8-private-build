# ATLAS ONE Android — Robot R1 + Recovery additive source patch

**Owner-private staging only.** Extends Android v0.4 source candidate without changing
its original release archive or app identity. No APK, installation, device configuration,
real robot, automatic account-export retrieval, web deployment or public exposure.

## What works in source

- New first hub tile opens the exact existing Second Brain V1.1 page with all 14 bundled
  local tools and its offline Robot R1 + Recovery tabs. Embedded files retain original
  SHA-256 and relative names. This is not a competing master dashboard.
- Added pure Java `RobotR1FramePolicy` for deterministic grammar checking of the R1
  virtual protocol and a per-session sequence/replay guard with STOP latch.
- Hardware access deliberately absent: no USB, Bluetooth, motor, microphone, sensor,
  network, key, Android bridge or external command execution in the R1 policy.
- New `test-r1-native.py` runs a JDK-compiled unit harness; wired into the existing
  `scripts/build-atlas-one.sh --source-only` preflight.
- No changes to AndroidManifest.xml, Android module host's existing network blocker,
  app ID or launch/default HOME declaration. Preserves all 11 previous native modules.
- Native WebView actual operation, local navigation, Android 13 encrypted storage,
  file export/restore and physical E-stop are UNVERIFIED until owner device tests.

## Packaging and gates

Run `bash scripts/build-atlas-one.sh --source-only` offline to run all existing source
security checks plus R1 native validation. Inspect the new SHA manifest and unchanged
originals. On a trusted owner-controlled build machine with Java 21 + Gradle 8.11.1
+ Android SDK platform 35/build-tools 35.0.0, run `bash scripts/build-atlas-one.sh`
for a debug APK build (not an authorization to install).

The preexisting GitHub Actions file is only a **private build recipe**; no Actions
workflow was started. A resulting APK must be checked for signature, package ID,
permissions, offline WebView navigation and recovery behavior on the real phone before
any deployment. No source page grants permission for robot motion.

## Robot R1 boundary

The `R1|SEQ|FROM|TO|VERB|ARG|SUM` XOR checksum detects basic accidental corruption
only. It does not authenticate commands or resist replay across sessions. The new
policy checks ordering *within a single new Session* and still MUST NOT be wired to
actuators. A future physical adapter requires signed firmware, authenticated transport,
owner approval, independently accessible power cut and supervised stationary tests.

## Evidence and unresolved

The full original Android v0.4 ZIP, Second Brain V1.1 ZIP, and original per-file bytes
are preserved outside this new candidate. This patch stores none of the user's
credentials, bank data, private chat exports or device storage. Actual raw ChatGPT
export intake was empty at the last read-only check; it cannot be auto-reconstructed.
