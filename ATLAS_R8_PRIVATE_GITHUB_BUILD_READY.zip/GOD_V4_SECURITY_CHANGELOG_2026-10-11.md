# ATLAS GOD V4 — Unicode input boundary hardening

Scope: **noncanonical Android source candidate only**, versionName `0.3.8-rc2-omega2-wakeguard1-appctx1-godv4`, versionCode 31. Parent is the independently preserved GOD V3 source archive, SHA-256 `6aa6ffa373d37d3b597bd73a3268c98217516140ec51693d3ff09b81d832e83f`.

## Defect reproduced before patch

In GOD V3, direct `CommandParser.parse("text hello\u2060")` classified a local TEXT composer action despite an invisible WORD JOINER; `GodCommandPolicy.parse("GOD: research robotics\u2060")` activated. Isolated UTF-16 surrogates and some non-format visually blank codepoints were also accepted. The main `AuthenticatedInputRouter` already independently rejected many FORMAT inputs; the flaw is **inconsistent defense across parser entry points**, not verified device compromise or permission escalation.

## Source repair

- Reuse `CommandParser.hasUnsafeControl` across local-device, GOD, and workflow parser paths; reject Unicode FORMAT controls, directional marks, isolated surrogate halves, Unicode line separators, C0/C1 controls other than TAB/CR/LF, and selected visually blank marks (U+034F, U+115F, U+1160, U+3164, U+FFA0, U+2800).
- Verify post-NFKC normalized input lengths in each parser; preserve valid paired-surrogate emoji.
- Add dynamic adversarial `InputUnicodeHardeningTest` with more than 4,900 assertions, plus targeted regressions in the three existing Java test suites and a static build tripwire.
- Preserve existing GOD read-only brain-handoff classification, independent owner session and source-data gates; do not introduce Android permissions, network/backend, external execution or device control.

## Proof boundaries

Host Java and source regressions are not equivalent to APK compilation, lint, signing, on-device authentication, Android permission auditing, installed device acceptance, or real-world penetration testing. No APK was produced or installed here. Preserve GOD V3 and other original source packages for independent rollback. GOD is a symbolic user command, not divinity or authorization.
