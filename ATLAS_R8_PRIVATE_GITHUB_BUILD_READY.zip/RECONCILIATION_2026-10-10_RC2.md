# ATLAS 0.3.7-rc2 private source reconciliation — October 10, 2026

This is an additive development candidate, not canonical, not installed, not a
signed app and not a production release. All three input archives are unchanged.

## Inputs and decision

The Library supplied two newer versionCode 11 candidates after the earlier
PIN-only patch was prepared. rc1 (`2465f826...143127f`) already includes two-entry
PIN setup, fresh-PIN change, interrupted-setup routing and opt-in offline recovery.
The security candidate (`8a3e97d9...d9581c`) instead uses Android device credentials
to authorize clearing the ATLAS PIN verifier. These recovery authorities are not
equivalent. This candidate derives from rc1 and does NOT add the alternative reset
route. Both original archives remain available and their full hashes are in
BUILD_STATE.json. The earlier PIN-only patch is not blindly overlaid, because it
would replace newer handlers. Recovery is inherited source, not newly proven
Android functionality, and no real recovery code was generated for the owner.

## New changes

The original recursive ZIP writer would include unexcluded local `.env`, keystore,
local SDK, and other private files if present. The replacement exports only files
in a reviewed SHA-256/size manifest; rejects stale hashes, unknown source additions,
symlinks, hardlinks, unsafe paths and existing output replacement; excludes common
secret/config/cache/build locations; and verifies the written ZIP. It does not
silently regenerate a manifest. Name filters and hashes are NOT a complete secret
scanner or proof of ownership. Review source contents and the manifest together.

WebView media requests previously did not check request origin or owner state, and
an empty runtime permission callback could satisfy a loop initialized to true.
For this candidate, every WebView PermissionRequest is denied and the obsolete
asynchronous media-grant path is removed. The native UI explains the privacy hold
instead of requesting browser camera/microphone. Browser-only behavior is unchanged.
Native voice controls retain their pre-existing separate gates; no Android voice
acceptance is claimed. This deliberately disables WebView camera/media until a
trusted-origin implementation and device tests exist. It does not secure every
other JavaScript bridge, navigation, session or storage surface.

Build verification now checks the source manifest, ZIP regression suite and JS
syntax before the existing Java/static/toolchain gates. The workflow is manual
only, never publication. Android compile SDK 35, build tools 35.0.0 and Gradle
8.11.1 remain pinned; this project's tested Java runtime is 21. VersionCode 12 is a
candidate allocation only, not proof that no other unavailable repository uses it.
Before merge, reconcile the actual private repository HEAD and installed version.

## Continuing blockers

No APK, Android compilation/lint, signing-key verification, install or device test
has occurred. The offline computer and empty GitHub repository visibility were
rechecked. The sandbox has Java 21 but no Gradle/SDK/ADB, and the official Gradle
host did not resolve. There was no SDK-license acceptance or credential creation.
No account/privacy setting, production website, customer contact, finance action,
purchase, investor outreach or physical-device action was performed.

Owner-approved beta accounts, server authorization, device enrollment/revocation,
tenant isolation, secure plaintext-note migration, vault transactionality, recovery
across Android lifecycle/storage failure, origin-constrained native bridges,
private dependency/license review and hardware acceptance remain release holds.
The earlier 60/346 phone-transfer defect and nested old build kit are NOT repaired
by this archive. This is a complete export of this selected source tree, not a full
phone-transfer bundle, historical backup or merger of all project work.

## Operator continuation

Use only synthetic data until RELEASE_GATES.md passes. Bring the authorized PC
online, reconcile this candidate on a new private branch, provision the verified
toolchain with owner-handled license acceptance, compile/lint, verify APK identity
and signature, then test on a disposable emulator/device before the S20 Ultra.
Do not overwrite the only working install or reset/delete app data as recovery.
The existing source archives are rollback inputs, not tested APK/data rollback.

## Primary technical references checked October 10, 2026

- Android AGP 8.9 compatibility: https://developer.android.com/build/releases/agp-8-9-0-release-notes
- Android WebView native-bridge risks: https://developer.android.com/privacy-and-security/risks/insecure-webview-native-bridges
- Android PermissionRequest API: https://developer.android.com/reference/android/webkit/PermissionRequest

All conclusions specific to ATLAS above derive from local source inspection and
attached execution receipts, not from those general references.
