# ATLAS Android v0.3.1 source merge report — 2026-09-27

Status: STAGED PRIVATE / SOURCE MERGED + REGRESSION TESTED / NOT COMPILED / NOT INSTALLED.

## Why this exists
The prior staged phone source had diverged: v0.2.x carried the stronger voice assistant, while v0.3.0 carried stronger command/seed/WebView/build hardening. v0.3.1 merges both lanes instead of pretending either divergent branch superseded the other.

## Voice lane preserved/improved
- Hey/OK/Okay Atlas parser with near-prefix false-trigger reduction.
- one-shot SpeechRecognizer + partial/final state model.
- confidence-aware transcript choice.
- Android TTS with barge-in.
- wake listener / one-shot microphone arbitration.
- repeated Assistant-role invocation through onNewIntent.
- local time/date/battery/identity/help replies.
- REAL_WORLD / FICTION_LORE / SHAUN_PRIVATE / DEVICE_ACTION / HIGH_STAKES routing hint.
- volatile prior-turn context envelope for future authenticated brain calls.
- explicit no-fake brain handoff when the authenticated backend is disconnected.
- concise TTS policy that strips URLs/path artifacts and normally speaks two sentences / ~360 chars.

## Security lane preserved/improved
- 512-character/control-character command bounds through typed CommandParser.
- malformed argument commands fail closed.
- ambiguous partial app-label matches fail closed.
- ACTION_DIAL / ACTION_SENDTO retain user confirmation boundaries.
- external WebView bridge URLs restricted to HTTP(S); empty dial requests rejected.
- private seed import limits file count, per-file size, total expanded size, path length and traversal/control characters.
- vault bridge requires active native owner session.
- native owner session expires after 15 minutes and fails closed when Android keyguard reports device locked.
- locked wake sessions allow only time/date/battery/help/identity; device actions require unlock.
- Gradle/CI build gate runs pure-Java tests + Android lint before APK artifact hashing.

## Still not proven
No Android SDK/Gradle toolchain is installed in this runtime. Therefore APK compilation, installation, default Assistant role, Hey Atlas reliability, Bluetooth routing, screen-off/background behavior, latency, battery, reboot, and real S20 Ultra acceptance remain unverified.
