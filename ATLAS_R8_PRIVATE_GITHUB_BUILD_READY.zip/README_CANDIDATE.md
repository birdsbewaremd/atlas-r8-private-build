# Candidate 0.3.8-rc2-omega2

This isolated private candidate builds on the reconciled `0.3.8-rc2-unified6` source and combines omega1 Storage1 with a bounded privacy/UI cleanup without connecting a backend or widening authority.

It preserves the authenticated routing, Human Interface, Safe for Later, Files Search, Human Learning, WorkflowPlanner, external-action, untrusted-content, exact-target, recovery and disconnected-network controls already reconciled in unified6. It removes shadowed duplicate Web UI declarations and prevents new raw Messages, Notes, Tasks and Photos from being persisted to WebView `localStorage` in the native shell; those surfaces are session-only until encrypted native persistence exists.

No backend is connected. No production promotion, native APK build, device install, sensor activation, BCI connection, or physical action is implied. Native build and real-device voice/screen acceptance remain separate gates.


## route1 safety merge — 2026-10-10
Frozen 52-case semantic preflight on the trust1 lineage found two compound natural-language inputs (`AI-A18`, `A12`) could be misclassified as local device commands. `route1` narrows local action parsing so conflicted/explanatory clauses hand off to the brain/workflow lane. Human Interface behavior remains presentation-only.


## sec1 security hardening — 2026-10-10
This child preserves the route1 parser/routing repair and adds least-privilege network/action controls before any backend is connected:
- removes Android `INTERNET` permission while backend/network-agent scope is disconnected;
- owner-gates private-UI external navigation and restricts it to an exact HTTPS allowlist;
- rejects HTTP, URL credentials/fragments, IP literals, local/intranet-style hosts, non-default ports, dot-segment aliases, redirect cycles, excess redirects, and any non-allowlisted redirect hop;
- adds short-lived single-use owner authorization bound to target hash, payload hash and session generation;
- evaluation/development live writes are preview-only;
- models/automations cannot self-authorize external writes; model-direct deployment, account-security changes, purchases, private disclosure, and high-consequence physical control are blocked;
- retrieved/web/imported/model content is data-plane input and cannot grant authority;
- AI Trust Gate V3 and a static security audit are mandatory host build gates.

Truth boundary: source/host hardening only. No APK compile/install, provider connection, device acceptance, robot/vehicle/BCI control, pilot, production, or security certification is claimed.


## unified1 branch reconciliation — 2026-10-10
This candidate also merges the parallel `0.3.8-rc2-trust1-sfl1` Safe for Later lane without replacing the newer HI1 Human Interface, route1 parser repair, or sec1 security controls.

Preserved Safe for Later properties:
- 29 redacted metadata-only items;
- owner-only tab and local reviewed-state marker;
- no `Native.call`, `runAtlasCommand`, or `atlasConsole` execution path inside the Safe for Later view;
- no raw encrypted-vault bodies, credentials, recovery secrets, customer records, or full proprietary idea text embedded in the runtime data asset.

The Safe for Later UI is organization metadata, not an authority source. Its text cannot grant tools, permissions, or execution.

## Omega1 storage convergence
Owner-confirmed read-only SAF document selection and bounded encrypted import live behind native session checks. The user still owns the source; no APK, real-device storage import, backup portability or local model is verified.

## RATEGUARD1 additive policy — 2026-10-11
A pure-Java read-only retry admission policy/test is now staged; it performs no network request and grants no authorization. See RATE_GUARD1_README_2026-10-11.md. Android native release gates remain blocked.
