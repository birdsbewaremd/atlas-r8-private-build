# ATLAS Android v0.3.6 — native owner-auth hardening

Status: VERIFIED STAGED SOURCE / APK NOT COMPILED / NOT INSTALLED.

## Security delta
- Removed JavaScript's ability to directly assert an active native owner session.
- Added native six-digit PIN verification using salted PBKDF2-HMAC-SHA256 (250,000 iterations) with private SharedPreferences storage.
- Added persistent escalating lockouts after repeated failed PIN attempts.
- Removed the configured-startup “Set Up Another Profile” bypass and locked-screen local-reset bypass.
- Existing v0.3.5 browser PIN verifiers can migrate once after a successful old-PIN verification; fresh native installs use native auth from setup.
- Sensitive assistant-role, microphone wake, dialer, system-panel and speech actions now re-check the native owner session.
- Disabled general WebView file access and content-provider access while preserving packaged android_asset resources; WebView debugging and JS-created windows are disabled.
- Control Center no longer says Voice is ready when the native bridge is absent.

## Source verification
- Pure-Java: CommandParser 52/52; SeedImportPolicy 21/21; VoiceCommandParser 9/9; WakePhrasePolicy 29/29; VoiceFrameClassifier 9/9; SpokenTextPolicy 4/4; TranscriptSelector 4/4; OwnerPinPolicy 13/13. Total 141/141 PASS.
- Source red-team: 42/42 PASS.
- No APK, install or real-device acceptance is claimed in this source checkpoint.

## Shipping continuation
Compile exact v0.3.6 with JDK 21 + Gradle 8.11.1 + Android SDK platform/build-tools 35, verify badging/hash/integrity, then install on SM-G988U and execute the existing acceptance matrix.
