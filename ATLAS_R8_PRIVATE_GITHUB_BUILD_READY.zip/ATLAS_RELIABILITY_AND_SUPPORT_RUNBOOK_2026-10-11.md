# ATLAS reliability and private support runbook — 2026-10-11

**PRIVATE / OWNER ONLY**. This is a source-only operational aid, not a production change or promise of zero errors.

## Owner-preserving failure response
1. Stop the failing step without claiming success; preserve last verified bytes, exact cause and scope.
2. Classify: ATLAS source/runtime; local/toolchain/device; ChatGPT platform/UI; connected provider; external business; or UNKNOWN. Never merge unrelated incidents by date alone.
3. Collect minimal metadata (time + timezone, component, version, redacted error code, observed impact, attempted remediation and tested outcome); DO NOT copy user secrets, private chats, private code, tokens, raw attachments, browser HAR or crash dumps into email.
4. Retry a read-only/idempotent operation at most once diagnostically; if it repeats, change to a documented safe fallback or stop. Never blindly retry a consequential write (email/send, purchase, account/security change, device action, deployment). Query provider state and use an idempotency key where supported.
5. For `container_session_unavailable`/expired container-backed Library upload: retain file bytes, export the exact version to a file snapshot and upload using its `source_file_ref`; confirm upload success, materialize/read back, compare SHA-256; do not claim durable save until then.
6. For ChatGPT `Too many requests`: treat as platform-scope, do not flood/retry rapidly or claim to change rate limits; check official status and ask Support with timestamp, platform, client version and redacted screenshot.
7. For unavailable Gradle/SDK/device/GitHub: mark native release BLOCKED; do not use host scripts as substitution for physical-device tests or weaken auth to get a build.
8. Every fix: reproduce before where safe, write narrow test, patch isolated candidate, run regression/security/source-integrity, preserve rollback and avoid overwriting canonical records during concurrency.

## Evidence and scope
- Pre-existing dated failure index: 164 **source records** (72 classified open/blocked), not 164 proven active bugs. PAUSEGUARD1 is a separate delta until canonical reconciliation.
- OpenAI support case #16970519: October 11, 2026 ~1:58 AM EDT Android red 'Too many requests'. Root cause UNVERIFIED; a secure follow-up draft exists in Gmail and is **UNSENT** pending owner approval.
- Another separately observed tool-layer failure on October 11: `container_session_unavailable` when uploading via container path; safe workaround completed and read back. No evidence of permanent data loss.
- Android source PAUSEGUARD1: source/host tests passed, but no APK, device biometric/Keystore, backup restore, or on-device acceptance occurred.

## Permanent guard rails
- All errors are possible, so minimize both recurrence and damage; avoid false zero-error or guaranteed-security claims.
- Source is **private**, no network privilege added, no provider route enabled, no production deployment.
- A release validator that receives even internally consistent receipts always returns `EVIDENCE_CONSISTENT_REVIEW_REQUIRED`, `release_authorization=DENIED`; the independent owner acceptance process is separate.
- Always require exact recipient and final text approval before sending outward; vendor product support tickets are not a place for proprietary implementation, credentials or private records.

## Remaining blockers
- DESKTOP-KID4BM0 offline; connected GitHub returns zero accessible repositories. Gradle, Android SDK and ADB missing from sandbox; native signed build and physical device tests NOT DONE.
- OpenAI cannot be forced to remove rate limits or fix platform/tool errors by editing local ATLAS source. Continue existing case, do not open duplicate complaints.
