# ATLAS semantic command routing — 0.3.8-rc1

Classification: PRIVATE SOURCE CANDIDATE. This document describes source behavior, not an installed APK or a connected ATLAS brain.

## Security boundary

All owner text entering through the app's typed field, one-shot native speech recognizer, or foreground wake listener reaches `AuthenticatedInputRouter` through a native call site that assigns the input origin. JavaScript cannot supply or elevate the origin. The router is a policy boundary, not an executor.

The routing order is:

1. Re-check the native owner session.
2. Reject null, empty, oversized, unsafe-control, or malformed input.
3. Keep reference/source text inert.
4. Recognize semantic workflow commands and compose their command stack.
5. Route only deterministic local-device commands to `CommandRouter` after a second native owner-session check.
6. Hand ordinary questions and workflow commands to the authenticated ATLAS brain boundary.

The source candidate contains no authenticated brain transport, so workflow and normal-question handoffs return an explicit disconnected outcome. They do not silently execute, fake completion, contact outside parties, or invoke a device action.

## Recognition protocol

The UI renders one of five semantic statuses:

- `🧭 MATCHED`
- `🧩 COMBINED`
- `🆕 CREATED`
- `💬 NORMAL REQUEST`
- `⚠️ PARTIAL MATCH`

`🆕 CREATED` is never emitted by the live router merely because a command-creation request was recognized. The parser can identify the requested status for acceptance testing, but the authenticated router downgrades it to `⚠️ PARTIAL MATCH` until durable persistence positively confirms the save.

The catalog is generated from the reviewed 92-entry JSON registry. The source carries the registry and the 40-case acceptance specification as immutable assets. `WorkflowCommandCatalog.java` is reproducible byte-for-byte from the registry using `scripts/generate-semantic-command-catalog.py`.

## Execution separation

`WorkflowIntentParser` and `AuthenticatedInputRouter` grant no execution authority. Semantic labels never map directly to `CommandRouter`. `CommandRouter.run(...)` has one call site inside the authenticated native gateway and is eligible only for `LOCAL_DEVICE` results.

Calls use `ACTION_DIAL`; text messages use a composer handoff; publication, deployment, deletion, credential changes, account changes, robot actuation, and external communications are not authorized by semantic recognition.

## Privacy and audit

The route JSON returned to the in-process WebView includes the current request so the UI can maintain turn context. The bounded native routing audit stores only timestamp, trusted origin, route, recognition label, input length, command IDs, local command kind, whether the local router was invoked, and a result code. Raw owner text is not written to this audit.

This does not convert browser `localStorage` into encrypted storage, provide a tamper-proof ledger, or protect records outside the existing native vault boundary.

## Verification performed at source level

- 92-entry registry integrity and deterministic catalog reproduction.
- 40 semantic acceptance cases with parser-label and stack comparisons.
- Command-definition body treated as inert data.
- Reference-origin, quoted-data, Google/Googol, Unicode normalization, unsafe control, no-send, and read-only security boundaries.
- Locked/invalid/source/local/workflow/brain route tests.
- Synthetic Chromium UI checks with a mocked native bridge.
- Structural red-team checks and deterministic source-package tests.

These checks do not establish APK compilation, Android lifecycle correctness, actual speech behavior, real-device storage behavior, backend authentication, command persistence, production deployment, or pilot readiness.
