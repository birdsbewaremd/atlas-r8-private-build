# ATLAS Android v0.3.2 — Manual Redteam + Deep Sync Delta

Status: **STAGED PRIVATE / SOURCE TESTED / NOT COMPILED / NOT INSTALLED**.

## Merge resolved
Two useful v0.3.1 branches existed concurrently: one emphasized stricter wake/WebView/security policy; the other carried richer voice/TTS/barge-in/mic-arbitration and the originality/benchmark work. v0.3.2 merges both forward and is intended to supersede both branches as the source frontier.

## Security / behavior
- Wake recognition is transcript-start and boundary-gated for `Hey Atlas`, `OK Atlas`, and `Okay Atlas`.
- Partial hypotheses are preview-only; final results alone can emit commands.
- Duplicate wake commands are suppressed and the wake service emits one event instead of also executing the command itself.
- WebView permission requests deny unknown resource types; camera/microphone are granted only after the matching Android permission exists.
- Packaged ATLAS pages stay internal; HTTP(S) opens externally; unknown/custom schemes fail closed.
- Calls use the dialer and messages use the composer; no silent call/SMS send path is introduced.
- Seed ZIP import keeps bounded file count, path, per-file and total-uncompressed limits.
- Raw microphone audio is not intentionally persisted by the ATLAS wake lane.

## Product / originality
ATLAS is its own system. Superiority over iOS/Siri/Google/Bixby/Alexa is a benchmark target, not a present verified claim. Advancement must be measured by task completion, latency, offline usefulness, continuity, owner-controlled privacy/export/revocation, reliability, recovery and cross-device capability—without copying proprietary UI/assets/trade dress/source/private APIs.

## Build gate
The local environment currently lacks Gradle 8.11.1, Android SDK and ADB. GitHub exposes no repo and Remote Desktop has no connected build device. Therefore APK compilation, installation and real-device acceptance remain blocked.
