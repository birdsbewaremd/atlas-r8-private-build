# ATLAS OMEGA2 — private source convergence checkpoint

Version: 0.3.8-rc2-omega2, versionCode 28
Parent branches: exact SHA-verified unified7 (`9ff1cbb2eb9e1dc72dc9a56c2f1aac1096162a699ce0459dbbe291b4c27dd29d`) and omega1 (`10c03d72dc10aadb7cabd8ff436bfba9f287c23134868ddca7bbd169b0ee78b6`) through unified6 common ancestor (`7e717ff289ba9d6126dfd24dab9a4ad5eb1542c95ed63e3994f5bac200a07acd`).

Combines source-level owner-confirmed, bounded, encrypted-copy Storage1 document import with Unified7 private UI protection: native raw Notes, Tasks, Messages and Photos are session-only and cleared on owner lock. No new INTERNET permission. Noncanonical private source candidate; no native compile, APK, device testing, deployed model, or production change.

Ten Git content conflicts in private isolated merge resolved deliberately; source-level tests must be independently rerun before claiming source/host verification. Web app.js merged automatically and requires both storage and UI privacy tests.

This document is a provenance record, not evidence of a working Android app or production-grade encryption/recovery.

## Current source/host verification
- Exact merged worktree: 12/12 Storage source, 10/10 Storage synthetic UI, 17/17 Omega integration, 14/14 private UI storage, 125/125 source red-team, AI trust/static security gates PASS.
- `scripts/build-debug.sh` exit 10 solely at native toolchain doctor: JDK21 FOUND, Gradle 8.11.1 and Android SDK35/build-tools 35.0.0 MISSING; ADB MISSING. No Android compiled APK or device acceptance.
- Local Git tree is isolated; no production, repo remote, or original parent was changed.
