# ATLAS Android v0.3.5 — truth-and-routing hardening

Status: STAGED SOURCE CANDIDATE. No compiled APK and no install claim.

## Why a new source version exists
The v0.3.4 UI displayed a hard-coded `14%` battery value in the status bar. That was false device telemetry and a concrete defect, so the source freeze was legitimately reopened.

## Changes
- Added a native `deviceStatus()` bridge backed by Android `BatteryManager`; unknown battery state renders as `--%` rather than invented data.
- Enforced the existing `ownerOnly` policy in the app router instead of leaving the policy set unused.
- The Home voice widget now says `Native ready` only when the Android native bridge exists; browser mode says `Install required`.
- Extended source red-team checks for all three behaviors.

## Unchanged boundaries
- Broader second-brain answers still require the authenticated ATLAS brain backend.
- Physical robot control remains offline.
- Calls remain dialer handoff and messages remain composer handoff.
- Private vault access remains owner-session gated.

## Shipping ladder
SOURCE READY -> APK COMPILED -> APK VERIFIED -> S20 INSTALL -> HOME -> ASSISTANT -> HEY ATLAS -> COMMAND ACCEPTANCE -> PRIVATE SEED -> REBOOT/RECOVERY -> RELEASE CANDIDATE.
