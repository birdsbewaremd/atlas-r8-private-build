# ATLAS GOD V4 + RATEGUARD1 — private noncanonical source candidate
2026-10-11 EDT. **Source-level policy ONLY — not a product patch, deployed backend, installed APK, ChatGPT app fix, or security certification.**

Parent preserved, unchanged: `0.3.8-rc2-omega2-wakeguard1-appctx1-godv4`, SHA-256 `7cdb443c8486fe79954586112101d47f2845bade5d281bac17d9664de6fb1213`.
Child overlay: GOD V4 + RATEGUARD1 distinct source archive/hash, inheriting parent versionCode 31 deliberately because it is **not an install/release candidate**. Never build/install this overlay as a released version until a version-code change and all release gates are separately reviewed. Exact archive hash in receipt.

What was added: pure-Java `RequestRecoveryPolicy` + synthetic `RequestRecoveryPolicyTest` and a host-test runner wiring. It computes bounded Retry-After/exponential-delay decisions for future *read-only, idempotent, authenticated* provider requests. Fails closed for expired owner session/device proof, offline, streamed output, non-idempotent or write actions, quota/billing hard limits, unknown error codes, bad Retry-After, and exhausted budgets. It grants no execution or authentication. This code does not call APIs, change ChatGPT limits, store request bodies, or replay requests.

Design for eventual real integration: a trusted Android transport must inject verified status/error headers, confirm live owner session and device-bound proof before every attempt, own a bounded persisted encrypted queue with opt-in drafts, deduplication and crash restore, respect API-specific limits and per-project budgets, ensure cancellation, and avoid double SDK retries. Refuse any request trying to sidestep rate limits using extra accounts/keys. Offline work should use local permitted capabilities, not pretend the network returned a result. Do not log raw prompts, secrets, customer/medical/legal/financial data, or access tokens.

Security acceptance still needed: native build, Android Keystore & biometric/session tests, lockscreen/wearable revocation, injection/duplicate send, offline/airplane testing, server backoff integration, enterprise/provider policy review, consent and connected-glasses boundary, penetration test, no secret leakage, independent restore tests, and signed debug APK acceptance on authorized test hardware. Source gates are not production proof.

Owner access rule: spoken "GOD", voice similarity, face resemblance, genetic clone, AI agent, and any digital/brain replica MUST NOT be treated as owner identity; trusted session + device-bound credentials + consent gate decide access. Delegation separately authorized, scope/time-limited, logged, and revocable. Cloud ChatGPT cannot promise provider invisibility; sensitive vault data must remain offline outside ChatGPT until user explicitly chooses to share a redacted excerpt.

**Do not promote, sign, install, publish, or deploy without new owner approval and complete release gates.**
