# ATLAS GOD V3 — Android APPCTX1 + GOD integration

**Classification:** PRIVATE SOURCE-ONLY, NONCANONICAL. No APK, installation, production deploy, outbound messages, or physical-device operation. Shaun is the owner of these changes.

## Engineering result

Merged the separate private branches without overwriting either original:

- App-awareness parent: `ATLAS_ANDROID_SOURCE_omega2-ci1-wakeguard1-appctx1_PRIVATE_2026-10-10.zip` (SHA-256 `308cb92c86594384e723391116b247fc9bab99bc2a163858772903d7b0da303b`).
- GOD parent: `ATLAS_ANDROID_SOURCE_omega2-ci1-wakeguard1-god1_PRIVATE_2026-10-10.zip` (SHA-256 `17174bf6d2fe0f9c1b84c834f18ba36e9361cc2618c5394525f39c12fd76302d`).
- Merged source candidate: `0.3.8-rc2-omega2-wakeguard1-appctx1-godv3` versionCode 30, debug applicationId `com.sbh.atlasos.candidate`.

The pure-Java `GodCommandPolicy` now treats explicit `GOD`, `GOD: build ...` and `ATLAS GOD ...` as informational mode recognition. It rejects ordinary God/KJV discussions and ambiguous prayer such as `God help me`, `God save me`, `God send me a sign`. Inputs must pass owner/native authentication, origin separation and size validation before GOD routing. GOD never executes a device action locally, grants no additional permission, and can only mark a brain handoff. The disconnected backend remains disconnected.

APPCTX1's fresh owner-PIN-confirmed, one-shot Android UsageStats package-list review remains in place with exactly the same app-awareness core/manifest/WebView source bytes from its parent. It requires separately granted Android Usage Access. No new privileges, INTERNET permission, or background collection were added.

## Verification scope

The source's `scripts/test-pure-java.sh`, `scripts/test-god-wiring.py`, `scripts/test-god-v3-convergence.py`, `scripts/test-app-awareness.py`, `scripts/test-app-android-stubs.py`, `scripts/test-java-syntax.sh`, static security source checks and ZIP manifest checks are mandatory gates. All are **host/source checks only**. `scripts/build-debug.sh` includes the new GOD regression checks and then stops at the missing Android Gradle/SDK toolchain on this host.

**Outstanding:** Build toolchain Gradle 8.11.1, Android SDK 35/build-tools 35.0.0; reproducible debug APK and validated SHA/signature; disposable user-approved phone install; Android 13+ real permission/privacy and owner-lock tests; offline speech/model tests; actual ATLAS brain backend; recovery drill. A new source archive is not a new installed intelligence.

## Research/ambition rule

For every proposed breakthrough classify VERIFIED, BUILDABLE, RESEARCH, SPECULATIVE or CONTRADICTORY; articulate strongest contrary evidence and a falsifiable test; prioritize the next safe $0 prototype. GOD remains symbolic, not a literal claim of being God or permission to circumvent security or consent.
