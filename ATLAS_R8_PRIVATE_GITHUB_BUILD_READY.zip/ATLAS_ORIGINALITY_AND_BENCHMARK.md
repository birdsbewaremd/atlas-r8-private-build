# ATLAS Originality + Competitive Benchmark Gate

Status: product requirement, not a superiority claim.

ATLAS is its own operating/assistant layer. The goal is to outperform incumbent phone assistants and mobile operating experiences on measurable owner utility without copying proprietary interface assets, trade dress, names, icons, animations, visual layouts, source code, or private APIs.

## Originality rules
- Use ATLAS-native concepts and language: second brain, Command Deck, Device Fabric, Atlas Index, capability manifests, owner/private/share-safe context.
- Use documented platform APIs, Android roles/intents, web standards, and device-vendor interfaces only through their legitimate contracts.
- Compatibility is allowed; imitation is not the design strategy.
- Do not present an iOS/Android visual clone as ATLAS. A familiar control is acceptable only when it is a standard interaction pattern and ATLAS has its own expression.
- Do not claim "better than iOS/Siri/Google/Bixby/Alexa" until the relevant benchmark is actually run on comparable hardware and conditions.

## Win conditions to measure
1. **Wake-to-useful-action latency:** p50/p95 from invocation to completed safe action.
2. **Local/offline completion:** percentage of supported device commands that work without a cloud brain.
3. **Context continuity:** follow-up success without the owner repeating known, authorized context.
4. **Cross-device portability:** same intent schema across Android, KaiOS/PWA, desktop and future robot adapters.
5. **Privacy:** minimum retained audio/transcripts, private-by-default context, explicit purpose/permission boundaries.
6. **Owner control:** exportability, revocation, rollback, local recovery, and transparent audit trail.
7. **Safety:** confirmation gates for consequential actions; deterministic physical safety below the model.
8. **Reliability:** restart/reboot/permission-denial/offline/timeout behavior and crash-free command execution.
9. **Recovery:** time to restore ATLAS state on a replacement device without proprietary lock-in.
10. **Personal utility:** measurable tasks completed, steps removed, and time saved for Shaun without sacrificing privacy or control.

ATLAS wins only where evidence beats the comparison. Where it does not, record the gap and improve it.
