# ATLAS Android v0.3.4 — REDTEAM convergence

Status: STAGED PRIVATE / SOURCE TESTED / NOT COMPILED / NOT INSTALLED.

Base: stronger canonical v0.3.3, SHA-256 `5a2c52de677c89df8fb73633b95c3e77216cef45e9de64770d965ea50f1f8dd8`.

Why v0.3.4 exists:
1. canonical v0.3.3 retained a legacy `VoiceCommandParser` that allowed a short lead-in before the wake phrase even though `WakePhrasePolicy` required transcript-start;
2. vault image bridge trusted JavaScript-provided MIME text when constructing `data:` URLs;
3. outer v0.3.3 packaging claimed v0.3.3 while `app/build.gradle` still declared `versionName 0.3.1`.

v0.3.4 preserves the stronger v0.3.3 owner-session, lock-safe, frame/context, transcript-confidence, speech/TTS, exact-once wake, command, seed and WebView security architecture while closing those three release-integrity defects.
