# ATLAS Android 0.3.7-rc3 — private source candidate

NOT AN APK. Not installed, deployed, device-tested, a certified security product,
or a full backup. Do not distribute this source bundle to friends or investors.
Read RC3_REVIEW.md, BUILD_STATE.json and RELEASE_GATES.md for current scope.
Historical reports apply only to their dated versions.

## Changes from rc2

The original rc2 ZIP is preserved unchanged, SHA-256:
`e871b65e8c75b9f3f1b328beae5d7ae459a2fe3fabef290221148765680ca7b5`.

* OwnerSessionGate fails closed on unavailable Android lock state, expires sessions,
  clears a session when device lock is observed, and requires fresh authentication
  after backgrounding. Backgrounding cancels private voice and wake listening.
* Late voice callbacks are ignored when locked. Native lock events clear the UI
  role and mask private content. The displayed native session is rechecked each
  second; this is not an exact real-time UI guarantee.
* Stored photo data is validated and escaped before insertion into HTML.
* Imports stage encrypted entries in a new private directory. A complete valid
  bounded ZIP and an active owner session are required before publishing one new
  import subtree. Existing files are never used as write destinations. Reimporting
  creates another snapshot; it does not update or deduplicate the first snapshot.
* The ZIP reader rejects missing/inconsistent end records, duplicate normalized
  names, traversal, absolute paths, size/count overruns and unsupported ZIP64 or
  multi-disk archives. This does not authenticate who created the ZIP.
* Returning from Android's file picker requires normal owner unlock followed by
  an explicit import confirmation. Selection expires after the recovery-flow
  window (five minutes). Only a temporary read grant is retained.
* Future debug builds have package `com.sbh.atlasos.candidate`, version
  `0.3.7-rc3-test`, versionCode 13 and the label `ATLAS Test Candidate`.
  This is a source configuration, not a verified compiled-manifest claim.

## Run the source/host gates

    bash scripts/test-pure-java.sh
    python3 scripts/test-native-session.py
    bash scripts/test-transactional-import.sh
    python3 scripts/source-redteam.py
    python3 scripts/test-source-package.py
    node --check app/src/main/assets/www/app.js
    python3 scripts/package-source.py --verify

With Playwright and local Chromium, run both optional UI suites:

    python3 scripts/test-owner-ui.py
    python3 scripts/test-security-ui.py

The session tests compile the actual gate against small fake Android APIs. The
import tests execute actual ZIP/filesystem transaction code with a synthetic byte
writer, not Android Keystore encryption. Browser tests use synthetic storage/native
callbacks. None proves Android compilation, lifecycle behavior, or device security.

## Build and recovery boundaries

    bash scripts/build-debug.sh

JDK 21 is present in this work environment. Gradle 8.11.1, Android SDK platform 35,
build-tools 35.0.0 and ADB are not. The desktop is offline and the GitHub connector
returns no accessible repositories. Official-host download DNS also failed.
No SDK license, release-signing key, public host, production branch, or device was
changed. Do not substitute a web preview for an installable Android application.

Existing PIN confirmation and offline single-use recovery design are preserved.
Recovery is not a backup of the vault/Keystore or a way to recover a lost phone.
No owner recovery token was generated here. Keep browser notes/tasks on synthetic
content: they remain localStorage plaintext, not encrypted by the native PIN.

Pending: MainActivity/Keystore integration, storage-full/process-death/fsync and
atomic-move behavior on Android, resource/package resolution, media/navigation/
iframe/native-bridge review, dependency audit, signing provenance, real-phone
acceptance, server-enforced accounts/owner approval/device binding/tenant isolation.
WebView camera/microphone remain disabled. Native voice is source-only. The new
background-lock policy intentionally stops the wake listener when leaving ATLAS;
background wake operation is not promised by this candidate.

Do not delete/clear app data or replace an only working installation to test this.
Use a disposable emulator or separate test package with synthetic data. The debug
key is not the owner's production signing identity. Preserve the real signing key
outside source archives. No canonical version or production deployment was promoted.
