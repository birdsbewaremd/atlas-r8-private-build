# Current candidate: 0.3.7-rc3

Read README_CANDIDATE.md first. The build guide below is inherited historical
context; its old identity/status statements do not override BUILD_STATE.json.
The test build now uses a separate com.sbh.atlasos.candidate package.

> CURRENT CANDIDATE: 0.3.7-rc2, source-tested only. Read README_CANDIDATE.md and RELEASE_GATES.md first. The original instructions below are retained as historical build context.

# ATLAS OS Native Android Source

This project wraps the accepted ATLAS phone UI as a native Android launcher shell without redesigning it.

Implemented in source:
- HOME/launcher intent so Android can offer ATLAS OS as the home app after installation.
- Local trusted WebView UI only; external HTTP/HTTPS links open outside the privileged WebView.
- Camera/microphone runtime permission bridge.
- Dialer handoff and system settings panels.
- One-file private seed import.
- Imported seed files encrypted with AES-GCM using an Android Keystore key and stored in app-private storage.
- JavaScript bridge can count/list vault items and decrypt an item on demand.
- Android backups disabled and cleartext network traffic disabled.

Not claimed here:
- This source is not a signed APK because the current ChatGPT runtime has no Android SDK/build-tools.
- It is not a custom ROM and does not replace Samsung firmware/kernel/verified boot.
- It does not claim GrapheneOS-equivalent low-level exploit resistance.

Build with Android SDK + JDK 21:
`./gradlew assembleDebug` after generating/adding a Gradle wrapper, or open the project in Android Studio and build.

## v0.2.0 assistant/device build lane
This source now includes:
- Android Home/launcher role surface.
- `ACTION_ASSIST` plus `VoiceInteractionService` / `VoiceInteractionSessionService` bridge.
- Owner-requested Android Assistant role flow.
- Opt-in foreground “Hey Atlas” microphone service (not claimed as privileged OEM DSP hotword access).
- Safe local device command router.
- GitHub Actions debug-APK workflow at `.github/workflows/build-android.yml`.
- Local deterministic build script at `scripts/build-debug.sh`.

The CI workflow intentionally builds only a debug/test APK. No production signing key or external model/API credential belongs in this repository.

## v0.2.1 voice-assistant forge — Sept. 27, 2026
Staged source upgrade from v0.2.0. Added:
- deterministic `Hey/OK/Okay Atlas` wake parsing with punctuation cleanup;
- partial recognition state and corrected recognizer restart timing (do not restart at end-of-speech before final results);
- bounded retry backoff and a notification Stop action for the foreground wake listener;
- native one-shot listen/transcribe events for the WebView UI;
- Android TTS replies with interruption/barge-in support;
- Assistant-role invocation opens Atlas and begins a one-shot listening turn after owner unlock;
- wake-listener / one-shot-listener coordination to reduce microphone contention;
- local private answers for time, date, and battery percentage;
- broader command synonyms for navigation, search, apps, flashlight, audio, settings, dialer, and message composer;
- explicit second-brain handoff when no safe local command matches instead of fabricating a general answer;
- pure-Java wake-parser regression test in `tests/VoiceCommandParserTest.java`.

Security boundary remains unchanged: no silent call placement or message sending, no robot actuation from the phone command list, no voiceprint authentication, no raw-audio persistence added, and no claim of privileged OEM/DSP hotword access.

Verification performed in the build environment:
- Java wake parser regression: 7/7 PASS.
- `node --check` on the bundled `app.js`: PASS.
- source/secret/static package checks: see `VOICE_FORGE_VERIFICATION_2026-09-27.txt`.

Not verified here:
- Android SDK/Gradle compile;
- APK install/signing;
- Assistant-role acceptance on the Galaxy S20 Ultra;
- screen-off/background-microphone behavior;
- real-device speech/TTS latency, wake false-positive rate, or battery impact.

## v0.2.2 voice hardening — Sept. 27, 2026
Continues v0.2.1 without replacing the working architecture:
- wake phrase must occur near the beginning of recognition, reducing ambient false-trigger risk;
- recognizer alternatives now use confidence-aware deterministic transcript selection;
- first-pass REAL_WORLD / FICTION_LORE / SHAUN_PRIVATE / DEVICE_ACTION / HIGH_STAKES frame classification is generated before brain handoff;
- prior-turn text/frame is kept in volatile UI session context for future authenticated brain handoff, not persisted as new memory;
- native owner-session gate mirrors the unlocked Atlas UI, expires after 15 minutes, and fails closed when Android is device-locked;
- locked/expired wake sessions can only answer a narrow lock-safe set of device facts; they cannot open apps, dialers, messages, navigation or settings;
- private vault bridge calls now require the active native owner session;
- TTS is concise by policy: strips URLs/path artifacts and normally speaks at most two sentences / ~360 characters;
- real-device acceptance matrix expanded to 70 cases.

Still not claimed: Android compile/APK install, S20 Ultra acceptance, privileged DSP hotword support, or connected authenticated Atlas brain backend.

## v0.3.1 merged phone source — Sept. 27, 2026
This is the first staged source after explicitly reconciling the v0.2.x voice lane with the v0.3.0 security lane. It is intended to close the SOURCE MERGE gate only. It does not close APK compile/install/device-acceptance gates. See `MERGE_REPORT_2026-09-27.md`, `BUILD_STATE.json`, and `VOICE_ACCEPTANCE_MATRIX.md`.


## v0.3.4 convergence hardening — Sept. 27, 2026
Starts from the stronger converged v0.3.3 source and preserves its owner-session/lock-safe gating, confidence-aware wake selection, frame classification, TTS, one-shot speech, exact-once wake event routing, seed/WebView security and 70-case real-device acceptance plan. v0.3.4 fixes three release-integrity defects: the legacy wake helper now delegates to the same strict transcript-start policy, vault image data URLs use a fixed image MIME allowlist, and the Android package version is internally consistent at versionCode 8 / versionName 0.3.4. Source-tested only; no APK/install/device claim.
