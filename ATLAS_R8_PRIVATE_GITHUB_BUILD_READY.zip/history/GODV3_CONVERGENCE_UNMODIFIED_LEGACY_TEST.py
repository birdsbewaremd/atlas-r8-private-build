#!/usr/bin/env python3
"""GOD V3 APPCTX1 merger tripwires: hashes + capability/permission checks.

Source-only tests, not APK/Android-device execution.
"""
from pathlib import Path
import hashlib, json, sys
ROOT=Path(__file__).resolve().parents[1]
PINNED_APPCTX_FILES={'app/src/main/java/com/sbh/atlasos/AppAwarenessPolicy.java': '7d5cf2ed4832ae1a7e46abd6cee27bd70c5fec11656ea1bed88a3231486df52d', 'app/src/main/java/com/sbh/atlasos/AppUsageReader.java': '345b795597a0fce8a71155182e36f9bb820f82072b3cbf68ec54adc13a3188b7', 'app/src/main/AndroidManifest.xml': '03f7a6fa27296366af2c59df55debd95b0bd336e82fb0b5a81f40ac2bfd960de', 'app/src/main/assets/www/app.js': 'c67ab82f685eb41fb6650fa2e5a03397cadb8a07ad148fdc3b26a5bc024d314a', 'scripts/test-app-awareness.py': 'e7373e7696736ee51b614b2d5017695a2717523cab12b0dd1d5009d703b7b039', 'scripts/test-app-android-stubs.py': 'd2b2166bfb4690c9bfd6be7d881dfb986270060d92accb92330dfcb84f44af3a'}
identity=json.loads((ROOT/'BUILD_STATE.json').read_text())
ui=(ROOT/'app/src/main/java/com/sbh/atlasos/MainActivity.java').read_text()
auth=(ROOT/'app/src/main/java/com/sbh/atlasos/AuthenticatedInputRouter.java').read_text()
appjs=(ROOT/'app/src/main/assets/www/app.js').read_text()
source=(ROOT/'scripts/build-debug.sh').read_text()
manifest=(ROOT/'app/src/main/AndroidManifest.xml').read_text()
checks={}
for name,sha in PINNED_APPCTX_FILES.items():
  checks['APPCTX1 parent exact bytes: '+name]=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha
checks.update({
  'God recognition on authenticated route only':auth.index('if (!authenticated)') < auth.index('GodCommandPolicy.Result god'),
  'God recognition after reference source gate':auth.index('WorkflowIntentParser.State.SOURCE_DATA') < auth.index('GodCommandPolicy.Result god'),
  'God never becomes local device action':auth.index('GodCommandPolicy.Result god') < auth.index('Route.LOCAL_DEVICE'),
  'App awareness UI remains intact':"Native.call('showRecentAppsOnce')" in appjs,
  'App awareness native owner PIN flow remains intact':'showRecentAppsOnceNative()' in ui and 'unlockOwnerNative(pin)' in ui,
  'God metadata active only on brain handoff': 'routed.route == AuthenticatedInputRouter.Route.BRAIN_HANDOFF' in ui and 'godMode.put("isExecution",false)' in ui,
  'No internet permission added': 'android.permission.INTERNET' not in manifest,
  'No broad package permission added': 'android.permission.QUERY_ALL_PACKAGES' not in manifest,
  'God and appctx tests in build': 'test-god-wiring.py' in source and 'test-app-awareness.py' in source,
  'Source not promoted to canonical': identity['canonical'] is False,
  'Unbuilt source still marked unbuilt': identity['apk_compiled'] is False,
  'Merged candidate version distinct':identity['version_code']==31 and identity['version_name'].endswith('-godv4'),
})
for k,v in checks.items():print(('PASS' if v else 'FAIL')+' GODV3 '+k)
print('GODV3_CONVERGENCE='+str(sum(checks.values()))+'/'+str(len(checks))+' '+('PASS' if all(checks.values()) else 'FAIL'))
sys.exit(0 if all(checks.values()) else 2)
