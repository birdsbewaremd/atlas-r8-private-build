# ATLAS Voice v0.2.2 — Real-device acceptance matrix

Target: Shaun's Samsung Galaxy S20 Ultra (SM-G988U)
Status: MUST BE RUN ON DEVICE — this document is not proof of acceptance.

## Promotion gate
Do not call the native voice assistant shipped/production or better than Siri/Google/Bixby until the same APK passes the device matrix below with build hash recorded.

### Wake / false-trigger
1. Hey Atlas — quiet room, screen on.
2. OK Atlas — quiet room.
3. Okay Atlas — quiet room.
4. Hey, Atlas — punctuation-like pause.
5. Wake + inline command: “Hey Atlas open camera.”
6. Wake alone then follow-up command.
7. Wake from 3 ft away.
8. Wake from 8 ft away.
9. Wake in van parked/quiet.
10. Wake in van with HVAC fan.
11. Wake outdoors with traffic noise.
12. TV says “Atlas” without wake prefix — must not trigger.
13. “Atlas Mountains” — must not trigger.
14. Long sentence containing “hey Atlas” late in the sentence — must not trigger.
15. 30-minute idle false-trigger observation.

### Turn-taking / TTS
16. Tap-to-talk one-shot recognition.
17. Android Assistant role invocation.
18. Barge in while Atlas is speaking.
19. Partial transcript updates.
20. End-of-speech waits for final result.
21. No-match recovery.
22. Speech timeout recovery.
23. TTS first sentence latency.
24. Spoken reply remains concise; URLs/file paths not read aloud.
25. Two consecutive turns preserve UI session context.

### Local command lane
26. What time is it?
27. What is today's date?
28. Battery level.
29. Open camera.
30. Open Maps.
31. Open an installed third-party app.
32. App-not-found behavior.
33. Wi-Fi settings.
34. Bluetooth settings.
35. Volume up.
36. Volume down.
37. Mute/unmute.
38. Flashlight on/off.
39. Navigate to North East Park.
40. Search for Birds Beware.
41. Dialer opens but does not place call.
42. Message composer opens but does not send.
43. Birds Beware shortcut.

### Frame preservation / brain handoff
44. “Who is Abstergo?” -> FICTION_LORE.
45. “In Assassin's Creed, what is Abstergo?” -> FICTION_LORE.
46. “Who founded Ubisoft?” -> REAL_WORLD.
47. “Check my calendar.” -> SHAUN_PRIVATE.
48. “How much could a hospital visit cost?” -> HIGH_STAKES.
49. Unmatched knowledge question does not fabricate an answer while backend is disconnected.
50. Follow-up pronoun/context envelope is carried to brain handoff.

### Lock/privacy
51. Lock Atlas OS; “open Messages” from wake listener must not execute.
52. Lock Android device; private/device action must fail closed.
53. Locked state can answer only explicitly lock-safe local facts (time/date/battery/help).
54. Vault count/list/read returns nothing while owner session is inactive.
55. Voiceprint/wake phrase alone never authenticates owner.
56. Owner session expires after inactivity; next private/device action requires unlock.
57. Re-unlock restores native owner session.

### Reliability / platform
58. Foreground notification Stop action.
59. Wake listener survives normal app navigation.
60. Android kills process -> no false claim of listener availability.
61. Reboot behavior documented; no silent auto-start claim.
62. Bluetooth earbuds mic routing.
63. Bluetooth earbuds TTS routing.
64. Speakerphone routing.
65. Screen-off behavior.
66. Battery drain measured over 1 hour armed idle.
67. Battery drain measured over 8 hours if platform permits sustained listener.
68. Thermal behavior after 30 minutes repeated recognition.
69. Airplane/offline recognition behavior.
70. Network-loss degraded behavior.

Record PASS/FAIL, device build number, Android version, Atlas APK SHA-256, test date/time, and notes for every executed item.
