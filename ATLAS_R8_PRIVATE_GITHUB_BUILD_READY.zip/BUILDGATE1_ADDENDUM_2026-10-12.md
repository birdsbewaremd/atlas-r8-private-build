# ATLAS native Android BUILDGATE1 — owner-private additive release

The original `ATLAS_ANDROID_GOD_MASTER_CHAT_V1_PRIVATE_SOURCE_2026-10-11.zip` is kept unchanged, SHA-256 `f8296a26476bd78d2e48855d9d93401f73bbae28b39c2d20c0237ef2aef3a8c0`. This release changes ONLY the source packaging/build entrypoint, adds synthetic tests, and updates README. It does not change runtime Android app logic, signing, permissions, versionCode or applicationId.

## Reproduced issue

Without Gradle 8.11.1 and Android SDK 35, `bash scripts/build-debug.sh` attempted all source gates before `toolchain-doctor.sh`, wasting time and yielding incomplete timed-out reports. `toolchain-doctor.sh` was previously called by the manual private CI workflow early, but not by the direct local script. This release makes direct invocation fail fast and provides `--source-only` for genuine full test coverage.

## Release caveats

- Native Android SDK/Gradle/ADB and actual phone acceptance remain separate blockers.
- The script's source-only success cannot establish a compiled, signed or installed APK.
- Source archive contains prior owner-private historical summaries; keep the ZIP in the private owner workspace. Never upload to a public repository.
- For a real device build, use approved private compile-capable host; review permissions and test on Samsung only with specific authorization.
