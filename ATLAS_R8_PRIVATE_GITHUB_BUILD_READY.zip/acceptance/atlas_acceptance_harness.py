#!/usr/bin/env python3
"""ATLAS 52-case acceptance evidence harness.

This tool validates the acceptance plan, creates a NOT_RUN result template,
and scores evidence returned by an external system-under-test adapter.
It does not execute the Android app, model providers, network calls, or side effects.
"""
from __future__ import annotations
import argparse, json, hashlib, sys
from pathlib import Path
from typing import Any

CASE_GROUPS = ("core_cases", "cycle_02_cases", "cycle_03_cases", "cycle_04_cases")
VALID_STATUSES = {"PASS", "FAIL", "NOT_RUN", "BLOCKED", "INCONCLUSIVE"}

class HarnessError(ValueError):
    pass

def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))

def flatten_cases(plan: dict) -> list[dict]:
    cases=[]
    for group in CASE_GROUPS:
        value=plan.get(group, [])
        if value is None:
            continue
        if not isinstance(value, list):
            raise HarnessError(f"{group} must be a list")
        for c in value:
            if not isinstance(c, dict) or not c.get("id"):
                raise HarnessError(f"invalid case in {group}")
            row=dict(c)
            row["_group"]=group
            cases.append(row)
    return cases

def validate_plan(plan: dict) -> dict:
    cases=flatten_cases(plan)
    ids=[c["id"] for c in cases]
    duplicates=sorted({x for x in ids if ids.count(x)>1})
    if duplicates:
        raise HarnessError(f"duplicate case IDs: {duplicates}")
    declared=(plan.get("case_counts") or {}).get("total")
    if declared is not None and declared != len(cases):
        raise HarnessError(f"declared total {declared} != actual {len(cases)}")
    if len(cases) != 52:
        raise HarnessError(f"V4 harness expects 52 cases; found {len(cases)}")
    return {
        "plan_id": plan.get("plan_id"),
        "case_count": len(cases),
        "case_ids": ids,
        "release_rule": plan.get("release_rule"),
    }

def expected_evidence(case: dict) -> list[str]:
    raw = case.get("evidence_required", case.get("evidence", []))
    if not isinstance(raw, list):
        return []
    return [str(x) for x in raw]

def make_template(plan: dict) -> dict:
    meta=validate_plan(plan)
    rows=[]
    for c in flatten_cases(plan):
        rows.append({
            "case_id":c["id"],
            "status":"NOT_RUN",
            "critical_failures":[],
            "evidence_present":[],
            "actual_output":None,
            "notes":None,
            "metrics":{},
        })
    return {
        "schema_version":"1.0",
        "plan_id":meta["plan_id"],
        "plan_sha256":None,
        "system_under_test":{
            "build_id":None,
            "source_sha256":None,
            "device_or_environment":None,
            "provider":None,
            "model":None,
            "model_version":None,
            "policy_version":None,
            "started_at":None,
            "completed_at":None
        },
        "results":rows
    }

def validate_results(plan: dict, results: dict) -> dict:
    plan_meta=validate_plan(plan)
    cases={c["id"]:c for c in flatten_cases(plan)}
    rows=results.get("results")
    if not isinstance(rows,list):
        raise HarnessError("results must be a list")
    seen=set()
    problems=[]
    normalized={}
    for row in rows:
        cid=row.get("case_id")
        if cid not in cases:
            problems.append(f"unknown case_id {cid!r}")
            continue
        if cid in seen:
            problems.append(f"duplicate result {cid}")
            continue
        seen.add(cid)
        st=row.get("status","NOT_RUN")
        if st not in VALID_STATUSES:
            problems.append(f"{cid}: invalid status {st}")
            st="INCONCLUSIVE"
        failures=row.get("critical_failures") or []
        if not isinstance(failures,list):
            problems.append(f"{cid}: critical_failures must be list")
            failures=["invalid critical_failures field"]
        evidence=row.get("evidence_present") or []
        if not isinstance(evidence,list):
            problems.append(f"{cid}: evidence_present must be list")
            evidence=[]
        req=expected_evidence(cases[cid])
        missing=[x for x in req if x not in evidence]
        if st=="PASS" and missing:
            problems.append(f"{cid}: PASS missing evidence: {missing}")
        if st=="PASS" and failures:
            problems.append(f"{cid}: PASS contains critical failures")
        normalized[cid]={
            "status":st,
            "critical_failures":[str(x) for x in failures],
            "missing_evidence":missing,
        }
    missing_cases=sorted(set(cases)-seen)
    if missing_cases:
        problems.append(f"missing {len(missing_cases)} case results")
    return {"plan":plan_meta,"normalized":normalized,"problems":problems,"missing_cases":missing_cases}

def score(plan: dict, results: dict) -> dict:
    vr=validate_results(plan,results)
    norm=vr["normalized"]
    counts={x:0 for x in sorted(VALID_STATUSES)}
    critical=[]
    for cid,row in norm.items():
        counts[row["status"]]+=1
        if row["critical_failures"]:
            critical.append({"case_id":cid,"failures":row["critical_failures"]})
    total=len(flatten_cases(plan))
    passes=counts["PASS"]
    release_eligible = (
        not vr["problems"]
        and len(norm)==total
        and passes==total
        and not critical
    )
    return {
        "plan_id":plan.get("plan_id"),
        "total_cases":total,
        "counts":counts,
        "pass_rate": passes/total if total else 0.0,
        "critical_failure_count":len(critical),
        "critical_failures":critical,
        "validation_problem_count":len(vr["problems"]),
        "validation_problems":vr["problems"],
        "release_eligible":release_eligible,
        "truth_boundary":"release_eligible means only that this evidence file satisfies this harness. It is not independent proof that the underlying observations are true.",
    }

def cmd_validate(args):
    p=load_json(Path(args.plan))
    print(json.dumps(validate_plan(p),indent=2))

def cmd_init(args):
    pp=Path(args.plan)
    p=load_json(pp)
    out=make_template(p)
    out["plan_sha256"]=sha256_file(pp)
    Path(args.output).write_text(json.dumps(out,indent=2),encoding="utf-8")
    print(args.output)

def cmd_score(args):
    p=load_json(Path(args.plan))
    r=load_json(Path(args.results))
    s=score(p,r)
    if args.output:
        Path(args.output).write_text(json.dumps(s,indent=2),encoding="utf-8")
    print(json.dumps(s,indent=2))
    return 0 if s["release_eligible"] else 2

def self_test(plan_path: Path):
    p=load_json(plan_path)
    v=validate_plan(p)
    assert v["case_count"]==52
    template=make_template(p)
    s=score(p,template)
    assert s["counts"]["NOT_RUN"]==52 and not s["release_eligible"]

    # Duplicate ID must fail.
    bad=json.loads(json.dumps(p))
    bad["cycle_04_cases"][0]["id"]=bad["core_cases"][0]["id"]
    try:
        validate_plan(bad)
        raise AssertionError("duplicate ID was not rejected")
    except HarnessError:
        pass

    # All-pass fixture with expected evidence should be eligible.
    good=make_template(p)
    cmap={c["id"]:c for c in flatten_cases(p)}
    for row in good["results"]:
        row["status"]="PASS"
        row["evidence_present"]=expected_evidence(cmap[row["case_id"]])
    sg=score(p,good)
    assert sg["release_eligible"]

    # One critical failure blocks even if evidence is otherwise complete.
    badres=json.loads(json.dumps(good))
    badres["results"][0]["status"]="FAIL"
    badres["results"][0]["critical_failures"]=["synthetic critical failure"]
    sb=score(p,badres)
    assert not sb["release_eligible"] and sb["critical_failure_count"]==1

    # Missing required evidence makes a PASS invalid.
    evid=json.loads(json.dumps(good))
    first=next((r for r in evid["results"] if expected_evidence(cmap[r["case_id"]])), None)
    assert first is not None
    first["evidence_present"]=[]
    se=score(p,evid)
    assert not se["release_eligible"] and se["validation_problem_count"]>=1
    return {
        "tests":[
            "52-case count and uniqueness",
            "all NOT_RUN does not pass",
            "duplicate IDs rejected",
            "complete synthetic PASS fixture accepted",
            "critical failure blocks release",
            "PASS without required evidence rejected",
        ],
        "passed":6,
        "failed":0
    }

def main():
    ap=argparse.ArgumentParser()
    sub=ap.add_subparsers(dest="cmd",required=True)
    p=sub.add_parser("validate-plan"); p.add_argument("plan"); p.set_defaults(fn=cmd_validate)
    p=sub.add_parser("init-results"); p.add_argument("plan"); p.add_argument("output"); p.set_defaults(fn=cmd_init)
    p=sub.add_parser("score-results"); p.add_argument("plan"); p.add_argument("results"); p.add_argument("--output"); p.set_defaults(fn=cmd_score)
    p=sub.add_parser("self-test"); p.add_argument("plan")
    args=ap.parse_args()
    if args.cmd=="self-test":
        print(json.dumps(self_test(Path(args.plan)),indent=2)); return 0
    return args.fn(args) or 0

if __name__=="__main__":
    sys.exit(main())
