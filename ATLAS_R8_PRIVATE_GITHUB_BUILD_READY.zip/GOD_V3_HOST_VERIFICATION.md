# ATLAS GOD V3 source test receipt

- **GodCommandPolicyTest**: 189 Java assertions PASS
- **test-pure-java.sh**: all 24 listed classes PASS
- **test-god-wiring.py**: 18/18 PASS
- **test-god-v3-convergence.py**: 18/18 PASS
- **test-app-awareness.py**: 17/17 source + 18/18 Java PASS
- **test-app-android-stubs.py**: 10/10 PASS
- **test-java-syntax.sh**: 41 source units parsed PASS; not an Android compilation
- **source-redteam.py**: 130/130 PASS
- **scripts/test-source-package.py**: 20 unittest methods PASS
- **scripts/test-omega-merge.py**: 17/17 PASS
- **scripts/test-safe-for-later.py**: 10/10 PASS
- **scripts/test-private-ui-storage.py**: 14/14 PASS
- **scripts/test-ci-build-workflow.py**: 16/16 PASS
- **scripts/test-semantic-assets.py**: check-semantic-command-assets.py PASS 92 entries
- **scripts/test-vault-search.sh**: 36/36 HOST PASS
- **scripts/test-human-learning-java.sh**: 91/91 PASS
- **scripts/test-learning-source.py**: 23/23 PASS
- **scripts/test-native-session.py**: 15/15 PASS
- **scripts/test-transactional-import.sh**: 64/64 PASS
- **scripts/test-voice-start.py**: 15/15 PASS
- **scripts/test-wake-session.py**: 11/11 PASS
- **scripts/test-storage-source.py**: 12/12 PASS
- **scripts/test-storage-ui.py**: 10/10 PASS
- **scripts/test-ai-trust-gates.py**: static PASS
- **scripts/security-audit.py**: static PASS
- **node --check**: app.js PASS

Toolchain doctor: Java 21 found; Gradle 8.11.1 and Android SDK 35 missing, ADB missing. APK compile, device acceptance, backend, and offline language model **NOT RUN**. This receipt is generated from command exit status and visible host output; source-level safety checks cannot certify production security. Both parent ZIPs remain intact; hashes recorded in JSON.
