# ATLAS Unified Security Integration — 2026-10-10

Candidate: `0.3.8-rc2-unified1-sec1` / versionCode 21
Status: private source candidate; not canonical or production.

## Parents reconciled
- `0.3.8-rc2-trust1-hi1-route1` — SHA-256 `da1008ed9d0ab4d528caa9daa1ec8fdd05632b031e4209a90273f507eab3ca0a`; provides bounded Human Interface + frozen-52 local-routing repair.
- `0.3.8-rc2-trust1-sfl1` — SHA-256 `1df00d3f8c7a5cf22f53c7301ac5d9bd638926554a9b9a3843f076e57d52d92f`; provides owner-only metadata-only Safe for Later UI and regression.

## Security hardening added
- Android INTERNET permission removed while backend/network-agent source scope is disconnected.
- Private UI external links require native owner session and exact HTTPS allowlist.
- External target policy rejects HTTP, URL credentials/fragments, IP literals, local/intranet-style names, non-default ports, dot-segment aliases, redirect cycles, overlong chains, and any redirect hop not explicitly allowlisted.
- Fresh owner action authorization is bound to exact target SHA-256, payload SHA-256, owner-session generation, short TTL and single-use state.
- Evaluation/development side effects are preview-only. Models/automations cannot self-authorize live writes.
- Model-direct deployment, account-security changes, purchases, private disclosure, and high-consequence physical control are blocked in the external-action policy.
- Retrieved/web/imported/model content remains data-plane input and cannot directly change authority.
- AI Trust Gate V3 + static security audit + Safe for Later regression are mandatory pre-toolchain build gates.

## Merge discipline
The route1 `CommandParser.java` and `HumanInterfacePolicy.java` were preserved byte-identical before this unified merge. Safe for Later UI assets were merged without replacing `MainActivity`, parser/router, or Human Interface policy. sec1 hardened `MainActivity` was retained.

## Truth boundary
Source/host hardening only. No APK compile/sign/install, Android Keystore device test, backend/provider connection, physical robot/vehicle/BCI control, pilot, production deployment, independent penetration test, or security certification is claimed.
