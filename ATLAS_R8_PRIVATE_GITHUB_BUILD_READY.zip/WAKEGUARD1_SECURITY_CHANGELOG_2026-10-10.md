# ATLAS wakeguard1 — private Android security candidate

Parent: exact recovered `ATLAS_ANDROID_SOURCE_omega2-ci1_PRIVATE_2026-10-10.zip` (SHA-256 `9bf152854abbe92848449d415a4e1da10759f8a52fc574bb32c83f6eb8e22a06`). This child is separate, source-only, noncanonical. Native package identifier and versionCode are deliberately unchanged (debug candidate) pending owner-reviewed APK promotion.

## Problem addressed
The opt-in `AtlasWakeService` accepted starts without explicitly binding the service to the current owner authentication session and returned `START_STICKY`, allowing possible service restarts after process death. Because the listener uses an Android `SpeechRecognizer`, this was a privacy/lifecycle risk, not demonstrated exploitation or live exfiltration.

## Changes
- Add `WakeSessionPolicy`, a strict owner-session generation permit with explicit revocation and no implicit cross-session rearm.
- Only explicit `ACTION_ARM` from `MainActivity` with an active native owner session can start listening. Notification STOP always works without unlock.
- Reject null/restart intents; return `START_NOT_STICKY`; stop/revoke on lock, session change, background, or missing permission.
- Revalidate owner-session generation every 2 seconds while armed, before microphone listen/retry, and before delivering partial/final recognition callbacks, preventing stale recognition from broadcasting a private command.
- Add 17 executed pure-Java generation tests, 11 integration source gates and five general source-redteam assertions; wire into `scripts/build-debug.sh`.
- Never connect a backend, add network permission, register a covert listener, or grant a model authority.

## Limitations
This is SOURCE/HOST-level work. JNI/Android service runtime semantics, user notification delivery, battery behavior, installed audio permission and actual on-device privacy stop need independent native and real-device acceptance. The existing persistent encrypted vault still requires a portable restore drill before it can be treated as a full independent second brain.

## Priority next
On an owner-controlled, online build machine: verify toolchain, build debug APK, independently inspect permissions and signature, test with airplane mode and explicit mic opt-in, lock/stop/restart/kill-process/re-auth race scenarios, verify no listener persists and no transcript leaks across sessions. Preserve originals and rollback.
