# ATLAS unified7 privacy/UI cleanup — 2026-10-10

Parent: `0.3.8-rc2-unified6`
Candidate: `0.3.8-rc2-unified7` / versionCode 27

## Defects repaired
1. Five top-level Web UI functions (`setupLook`, `home`, `bindHome`, `frame`, `control`) had older shadowed declarations left by branch reconciliation. JavaScript hoisting meant only the later declarations were active, but the dead duplicates increased regression and audit ambiguity. The shadowed declarations were removed.
2. Raw Messages, Notes, Tasks and Photos still wrote to persistent WebView `localStorage` even in the native shell, despite the documented truth that browser localStorage is outside the encrypted native-vault boundary.

## New privacy behavior
- Browser preview retains browser-local behavior.
- Native shell routes those four raw-content surfaces through sessionStorage only.
- Owner lock clears those native private-session keys.
- Delayed chat callbacks refuse to repopulate data after the owner session/role is no longer active.
- Notes and Tasks explicitly state that native persistence is session-only until encrypted native persistence is implemented.

This deliberately chooses privacy over pretending durable encrypted storage exists. Existing historical localStorage data is not deleted or migrated by this source change; migration needs a separately verified path to avoid data loss.

## Truth boundary
No Android APK/device run is claimed. This is source/host privacy hardening only.
