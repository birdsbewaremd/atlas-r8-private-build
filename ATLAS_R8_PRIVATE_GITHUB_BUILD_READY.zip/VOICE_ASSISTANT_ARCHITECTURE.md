# ATLAS Voice Assistant Architecture — v0.3.1 merged candidate

Status: STAGED SOURCE / NOT COMPILED OR INSTALLED
Date: 2026-09-27

## Turn model
HEY ATLAS / Android Assistant / mic button -> LISTENING -> PARTIAL TRANSCRIPT -> FINAL TRANSCRIPT -> FRAME CLASSIFICATION -> LOCAL ROUTER or AUTHENTICATED ATLAS BRAIN -> CONCISE SPOKEN ACK/ANSWER -> READY.

The foreground wake listener is paused during a one-shot listening turn and restored afterward to avoid two Android SpeechRecognizer instances competing for the microphone.

## Recognition hardening
- Wake phrase parser accepts Hey/OK/Okay Atlas with natural punctuation.
- Ambient detections are rejected when the wake phrase occurs too deep into a long transcript.
- Recognition alternatives are selected deterministically using Android confidence scores when available.
- Wake turns require a candidate containing an accepted wake phrase.

## Local lane
Deterministic and privacy-preserving for device actions and device facts. It may open Android settings/apps, adjust volume/flashlight, open navigation/search, open the dialer/message composer, and answer time/date/battery while the authenticated owner session is active. It never silently places a call or sends a message.

When the native owner session is expired or Android is device-locked, wake handling fails closed. Only a narrow lock-safe set of facts (time/date/battery/help/identity) can be handled; app opening, dialer, messaging, navigation, settings, flashlight and other actions require unlock.

## Brain lane
General knowledge, Shaun OS retrieval, connected-service reasoning, source reconciliation, and higher-stakes decisions belong behind the authenticated Atlas brain boundary. The local phone build must not invent those answers when the backend is absent.

A structured brain-handoff event now carries:
- current transcript;
- source (voice/text);
- frame classification;
- prior turn's text/frame;
- turn number.

This context is volatile UI-session state in this source candidate. It is not promoted into Shaun OS or durable memory automatically.

## Frame-preservation rule
Before speaking a knowledge answer, classify the frame as REAL_WORLD, FICTION_LORE, SHAUN_PRIVATE, DEVICE_ACTION, or HIGH_STAKES. Preserve that frame in the spoken answer. Example: Abstergo must be described as fictional and scoped to Assassin's Creed before any lore details are spoken.

The classifier is a conservative routing hint, not a source of factual truth. The authenticated brain still has to verify current/high-stakes claims using appropriate sources/tools.

## Speech-output policy
The native TTS bridge strips URLs/path artifacts and normally speaks no more than the first two sentences / roughly 360 characters. Full detail remains on-screen. Barge-in stops current TTS before a new listening turn.

## Privacy / authentication
Voice style is not authentication. Wake phrase is not authentication. PRIVATE FULL requires the authenticated owner session. A native owner-session mirror expires after 15 minutes and also fails closed while Android reports the device locked. Vault bridge access follows the same native gate.

The app does not add raw microphone-audio persistence. Platform speech services may process recognition according to device/provider configuration.

## Acceptance
`VOICE_ACCEPTANCE_MATRIX.md` defines 70 on-device checks. Source/static tests do not satisfy this gate.
