# ATLAS rc3 review and failure ledger — October 10, 2026

## Verified baseline and defects

The original supplied rc2 source archive matched its recorded SHA-256. Its previous
180 Java assertions, 57 structural checks, 21 simulated-screen checks and 20 source
packaging tests all passed again. Passing those tests did not establish safety.

1. **Import data loss.** rc2 encrypted directly to an existing path and deleted that
   path on encryption failure. Replaying the exact extracted rc2 encryption method
   with a temporary JVM AES key and a synthetic existing file reproduced deletion
   on size overflow. No personal file was used. rc3 writes a fresh staged snapshot,
   validates completion and publishes a new subtree, leaving prior content intact.
2. **Native session fail-open and resurrection.** Actual rc2 gate code, compiled
   against minimal fake Android APIs, passed 6/15 new checks and failed 9. Missing
   lock state, API exceptions, clock rollback and background transitions were not
   handled safely. rc3 passes 15/15 in this same host scope.
3. **Late callbacks and UI lock.** The new browser regression suite passed 0/8
   against rc2. A late voice result rendered a command surface, lock/background
   events left browser state active, and a poisoned stored photo inserted/executed
   an HTML event handler in the test DOM. rc3 passes 8/8 with the same fixtures.
   This does not prove an external attacker can write this app's localStorage.
4. **Truncated ZIP acceptance discovered while testing rc3.** ZipInputStream alone
   accepted a valid prefix from the truncation fixture. The added bounded tail
   guard checks standard ZIP completion and entry counts before any publication.
   The failing truncation case now rejects, preserving existing committed bytes.

Why older gates missed these: mostly policy functions, happy-path mocked screens
and string-presence checks; MainActivity transaction/lifecycle behavior was not
covered. Prevention: keep before/after regression fixtures, distinguish host fakes
from Android runtime tests, and block a real release until device gates pass.

## Final source/host scope

* Existing pure-Java policy assertions: 180/180.
* Actual native session class with fake Android APIs: 15/15.
* Transactional ZIP/filesystem assertions with synthetic writer: 64/64.
* Existing synthetic Chromium onboarding/settings/media UI: 21/21.
* Additional synthetic Chromium late-callback/lock/photo UI: 8/8.
* Structural source assertions: 60/60. These are not behavioral Android tests.
* Source packaging regression cases: 20/20.
* JavaScript, XML, JSON, shell syntax and manifest-integrity gates are separate.

These figures must not be combined into a security grade, valuation or device
acceptance score. Final execution logs belong to the accompanying private receipt
bundle. Source edits after these runs invalidate the receipt until rerun.

## Deliberate boundaries and remaining risks

This is an isolated source candidate. App package/label configuration is not a
compiled APK verification. Owner approval, accounts, revocation, one-device pilot
binding, and multi-user data isolation are not implemented. Never share an owner
build containing Shaun OS data as a substitute for those server controls.

New imports preserve existing snapshots but do not deduplicate or migrate them.
A killed process may leave an encrypted private staging directory; cleanup after
process death and directory fsync/power-loss durability remain Android test gates.
Atomic move support on the device must be verified; there is no unsafe fallback.
ZIP64/multi-disk are deliberately rejected rather than partially accepted.
Backgrounding locks the session and stops microphone services; this trades wake
convenience for a bounded private test mode. PIN lockout/recovery storage durability,
full WebView origin/iframe isolation, and plaintext browser notes remain open.

## References checked for this review

Android native bridges expose objects to frames and need strict content boundaries:
https://developer.android.com/privacy-and-security/risks/insecure-webview-native-bridges

URI parsing and trust-boundary guidance:
https://developer.android.com/privacy-and-security/risks/unsafe-uri-loading

Android Files.move API and atomic-move behavior:
https://developer.android.com/reference/java/nio/file/Files

AGP 8.9 compatibility: Gradle 8.11.1, API/build-tools 35, minimum JDK 17.
This candidate deliberately retains its existing pinned host JDK 21 policy:
https://developer.android.com/build/releases/agp-8-9-0-release-notes

Public documentation requests did not include private app source or personal data.
This work used files already available to this ChatGPT session and is not offline-
only processing or proof of exclusive local possession. No public source upload,
external AI service upload, live account enrollment or hardware action occurred.
