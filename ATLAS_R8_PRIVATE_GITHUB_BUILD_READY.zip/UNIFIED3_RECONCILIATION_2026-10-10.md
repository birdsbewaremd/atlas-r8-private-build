# ATLAS Android unified3 reconciliation — 2026-10-10

Private/noncanonical source candidate.

Deep Sync compared the concurrently-created `integrated3` source against exact `unified2` bytes. Integrated3 had no unique production Java/JS feature absent from unified2 except a more complete service-worker offline cache list; unified2 retained stronger sec1 authorization/untrusted-content/target policy.

Unified3 therefore uses unified2 as the functional/security base and selectively adopts the missing offline cache coverage for `file-search.js/css` and `human-learning.js/css`, with a new cache identity so an older cache cannot masquerade as the current candidate. No network permission, backend, model authority, device action or production promotion is added.
