# ATLAS GOD mode — owner-controlled capability expansion (APPCTX1)

Date: 2026-10-10, America/New_York.
Parent (untouched): `ATLAS_ANDROID_SOURCE_omega2-ci1-wakeguard1_GODTIER_PRIVATE_2026-10-10.zip`, verified SHA-256 `b31e03d732528e6a944af444297c9e222aaf4a545edf95795e6dc4babcd9f49f`.
Branch: `omega2-ci1-wakeguard1-appctx1`, **new source-only private candidate**, not a production release or installed app.

## Actual new functionality written
- Owner Settings → App Awareness → Review recently used apps once.
- Native Android `UsageStatsManager.queryEvents()` reads recent foreground-event **package names**, not another app's messages, screen or credentials.
- Fresh owner PIN verified by existing native throttled PIN logic for **each single read**; independent Android Usage Access grant is required. The WebView cannot receive the resulting package list.
- Captured owner-session generation rechecked before and during reading; lock or background invalidates it; Android's unlocked-state check is mandatory.
- Results are shown in a native dialog; the user can close it. No persistence, telemetry, background listener, scheduled polling, or network transport is introduced. No `INTERNET` or broad package-query permission.
- Query strictly bounded: max 15 minutes, 2,500 scanned events, 12 distinct recent package names, exact package-token validation, reject stale/future events, duplicates collapsed and deterministic order.
- Does **not** establish current foreground app, contents of apps, screenshots, signed-in accounts, which person used the phone, or permission to control another app.

## Prioritization: missing abilities, the achievable path, and real gates

| Priority | Desired capability | Today / new work | Next verifiable gate | Caution |
|---|---|---|---|---|
| 0 | Real installable ATLAS Android assistant | Source candidate only; **NO APK** | Obtain official Android SDK 35/build-tools, Gradle 8.11.1 and owner desktop/approved private CI; compile/lint/signature inspection | Do not install on primary device before disposable-test acceptance |
| 1 | Know recently used phone apps | **APPCTX1 source + host tests**; no device run | Install source-derived test APK with user consent, grant special access in Android Settings, test fresh PIN/lock/revocation/expiry | Only package names, not a full screen/session feed |
| 1 | Offline assistant that reasons and speaks | Voice UI and synthetic routing exist, no verified real LLM/fully offline speech | Owner-initiated actual local on-device model+speech tests under airplane mode and RAM/battery profiling | Never label synthetic parser as general LLM |
| 1 | Owner-owned secure memory and backups | Vault/source-policy components exist, recovery drills missing | Pass real Android Keystore/device restore, independent encrypted owner-held backup and recovery | No 'zero risk' or sole-device key dependence |
| 2 | Ask ATLAS to understand shared screen | **NOT IMPLEMENTED**; Android supports session consent with MediaProjection | Separate opt-in capture module; explicit per-session Android consent; privacy filtering and stop button | No stealth capture, no passwords or unauthorized sharing |
| 2 | Navigate other applications | **NOT IMPLEMENTED**; app-supported intents and explicit roles first | Permission-specific integrations, visible user control, UI tests; accessibility only for appropriate declared use | No silent broad Accessibility privileges, no credential scraping |
| 2 | Read/respond to calls, SMS and email | Limited dial handoff source, connected email tool availability in ChatGPT; no general local control | Role/permission audit and explicit owner-confirmed drafts/actions per target | Do not send/post/call without user approval |
| 2 | Always-available offline service | Opt-in wake source and tested generation guard; Android lifecycle/device unverified | Test visible microphone foreground-service/role limits; user stop, kill/restart and battery/lock cases | Not guaranteed always listening or reboot-persistent |
| 3 | PC, other phones, local network, media | Multi-device connectors and design exist; owner PC offline | Bring trusted owner desktop online; scoped local pairing, read-only dry runs, independent disable switch | No cross-device privilege escalation |
| 3 | Self-update, self-test and recover | Static gates, source CI workflow and offline simulator are present | Private signed candidate builds, manual promotion, provenance, attestation and rollback drills | Agent may propose/test patches, but cannot self-grant deployment authority |
| 4 | Robots, vehicles, home, brain implants | Planning/research/simulation only | Real controlled hardware, safety engineering, supervised offline simulation, physical E-stop and legal review | Never actuate dangerous hardware from an unverified model |
| Never claim | Omniscience, all-app access, literal divinity, perfect security, infinite storage, time travel to the past | Not real capabilities | None; state truthful limits | 'GOD' is a rigor standard, not additional system privileges |

## Verification boundaries
1. Required host tests: `python3 scripts/test-app-awareness.py` (executable pure-Java logic + static source gates); `bash scripts/test-java-syntax.sh`; source build gates (`scripts/build-debug.sh`) down through Android toolchain check.
2. **No live APK, device, Usage Access grant, PIN entry, app data, Gmail, robot, website or security configuration was changed.**
3. The Android SDK agreement was previously approved for the existing project. Installation on a real device remains a separate, specific action.
4. Fail closed on missing grant, device lock, expired owner generation, oversized event feed, package malformedness and unavailable Android services. Exact Android system behavior remains **UNTESTED**.
5. This is private ChatGPT-context source, not an offline-only encrypted backup. Keep an owner-held encrypted copy before relying on it.

## Primary reference documentation (checked 2026-10-10)
- Android UsageStatsManager usage events and special permission: https://developer.android.com/reference/android/app/usage/UsageStatsManager
- Android app roles and consent: https://developer.android.com/reference/android/app/role/RoleManager
- Android foreground microphone restrictions: https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start
- Android per-session screen capture consent: https://developer.android.com/media/grow/media-projection
- Android on-device speech availability: https://developer.android.com/reference/android/speech/SpeechRecognizer
- Android least-privilege advice: https://developer.android.com/privacy-and-security/security-best-practices

## Operator truth marker
This package adds a real, reviewable, host-testable Android feature implementation to a previously verified private source baseline. **Source/host tests are not APK compilation or device functional tests**. The next meaningful result is a real APK compiled from the checked source on an authorized online Windows computer, then permission/revocation tests on a disposable Android device. Reconnect existing desktop / private CI; do not rebrand, deploy production, send email, use the main phone, or grant device permissions automatically.
