# ATLAS Android v0.3.2 — parallel-branch reconciliation

Status: STAGED PRIVATE / SOURCE-TESTED / NOT COMPILED / NOT INSTALLED.

v0.3.2 exists because multiple v0.3.1 candidates were produced in parallel. It reconciles the useful deltas instead of selecting by filename, timestamp or size.

Key corrections over the parallel candidates:
- wake service now emits one final package-scoped event and never executes the command itself, eliminating the duplicate-action path;
- final wake transcript selection uses recognizer confidence while partial transcripts remain non-executing preview only;
- bounded error-specific wake retry/backoff from the hardened branch is retained;
- unknown WebView permission resources are denied instead of being accidentally granted;
- only explicit camera/microphone web resources can be granted;
- owner-session/Android-lock gating, lock-safe local facts, seed-import bounds, HTTP(S)-only bridge, ambiguous-app fail-closed, TTS/barge-in, frame classifier, transcript selector, spoken-answer policy and prior-turn handoff are retained;
- source red-team + toolchain doctor are now first-class build gates.

Promotion rule: no more source-version churn unless testing exposes a concrete defect. Next legitimate gate is APK compilation from this exact tree.
