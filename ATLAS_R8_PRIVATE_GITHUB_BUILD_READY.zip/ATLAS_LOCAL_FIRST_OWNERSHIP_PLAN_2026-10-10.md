# ATLAS LOCAL-FIRST OWNERSHIP PLAN — 2026-10-10

## Decision

Keep ChatGPT available as an external tool, **make ATLAS the owner-controlled hub**, and avoid buying ChatGPT Pro or any extra storage until a measured workflow proves the need. Do not replace the current working provider, canonical source, or data with a speculative redesign. A free model does not magically include free unlimited cloud compute or storage.

## Two independent resources

**Storage:** Existing desktop HDD (previously inventoried as 1 TB) and owned phone space can hold many files without a new monthly vendor fee, but the capacity and hardware durability are finite. The Android STORAGE1 candidate reports **the app-internal device filesystem's real capacity**, not Cloud/SD/network capacity. File imports are per-document, owner-chosen, size-limited, encrypted, non-destructive. The existing Android Keystore-based vault is not portable; source-file preservation and separate independently restorable offline backups are mandatory before storing the only copy of anything important. Google personal storage has an official standard free allowance of **up to 15 GB shared across Drive/Gmail/Photos**, subject to policy (source: https://support.google.com/drive/answer/9312312).

**Inference:** Local open-weight language models can be used without per-token cloud charges by hosting a runtime on the user's own offline-capable hardware. Hardware RAM/VRAM/disk, electricity, and model quality limit what can actually run. The last recorded PC inventory includes i7-9700F, ~24 GB RAM, GTX 1660 Ti, 256 GB SSD + 1 TB HDD, with the SSD near full; do not assert those resources are still available without a fresh machine check. Start with a small 3–8B quantized model, then benchmark privacy, retrieval quality and latency before moving to larger models. Ollama Windows install and compatible model support: https://ollama.com/download/windows and https://ollama.com/library . Do not expose the local model API to the public internet or unauthenticated home-network clients.

## Suggested architecture, phased

1. **Source reconciliation:** current strongest locally visible lineage is unchanged `ATLAS_ANDROID_SOURCE_v0.3.8-rc2-unified3_PRIVATE_2026-10-10.zip`; STORAGE1 is additive and private, not canonical. GitHub HEAD remains inaccessible through the connected app.
2. **Phone UI and data:** preserve existing authenticated native shell; improve document capture, file search, free-space truth and audit. Never request unrestricted storage permissions. No background deletions. No false claims of portability.
3. **Local node:** when the already-owned Windows desktop is online and access is verified, install a local model runtime in a controlled directory; prefer putting sizeable model weights on HDD instead of nearly-full SSD; benchmark smallest viable model first; test without cloud fallback.
4. **Provider routing:** optional OpenAI/Gemini/Claude services behind scoped, revocable user consent with per-provider usage and spend caps and data-minimization. No provider access is currently included in STORAGE1. ChatGPT subscription does not automatically pay for OpenAI API calls.
5. **Portable recovery:** design, threat-model, implement and independently test a cross-device encrypted portable backup with passphrase/key outside ChatGPT, restore checks and rollback **before** ATLAS becomes the sole storage of record. Do not treat `.atlasenc` as self-contained backup.
6. **Native release gate:** install Android SDK 35/build-tools 35.0.0, Gradle 8.11.1, ADB in owner-authorized nonproduction environment; compile/lint/test the exact source ZIP; then owner-controlled Galaxy S20 Ultra acceptance, `52` workflow tests, and a clean encrypted backup restore before any promotion.

## Comparison research (as of 2026-10-10)

- ChatGPT: Free limited access; Plus $20/month; Pro 100/200/500 $100/$200/$500/month. These are ChatGPT UI plans, not unlimited external API access. https://help.openai.com/en/articles/9793128-about-chatgpt-pro-tiers and https://help.openai.com/en/articles/6950777-what-is-chatgpt-plus
- Claude: Free; Pro $20/month; Max $100+/month, all with varying usage limitations. https://www.anthropic.com/pricing
- Gemini: Free tier with standard usage caps and paid higher limits; not unlimited. https://support.google.com/gemini/answer/16275805
- Ollama: local runtime enables device-hosted models without per-token cloud billing. Ollama's separate cloud plans have credit/token pricing, not unlimited cloud resources. https://ollama.com/blog/transparent-pricing

## Verified status to communicate

STORAGE1 is a **source code feature and test report**, not an installed or hosted service. No storage was added to the phone, no data imported, no ChatGPT plan canceled, no bills incurred, no endpoint exposed, no local model connected, no production changes or physical controls performed.
