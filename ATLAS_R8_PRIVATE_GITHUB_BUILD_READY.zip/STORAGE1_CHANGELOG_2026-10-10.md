# ATLAS Android STORAGE1 additive source candidate — 2026-10-10

**Parent:** `0.3.8-rc2-unified3` (unchanged, independent). **New candidate:** `0.3.8-rc2-unified3-storage1` / debug-only `com.sbh.atlasos.candidate`.

## Implemented in source
- Settings → Storage and an owner-only Storage app with live finite Android internal-partition free/total space and encrypted-vault size/count, rejecting locked sessions.
- User-tapped Android Storage Access Framework `ACTION_OPEN_DOCUMENT` picker (one document only), content:// scheme, provider-reported name/size checks, allowlisted inert text extensions, maximum 8 MiB streamed plaintext, 16 MiB storage safety reserve.
- Re-authentication and explicit native confirmation after Android picker; selected original untouched. New owner-private per-import random directory, AES-GCM through the existing Keystore vault codec, `.atlaspart` staging with atomic ciphertext publication. Session is checked throughout and before publication; failures remove new stage only.
- Files app can discover newly imported filenames through existing bounded Vault Search, subject to existing 256 KiB text-preview limit.
- No added Android permissions, network, cloud subscription, deletion, external device control, background job, credentials, or model access.

## Limitations / safety gates
- **Source only.** Compilation, APK, Android SAF/Keystore execution and Galaxy S20 Ultra verification remain blocked by missing Gradle 8.11.1, Android SDK 35/build-tools and ADB; owner's desktop is offline; GitHub source-of-truth not connected.
- Vault encrypted files rely on the device-bound Android Keystore key. This code does **not** implement exportable/passphrase-derived cross-device restore. Do not mistake copied `.atlasenc` blobs for recoverable backups. Do not store sole copies of essential files in this candidate.
- Storage reporting covers the app-internal filesystem partition, not all Google Drive/cloud accounts or arbitrary SD/network locations. Imports consume finite local free space; user chooses each source.
- Document content is treated as data, not executable instructions. Content validation is constrained by encryption and search decoder (malformed UTF-8 rejected at read); the file-picker only allows the documented extension classes.
- External cloud model access remains explicitly disconnected. Local Ollama can be an independent optional inference adapter after local-host authentication/review; no external API credentials are in this source package.

## Mandatory before install
1. Native SDK 35/Gradle 8.11.1 compile and lint; verify APK application ID, hash, debug signature, permissions and no sensitive secrets.
2. Android Keystore, one-document selection and cancellation, 8 MiB limit, free-space failure, owner session expiry, lifecycle lock/re-auth, atomic crash recovery, and reading imported text with synthetic fixtures.
3. Owner-controlled nonproduction test device only; import no unique/irreplaceable user records; verify separate recoverable backup strategy before production.

This is neither a full app launch nor free/unlimited cloud storage.
