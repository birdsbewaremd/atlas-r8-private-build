# ATLAS ONE 0.4 — Private Android source candidate (Oct 12, 2026)

**R1 / Recovery source-only addendum:** This preserved V0.4 candidate is now staged with one additive Second Brain + Robot R1 module, bringing the source hub to **12 modules**. See `R1_ROBOT_AND_RECOVERY_PRIVATE_PATCH_2026-10-12.md`. This is not a compiled APK.

**Status: SOURCE BUILT, HOST SOURCE VERIFIED, BROWSER HOST SMOKE-TESTED. APK NOT COMPILED, NOT SIGNED, NOT INSTALLED; ANDROID FIELD TEST NOT RUN.**

## What has been integrated
- The pre-existing ATLAS Android BuildGate1 Java main app: owner PIN, encrypted vault experiment, voice assistant wiring, home-role capability, and prior policies. The previous BuildGate1 original is archived untouched separately.
- A new **ATLAS ONE** button opens a native, private offline module explorer. Eleven original distinct offline modules are preserved, plus one new Second Brain + Robot R1/Recovery module (12 total in this candidate): Life OS, App Forge, Omni Research, Media Engine, Future Finder, 100-Year Companion, School, Technology/Languages, Faith Atlas, Quiet Mode, and an original Fun Lab. The copied prior HTML files match their archive bytes; some third-party/prototype features may not work on device, especially browser download/export and password-key persistence until verified.
- A **CLEANUP** button opens native storage review: capacity summary, Android storage settings, installed-app settings, default launcher settings, read-only user-picked folder scanning for SHA-256 content duplicates, and *optional confirmed ATLAS temporary cache cleanup only*.
- Navigation to bundled materials uses a restricted Android WebView and local-only HTTPS asset interception. There is no exposed JavaScript-to-native bridge in this module explorer. External HTTPS links require a separate confirmation and open in the owner's browser. No INTERNET permission or all-files permission requested.

## One-phone experience vs. Android itself
You may *choose* ATLAS as your Android default launcher via Android Settings (the existing Android manifest supports HOME); it does not replace Android firmware, silently alter installed apps, bypass system permissions, take over notifications, record audio without platform approval, or delete arbitrary phone contents. It is not a custom ROM and is not a guarantee of cyberattack immunity.

## Build locally from owner-private sources
1. On a trusted build machine with **JDK 21**, **Gradle 8.11.1**, **Android SDK platform 35** and **build-tools 35.0.0**, extract the candidate source ZIP. Inspect code/security gates and keep private.
2. Run `bash scripts/build-atlas-one.sh --source-only` for integrity+source tests.
3. Run `bash scripts/build-atlas-one.sh` for a debug APK, only on a trusted machine with the toolchain and official SDK license. It should write `app/build/outputs/apk/debug/app-debug.apk` and a `.sha256` receipt. Run `apksigner verify --verbose` and `aapt dump permissions` before any field test.
4. Back up the device and verify recovery. Inspect the signed test APK. Installation, permissions and default HOME selection are **separate owner decisions**. No install is authorized by this source-only release.
5. Field-test with airplane mode, screen lock, offline content, folder picker, no deletion, native PIN recovery and device resource usage. Keep old default launcher for rollback until acceptance.

## Tests and unresolved gates
- Existing Java parse gates and prior selected Java security/authority session unit tests passed in the source-only container.
- The original 11 modules rendered in earlier host-injected Chromium checks; the R1 module and hub ran in-memory follow-on Chromium checks. Neither test proves Android WebView: browser smoke tests do **not** prove Android WebView compatibility or native Java compilation.
- No Android SDK, Gradle, or online authorized desktop available in this workspace. Private GitHub Actions has not run; connected GitHub repository list was empty.
- Real APK signing, installation and full-device testing remain **BLOCKED**. Do not rename ZIP to APK or claim installation.

## Private data and recovery
Source archives and browser prototypes are owner-private; do not publish them or email them. Original archives are shipped in the separate recovery ZIP, each SHA-256 recorded in `ORIGINAL_ARCHIVES_SHA256.json`. Never put passwords, private keys, confidential exports, or credentials into a preinstalled APK asset. Existing native vault uses Android Keystore and must not be considered a portable backup until independent restore testing succeeds.

## Source references
The exact Library-origin archive filenames and per-module SHA-256 are recorded in `ORIGINAL_ARCHIVES_SHA256.json` and `UNIFIED_MODULE_INDEX.json`. Android docs: https://developer.android.com/guide/topics/providers/document-provider and https://developer.android.com/develop/ui/views/layout/webapps/load-local-content.
