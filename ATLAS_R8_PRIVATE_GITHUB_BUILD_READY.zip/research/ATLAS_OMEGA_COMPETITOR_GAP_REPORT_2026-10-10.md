# ATLAS OMEGA — AI competitor gaps, constraints and build strategy

**Research checkpoint:** 2026-10-10 (public sources reviewed this session).
**Security classification:** PRIVATE research and source candidate. No secrets included.
**Coverage:** Prioritized 20-gap starter ledger; **not** every AI company, every complaint, or a census of user sentiment.

## Decision

**Build ATLAS as an owner-controlled offline-first assistant; keep advanced cloud products as replaceable tools.** Do not claim ATLAS is smarter than ChatGPT, Claude, Gemini or Muse: there is no comparable live benchmark, local model or installed phone build. Focus on superior *ownership for one user*, traceable personal context, privacy controls, low recurring costs, and reliable completion of authorized routine work.

## Verified competitor strengths and relevant limits

| Product/ecosystem | Verified strength | Verified boundary / opportunity |
| --- | --- | --- |
| OpenAI ChatGPT / GPT-6 | Models, tools, multi-source memory, rich research | Official memory guide says not every detail is retained; plan/model/tool limits exist |
| Claude | Long context, memory across chats, projects, code workflows | Official guidance distinguishes 5-hour/weekly usage limits and fixed context capacity |
| Gemini | Google ecosystem personalization, tool connections | Official documentation covers compute-based usage limits |
| Meta Muse | Browser-backed persistent agent, app connectors, background tasks, owner approval | Official site explicitly describes a remote secure VM and free usage limit; not an owner-hosted offline substitute |
| Open local models (Muse Glimmer, llama.cpp, Ollama) | Genuine device/PC inferencing, no recurring token billing on owned hardware | Still need hardware, electricity, compatible model files, updates, and quality testing; phone RAM/context limits |
| Others (xAI/Grok, Copilot, Perplexity, DeepSeek, Qwen etc.) | Active competitors and candidate engines | This checkpoint has **not** independently benchmarked these products; no unsupported ranking assigned |

### Community signal ≠ prevalence

A March 2026 Reddit complaint reports perceived hallucinations and wrong coding fixes. A February 2026 r/LocalLLaMA discussion frames local-vs-cloud quality/privacy tradeoffs. Both are examples of *user/community reports*, not measured error rates. Do not convert isolated posts into industry-wide percentages.

## 20 complaint-to-fix opportunities

Prioritized, labeled evidence and implementation states are machine-readable in `ATLAS_OMEGA_COMPLAINT_LEDGER_2026-10-10.json`. Highest priority: `GAP-001` selective memory, `GAP-003` usage quotas, `GAP-005` privacy, `GAP-006` hallucinations, `GAP-007` code regressions, `GAP-008` owner approval, `GAP-012` unrecoverable encryption keys, `GAP-014` false completion claims, and `GAP-017` difficult installation.

**Do not confuse apparent superiority with evidence:** No head-to-head runs, timed local model tokens/sec, S20 native install, recovery drills, or cloud provider API integrations occurred here. Claims marked `NOT_TESTED` remain unknown, not ATLAS wins.

## Concrete build delivered in this candidate

Three-way reconciliation of two visible parent archives against common `unified3`: `unified6` preserves fresh Safe for Later v0.3.4/29 records and stronger standalone source gates; `storage1` adds scoped read-only document picker, owner confirmation, encrypted import bounded to 8 MiB, finite storage stats and backup risk messaging. The new private source package includes an offline regression gate and research ledger. No model weights or INTERNET permission added. Original parents untouched.

## Cheapest offline intelligence path

1. **$0 first:** Use current files/hardware. Run locally packaged utility, owner-prompted imports, search, data catalog, basic policy and command workflows. This is a limited assistant *without* true generative model inferencing.
2. **$0 incremental experimentation, if device free capacity permits:** Test a **small quantized GGUF** with official llama.cpp Android example or Termux in an isolated setup; source/model downloads require internet initially. No measured model speed on Galaxy S20 Ultra. No promise of one-tap ATLAS integration yet.
3. **Best future upgrade:** First inventory actual owner-PC RAM, GPU/VRAM and disk once connected. For local 7–14B-class models a 16–32GB system may support CPU-limited use; bigger context/models demand more RAM/VRAM. Hardware budget follows measured inventory and available trades, not speculative purchases.
4. **Hybrid only when explicitly enabled:** Higher-end tasks use remote model APIs with transparent metering, explicit scope, and no unrestricted private vault sharing. Current Android source deliberately has no `INTERNET` permission and no backend.

## Safety and independence

Do not delete originals or entrust critical records solely to the current device-bound Android Keystore vault. Provide an independently encrypted portable backup and test restore before any migration. Keep human controls on messages, spending, security, publication, production, vehicle, robot and BCI actions. Do not run unsafe autonomy to chase 'Million-X'. Do not buy cloud storage or tools without owner authorization.

## Build/benchmark acceptance ladder

| Stage | What constitutes valid proof | Status |
| --- | --- | --- |
| Source evidence | Parent hashes, merge diff, complete source gates | Execute and record exact output in reconciliation report |
| Offline host tests | Pure policy tests, Chromium synthetic UI, source trust | Execute and record; never call Android runtime proof |
| Native Android | Actual Gradle + SDK 35 compile/lint/APK | BLOCKED by toolchain |
| Actual S20 Ultra | Install, owner PIN, storage picker, crypto, denial/recovery | NOT_RUN |
| Local model | Download verified compatible weights; launch measured tokens/s, memory, thermal impact | NOT_RUN |
| Competitor A/B | Same prompts, constraints and judge across products | NOT_RUN |
| Production | Explicit owner approval after backups/security/rollback | NO |

## Source ledger

- `OPENAI_MEMORY`: https://help.openai.com/en/articles/8590148-memory-in-chatgpt
- `OPENAI_LIMITS`: https://help.openai.com/en/articles/20001354-gpt-6-and-other-models-in-chatgpt
- `CLAUDE_LIMITS`: https://support.claude.com/en/articles/11647753-how-do-usage-and-length-limits-work
- `CLAUDE_MEMORY`: https://support.claude.com/en/articles/11817273-use-claude-s-chat-search-and-memory-to-build-on-previous-context
- `GOOGLE_LIMITS`: https://support.google.com/gemini/answer/16275805?hl=en-CA
- `GOOGLE_PERSONAL`: https://blog.google/innovation-and-ai/products/gemini-app/personal-intelligence-nano-banana-us-expansion/
- `META_MUSE`: https://ai.meta.com/muse/
- `META_GLIMMER`: https://research.meta.ai/blog/introducing-muse-glimmer-open-agentic-model
- `LLAMA_ANDROID`: https://github.com/ggml-org/llama.cpp/blob/master/docs/android.md
- `OLLAMA_LOCAL`: https://ollama.com/blog/launch
- `REDDIT_HALLUCINATION`: https://www.reddit.com/r/ChatGPT/comments/1rm7bp5/new_gpt_model_releases_are_hallucinating_more_and/
- `REDDIT_LOCAL`: https://www.reddit.com/r/LocalLLaMA/comments/1rc00nj/in_the_long_run_everything_will_be_local/

## Open issues / next verified blocker

- Native Gradle 8.11.1, Android SDK 35/build-tools 35.0.0 and ADB absent in current container. Android SDK license approval is already recorded, but binaries are not installed.
- Connected Windows desktop was last seen offline; connected GitHub lists zero accessible repositories. No unauthorized access attempts or production changes.
- Existing phone-local encrypted import is not independently restorable. Need safe owner-controlled portable backup protocol before deleting any originals.
- Competitive product coverage is incomplete by design; research ledger should be expanded only with dated evidence and independently scored live comparisons.
