# ATLAS Android omega2 private candidate build

Private candidate: **0.3.8-rc2-omega2 / versionCode 28**. Combines unified7 session-only private UI and omega1 scoped owner-approved Storage1 under the unified6 common ancestor. Noncanonical and uninstalled.

Run `bash scripts/build-debug.sh`. Required native toolchain: Java 21, Gradle 8.11.1, Android platform 35, build-tools 35.0.0. Debug builds use application ID `com.sbh.atlasos.candidate`. Do not install over an owner production build.

## Omega1 source reconciliation — 2026-10-10
Current private source candidate: 0.3.8-rc2-u6-s1-omega1 (versionCode 27), merged from unified6 and unified3-storage1 without overwriting either parent. Adds bounded owner-approved local document Storage, while preserving the newer safe-for-later data, Files/Human Learning source gates and existing no-INTERNET security policy. No native APK, connected LLM, Android device acceptance or production promotion. See ATLAS_OMEGA_RECONCILIATION_2026-10-10.md.

## Unified7 privacy gate retained
- `scripts/test-private-ui-storage.py` checks that native Messages, Notes, Tasks and Photos are session-only and lock wipes in-memory private content. There is no encrypted durable persistence guarantee.

## Additive build-entrypoint fail-fast (2026-10-12)

- `bash scripts/build-debug.sh` now executes `toolchain-doctor.sh` **before** the source suite. Missing JDK 21 / Gradle 8.11.1 / Android SDK platform 35 / build tools 35.0.0 yields a fast BLOCKED status, **not a false APK success**. The existing manual-only private CI workflow already had a preflight; this also protects direct local runs.
- `bash scripts/build-debug.sh --doctor` shows toolchain status without touching the source tests.
- `bash scripts/build-debug.sh --source-only` executes every existing source gate on an SDK-less host; a passing result states `ANDROID_APK=NOT_BUILT`. `--source-only` is not a replacement for `lintDebug`, `assembleDebug`, APK signature review or the Samsung device acceptance suite.
- `python3 scripts/test-build-entrypoint.py` checks fail-fast, source-only, CLI refusal, exact order and syntax using entirely synthetic temporary fixtures. It makes no external connection or native device changes.
- Same project/device approvals continue to apply; no automated transfer to GitHub, installation, deployment or private-data upload is authorized by this update.
