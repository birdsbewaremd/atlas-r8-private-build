# ATLAS omega2 CI1 — debug build readiness (not installed)

**Private research/source only.** This checkpoint does not contain a compiled APK, local LLM, guaranteed offline speech service or Android phone test.

## What changed
The existing `build-android.yml` workflow previously requested Gradle before checking for Android SDK, did not explicitly install SDK 35 or browser dependencies, and did not enforce a private repository. CI1 adds a manual-only **private repo guard**, JDK 21, Gradle 8.11.1, Android SDK platform 35/build-tools 35.0.0/ADB, pinned Playwright+Chromium for existing UI tests, full project source gates, APK application ID and no-INTERNET-permission checks, debug APK signature inspection, SHA-256 checksum, and a 3-day private CI artifact.

### How to run (only after owner has a private GitHub repository)
1. Keep ATLAS source **PRIVATE**. Never upload this ZIP, credentials, personal files or private memory into a public repository. The workflow actively refuses a public repository.
2. Extract this candidate ZIP in a clean working directory, make a git commit in the private repository, then use GitHub **Actions → ATLAS Private Android Debug Build → Run workflow**.
3. If all setup/tests/compile/signature gates pass, download the `ATLAS-private-omega2-debug-apk` Actions artifact. Verify `app-debug.apk.sha256` independently and examine `verification/permissions.txt`.
4. APK package identity must be `com.sbh.atlasos.candidate`, distinct from production. It must not request INTERNET permission while no backend is connected. The CI job **does not install the APK** or deploy production.
5. Before phone installation, export a verified device backup and test recovery on independently held copies. Install to an owner-approved disposable test profile/device, not into the primary production slot. No phone control without this action.

### On-device test acceptance — required, not currently run
- Record exact APK SHA-256, Android version/build, device (S20 Ultra), permissions and test operator/date.
- With **airplane mode ON**, launch/lock/unlock; verify time/battery/local command functionality. Do **not** assume Android SpeechRecognizer is genuinely offline merely because `RecognizerIntent.EXTRA_PREFER_OFFLINE=true`. If downloaded offline recognition packs are unavailable, mark speech `FAIL/UNAVAILABLE`, not PASS.
- Opt into microphone permission and foreground wake listener manually; measure false wake, lock state, network errors, battery drain and stop action.
- Confirm microphone access stops when listener is disabled; without an always-on supported DSP implementation, 24/7 low-power wake is not guaranteed.
- Verify owner-approved document picker, import confirmation, 8 MiB limit, encrypted storage, insufficient-space behavior, lockout and original-file preservation.
- Avoid moving important files solely into Android Keystore vault until an independent passphrase-encrypted **portable backup with restore drill** exists. Current vault does not satisfy this gate.
- Run `VOICE_ACCEPTANCE_MATRIX.md` and all frozen end-to-end business and privacy cases. Record every actual PASS/FAIL with evidence; don't infer from host mocks.

### Remaining external blockers
- No connected Android phone or authorized ADB connection in current container.
- Local environment has Java 21, but no Gradle 8.11.1, Android SDK/platform-tools, and cannot DNS-resolve official download servers.
- Connected desktop was reported OFFLINE; GitHub connector exposed no owner repositories.
- Private workflow has **not executed on GitHub**. CI1 proves source readiness and validates YAML/static assumptions only, not cloud build success.

**Fallback:** The preserved `ATLAS_OMEGA2_WINDOWS_OFFLINE_AI_KIT_2026-10-10.zip` offers a different owner-initiated, local desktop bootstrap. It also needs network/download capability and may require prerequisites.

## Security boundaries
No auto-sync to cloud, no public Actions triggers, no production deployment, no app signing keys beyond local debug test keys, no phone permission escalation or covert audio recording. All platform installs/actions must remain owner-approved. Windows and private GitHub workflow are alternative build *routes*, not expanded ATLAS permissions.
