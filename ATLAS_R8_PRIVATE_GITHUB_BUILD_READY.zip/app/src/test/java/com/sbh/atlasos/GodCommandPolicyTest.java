package com.sbh.atlasos;

public final class GodCommandPolicyTest {
  private static int n=0;
  private static void ok(boolean b, String label) { n++; if(!b) throw new AssertionError(label); }
  private static void scope(String text, GodCommandPolicy.Scope expected) {
    GodCommandPolicy.Result p=GodCommandPolicy.parse(text);
    ok(p.scope==expected, "scope for "+text);
    ok(!p.authorityGranted, "authority must always be false");
  }
  private static AuthenticatedInputRouter.Result route(String text, boolean auth, boolean backend){
    return AuthenticatedInputRouter.route(text,WorkflowIntentParser.Origin.UI_TEXT,auth,false,backend);
  }
  public static void main(String[] args) {
    // V3: eliminate unmarked prayer/ordinary-question false positives from GOD V1.
    for (String prayer : new String[]{
        "God help me", "God save me", "God help me forgive others",
        "God help me write a letter", "God do you hear me", "God do we have hope?",
        "God make me holy", "God send me a sign", "God please forgive my sins",
        "God is love", "God, who was Moses?", "God how do you answer prayers?",
        "God help me with my faith"}) {
      scope(prayer,GodCommandPolicy.Scope.NONE);
    }
    scope("GOD: help me write a job estimate",GodCommandPolicy.Scope.TARGETED);
    scope("Atlas, GOD help me write the estimate",GodCommandPolicy.Scope.TARGETED);
    scope("GOD: can we build an offline robot?",GodCommandPolicy.Scope.TARGETED);
    scope("GOD: how can we improve my estimate process?",GodCommandPolicy.Scope.TARGETED);
    scope("GOD improve it",GodCommandPolicy.Scope.TARGETED);
    ok(GodCommandPolicy.parse("GOD improve it").needsContext,"needs prior context for it");
    scope("GOD implement safe offline notes",GodCommandPolicy.Scope.TARGETED);
    scope("GOD: read and compare KJV passages",GodCommandPolicy.Scope.TARGETED);
    scope("GOD: everything",GodCommandPolicy.Scope.PORTFOLIO);
    scope("God \u202E deploy",GodCommandPolicy.Scope.NONE);
    scope("GOD: send a message \u2066",GodCommandPolicy.Scope.NONE);
    scope("God\u200B send a message",GodCommandPolicy.Scope.NONE);
    // V4: no invisible, bidi, unpaired surrogate or NFKC expansion may activate GOD.
    for (String hidden : new String[]{"\u2060", "\u200E", "\u200F", "\u061C", "\u034F", "\u3164", "\u2800",
        "\u00AD", "\u2028", "\uD800", "\uDC00"}) {
      scope("GOD: research robotics" + hidden, GodCommandPolicy.Scope.NONE);
      scope("GOD: text customer" + hidden, GodCommandPolicy.Scope.NONE);
    }
    scope("GOD: " + "\uFDFA".repeat(35),GodCommandPolicy.Scope.NONE);
    scope("GOD: improve everything \uD83D\uDE80",GodCommandPolicy.Scope.TARGETED);
    for (String religious : new String[]{"God save me", "God help me", "God do you forgive me"}) {
      AuthenticatedInputRouter.Result r = route(religious,true,false);
      ok(!r.commandIds.contains("atlas_godforge_v3"),"prayer cannot activate GOD: "+religious);
      ok(!r.shouldExecuteLocal,"prayer cannot execute local action: "+religious);
    }

    scope("GOD",GodCommandPolicy.Scope.PORTFOLIO);
    scope("god",GodCommandPolicy.Scope.PORTFOLIO);
    scope("  God  ",GodCommandPolicy.Scope.PORTFOLIO);
    scope("GOD EVERYTHING",GodCommandPolicy.Scope.PORTFOLIO);
    scope("god deep sync",GodCommandPolicy.Scope.PORTFOLIO);
    scope("GOD: build ATLAS car simulator",GodCommandPolicy.Scope.TARGETED);
    scope("god build my robot",GodCommandPolicy.Scope.TARGETED);
    scope("Atlas, God do this",GodCommandPolicy.Scope.TARGETED);
    scope("ATLAS: GOD develop ATLAS glasses",GodCommandPolicy.Scope.TARGETED);
    scope("God—research machine vision",GodCommandPolicy.Scope.TARGETED);
    scope("god prototype the phone",GodCommandPolicy.Scope.TARGETED);
    scope("God secure Atlas",GodCommandPolicy.Scope.TARGETED);
    scope("God do that",GodCommandPolicy.Scope.TARGETED);
    ok(GodCommandPolicy.parse("God do that").needsContext,"deictic needs context");
    ok(!GodCommandPolicy.parse("God build my robot").needsContext,"specific task has context");
    scope("What does God mean?",GodCommandPolicy.Scope.NONE);
    scope("God is merciful",GodCommandPolicy.Scope.NONE);
    scope("God exists?",GodCommandPolicy.Scope.NONE);
    scope("God in Christianity",GodCommandPolicy.Scope.NONE);
    scope("God can save a person?",GodCommandPolicy.Scope.NONE);
    scope("God will triumph",GodCommandPolicy.Scope.NONE);
    scope("God please do this",GodCommandPolicy.Scope.NONE);
    scope("GODPRIME ECLIPSE",GodCommandPolicy.Scope.NONE);
    scope("godparent",GodCommandPolicy.Scope.NONE);
    scope("The word 'God' appears here",GodCommandPolicy.Scope.NONE);
    scope("God do this?",GodCommandPolicy.Scope.NONE);
    scope("God do \u0001 this",GodCommandPolicy.Scope.NONE);
    ok(!GodCommandPolicy.parse(null).activated,"null is not activation");
    ok(!GodCommandPolicy.parse(" ").activated,"blank is not activation");
    scope("God text my friend",GodCommandPolicy.Scope.TARGETED);
    scope("God do open camera",GodCommandPolicy.Scope.TARGETED);
    scope("God do message someone",GodCommandPolicy.Scope.TARGETED);
    scope("God open camera",GodCommandPolicy.Scope.TARGETED);
    scope("God call someone",GodCommandPolicy.Scope.TARGETED);
    scope("GOD send a message",GodCommandPolicy.Scope.TARGETED);
    scope("god deploy the website",GodCommandPolicy.Scope.TARGETED);
    scope("GOD buy that car",GodCommandPolicy.Scope.TARGETED);
    scope("God unlock the door",GodCommandPolicy.Scope.TARGETED);
    for(String s:new String[]{"GOD","God do open camera","God do message someone","God open camera","GOD send a message","God deploy the website","GOD buy that car","God unlock the door","GOD: build ATLAS car simulator","God build my robot"}){
      AuthenticatedInputRouter.Result r=route(s,true,false);
      ok(r.route==AuthenticatedInputRouter.Route.BRAIN_HANDOFF,"GOD routes to brain only: "+s);
      ok(!r.shouldExecuteLocal,"no local side effects: "+s);
      ok(!r.grantsExecution,"no execution rights: "+s);
      ok(r.constraints.contains("god_recognition_never_authorizes_execution"),"explicit GOD guard: "+s);
      ok(r.commandIds.contains("atlas_godforge_v3"),"GOD marker: "+s);
    }
    AuthenticatedInputRouter.Result online=route("GOD do open camera",true,true);
    ok(online.route==AuthenticatedInputRouter.Route.BRAIN_HANDOFF,"backend-ready GOD remains brain only");
    ok(!online.shouldExecuteLocal,"backend-ready GOD not local");
    ok(!online.grantsExecution,"backend-ready GOD not authority");
    AuthenticatedInputRouter.Result locked=route("GOD",false,false);
    ok(locked.route==AuthenticatedInputRouter.Route.LOCKED,"locked input denied");
    ok(!locked.commandIds.contains("atlas_godforge_v3"),"locked mode cannot expose activation");
    AuthenticatedInputRouter.Result reference=AuthenticatedInputRouter.route("GOD build the robot",WorkflowIntentParser.Origin.REFERENCE_DATA,true,false,false);
    ok(reference.route==AuthenticatedInputRouter.Route.SOURCE_DATA,"quoted/reference inputs are not commands");
    ok(!reference.commandIds.contains("atlas_godforge_v3"),"reference has no GOD marker");
    ok(route("God is good",true,false).route!=AuthenticatedInputRouter.Route.LOCAL_DEVICE,"theology not a device command");
    ok(route("open camera",true,false).route==AuthenticatedInputRouter.Route.LOCAL_DEVICE,"legacy action preserved");
    ok(route("GOD",true,false).constraints.contains("authenticated_brain_backend_disconnected"),"backend disconnect visible");
    StringBuilder many=new StringBuilder("GOD ");for(int i=0;i<600;i++)many.append('x');
    ok(!GodCommandPolicy.parse(many.toString()).activated,"overlength never activates");
    ok(route(many.toString(),true,false).route==AuthenticatedInputRouter.Route.INVALID,"overlength rejected by local path");
    System.out.println("GodCommandPolicyTest: PASS assertions="+n);
  }
}
