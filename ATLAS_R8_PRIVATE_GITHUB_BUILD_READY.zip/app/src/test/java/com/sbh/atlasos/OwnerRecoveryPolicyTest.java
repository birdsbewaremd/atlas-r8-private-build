package com.sbh.atlasos;

import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Arrays;

/** Synthetic-only policy tests; not Android dialog/device acceptance. */
public final class OwnerRecoveryPolicyTest {
  private static int total=0;
  private static void check(boolean ok,String name){total++;if(!ok)throw new AssertionError(name);}
  public static void main(String[] args)throws Exception{
    check(OwnerRecoveryPolicy.pinPairMatches("123456","123456"),"equal ASCII PINs");
    check(!OwnerRecoveryPolicy.pinPairMatches("123456","123457"),"mismatch");
    check(!OwnerRecoveryPolicy.pinPairMatches(null,"123456"),"null first");
    check(!OwnerRecoveryPolicy.pinPairMatches("123456",null),"null confirmation");
    check(!OwnerRecoveryPolicy.pinPairMatches("12345","12345"),"short");
    check(!OwnerRecoveryPolicy.pinPairMatches("１２３４５６","１２３４５６"),"Unicode digits rejected");
    check(!OwnerRecoveryPolicy.pinPairMatches("1234567","1234567"),"long");
    check(OwnerRecoveryPolicy.flowValid(0,0),"flow at monotonic origin");
    check(OwnerRecoveryPolicy.flowValid(100,300099),"just before expiry");
    check(!OwnerRecoveryPolicy.flowValid(100,300100),"exact expiry denied");
    check(!OwnerRecoveryPolicy.flowValid(100,99),"clock reversal denied");
    check(!OwnerRecoveryPolicy.flowValid(-1,0),"negative start denied");
    check(!OwnerRecoveryPolicy.flowValid(0,Long.MAX_VALUE),"far expired denied");
    SecureRandom sequence=new SecureRandom(){@Override public void nextBytes(byte[] b){for(int i=0;i<b.length;i++)b[i]=(byte)i;}};
    String code=OwnerRecoveryPolicy.newCode(sequence);
    check(code.equals("0001-0203-0405-0607-0809-0A0B-0C0D-0E0F-1011-1213-1415-1617-1819-1A1B-1C1D-1E1F"),"full 32 bytes encoded");
    check(code.length()==79,"display length");
    check(OwnerRecoveryPolicy.normalize(code).length()==64,"256-bit hex size");
    check(OwnerRecoveryPolicy.normalize(code.toLowerCase()).equals(OwnerRecoveryPolicy.normalize(code)),"case normalization");
    check(OwnerRecoveryPolicy.normalize(code.replace('-',' ')).equals(OwnerRecoveryPolicy.normalize(code)),"space grouping");
    check(OwnerRecoveryPolicy.normalize(null)==null,"null code");
    check(OwnerRecoveryPolicy.normalize("")==null,"empty code");
    check(OwnerRecoveryPolicy.normalize(code.substring(1))==null,"short code");
    check(OwnerRecoveryPolicy.normalize(code+"0")==null,"long code");
    check(OwnerRecoveryPolicy.normalize("Z"+code.substring(1))==null,"invalid alphabet");
    check(OwnerRecoveryPolicy.normalize("０"+code.substring(1))==null,"Unicode code denied");
    check(OwnerRecoveryPolicy.normalize(code+"\n")==null,"newline denied");
    check(OwnerRecoveryPolicy.normalize(" ".repeat(129))==null,"bounded normalization");
    byte[] salt=new byte[OwnerPinPolicy.SALT_BYTES],otherSalt=salt.clone();otherSalt[0]=1;
    byte[] digest=OwnerRecoveryPolicy.digest(code,salt);
    check(digest.length==32,"stored hash size");
    check(OwnerRecoveryPolicy.matches(code,salt,digest),"authentic code accepted");
    check(OwnerRecoveryPolicy.matches(code.replace("-","").toLowerCase(),salt,digest),"normalized verification");
    check(!OwnerRecoveryPolicy.matches("F"+code.substring(1),salt,digest),"wrong code denied");
    check(!OwnerRecoveryPolicy.matches(code,otherSalt,digest),"salt separates verifiers");
    check(!OwnerRecoveryPolicy.matches(code,salt,new byte[31]),"bad digest length");
    check(!OwnerRecoveryPolicy.matches(code,salt,null),"missing verifier");
    check(!OwnerRecoveryPolicy.matches(code,null,digest),"missing salt");
    check(!OwnerRecoveryPolicy.matches(code,new byte[1],digest),"wrong salt size");
    check(!OwnerRecoveryPolicy.matches(null,salt,digest),"missing supplied code");
    check(!Arrays.equals(digest,OwnerRecoveryPolicy.digest(code,otherSalt)),"digest salt changes output");
    boolean threw=false;try{OwnerRecoveryPolicy.newCode(null);}catch(IllegalArgumentException e){threw=true;}check(threw,"random provider required");
    threw=false;try{OwnerRecoveryPolicy.digest("bad",salt);}catch(GeneralSecurityException e){threw=true;}check(threw,"malformed digest input rejected");
    System.out.println("OwnerRecoveryPolicy "+total+"/"+total+" PASS");
  }
}
