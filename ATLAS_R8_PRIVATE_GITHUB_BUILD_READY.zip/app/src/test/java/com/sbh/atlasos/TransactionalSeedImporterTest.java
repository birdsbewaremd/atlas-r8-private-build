package com.sbh.atlasos;
import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.*;

/** Host filesystem tests, with synthetic byte-writer; not Android/Keystore tests. */
public final class TransactionalSeedImporterTest {
  static int passed,total;
  static Path root,vault;static byte[] original="SYNTHETIC ORIGINAL -- MUST SURVIVE".getBytes();
  static void check(String name,boolean condition){total++;if(condition)passed++;else throw new AssertionError(name);System.out.println("PASS "+name);}
  static byte[] zip(String... items)throws Exception{
    ByteArrayOutputStream out=new ByteArrayOutputStream();
    try(ZipOutputStream z=new ZipOutputStream(out)){
      for(int i=0;i<items.length;i+=2){z.putNextEntry(new ZipEntry(items[i]));z.write(items[i+1].getBytes("UTF-8"));z.closeEntry();}
    }return out.toByteArray();
  }
  static final TransactionalSeedImporter.EncryptedWriter SYNTHETIC=(in,file,limit)->{
    long n=0;try(OutputStream out=Files.newOutputStream(file.toPath(),StandardOpenOption.CREATE_NEW)){
      int b;while((b=in.read())!=-1){if(++n>limit)throw new IOException("synthetic byte limit");out.write(b);}
    }return n;
  };
  static Map<String,String> snapshot(Path path)throws Exception{
    Map<String,String> m=new TreeMap<>();try(java.util.stream.Stream<Path> stream=Files.walk(path)){
      for(Iterator<Path> it=stream.iterator();it.hasNext();){Path p=it.next();if(Files.isRegularFile(p))m.put(path.relativize(p).toString(),Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(p))));}
    }return m;
  }
  interface Attempt{void run()throws Exception;}
  static void rejected(String name,Attempt fn)throws Exception{
    Map<String,String> before=snapshot(vault);boolean denied=false;
    try{fn.run();}catch(Exception expected){denied=true;}
    check(name+" rejected",denied);check(name+" preserves all committed bytes",before.equals(snapshot(vault)));
    try(java.util.stream.Stream<Path> stream=Files.list(root)){check(name+" cleans its staging",stream.noneMatch(p->p.getFileName().toString().startsWith(".atlas-import-")));}
  }
  static TransactionalSeedImporter.Result run(byte[] b,TransactionalSeedImporter.EncryptedWriter w,TransactionalSeedImporter.Authorization auth,int count,long one,long total)throws Exception{
    return TransactionalSeedImporter.importWithLimits(new ByteArrayInputStream(b),root.toFile(),vault.toFile(),w,auth,count,one,total);
  }
  public static void main(String[] args)throws Exception{
    root=Files.createTempDirectory("atlas-import-regression-");vault=Files.createDirectory(root.resolve("vault"));Files.write(vault.resolve("note.txt.atlasenc"),original);
    try{
      TransactionalSeedImporter.Result r=run(zip("note.txt","new content","nested/second.txt","second"),SYNTHETIC,()->true,10,100,200);
      check("valid archive commits both files",r.files==2&&r.bytes==17);
      check("existing same-name file remains byte-identical",Arrays.equals(original,Files.readAllBytes(vault.resolve("note.txt.atlasenc"))));
      check("new snapshot contains nested content",new String(Files.readAllBytes(vault.resolve(r.directory).resolve("nested/second.txt.atlasenc"))).equals("second"));
      Map<String,String> before=snapshot(vault);
      TransactionalSeedImporter.Result again=run(zip("note.txt","different"),SYNTHETIC,()->true,10,100,200);
      check("reimport creates different snapshot",!again.directory.equals(r.directory));
      check("reimport preserves earlier snapshot",snapshot(vault).entrySet().containsAll(before.entrySet()));
      AtomicInteger calls=new AtomicInteger();
      rejected("second-entry storage failure",()->run(zip("a","first","note.txt","second"),(in,f,l)->{
        if(calls.incrementAndGet()==2){Files.write(f.toPath(),new byte[]{1});throw new IOException("synthetic disk full");}return SYNTHETIC.write(in,f,l);
      },()->true,10,100,200));
      rejected("per-file overflow",()->run(zip("note.txt","this is too long"),SYNTHETIC,()->true,10,3,100));
      rejected("batch overflow",()->run(zip("a","12345","b","12345"),SYNTHETIC,()->true,10,10,8));
      rejected("file-count overflow",()->run(zip("a","1","b","2"),SYNTHETIC,()->true,1,10,20));
      rejected("path traversal after valid entry",()->run(zip("first","safe","../note.txt","bad"),SYNTHETIC,()->true,10,100,200));
      rejected("absolute path",()->run(zip("/note.txt","bad"),SYNTHETIC,()->true,10,100,200));
      rejected("Windows absolute path",()->run(zip("C:\\note.txt","bad"),SYNTHETIC,()->true,10,100,200));
      rejected("duplicate normalized paths",()->run(zip("nested/a","first","nested\\a","second"),SYNTHETIC,()->true,10,100,200));
      rejected("empty ZIP",()->run(zip(),SYNTHETIC,()->true,10,100,200));
      rejected("non-ZIP bytes",()->run("not a ZIP".getBytes(),SYNTHETIC,()->true,10,100,200));
      rejected("directory flood",()->{String[] pairs=new String[246];for(int i=0;i<123;i++){pairs[2*i]="d"+i+"/";pairs[2*i+1]="";}run(zip(pairs),SYNTHETIC,()->true,10,100,200);});
      AtomicInteger approvals=new AtomicInteger();
      rejected("authorization lost before commit",()->run(zip("a","safe"),SYNTHETIC,()->approvals.incrementAndGet()<=2,10,100,200));
      rejected("authorization initially absent",()->run(zip("a","safe"),SYNTHETIC,()->false,10,100,200));
      rejected("writer skipped entry bytes",()->run(zip("a","safe"),(in,f,l)->{Files.write(f.toPath(),new byte[]{1});return 1;},()->true,10,100,200));
      rejected("writer overreports byte limit",()->run(zip("a","safe"),(in,f,l)->{SYNTHETIC.write(in,f,l);return l+1;},()->true,10,100,200));
      byte[] compressed=zip("a","valid","b","truncated entry data data data");byte[] truncated=Arrays.copyOf(compressed,60);
      rejected("truncated compressed data",()->run(truncated,SYNTHETIC,()->true,10,100,200));
      Path link=root.resolve("linkedVault");Files.createSymbolicLink(link,vault);
      rejected("symlink vault",()->TransactionalSeedImporter.importNew(new ByteArrayInputStream(zip("a","bad")),root.toFile(),link.toFile(),SYNTHETIC,()->true));
      Files.delete(link);
      TransactionalSeedImporter.Result directories=run(zip("nested/","","nested/a","safe"),SYNTHETIC,()->true,10,100,200);
      check("normal directory entries remain supported",directories.files==1);
      rejected("directory entry carrying payload",()->run(zip("dir/","unexpected data","a","safe"),SYNTHETIC,()->true,10,100,200));
      byte[] noEnd=zip("a","safe");
      rejected("missing ZIP end record",()->run(Arrays.copyOf(noEnd,noEnd.length-22),SYNTHETIC,()->true,10,100,200));
      check("original survives every scenario",Arrays.equals(original,Files.readAllBytes(vault.resolve("note.txt.atlasenc"))));
      System.out.println("TRANSACTIONAL_IMPORT="+passed+"/"+total+" PASS");
    }finally{
      try(java.util.stream.Stream<Path> stream=Files.walk(root)){
        for(Iterator<Path> it=stream.sorted(Comparator.reverseOrder()).iterator();it.hasNext();)Files.delete(it.next());
      }
    }
  }
}
