package com.sbh.atlasos;

public final class ProviderRoutePolicyTest {
  private static int n=0;
  private static void eq(Object got,Object exp,String m){n++; if(!exp.equals(got)) throw new AssertionError(m+" got="+got+" exp="+exp);}
  private static ProviderRoutePolicy.RouteProfile route(boolean external, ProviderRoutePolicy.RouteStatus s,
      ProviderRoutePolicy.TrainingUse t, boolean retention, boolean state, boolean current) {
    return new ProviderRoutePolicy.RouteProfile("r1", external?"api":"local", external, s, t, retention, state, current);
  }
  public static void main(String[] args){
    eq(ProviderRoutePolicy.decide(ProviderRoutePolicy.DataClass.SECRET,
        route(false,ProviderRoutePolicy.RouteStatus.APPROVED,ProviderRoutePolicy.TrainingUse.LOCAL_ONLY,true,true,true)),
        ProviderRoutePolicy.Decision.BLOCK,"secrets never model-routed");
    eq(ProviderRoutePolicy.decide(ProviderRoutePolicy.DataClass.CUSTOMER_PRIVATE,
        route(true,ProviderRoutePolicy.RouteStatus.APPROVED,ProviderRoutePolicy.TrainingUse.UNKNOWN,true,true,true)),
        ProviderRoutePolicy.Decision.BLOCK,"private + unknown training");
    eq(ProviderRoutePolicy.decide(ProviderRoutePolicy.DataClass.CUSTOMER_PRIVATE,
        route(true,ProviderRoutePolicy.RouteStatus.APPROVED,ProviderRoutePolicy.TrainingUse.NO_BY_DEFAULT,false,true,true)),
        ProviderRoutePolicy.Decision.BLOCK,"private + unknown retention");
    eq(ProviderRoutePolicy.decide(ProviderRoutePolicy.DataClass.PERSONAL_PRIVATE,
        route(true,ProviderRoutePolicy.RouteStatus.APPROVED,ProviderRoutePolicy.TrainingUse.OPTED_OUT,true,true,false)),
        ProviderRoutePolicy.Decision.BLOCK,"stale policy");
    eq(ProviderRoutePolicy.decide(ProviderRoutePolicy.DataClass.CUSTOMER_PRIVATE,
        route(true,ProviderRoutePolicy.RouteStatus.APPROVED,ProviderRoutePolicy.TrainingUse.OPTED_OUT,true,true,true)),
        ProviderRoutePolicy.Decision.ALLOW,"known approved private route");
    eq(ProviderRoutePolicy.decide(ProviderRoutePolicy.DataClass.BUSINESS_INTERNAL,
        route(true,ProviderRoutePolicy.RouteStatus.APPROVED,ProviderRoutePolicy.TrainingUse.OPTED_IN,true,true,true)),
        ProviderRoutePolicy.Decision.MINIMIZE_ONLY,"opted-in business route minimizes");
    eq(ProviderRoutePolicy.decide(ProviderRoutePolicy.DataClass.PUBLIC,
        route(true,ProviderRoutePolicy.RouteStatus.APPROVED_MINIMIZED_ONLY,ProviderRoutePolicy.TrainingUse.UNKNOWN,false,false,true)),
        ProviderRoutePolicy.Decision.MINIMIZE_ONLY,"route restriction survives public data");
    eq(ProviderRoutePolicy.decide(ProviderRoutePolicy.DataClass.HEALTH_LEGAL_FINANCIAL,
        route(false,ProviderRoutePolicy.RouteStatus.APPROVED,ProviderRoutePolicy.TrainingUse.LOCAL_ONLY,true,true,true)),
        ProviderRoutePolicy.Decision.ALLOW,"approved local route may handle sensitive non-secret data");
    System.out.println("ProviderRoutePolicyTest PASS "+n);
  }
}
