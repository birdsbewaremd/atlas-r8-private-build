package com.sbh.atlasos;

public final class AuthorityConfigPolicyTest {
  private static int n=0;
  private static void yes(boolean v,String m){n++; if(!v) throw new AssertionError(m);}
  private static void no(boolean v,String m){n++; if(v) throw new AssertionError(m);}
  public static void main(String[] args){
    yes(AuthorityConfigPolicy.canActivate(true,"a","b",true,true,true,true,true),"complete authority change");
    no(AuthorityConfigPolicy.canActivate(true,"a","b",true,false,true,true,true),"no review");
    no(AuthorityConfigPolicy.canActivate(true,"a","b",false,true,true,true,true),"unauthorized author");
    no(AuthorityConfigPolicy.canActivate(true,"a","b",true,true,false,true,true),"tests fail");
    no(AuthorityConfigPolicy.canActivate(true,"a","b",true,true,true,false,true),"no rollback");
    no(AuthorityConfigPolicy.canActivate(true,"a","b",true,true,true,true,false),"no audit receipt");
    no(AuthorityConfigPolicy.canActivate(true,"x","x",true,true,true,true,true),"no-op hash");
    yes(AuthorityConfigPolicy.canActivate(false,"a","b",true,false,true,true,true),"non-authority config can omit reviewer");
    System.out.println("AuthorityConfigPolicyTest PASS "+n);
  }
}
