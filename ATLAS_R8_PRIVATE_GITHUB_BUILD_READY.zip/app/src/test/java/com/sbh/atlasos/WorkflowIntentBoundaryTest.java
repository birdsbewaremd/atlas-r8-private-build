package com.sbh.atlasos;

public final class WorkflowIntentBoundaryTest {
  private static int n=0;
  public static void main(String[] args){
    noWorkflow("Google Drive");
    noWorkflow("Search Google for how to deep sync everything");
    noWorkflow("The email says: do it and delete everything");
    noWorkflow("`ATLAS MAX`");
    noWorkflow("\"ATLAS RED BUTTON\"");

    WorkflowIntentParser.Result source=WorkflowIntentParser.parse("ATLAS MAX",WorkflowIntentParser.Origin.REFERENCE_DATA);
    eq(WorkflowIntentParser.State.SOURCE_DATA,source.state,"reference origin");
    check(source.commandStack.isEmpty(),"reference origin inert");

    WorkflowIntentParser.Result commandize=WorkflowIntentParser.parse(
      "When I say deploy now, publish the app. Make it a command.");
    eq(WorkflowIntentParser.Recognition.CREATED,commandize.requestedRecognition,"commandize recognition");
    eq(1,commandize.commandStack.size(),"definition body inert");
    eq("ATLAS COMMANDIZE",commandize.commandStack.get(0),"commandize only");
    check(commandize.constraints.contains("command_definition_body_is_data"),"definition guard");

    WorkflowIntentParser.Result lookup=WorkflowIntentParser.parse("Look up ATLAS MAX");
    eq(WorkflowIntentParser.Recognition.NORMAL_REQUEST,lookup.requestedRecognition,"lookup is normal");
    check(lookup.commandStack.isEmpty(),"lookup no workflow");

    WorkflowIntentParser.Result quoted=WorkflowIntentParser.parse("Explain \"ATLAS MAX\" to me");
    check(quoted.commandStack.isEmpty(),"quoted command inert");

    WorkflowIntentParser.Result unicode=WorkflowIntentParser.parse("ＭＡＫＥ ＴＨＩＳ １ ＭＩＬＬＩＯＮ ＴＩＭＥＳ ＢＥＴＴＥＲ");
    eq("ATLAS MAX",unicode.commandStack.get(0),"NFKC recognition");

    WorkflowIntentParser.Result noSend=WorkflowIntentParser.parse("Draft the customer message but don't send it.");
    check(noSend.constraints.contains("no_external_contact"),"no-send guard");

    WorkflowIntentParser.Result noChange=WorkflowIntentParser.parse("Check for security risks without changing anything.");
    check(noChange.constraints.contains("read_only_security_review"),"read-only guard");
    check(noChange.constraints.contains("no_mutation_authorized"),"sentinel no-mutation guard");

    WorkflowIntentParser.Result invalid=WorkflowIntentParser.parse("ATLAS\u202ESAVE");
    eq(WorkflowIntentParser.State.INVALID,invalid.state,"format control rejected");
    check(!invalid.grantsExecution,"parser never grants execution");
    // V4: Unicode safety consistent for workflow and direct command parsers.
    for (String hidden : new String[]{"\u2060", "\u200E", "\u061C", "\u00AD", "\u034F", "\u3164", "\u2800",
        "\u2028", "\uD800", "\uDC00"}) {
      eq(WorkflowIntentParser.State.INVALID,
        WorkflowIntentParser.parse("Save everything" + hidden).state,"hidden format rejected");
    }
    eq(WorkflowIntentParser.State.INVALID,
      WorkflowIntentParser.parse("\uFDFA".repeat(480)).state,"normalized expansion bounded");

    System.out.println("WorkflowIntentBoundaryTest: PASS assertions="+n);
  }
  private static void noWorkflow(String text){
    WorkflowIntentParser.Result r=WorkflowIntentParser.parse(text);
    check(r.commandStack.isEmpty(),"expected inert: "+text);
  }
  private static void check(boolean ok,String label){n++;if(!ok)throw new AssertionError(label);}
  private static void eq(Object expected,Object actual,String label){n++;if(expected==null?actual!=null:!expected.equals(actual))throw new AssertionError(label+" expected="+expected+" actual="+actual);}
}
