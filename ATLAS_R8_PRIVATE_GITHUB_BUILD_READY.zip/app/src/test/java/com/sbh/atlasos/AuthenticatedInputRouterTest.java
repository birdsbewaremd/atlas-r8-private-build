package com.sbh.atlasos;

public final class AuthenticatedInputRouterTest {
  private static int n = 0;

  public static void main(String[] args) {
    AuthenticatedInputRouter.Result locked = route("open camera", false, false, true);
    eq(AuthenticatedInputRouter.Route.LOCKED, locked.route, "locked route");
    check(!locked.shouldExecuteLocal, "locked cannot execute local");
    check(locked.constraints.contains("owner_unlock_required"), "locked guard");

    AuthenticatedInputRouter.Result local = route("open camera", true, false, true);
    eq(AuthenticatedInputRouter.Route.LOCAL_DEVICE, local.route, "local route");
    eq(CommandParser.Kind.CAMERA, local.local.kind, "local kind");
    check(local.shouldExecuteLocal, "local eligible after native recheck");
    check(!local.grantsExecution, "local classification is not execution");

    AuthenticatedInputRouter.Result workflow = route("Build the app, test it, and don't break anything already working.", true, false, false);
    eq(AuthenticatedInputRouter.Route.WORKFLOW_HANDOFF, workflow.route, "workflow route");
    check(!workflow.shouldExecuteLocal, "workflow cannot hit device action router");
    check(workflow.requiresBackend, "workflow requires backend");
    check(workflow.constraints.contains("authenticated_brain_backend_disconnected"), "backend disconnect surfaced");

    AuthenticatedInputRouter.Result normal = route("Explain compound interest.", true, false, false);
    eq(AuthenticatedInputRouter.Route.BRAIN_HANDOFF, normal.route, "normal request route");
    eq(WorkflowIntentParser.Recognition.NORMAL_REQUEST, normal.recognition, "normal recognition");

    AuthenticatedInputRouter.Result source = AuthenticatedInputRouter.route(
      "ATLAS MAX", WorkflowIntentParser.Origin.REFERENCE_DATA, true, false, true);
    eq(AuthenticatedInputRouter.Route.SOURCE_DATA, source.route, "source data route");
    check(source.commandStack.isEmpty(), "source data not interpreted as command");

    String original = "  Make this 1 million times better.  ";
    AuthenticatedInputRouter.Result preserved = AuthenticatedInputRouter.route(
      original, WorkflowIntentParser.Origin.VOICE_TRANSCRIPT, true, false, true);
    eq(original, preserved.original, "original input preserved");
    eq(WorkflowIntentParser.Origin.VOICE_TRANSCRIPT, preserved.origin, "trusted origin preserved");

    AuthenticatedInputRouter.Result commandize = route("Make this a command.", true, false, true);
    eq(WorkflowIntentParser.Recognition.PARTIAL_MATCH, commandize.recognition, "unpersisted creation downgraded");
    check(commandize.constraints.contains("command_creation_not_persisted"), "creation guard");
    AuthenticatedInputRouter.Result saved = route("Make this a command.", true, true, true);
    eq(WorkflowIntentParser.Recognition.CREATED, saved.recognition, "persisted creation confirmed");

    AuthenticatedInputRouter.Result invalid = route("\u0000", true, false, true);
    eq(AuthenticatedInputRouter.Route.INVALID, invalid.route, "unsafe input rejected");

    StringBuilder longText = new StringBuilder();
    for (int i = 0; i < WorkflowIntentParser.MAX_CHARS + 1; i++) longText.append('a');
    AuthenticatedInputRouter.Result tooLong = route(longText.toString(), true, false, true);
    eq(AuthenticatedInputRouter.Route.INVALID, tooLong.route, "long input rejected");

    AuthenticatedInputRouter.Result confirm = route("call 4105089274", true, false, true);
    eq(AuthenticatedInputRouter.Route.LOCAL_DEVICE, confirm.route, "dial route");
    check(confirm.constraints.contains("user_confirmation_boundary_required"), "dial confirmation boundary");

    System.out.println("AuthenticatedInputRouterTest: PASS assertions=" + n);
  }

  private static AuthenticatedInputRouter.Result route(String text, boolean authenticated, boolean persisted, boolean backend) {
    return AuthenticatedInputRouter.route(text, WorkflowIntentParser.Origin.UI_TEXT,
      authenticated, persisted, backend);
  }

  private static void check(boolean ok, String label) {
    n++;
    if (!ok) throw new AssertionError(label);
  }
  private static void eq(Object expected, Object actual, String label) {
    n++;
    if (expected == null ? actual != null : !expected.equals(actual)) {
      throw new AssertionError(label + " expected=" + expected + " actual=" + actual);
    }
  }
}
