package com.sbh.atlasos;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.io.*;
import java.util.*;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

/** Host JCE + real temporary-file contract checks; not Android/device acceptance. */
public final class OwnerRecordStoreTest {
  private static int passed;
  private static void check(boolean yes,String label){if(!yes)throw new AssertionError(label);passed++;System.out.println("PASS "+label);}
  private static void status(OwnerRecordStore.Result result,String expected,String label){check(expected.equals(result.status),label+" ("+result.status+")");}
  private static final class Keys implements OwnerRecordStore.KeySource {
    SecretKey key;boolean unavailable;int creates;
    public SecretKey get(boolean create)throws Exception{
      if(unavailable)throw new IOException("key unavailable");
      if(key==null){if(!create)throw new IOException("no key");KeyGenerator generator=KeyGenerator.getInstance("AES");generator.init(256);key=generator.generateKey();creates++;}
      return key;
    }
  }
  private static final class Session {
    boolean active=true;long generation=1;
    OwnerRecordStore.Access capture(){final long original=generation;return ()->active&&original==generation;}
  }
  private static final class FilesBackend implements OwnerRecordStore.BlobStore {
    final Path dir;boolean failBeforeCommit;Runnable beforeCommit;
    FilesBackend(Path dir){this.dir=dir;}
    Path file(String key){return dir.resolve(key+".enc");}
    public byte[] read(String key)throws Exception{return Files.exists(file(key))?Files.readAllBytes(file(key)):null;}
    public void write(String key,byte[] bytes,OwnerRecordStore.Access access)throws Exception{
      Path staged=dir.resolve(key+".stage");
      try(FileOutputStream stream=new FileOutputStream(staged.toFile())){stream.write(bytes);stream.getFD().sync();}
      try{
        if(beforeCommit!=null){Runnable callback=beforeCommit;beforeCommit=null;callback.run();}
        OwnerRecordStore.require(access);
        if(failBeforeCommit)throw new IOException("injected disk failure");
        Files.move(staged,file(key),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
      }finally{Files.deleteIfExists(staged);}
    }
  }
  public static void main(String[] ignored)throws Exception{
    Path dir=Files.createTempDirectory("atlas-records-host-");
    try{
      Keys keys=new Keys();FilesBackend files=new FilesBackend(dir);Session session=new Session();
      OwnerRecordStore records=new OwnerRecordStore(files,keys);
      OwnerRecordStore.Result empty=records.read("notes",session.capture());
      check("ok".equals(empty.status)&&empty.value==null&&empty.revision==0&&keys.creates==0,"missing record is empty without creating a key");
      String first="{\"text\":\"PRIVATE_NOTE_MARKER hello 🌎\"}";
      OwnerRecordStore.Result saved=records.write("notes",first,0,session.capture());
      check("ok".equals(saved.status)&&saved.revision==1,"first save commits revision one");
      byte[] firstBlob=Files.readAllBytes(files.file("notes"));
      check(!new String(firstBlob,StandardCharsets.ISO_8859_1).contains("PRIVATE_NOTE_MARKER"),"plaintext is absent from stored blob");
      records=new OwnerRecordStore(new FilesBackend(dir),keys);
      OwnerRecordStore.Result reopened=records.read("notes",session.capture());
      check("ok".equals(reopened.status)&&first.equals(reopened.value)&&reopened.revision==1,"reopened store restores Unicode text and revision");
      status(records.write("notes","stale",0,session.capture()),"conflict","stale revision refuses overwrite");
      check(Arrays.equals(firstBlob,Files.readAllBytes(files.file("notes"))),"stale write preserves original ciphertext");
      OwnerRecordStore.Result second=records.write("notes","{\"text\":\"second\"}",1,session.capture());
      check("ok".equals(second.status)&&second.revision==2,"valid revision advances atomically");
      byte[] current=Files.readAllBytes(files.file("notes"));
      Files.write(files.file("tasks"),current);
      status(records.read("tasks",session.capture()),"corrupt","ciphertext cannot be moved across record keys");
      status(records.write("tasks","[]",0,session.capture()),"corrupt","swapped record cannot be overwritten as missing");
      Files.delete(files.file("tasks"));
      byte[] tampered=current.clone();tampered[tampered.length-1]^=1;Files.write(files.file("notes"),tampered);
      status(records.read("notes",session.capture()),"corrupt","authentication detects changed ciphertext");
      status(records.write("notes","",2,session.capture()),"corrupt","tampered record refuses empty overwrite");
      check(Arrays.equals(tampered,Files.readAllBytes(files.file("notes"))),"corruption stays intact for recovery");
      Files.write(files.file("notes"),Arrays.copyOf(current,20));
      status(records.read("notes",session.capture()),"corrupt","truncated blob is not treated as absent");
      Files.write(files.file("notes"),current);keys.unavailable=true;int creates=keys.creates;
      status(records.read("notes",session.capture()),"unavailable","missing key stays unavailable");
      status(records.write("notes","",2,session.capture()),"unavailable","missing key cannot replace existing record");
      check(keys.creates==creates&&Arrays.equals(current,Files.readAllBytes(files.file("notes"))),"missing-key write neither creates key nor replaces bytes");keys.unavailable=false;
      records=new OwnerRecordStore(files,keys);files.failBeforeCommit=true;
      status(records.write("notes","disk fail",2,session.capture()),"unavailable","injected precommit disk failure is reported");
      check(Arrays.equals(current,Files.readAllBytes(files.file("notes"))),"failed commit retains last stored record");files.failBeforeCommit=false;
      session.active=false;
      status(records.read("notes",session.capture()),"locked","locked read returns no record");
      status(records.write("notes","locked",2,session.capture()),"locked","locked write refuses mutation");session.active=true;
      final int[] checks={0};
      status(records.read("notes",()->++checks[0]==1),"locked","session ending during read suppresses plaintext");
      OwnerRecordStore.Access original=session.capture();files.beforeCommit=()->session.generation++;
      status(records.write("notes","old session",2,original),"locked","old login cannot commit after relogin");
      check(Arrays.equals(current,Files.readAllBytes(files.file("notes"))),"session race preserves committed ciphertext");
      status(records.write("../outside","x",0,session.capture()),"invalid","path-like key is rejected");
      status(records.read("unknown",session.capture()),"invalid","unknown namespace is rejected");
      status(records.write("notes","x",-1,session.capture()),"invalid","negative revision is rejected");
      status(records.write("notes","x",OwnerRecordStore.MAX_REVISION,session.capture()),"invalid","revision cannot exceed safe range");
      status(records.write("notes","\ud800",2,session.capture()),"invalid","invalid UTF-16 is rejected without silent replacement");
      StringBuilder large=new StringBuilder();for(int i=0;i<90000;i++)large.append("🌎");
      status(records.write("notes",large.toString(),2,session.capture()),"invalid","limit counts UTF-8 bytes rather than Java characters");
      char[] exact=new char[OwnerRecordStore.MAX_BYTES];Arrays.fill(exact,'x');
      status(records.write("bookmarks",new String(exact),0,session.capture()),"ok","exact byte limit is accepted");
      check(records.read("bookmarks",session.capture()).value.length()==OwnerRecordStore.MAX_BYTES,"maximum bounded record survives reload");
      for(String good:new String[]{"https://example.com/","https://example.com:8443/a?q=b#c","https://[::1]/"})check(BookmarkedUrlPolicy.validated(good)!=null,"HTTPS URL accepted: "+good);
      for(String bad:new String[]{"http://example.com","javascript:alert(1)","https://user:password@example.com","https://example.com\n.evil"," https://example.com","https://","https://example.com:70000","intent://test","file:///tmp/a"})check(BookmarkedUrlPolicy.validated(bad)==null,"unsafe or malformed URL rejected");
      System.out.println("OWNER_RECORD_HOST="+passed+"/"+passed+" PASS (JCE + host atomic-file backend, not Android Keystore/device)");
    }finally{
      try(java.util.stream.Stream<Path> paths=Files.walk(dir)){paths.sorted(Comparator.reverseOrder()).forEach(path->{try{Files.delete(path);}catch(IOException cleanupError){}});}
    }
  }
}
