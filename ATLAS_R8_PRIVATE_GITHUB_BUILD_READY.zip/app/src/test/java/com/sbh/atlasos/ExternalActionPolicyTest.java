package com.sbh.atlasos;
public final class ExternalActionPolicyTest {
  private static int n=0;
  private static void eq(Object a,Object b,String m){n++;if(!a.equals(b))throw new AssertionError(m+" got="+a);}
  public static void main(String[] args){
    using(ExternalActionPolicy.Actor.MODEL, ExternalActionPolicy.Environment.PRODUCTION, ExternalActionPolicy.Effect.READ_PUBLIC,true,false,false, ExternalActionPolicy.Decision.ALLOW_READ_ONLY,"model read");
    using(ExternalActionPolicy.Actor.MODEL, ExternalActionPolicy.Environment.EVALUATION, ExternalActionPolicy.Effect.FORM_SUBMIT,true,true,true, ExternalActionPolicy.Decision.PREVIEW_ONLY,"eval never submits");
    using(ExternalActionPolicy.Actor.OWNER, ExternalActionPolicy.Environment.DEVELOPMENT, ExternalActionPolicy.Effect.MESSAGE_SEND,true,true,true, ExternalActionPolicy.Decision.PREVIEW_ONLY,"dev never sends");
    using(ExternalActionPolicy.Actor.MODEL, ExternalActionPolicy.Environment.PRODUCTION, ExternalActionPolicy.Effect.FORM_SUBMIT,true,true,true, ExternalActionPolicy.Decision.REQUIRE_OWNER_BROKER,"model cannot self-authorize form");
    using(ExternalActionPolicy.Actor.AUTOMATION, ExternalActionPolicy.Environment.PILOT, ExternalActionPolicy.Effect.PUBLISH,true,true,true, ExternalActionPolicy.Decision.REQUIRE_OWNER_BROKER,"automation publish broker");
    using(ExternalActionPolicy.Actor.MODEL, ExternalActionPolicy.Environment.PRODUCTION, ExternalActionPolicy.Effect.DEPLOY,true,true,true, ExternalActionPolicy.Decision.BLOCK,"model deploy blocked");
    using(ExternalActionPolicy.Actor.MODEL, ExternalActionPolicy.Environment.PRODUCTION, ExternalActionPolicy.Effect.ACCOUNT_SECURITY_CHANGE,true,true,true, ExternalActionPolicy.Decision.BLOCK,"model security change blocked");
    using(ExternalActionPolicy.Actor.MODEL, ExternalActionPolicy.Environment.PRODUCTION, ExternalActionPolicy.Effect.PHYSICAL_DEVICE_CONTROL,true,true,true, ExternalActionPolicy.Decision.BLOCK,"model physical high consequence blocked");
    using(ExternalActionPolicy.Actor.OWNER, ExternalActionPolicy.Environment.PRODUCTION, ExternalActionPolicy.Effect.MESSAGE_SEND,true,false,true, ExternalActionPolicy.Decision.REQUIRE_OWNER_BROKER,"fresh approval required");
    using(ExternalActionPolicy.Actor.OWNER, ExternalActionPolicy.Environment.PRODUCTION, ExternalActionPolicy.Effect.MESSAGE_SEND,true,true,false, ExternalActionPolicy.Decision.REQUIRE_OWNER_BROKER,"independent gate required");
    using(ExternalActionPolicy.Actor.OWNER, ExternalActionPolicy.Environment.PRODUCTION, ExternalActionPolicy.Effect.MESSAGE_SEND,true,true,true, ExternalActionPolicy.Decision.ALLOW_BROKERED,"brokered owner action");
    using(ExternalActionPolicy.Actor.OWNER, ExternalActionPolicy.Environment.PRODUCTION, ExternalActionPolicy.Effect.MESSAGE_SEND,false,true,true, ExternalActionPolicy.Decision.BLOCK,"target allowlist required");
    using(ExternalActionPolicy.Actor.UNKNOWN, ExternalActionPolicy.Environment.PRODUCTION, ExternalActionPolicy.Effect.READ_PUBLIC,true,true,true, ExternalActionPolicy.Decision.BLOCK,"unknown actor blocked");
    System.out.println("ExternalActionPolicyTest PASS "+n);
  }
  private static void using(ExternalActionPolicy.Actor a,ExternalActionPolicy.Environment e,ExternalActionPolicy.Effect f,boolean t,boolean o,boolean s,ExternalActionPolicy.Decision want,String m){
    eq(ExternalActionPolicy.decide(a,e,f,t,o,s),want,m);
  }
}
