package com.sbh.atlasos;

import java.util.Arrays;

public final class OwnerPinPolicyTest {
  private static int pass=0,total=0;
  private static void check(boolean ok,String name){ total++; if(!ok) throw new AssertionError(name); pass++; }
  public static void main(String[] args) throws Exception {
    check(OwnerPinPolicy.validPin("123456"),"six digits accepted");
    check(!OwnerPinPolicy.validPin("12345"),"short rejected");
    check(!OwnerPinPolicy.validPin("1234567"),"long rejected");
    check(!OwnerPinPolicy.validPin("12a456"),"nondigit rejected");
    check(!OwnerPinPolicy.validPin(null),"null rejected");
    byte[] salt=new byte[OwnerPinPolicy.SALT_BYTES];
    for(int i=0;i<salt.length;i++)salt[i]=(byte)i;
    byte[] a=OwnerPinPolicy.derive("123456",salt),b=OwnerPinPolicy.derive("123456",salt),c=OwnerPinPolicy.derive("654321",salt);
    check(Arrays.equals(a,b),"derivation deterministic");
    check(!Arrays.equals(a,c),"different pin differs");
    check(OwnerPinPolicy.constantTimeEquals(a,b),"constant equality true");
    check(!OwnerPinPolicy.constantTimeEquals(a,c),"constant equality false");
    check(OwnerPinPolicy.lockoutMillisForFailures(4)==0L,"no lockout below threshold");
    check(OwnerPinPolicy.lockoutMillisForFailures(5)==30_000L,"five failures lockout");
    check(OwnerPinPolicy.lockoutMillisForFailures(8)==300_000L,"eight failures lockout");
    check(OwnerPinPolicy.lockoutMillisForFailures(10)==3_600_000L,"ten failures one hour");
    System.out.println("OwnerPinPolicy "+pass+"/"+total+" PASS");
  }
}
