package com.sbh.atlasos;

/** Unicode command boundary defense-in-depth. Host-only tests; not a device security proof. */
public final class InputUnicodeHardeningTest {
  private static int checks = 0;
  private static void ok(boolean condition, String label) {
    checks++; if (!condition) throw new AssertionError(label);
  }
  private static void reject(String value) {
    ok(CommandParser.parse(value).kind == CommandParser.Kind.INVALID,"local rejected");
    ok(WorkflowIntentParser.parse(value).state == WorkflowIntentParser.State.INVALID,"workflow rejected for "+value.length()+" / "+value.substring(0,Math.min(value.length(),18)));
    ok(!GodCommandPolicy.parse(value).activated,"GOD rejected");
    AuthenticatedInputRouter.Result routed = AuthenticatedInputRouter.route(
        value, WorkflowIntentParser.Origin.UI_TEXT, true, false, true);
    ok(routed.route == AuthenticatedInputRouter.Route.INVALID,"native routing rejected");
    ok(!routed.shouldExecuteLocal && !routed.grantsExecution,"not eligible for execution");
  }
  public static void main(String[] args) {
    String[] inputCases = {
      "GOD", "GOD build the robot", "GOD: text my friend", "ATLAS: GOD audit security",
      "text call me later", "call +14105550101", "open camera", "save everything",
      "navigate to North East", "search historical reports", "ATLAS MAX"
    };
    // Format marks + control + isolated UTF-16 + invisible blank lookalikes.
    String[] bad = {"\u200B", "\u200C", "\u200D", "\u200E", "\u200F", "\u202E",
        "\u2060", "\u2066", "\u2069", "\u061C", "\u00AD", "\uFEFF",
        "\u034F", "\u115F", "\u1160", "\u3164", "\uFFA0", "\u2800",
        "\u2028", "\u2029", "\uD800", "\uDC00", "\u0000"};
    for (String base : inputCases) {
      for (String mark : bad) {
        reject(mark + base);
        reject(base.substring(0, 1) + mark + base.substring(1));
        int gap = base.indexOf(' ');
        if (gap > 0) reject(base.substring(0, gap + 1) + mark + base.substring(gap + 1));
        reject(base + mark);
      }
    }
    // NFKC expands some compatibility characters many times; raw bounds alone
    // do not constrain how much text reaches the rest of the parser.
    String expansion = "\uFDFA";
    ok(!GodCommandPolicy.parse("GOD: research " + expansion.repeat(40)).activated,
      "GOD 512-char normalized bound");
    ok(CommandParser.parse("text " + expansion.repeat(40)).kind == CommandParser.Kind.INVALID,
      "local 512-char normalized bound");
    reject("GOD: " + expansion.repeat(480));
    reject("text " + expansion.repeat(480));
    reject(expansion.repeat(480));
    // Legitimate paired surrogate emoji must not be rejected indiscriminately.
    String emoji = "\uD83D\uDE80";
    ok(CommandParser.parse("text hello " + emoji).kind == CommandParser.Kind.TEXT,"ordinary emoji remains usable");
    ok(GodCommandPolicy.parse("GOD: research robotics " + emoji).activated,"valid emoji GOD task");
    ok(WorkflowIntentParser.parse("GOD research " + emoji).state != WorkflowIntentParser.State.INVALID,"valid emoji workflow input");
    ok(GodCommandPolicy.parse("GOD").scope == GodCommandPolicy.Scope.PORTFOLIO,"standalone GOD preserved");
    AuthenticatedInputRouter.Result good = AuthenticatedInputRouter.route(
      "GOD", WorkflowIntentParser.Origin.UI_TEXT, true, false, true);
    ok(good.route == AuthenticatedInputRouter.Route.BRAIN_HANDOFF,"GOD stays brain-only");
    ok(!good.shouldExecuteLocal && !good.grantsExecution,"GOD cannot grant local authority");
    AuthenticatedInputRouter.Result ref = AuthenticatedInputRouter.route(
      "GOD", WorkflowIntentParser.Origin.REFERENCE_DATA, true, false, true);
    ok(ref.route == AuthenticatedInputRouter.Route.SOURCE_DATA,"quoted GOD never becomes execution");
    // Owner session is still an independent gate.
    AuthenticatedInputRouter.Result locked = AuthenticatedInputRouter.route(
      "GOD", WorkflowIntentParser.Origin.UI_TEXT, false, false, true);
    ok(locked.route == AuthenticatedInputRouter.Route.LOCKED,"locked owner does not activate");
    System.out.println("InputUnicodeHardeningTest: PASS assertions=" + checks);
  }
}
