package com.sbh.atlasos;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/** Pure JVM checks: all observations are synthetic, never device history. */
public final class BatteryTrendTest {
  private static int assertions;
  private static final long T = 1_800_000_000_000L;
  private static final long MIN = 60_000L;
  private static void check(boolean ok, String why) {
    assertions++;
    if (!ok) throw new AssertionError(why);
  }
  private static BatteryTrend.Sample s(int minute, int level) {
    return new BatteryTrend.Sample(T + minute * MIN, level, false, "none");
  }
  private static void unavailable(String expected, BatteryTrend.Result r) {
    check(expected.equals(r.status), expected + " status, got " + r.status);
    check(r.ratePerHour == null, "unavailable evidence must not invent a rate");
    check("unknown".equals(r.direction), "unavailable evidence must not invent a direction");
  }
  public static void main(String[] args) {
    unavailable("insufficient_data", BatteryTrend.calculate(Collections.<BatteryTrend.Sample>emptyList(), T));
    unavailable("insufficient_data", BatteryTrend.calculate(Arrays.asList(s(0, 70)), T));
    unavailable("insufficient_data", BatteryTrend.calculate(Arrays.asList(s(0, 70), s(5, 69)), T + 5 * MIN));
    BatteryTrend.Result r = BatteryTrend.calculate(Arrays.asList(s(0, 80), s(15, 78), s(30, 76)), T + 30 * MIN);
    check("ok".equals(r.status), "continuous samples yield a trend");
    check(Math.abs(r.ratePerHour + 8.0) < 0.000001, "signed points/hour use real elapsed time");
    check(r.observedMinutes == 30 && r.samplesUsed == 3, "observed window is explicit");
    check("falling".equals(r.direction), "negative change falls");
    r = BatteryTrend.calculate(Arrays.asList(s(0, 80), s(17, 78), s(41, 75)), T + 41 * MIN);
    check(Math.abs(r.ratePerHour - (-5.0 * 60 / 41)) < 0.000001, "irregular samples do not assume a 15m cadence");
    unavailable("gap", BatteryTrend.calculate(Arrays.asList(s(0, 90), s(120, 80)), T + 120 * MIN));
    r = BatteryTrend.calculate(Arrays.asList(s(0, 90), s(120, 80), s(135, 78)), T + 135 * MIN);
    check("ok".equals(r.status) && r.samplesUsed == 2 && r.observedMinutes == 15,
        "fresh segment after a gap does not span the missing hours");
    check(Math.abs(r.ratePerHour + 8) < 0.000001, "post-gap rate uses only observed recent segment");
    unavailable("stale", BatteryTrend.calculate(Arrays.asList(s(0, 80), s(15, 78)), T + 61 * MIN));
    unavailable("power_state_changed", BatteryTrend.calculate(Arrays.asList(s(0, 50),
        new BatteryTrend.Sample(T + 15 * MIN, 52, true, "usb")), T + 15 * MIN));
    r = BatteryTrend.calculate(Arrays.asList(s(0, 50),
        new BatteryTrend.Sample(T + 15 * MIN, 52, true, "usb"),
        new BatteryTrend.Sample(T + 30 * MIN, 57, true, "usb")), T + 30 * MIN);
    check("ok".equals(r.status) && r.ratePerHour == 20.0 && r.samplesUsed == 2,
        "charging rate starts after charging transition");
    check("rising".equals(r.direction), "positive change rises");
    unavailable("power_state_changed", BatteryTrend.calculate(Arrays.asList(
        new BatteryTrend.Sample(T, 50, true, "usb"),
        new BatteryTrend.Sample(T + 15 * MIN, 55, true, "ac")), T + 15 * MIN));
    unavailable("tracking_changed", BatteryTrend.calculate(Arrays.asList(
        new BatteryTrend.Sample(T, 80, false, "none", "before-stop"),
        new BatteryTrend.Sample(T + 15 * MIN, 79, false, "none", "after-start")), T + 15 * MIN));
    r = BatteryTrend.calculate(Arrays.asList(s(0, 100), s(15, 100)), T + 15 * MIN);
    check("ok".equals(r.status) && r.ratePerHour == 0.0 && "steady".equals(r.direction),
        "no integer-level change means observed steady, no invented fractional drain");
    unavailable("invalid_data", BatteryTrend.calculate(null, T));
    unavailable("invalid_data", BatteryTrend.calculate(Arrays.asList(s(0, 101), s(15, 90)), T + 15 * MIN));
    unavailable("invalid_data", BatteryTrend.calculate(Arrays.asList(s(0, -1), s(15, 90)), T + 15 * MIN));
    unavailable("invalid_data", BatteryTrend.calculate(Arrays.asList(s(0, 80), null), T + 15 * MIN));
    unavailable("invalid_data", BatteryTrend.calculate(Arrays.asList(new BatteryTrend.Sample(T, 80, false, "bad")), T));
    unavailable("invalid_data", BatteryTrend.calculate(Arrays.asList(new BatteryTrend.Sample(0, 80, false, "none")), T));
    unavailable("invalid_data", BatteryTrend.calculate(Arrays.asList(s(0, 80)), 0));
    unavailable("power_state_unknown", BatteryTrend.calculate(Arrays.asList(
        new BatteryTrend.Sample(T, 80, false, "unknown"),
        new BatteryTrend.Sample(T + 15 * MIN, 79, false, "unknown")), T + 15 * MIN));
    unavailable("clock_changed", BatteryTrend.calculate(Arrays.asList(s(15, 80), s(0, 79)), T + 15 * MIN));
    unavailable("clock_changed", BatteryTrend.calculate(Arrays.asList(s(0, 80), s(0, 79)), T));
    unavailable("clock_changed", BatteryTrend.calculate(Arrays.asList(s(0, 80), s(15, 79)), T + 14 * MIN));
    r = BatteryTrend.calculate(Arrays.asList(s(0, 80), s(45, 75)), T + 45 * MIN);
    check("ok".equals(r.status), "45 minute allowed gap boundary");
    unavailable("gap", BatteryTrend.calculate(Arrays.asList(s(0, 80), s(46, 75)), T + 46 * MIN));
    ArrayList<BatteryTrend.Sample> longRun = new ArrayList<>();
    for (int i = 0; i <= 40; i++) longRun.add(s(i * 15, 100 - i));
    r = BatteryTrend.calculate(longRun, T + 600 * MIN);
    check(r.observedMinutes == 360.0 && r.samplesUsed == 25, "rate window is bounded to six hours");
    ArrayList<BatteryTrend.Sample> tooMany = new ArrayList<>();
    for (int i = 0; i <= BatteryTrend.MAX_SAMPLES; i++) tooMany.add(s(i, 50));
    unavailable("invalid_data", BatteryTrend.calculate(tooMany, T + BatteryTrend.MAX_SAMPLES * MIN));
    System.out.println("BatteryTrendTest: " + assertions + "/" + assertions + " PASS");
  }
}
