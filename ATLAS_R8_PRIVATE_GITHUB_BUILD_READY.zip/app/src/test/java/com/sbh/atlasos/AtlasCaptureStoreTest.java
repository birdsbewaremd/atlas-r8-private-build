package com.sbh.atlasos;

import java.io.*;
import java.nio.file.*;
import java.security.SecureRandom;
import java.util.*;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

/** Host JCE/file tests. These do not execute Android MediaProjection, codecs, or Keystore. */
public final class AtlasCaptureStoreTest {
    private static int passed;
    private interface Attempt { void run() throws Exception; }
    private static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        passed++; System.out.println("PASS " + label);
    }
    private static void refused(Attempt attempt, String label) throws Exception {
        boolean denied = false;
        try { attempt.run(); } catch (Exception expected) { denied = true; }
        check(denied, label);
    }
    public static void main(String[] ignored) throws Exception {
        AtlasCaptureStore.LaunchTokens tickets = new AtlasCaptureStore.LaunchTokens();
        String one = tickets.issue("session", 100L, 30_000L);
        check(tickets.consume(one, "session", 101L) == 30_100L, "valid scoped ticket returns its deadline");
        check(tickets.consume(one, "session", 102L) == 0L, "consumed ticket cannot be replayed");
        String expired = tickets.issue("session", 200L, 30_000L);
        check(tickets.consume(expired, "session", 30_200L) == 0L, "ticket expires at the deadline");
        String wrongScope = tickets.issue("play:recording-a", 40_000L, 30_000L);
        check(tickets.consume(wrongScope, "play:recording-b", 40_001L) == 0L, "playback ticket is bound to one recording");
        check(tickets.consume(wrongScope, "play:recording-a", 40_002L) == 0L, "a wrong-scope attempt consumes the ticket");
        String startOnly = tickets.issue("session", 50_000L, 30_000L);
        check(tickets.consume(startOnly, "delete:a", 50_001L) == 0L, "capture authority cannot delete a clip");
        String processTicket = tickets.issue("session", 60_000L, 30_000L);
        check(new AtlasCaptureStore.LaunchTokens().consume(processTicket, "session", 60_001L) == 0L,
                "a new process ledger cannot resume an earlier ticket");
        String clockTicket = tickets.issue("session", 70_000L, 30_000L);
        check(tickets.consume(clockTicket, "session", 69_999L) == 0L, "clock rollback invalidates tickets");
        String cleared = tickets.issue("session", 80_000L, 30_000L); tickets.clear();
        check(tickets.consume(cleared, "session", 80_001L) == 0L, "screen-off revocation clears pending authority");
        refused(() -> tickets.issue("session", -1L, 30_000L), "negative ticket time is refused");
        refused(() -> tickets.issue("session", 1L, Long.MAX_VALUE), "unbounded ticket lifetime is refused");
        check(AtlasCaptureStore.remainingDuration(100L, 100L) == 600_000L, "duration budget starts at ten minutes");
        check(AtlasCaptureStore.remainingDuration(100L, 600_100L) == 0L, "duration budget cannot extend past its cap");
        check(AtlasCaptureStore.remainingDuration(100L, 99L) == 0L, "clock rollback cannot extend capture duration");
        check(AtlasCaptureStore.remainingBytes(100_000_001L) == 0L, "byte budget does not become negative");
        check(AtlasCaptureStore.budgetForArchive(0L) == 100_000_000L, "an empty archive permits the per-session cap");
        check(AtlasCaptureStore.budgetForArchive(200_000_000L) > 49_000_000L
                && AtlasCaptureStore.budgetForArchive(200_000_000L) < 50_000_000L,
                "near-full archive reserves encryption overhead and reduces recording budget");
        check(AtlasCaptureStore.budgetForArchive(250_000_000L) == 0L
                && AtlasCaptureStore.budgetForArchive(Long.MAX_VALUE) == 0L
                && AtlasCaptureStore.budgetForArchive(-1L) == 0L, "full or invalid archive budgets fail closed");

        String id = "0123456789abcdef0123456789abcdef";
        check(AtlasCaptureStore.isValidId(id), "canonical recording identifier is accepted");
        for (String bad : new String[]{null, "", "../private", "/absolute", id + ".acap", id.toUpperCase(Locale.US),
                id + "\n", "0123456789abcdef0123456789abcdeg"})
            check(!AtlasCaptureStore.isValidId(bad), "path-like or malformed recording identifier is refused");
        refused(() -> new AtlasCaptureStore.Clip(id, 1L, 600_001L, 1L), "metadata cannot exceed the duration cap");
        refused(() -> new AtlasCaptureStore.Clip(id, 1L, 1L, 100_000_001L), "metadata cannot exceed the size cap");
        refused(() -> new AtlasCaptureStore.Clip(id, 1L, 0L, 1L), "unfinished zero-duration clip is refused");

        Path directory = Files.createTempDirectory("atlas-capture-contract-");
        try {
            refused(() -> AtlasCaptureStore.clipFile(directory.toFile(), "../outside"), "file resolver refuses directory traversal");
            Path outside = Files.createTempFile(directory, "outside-", ".bin");
            Path symlink = directory.resolve(id + ".acap"); Files.createSymbolicLink(symlink, outside);
            refused(() -> AtlasCaptureStore.clipFile(directory.toFile(), id), "file resolver refuses symlink targets");
            Files.delete(symlink);

            KeyGenerator generator = KeyGenerator.getInstance("AES"); generator.init(256);
            SecretKey key = generator.generateKey(), wrongKey = generator.generateKey();
            byte[] plain = new byte[600_123]; new SecureRandom().nextBytes(plain);
            byte[] marker = "PRIVATE_CAPTURE_TEST_MARKER".getBytes(java.nio.charset.StandardCharsets.US_ASCII);
            System.arraycopy(marker, 0, plain, 0, marker.length);
            File input = directory.resolve("input.mp4.tmp").toFile(); Files.write(input.toPath(), plain);
            AtlasCaptureStore.Clip clip = new AtlasCaptureStore.Clip(id, 1_700_000_000_000L, 8_712L, plain.length);
            File encrypted = directory.resolve(id + ".acap").toFile();
            AtlasCaptureStore.encrypt(input, encrypted, key, clip, () -> true);
            byte[] encoded = Files.readAllBytes(encrypted.toPath());
            check(!new String(encoded, java.nio.charset.StandardCharsets.ISO_8859_1).contains("PRIVATE_CAPTURE_TEST_MARKER"),
                    "committed-format bytes contain no plaintext marker");
            File decoded = directory.resolve("decoded.mp4").toFile();
            AtlasCaptureStore.Clip reopened = AtlasCaptureStore.decrypt(encrypted, decoded, key, id, () -> true);
            check(Arrays.equals(plain, Files.readAllBytes(decoded.toPath())), "multi-chunk recording roundtrips without truncation");
            check(reopened.bytes == clip.bytes && reopened.durationMs == clip.durationMs
                    && reopened.createdAtMs == clip.createdAtMs, "authenticated metadata survives reopening");
            File second = directory.resolve("second.acap").toFile();
            AtlasCaptureStore.encrypt(input, second, key, clip, () -> true);
            check(!Arrays.equals(encoded, Files.readAllBytes(second.toPath())), "fresh encryption uses independent nonces");
            refused(() -> AtlasCaptureStore.encrypt(input, encrypted, key, clip, () -> true), "encryption cannot replace a nonempty original");
            check(Arrays.equals(encoded, Files.readAllBytes(encrypted.toPath())), "failed replacement preserves original ciphertext");
            refused(() -> AtlasCaptureStore.decrypt(encrypted, directory.resolve("wrong-key.mp4").toFile(), wrongKey, id, () -> true),
                    "wrong key cannot decrypt or authenticate metadata");
            check(!Files.exists(directory.resolve("wrong-key.mp4")), "failed authentication removes playback temporary output");
            refused(() -> AtlasCaptureStore.decrypt(encrypted, directory.resolve("wrong-id.mp4").toFile(), key,
                    "11111111111111111111111111111111", () -> true), "ciphertext cannot be renamed to another recording identity");
            byte[] changedHeader = encoded.clone(); changedHeader[47] ^= 1;
            File corrupt = directory.resolve("corrupt.acap").toFile(); Files.write(corrupt.toPath(), changedHeader);
            refused(() -> AtlasCaptureStore.decrypt(corrupt, directory.resolve("header.mp4").toFile(), key, id, () -> true),
                    "metadata tampering is authenticated and refused");
            byte[] changedChunk = encoded.clone(); changedChunk[changedChunk.length - 1] ^= 1; Files.write(corrupt.toPath(), changedChunk);
            refused(() -> AtlasCaptureStore.decrypt(corrupt, directory.resolve("chunk.mp4").toFile(), key, id, () -> true),
                    "late chunk tampering is detected after earlier chunks");
            check(!Files.exists(directory.resolve("chunk.mp4")), "late authentication failure leaves no partial playback file");
            Files.write(corrupt.toPath(), Arrays.copyOf(encoded, encoded.length - 1));
            refused(() -> AtlasCaptureStore.decrypt(corrupt, directory.resolve("short.mp4").toFile(), key, id, () -> true),
                    "truncated encrypted recordings are refused");
            byte[] extra = Arrays.copyOf(encoded, encoded.length + 1); Files.write(corrupt.toPath(), extra);
            refused(() -> AtlasCaptureStore.decrypt(corrupt, directory.resolve("extra.mp4").toFile(), key, id, () -> true),
                    "trailing unauthenticated data is refused");
            // Swap the first two full encrypted chunks; both have the same length.
            byte[] swapped = encoded.clone(); int first = 96, chunk = 262_144 + 28;
            System.arraycopy(encoded, first + chunk, swapped, first, chunk);
            System.arraycopy(encoded, first, swapped, first + chunk, chunk);
            Files.write(corrupt.toPath(), swapped);
            refused(() -> AtlasCaptureStore.decrypt(corrupt, directory.resolve("swapped.mp4").toFile(), key, id, () -> true),
                    "authenticated chunk indices reject reordering");
            final int[] calls = {0};
            refused(() -> AtlasCaptureStore.decrypt(encrypted, directory.resolve("paused.mp4").toFile(), key, id,
                    () -> ++calls[0] <= 3), "authorization loss during decryption cancels playback preparation");
            check(!Files.exists(directory.resolve("paused.mp4")), "backgrounding cancellation deletes temporary plaintext");
            refused(() -> AtlasCaptureStore.decrypt(encrypted, directory.resolve("locked.mp4").toFile(), key, id, () -> false),
                    "locked access performs no playback decryption");
            check(Arrays.equals(encoded, Files.readAllBytes(encrypted.toPath())), "tamper tests and cancellation preserve the committed original");
            check(AtlasCaptureStore.deleteTemporary(decoded) && !decoded.exists(), "private playback file cleanup removes its file");
            Arrays.fill(plain, (byte) 0);
        } finally {
            try (java.util.stream.Stream<Path> paths = Files.walk(directory)) {
                paths.sorted(Comparator.reverseOrder()).forEach(path -> { try { Files.delete(path); } catch (IOException ignoredDelete) { } });
            }
        }
        System.out.println("CAPTURE_HOST=" + passed + "/" + passed + " PASS (JCE, files and policy only; no Android device acceptance)");
    }
}
