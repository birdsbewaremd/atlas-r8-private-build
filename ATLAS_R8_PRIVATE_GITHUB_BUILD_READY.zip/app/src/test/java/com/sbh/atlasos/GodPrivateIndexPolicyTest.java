package com.sbh.atlasos;
import java.nio.file.*;
import java.util.*;

public final class GodPrivateIndexPolicyTest {
 static int passed=0;
 static void yes(boolean condition,String test){if(!condition)throw new AssertionError(test);passed++;}
 public static void main(String[] args)throws Exception{
   String valid="import-d89a7c2e/files/god/GOD_PRIVATE_MASTER_V1.json";
   yes(GodPrivateIndexPolicy.isCandidatePath(valid),"valid native encrypted import path");
   String[] rejects={"god/GOD_PRIVATE_MASTER_V1.json","/import-x/files/god/GOD_PRIVATE_MASTER_V1.json",
       "import-x/files/../../GOD_PRIVATE_MASTER_V1.json","import-x/files/god/other.json",
       "import-x/files/god/GOD_PRIVATE_MASTER_V1.json/more","import-x/files/god\\GOD_PRIVATE_MASTER_V1.json",
       "../import-x/files/god/GOD_PRIVATE_MASTER_V1.json","import-x/files/GOD_PRIVATE_MASTER_V1.json",
       "import-x/files/god/./GOD_PRIVATE_MASTER_V1.json", "import-x/files/god/GOD_PRIVATE_MASTER_V1.json\u0000"};
   for(String s:rejects)yes(!GodPrivateIndexPolicy.isCandidatePath(s),"reject path "+s);
   yes(!GodPrivateIndexPolicy.isCandidatePath(null),"reject null path");
   yes(!GodPrivateIndexPolicy.isCandidatePath("x".repeat(257)),"reject oversize path");
   List<String> found=GodPrivateIndexPolicy.candidatePaths(Arrays.asList(valid,"not-secret.txt","import-fake/files/god/no.txt"));
   yes(found.size()==1&&valid.equals(found.get(0)),"only target selected");
   yes(GodPrivateIndexPolicy.candidatePaths(null).isEmpty(),"null list");
   yes(!GodPrivateIndexPolicy.trustedContent(""),"reject empty");
   yes(!GodPrivateIndexPolicy.trustedContent(null),"reject null");
   yes(!GodPrivateIndexPolicy.trustedContent("GOD".repeat(1000)),"reject fake");
   yes(!GodPrivateIndexPolicy.trustedContent("A".repeat(200001)),"reject excessive size");
   if(args.length>0){
      String good=Files.readString(Path.of(args[0]));
      yes(GodPrivateIndexPolicy.trustedContent(good),"accept only pinned real private index");
      yes(!GodPrivateIndexPolicy.trustedContent(good+" "),"reject trailing changes");
      yes(!GodPrivateIndexPolicy.trustedContent(good.replace("G00","G99")),"reject tampering");
      yes(!GodPrivateIndexPolicy.trustedContent(good.substring(0,good.length()-1)),"reject truncation");
   }
   System.out.println("GOD private index policy PASS "+passed+" assertions (positive pinned import included="+(args.length>0)+")");
 }
}
