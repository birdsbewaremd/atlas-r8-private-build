package com.sbh.atlasos;

public final class ArtifactTrustPolicyTest {
  private static int n=0;
  private static void eq(Object g,Object e,String m){n++; if(!e.equals(g)) throw new AssertionError(m);}
  private static ArtifactTrustPolicy.ArtifactProfile p(boolean source,boolean hash,boolean lic,boolean comm,boolean red,
      boolean scan,boolean iso,boolean ser,boolean sig,boolean sigv,boolean siga){
    return new ArtifactTrustPolicy.ArtifactProfile(source,hash,lic,comm,red,scan,iso,ser,sig,sigv,siga);
  }
  public static void main(String[] args){
    eq(ArtifactTrustPolicy.decide(p(true,true,true,true,true,true,true,true,false,false,false)),ArtifactTrustPolicy.Decision.APPROVE,"complete unsigned provenance");
    eq(ArtifactTrustPolicy.decide(p(false,true,true,true,true,true,true,true,false,false,false)),ArtifactTrustPolicy.Decision.BLOCK,"unknown source");
    eq(ArtifactTrustPolicy.decide(p(true,false,true,true,true,true,true,true,false,false,false)),ArtifactTrustPolicy.Decision.BLOCK,"missing hash");
    eq(ArtifactTrustPolicy.decide(p(true,true,false,true,true,true,true,true,false,false,false)),ArtifactTrustPolicy.Decision.BLOCK,"unknown license");
    eq(ArtifactTrustPolicy.decide(p(true,true,true,false,true,true,true,true,false,false,false)),ArtifactTrustPolicy.Decision.BLOCK,"commercial blocked");
    eq(ArtifactTrustPolicy.decide(p(true,true,true,true,true,false,true,true,false,false,false)),ArtifactTrustPolicy.Decision.BLOCK,"scan fail");
    eq(ArtifactTrustPolicy.decide(p(true,true,true,true,true,true,false,true,false,false,false)),ArtifactTrustPolicy.Decision.BLOCK,"isolated test fail");
    eq(ArtifactTrustPolicy.decide(p(true,true,true,true,true,true,true,false,false,false,false)),ArtifactTrustPolicy.Decision.BLOCK,"serialization unresolved");
    eq(ArtifactTrustPolicy.decide(p(true,true,true,true,true,true,true,true,true,true,false)),ArtifactTrustPolicy.Decision.BLOCK,"valid signature unknown signer");
    eq(ArtifactTrustPolicy.decide(p(true,true,true,true,true,true,true,true,true,true,true)),ArtifactTrustPolicy.Decision.APPROVE,"authorized signature");
    System.out.println("ArtifactTrustPolicyTest PASS "+n);
  }
}
