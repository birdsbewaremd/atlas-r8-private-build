package com.sbh.atlasos;

public final class SeedImportPolicyTest {
  private static int tests = 0;

  public static void main(String[] args) {
    ok("profile/me.json", "profile/me.json");
    ok("folder\\file.txt", "folder/file.txt");
    ok("/folder/file.txt", "folder/file.txt");
    bad(null);
    bad("");
    bad("/");
    bad("../secret");
    bad("folder/../secret");
    bad("folder/./file");
    bad("folder//file");
    bad("C:/secret.txt");
    bad("folder/\u0000bad");
    bad("folder/\u0007bad");
    bad("x".repeat(SeedImportPolicy.MAX_PATH_CHARS + 1));
    bad("folder/" + "x".repeat(256));
    size(true, -1);
    size(true, SeedImportPolicy.MAX_FILE_BYTES);
    size(false, SeedImportPolicy.MAX_FILE_BYTES + 1);
    remaining(SeedImportPolicy.MAX_TOTAL_BYTES, 0);
    remaining(SeedImportPolicy.MAX_TOTAL_BYTES - 1, 1);
    remaining(0, SeedImportPolicy.MAX_TOTAL_BYTES);
    System.out.println("SeedImportPolicy tests PASS: " + tests + "/" + tests);
  }

  private static void ok(String in, String expected) {
    tests++;
    String actual = SeedImportPolicy.safeRelative(in);
    if (!expected.equals(actual)) throw new AssertionError("Expected " + expected + " got " + actual);
  }

  private static void bad(String in) {
    tests++;
    if (SeedImportPolicy.safeRelative(in) != null) throw new AssertionError("Expected rejection: " + in);
  }

  private static void size(boolean expected, long n) {
    tests++;
    if (SeedImportPolicy.declaredSizeAllowed(n) != expected) throw new AssertionError("Size policy failure: " + n);
  }

  private static void remaining(long current, long expected) {
    tests++;
    long actual = SeedImportPolicy.remainingBudget(current);
    if (actual != expected) throw new AssertionError("Budget expected " + expected + " got " + actual);
  }
}
