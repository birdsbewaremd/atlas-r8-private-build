package com.sbh.atlasos;

import java.util.HashSet;
import java.util.Set;

public final class WorkflowCommandCatalogTest {
  public static void main(String[] args) {
    int checks=0;
    check(WorkflowCommandCatalog.TOTAL_ENTRIES==92,"catalog total");checks++;
    check(WorkflowCommandCatalog.all().size()==92,"catalog list size");checks++;
    Set<String> ids=new HashSet<String>();
    Set<String> canonicals=new HashSet<String>();
    for(WorkflowCommandCatalog.Entry e:WorkflowCommandCatalog.all()){
      check(ids.add(e.id),"duplicate id "+e.id);checks++;
      check(canonicals.add(e.canonical),"duplicate canonical "+e.canonical);checks++;
      check(WorkflowCommandCatalog.byId(e.id)==e,"id lookup "+e.id);checks++;
      WorkflowCommandCatalog.Entry direct=WorkflowCommandCatalog.exactOrAnchored(e.canonical);
      check(direct!=null&&direct.id.equals(e.id),"canonical lookup "+e.canonical);checks++;
    }
    check(WorkflowCommandCatalog.REGISTRY_SHA256.matches("[0-9a-f]{64}"),"registry digest shape");checks++;
    System.out.println("WorkflowCommandCatalogTest: PASS entries=92 assertions="+checks);
  }
  private static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);}
}
