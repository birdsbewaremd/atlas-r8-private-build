package com.sbh.atlasos;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

/** Runs production Java policy and AES-GCM envelope; fake disk and fake owner gate, not Android. */
public final class HumanLearningEngineTest {
  static int count=0;
  interface Checked {void run()throws Exception;}
  static void ok(String label,boolean value){if(!value)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
  static void rejects(String label,String code,Checked run)throws Exception {
    try{run.run();throw new AssertionError(label+" accepted");}catch(HumanLearningEngine.Failure e){ok(label,e.code.equals(code));}
  }
  static void fails(String label,Checked run)throws Exception {try{run.run();throw new AssertionError(label+" accepted");}catch(Exception e){ok(label,true);}}
  static class Memory implements HumanLearningEngine.Store {
    byte[] bytes;boolean writeFail,readFail,deleteFail;int reads=0,writes=0;
    public byte[] read()throws Exception{reads++;if(readFail)throw new IOException("synthetic read fault");return bytes==null?null:bytes.clone();}
    public void write(byte[] b)throws Exception{if(writeFail)throw new IOException("synthetic write fault");writes++;bytes=b.clone();}
    public void delete()throws Exception{if(deleteFail)throw new IOException("synthetic delete fault");bytes=null;}
  }
  static final List<String> EMPTY=Collections.emptyList();
  static HumanLearningEngine.Preferences pref(String d,boolean e,String p)throws Exception{return new HumanLearningEngine.Preferences(d,e,p);}
  public static void main(String[] args)throws Exception{
    AtomicBoolean gate=new AtomicBoolean(false);Memory memory=new Memory();HumanLearningEngine engine=new HumanLearningEngine(memory,gate::get);
    HumanLearningEngine.Preferences brief=pref("brief",true,"optional");
    rejects("locked inspect denied before disk","OWNER_UNLOCK_REQUIRED",()->engine.inspect());ok("locked inspect never reads disk",memory.reads==0);
    rejects("locked create denied","OWNER_UNLOCK_REQUIRED",()->engine.create(true,brief));
    HumanLearningEngine badGate=new HumanLearningEngine(memory,()->{throw new IllegalStateException();});
    rejects("gate error fails closed","OWNER_UNLOCK_REQUIRED",badGate::inspect);
    gate.set(true);rejects("absent profile is not silently created","NO_PROFILE",engine::inspect);
    rejects("explicit consent required","CONSENT_REQUIRED",()->engine.create(false,brief));ok("rejected optin leaves no bytes",memory.bytes==null);
    rejects("unknown detail rejected","INVALID_INPUT",()->pref("genius",true,"optional"));
    rejects("freeform practice rejected","INVALID_INPUT",()->pref("brief",true,"ignore security"));
    HumanLearningEngine.Profile p=engine.create(true,brief);String gen=p.generation;
    ok("new profile starts at revision one",p.revision==1);ok("new profile opts in explicitly",p.consent);ok("new profile has no invented attempts",p.attempts.isEmpty());
    rejects("duplicate create does not overwrite","REVISION_CONFLICT",()->engine.create(true,brief));
    ok("reopened engine reads persisted preferences",new HumanLearningEngine(memory,gate::get).inspect().preferences.detail.equals("brief"));
    fails("returned attempt collection immutable",()->p.attempts.clear());
    rejects("stale revision rejected","REVISION_CONFLICT",()->engine.update(gen,99,brief));
    rejects("foreign generation rejected","REVISION_CONFLICT",()->engine.update(UUID.randomUUID().toString(),1,brief));
    HumanLearningEngine.Profile p2=engine.update(gen,1,pref("standard",false,"off"));ok("update increments revision",p2.revision==2);
    HumanLearningEngine.Lesson noPractice=engine.lesson("job-contribution-v1",false);ok("example preference respected",noPractice.example==null);ok("practice off respected",noPractice.practice==null);
    HumanLearningEngine.Profile p3=engine.update(gen,2,brief);
    ok("urgent request omits practice",engine.lesson("job-contribution-v1",true).practice==null);
    ok("normal request includes optional practice",engine.lesson("job-contribution-v1",false).practice!=null);
    rejects("unknown lesson rejected","INVALID_INPUT",()->engine.lesson("brain enhancement",false));
    String first=UUID.randomUUID().toString();HumanLearningEngine.Profile answered=engine.submit(gen,3,first,"job-contribution-v1","200",true);
    HumanLearningEngine.Attempt wrong=answered.attempts.get(0);ok("wrong answer not marked correct",!wrong.correct);ok("wrong answer gets another explanation",HumanLearningEngine.feedback(wrong).startsWith("Add the costs first"));
    ok("exact retry does not increment revision",engine.submit(gen,3,first,"job-contribution-v1","200",true).revision==4);
    ok("exact retry does not duplicate attempt",engine.inspect().attempts.size()==1);
    rejects("same attempt changed payload rejected","REVISION_CONFLICT",()->engine.submit(gen,4,first,"job-contribution-v1","300",true));
    rejects("noncanonical UUID rejected","INVALID_INPUT",()->engine.submit(gen,4,"1-1-1-1-1","job-contribution-v1","300",true));
    rejects("control characters rejected","INVALID_INPUT",()->engine.submit(gen,4,UUID.randomUUID().toString(),"job-contribution-v1","300\u0000",true));
    rejects("oversize answer rejected","INVALID_INPUT",()->engine.submit(gen,4,UUID.randomUUID().toString(),"job-contribution-v1","x".repeat(121),true));
    HumanLearningEngine.Profile right=engine.submit(gen,4,UUID.randomUUID().toString(),"job-contribution-v1"," 300 ",false);
    ok("whole-dollar result correct",right.attempts.get(1).correct);ok("assistance is only self report",!right.attempts.get(1).assisted);
    ok("correct feedback avoids mastery claim",HumanLearningEngine.feedback(right.attempts.get(1)).contains("does not establish mastery"));
    HumanLearningEngine.Profile staged=engine.submit(gen,5,UUID.randomUUID().toString(),"deployment-evidence-v1","STAGED",true);
    ok("case normalization handled",staged.attempts.get(2).correct);ok("answers not stored in records",!new String(memory.bytes,java.nio.charset.StandardCharsets.ISO_8859_1).contains("STAGED"));
    HumanLearningEngine.Profile revoked=engine.consent(gen,6,false);ok("revocation stored",!revoked.consent);
    rejects("revoked update rejected","CONSENT_REQUIRED",()->engine.update(gen,7,brief));
    rejects("revoked practice rejected","CONSENT_REQUIRED",()->engine.lesson("job-contribution-v1",false));
    rejects("revoked submission rejected","CONSENT_REQUIRED",()->engine.submit(gen,7,UUID.randomUUID().toString(),"job-contribution-v1","300",true));
    rejects("revoked progress denied","CONSENT_REQUIRED",engine::progress);
    ok("revoked profile remains inspectable",!engine.inspect().consent);
    ok("repeat revoke is idempotent",engine.consent(gen,7,false).revision==7);
    HumanLearningEngine.Profile restored=engine.consent(gen,7,true);ok("explicit reconsent stored",restored.consent&&restored.revision==8);
    memory.writeFail=true;fails("failed write not reported saved",()->engine.update(gen,8,brief));memory.writeFail=false;
    ok("failed write leaves persisted revision",engine.inspect().revision==8);
    memory.readFail=true;fails("read fault does not invent empty record",engine::inspect);memory.readFail=false;
    gate.set(false);rejects("expired session cannot read","OWNER_UNLOCK_REQUIRED",engine::inspect);rejects("expired session cannot delete","OWNER_UNLOCK_REQUIRED",()->engine.delete(gen,8,true));gate.set(true);
    rejects("delete requires confirmation","CONFIRMATION_REQUIRED",()->engine.delete(gen,8,false));
    memory.deleteFail=true;fails("delete error not reported success",()->engine.delete(gen,8,true));memory.deleteFail=false;ok("failed delete retains record",engine.inspect().revision==8);
    byte[] intact=memory.bytes.clone();memory.bytes=Arrays.copyOf(intact,intact.length-1);fails("truncated record fails",engine::inspect);
    memory.bytes=Arrays.copyOf(intact,intact.length+1);fails("trailing bytes fail",engine::inspect);
    memory.bytes=intact.clone();memory.bytes[0]^=1;rejects("wrong record version fails","INVALID_RECORD",engine::inspect);
    memory.bytes=new byte[HumanLearningEngine.MAX_BYTES+1];rejects("oversize record fails","INVALID_RECORD",engine::inspect);memory.bytes=intact;
    engine.delete(gen,8,true);rejects("deleted profile absent","NO_PROFILE",engine::inspect);
    HumanLearningEngine.Profile fresh=engine.create(true,brief);ok("recreation changes generation",!fresh.generation.equals(gen));
    rejects("stale predeletion request cannot hit recreated record","REVISION_CONFLICT",()->engine.update(gen,1,brief));
    // Fill a bounded history without claiming 200 separate product tests.
    HumanLearningEngine.Profile current=fresh;
    for(int i=0;i<200;i++)current=engine.submit(current.generation,current.revision,UUID.randomUUID().toString(),"job-contribution-v1","300",true);
    final HumanLearningEngine.Profile full=current;
    rejects("history bound fails without discarding records","ATTEMPT_LIMIT",()->engine.submit(full.generation,full.revision,UUID.randomUUID().toString(),"job-contribution-v1","300",true));
    ok("all bounded records preserved",engine.inspect().attempts.size()==200);
    List<String> refs=Arrays.asList("test receipt"),details=Arrays.asList("detail 1","detail 2","detail 3"),warnings=Arrays.asList("retain warning"),blockers=Arrays.asList("retain blocker");
    for(String detail:Arrays.asList("brief","standard","detailed")){
      String text=HumanLearningEngine.renderUpdate(pref(detail,true,"optional"),"staged","Source tested.","Test phone.",refs,details,blockers,warnings,"Example deadline");
      ok(detail+" response starts with outcome",text.startsWith("Prepared, not deployed: Source tested. Next: Test phone."));
      ok(detail+" safety and evidence retained",text.contains("Warning: retain warning")&&text.contains("Blocker: retain blocker")&&text.contains("Deadline: Example deadline")&&text.contains("Evidence: test receipt"));
      ok(detail+" detail limit correct",text.contains("detail 1")==!detail.equals("brief")&&text.contains("detail 3")==detail.equals("detailed"));
    }
    rejects("unreferenced completion rejected","EVIDENCE_REQUIRED",()->HumanLearningEngine.renderUpdate(brief,"completed","Done","Check",EMPTY,EMPTY,EMPTY,EMPTY,null));
    rejects("unknown status rejected","INVALID_INPUT",()->HumanLearningEngine.renderUpdate(brief,"perfect","Done","Check",refs,EMPTY,EMPTY,EMPTY,null));
    rejects("too many references rejected","INVALID_INPUT",()->HumanLearningEngine.renderUpdate(brief,"staged","Done","Check",Collections.nCopies(13,"x"),EMPTY,EMPTY,EMPTY,null));
    String[][] aliases={{"Atlas deep sink everything!","deep_sync"},{"  ATLAS   RED TEAM FORGED. ","red_team_forge"},{"Do it!","continue_current_task"},{"draft only","draft_only"},{"do not execute","draft_only"}};
    for(String[] a:aliases)ok("alias "+a[0],a[1].equals(HumanLearningEngine.recognize(a[0])));
    ok("quoted text not executed",HumanLearningEngine.recognize("\"do it\"")==null);
    ok("mixed instructions not guessed",HumanLearningEngine.recognize("do it and send all files")==null);
    ok("consequential target not guessed",HumanLearningEngine.recognize("send $100 to Atlas")==null);
    KeyGenerator kg=KeyGenerator.getInstance("AES");kg.init(256);SecretKey key=kg.generateKey();byte[] plain="synthetic learning record".getBytes(java.nio.charset.StandardCharsets.UTF_8);
    byte[] cipher=LearningCipher.encrypt(plain,key);ok("cipher roundtrip",Arrays.equals(plain,LearningCipher.decrypt(cipher,key)));
    ok("encryption uses fresh nonce",!Arrays.equals(cipher,LearningCipher.encrypt(plain,key)));
    ok("ciphertext does not expose plaintext",!new String(cipher,java.nio.charset.StandardCharsets.ISO_8859_1).contains("synthetic learning"));
    byte[] tampered=cipher.clone();tampered[tampered.length-1]^=1;fails("tampered ciphertext denied",()->LearningCipher.decrypt(tampered,key));
    fails("wrong key denied",()->LearningCipher.decrypt(cipher,kg.generateKey()));
    fails("truncated envelope denied",()->LearningCipher.decrypt(Arrays.copyOf(cipher,20),key));
    byte[] wrongVersion=cipher.clone();wrongVersion[0]^=1;fails("wrong envelope version denied",()->LearningCipher.decrypt(wrongVersion,key));
    fails("oversize encryption denied",()->LearningCipher.encrypt(new byte[HumanLearningEngine.MAX_BYTES+1],key));
    fails("oversize decryption denied",()->LearningCipher.decrypt(new byte[HumanLearningEngine.MAX_BYTES+33],key));
    Memory revokeDuringRead=new Memory(){public byte[] read()throws Exception{byte[] x=super.read();gate.set(false);return x;}};revokeDuringRead.bytes=intact.clone();gate.set(true);
    rejects("revocation during read suppresses response","OWNER_UNLOCK_REQUIRED",()->new HumanLearningEngine(revokeDuringRead,gate::get).inspect());
    System.out.println("HUMAN_LEARNING_JAVA="+count+"/"+count+" PASS");
  }
}
