package com.sbh.atlasos;
public final class ActionAuthorizationPolicyTest {
  private static int n=0;
  private static final String A="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
  private static final String B="bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
  private static void yes(boolean v,String m){n++;if(!v)throw new AssertionError(m);}
  private static void no(boolean v,String m){n++;if(v)throw new AssertionError(m);}
  private static boolean valid(boolean auth,long issued,long now,long ttl,long eg,long ag,String et,String at,String ep,String ap,boolean used){
    return ActionAuthorizationPolicy.isFreshAndBound(auth,issued,now,ttl,eg,ag,et,at,ep,ap,used);
  }
  public static void main(String[] args){
    yes(valid(true,1000,1500,1000,7,7,A,A,B,B,false),"valid bound approval");
    no(valid(false,1000,1500,1000,7,7,A,A,B,B,false),"owner auth required");
    no(valid(true,1000,2501,1000,7,7,A,A,B,B,false),"expired");
    no(valid(true,1000,900,1000,7,7,A,A,B,B,false),"clock rollback");
    no(valid(true,1000,1500,ActionAuthorizationPolicy.MAX_TTL_MS+1,7,7,A,A,B,B,false),"ttl cap");
    no(valid(true,1000,1500,1000,7,8,A,A,B,B,false),"generation bound");
    no(valid(true,1000,1500,1000,7,7,A,B,B,B,false),"target bound");
    no(valid(true,1000,1500,1000,7,7,A,A,B,A,false),"payload bound");
    no(valid(true,1000,1500,1000,7,7,"A", "A",B,B,false),"canonical sha256 required");
    no(valid(true,1000,1500,1000,7,7,A,A,B,B,true),"single-use consumed");
    System.out.println("ActionAuthorizationPolicyTest PASS "+n);
  }
}
