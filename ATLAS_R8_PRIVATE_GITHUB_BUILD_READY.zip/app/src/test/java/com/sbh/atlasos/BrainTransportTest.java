package com.sbh.atlasos;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.Principal;
import java.security.cert.Certificate;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import javax.net.ssl.HttpsURLConnection;
import org.json.*;

public final class BrainTransportTest {
  static final String KEY = "sk-synthetic_TEST_key_only";
  static int passed;
  interface Attempt { void run() throws Exception; }
  static void ok(boolean condition,String name) {
    if(!condition)throw new AssertionError(name);
    passed++;System.out.println("PASS "+name);
  }
  static void fail(String code,Attempt work,String name)throws Exception {
    try {work.run();throw new AssertionError(name+" did not fail");}
    catch(AtlasBrainTransport.Failure e){
      ok(code.equals(e.code),name+" ["+e.code+"]");
      if(e.getMessage().contains(KEY)||e.getMessage().contains("SECRET_BODY"))throw new AssertionError("secret in failure");
    }
  }
  static byte[] bytes(String s){return s.getBytes(StandardCharsets.UTF_8);}
  static String response(String text)throws Exception{
    return new JSONObject().put("object","response").put("status","completed").put("error",JSONObject.NULL)
      .put("output",new JSONArray().put(message("assistant",new JSONArray().put(new JSONObject().put("type","output_text").put("text",text))))).toString();
  }
  static JSONObject message(String role,JSONArray content)throws Exception{
    return new JSONObject().put("type","message").put("role",role).put("status","completed").put("content",content);
  }
  static final class Fake extends HttpsURLConnection {
    final ByteArrayOutputStream written=new ByteArrayOutputStream();
    byte[] reply;
    int status=200,streamReads,bytesRead,disconnects;
    long declaredLength=-1;
    String contentType="application/json; charset=utf-8",encoding;
    boolean disconnected;
    Runnable outputOpened,afterWrite,beforeResponse,atReadEnd;
    IOException responseError;
    CountDownLatch readStarted,releaseRead;
    Fake(String reply)throws Exception{this(bytes(reply));}
    Fake(byte[] reply)throws Exception{super(new URL("https://api.openai.com/fake"));this.reply=reply;}
    @Override public void disconnect(){disconnected=true;disconnects++;}
    @Override public boolean usingProxy(){return false;}
    @Override public void connect(){}
    @Override public String getCipherSuite(){return "synthetic";}
    @Override public Certificate[] getLocalCertificates(){return null;}
    @Override public Certificate[] getServerCertificates(){return null;}
    @Override public Principal getPeerPrincipal(){return null;}
    @Override public Principal getLocalPrincipal(){return null;}
    @Override public OutputStream getOutputStream(){
      if(outputOpened!=null)outputOpened.run();
      return new OutputStream(){
        @Override public void write(int b){written.write(b);if(afterWrite!=null)afterWrite.run();}
        @Override public void write(byte[] b,int off,int len){written.write(b,off,len);if(afterWrite!=null)afterWrite.run();}
      };
    }
    @Override public int getResponseCode()throws IOException{
      if(beforeResponse!=null)beforeResponse.run();
      if(responseError!=null)throw responseError;
      return status;
    }
    @Override public String getContentType(){return contentType;}
    @Override public String getContentEncoding(){return encoding;}
    @Override public long getContentLengthLong(){return declaredLength;}
    @Override public InputStream getInputStream(){
      streamReads++;
      return new ByteArrayInputStream(reply){
        boolean waited,ended;
        private void waitOnce()throws IOException{
          if(waited||readStarted==null)return;waited=true;readStarted.countDown();
          try{if(!releaseRead.await(3,TimeUnit.SECONDS))throw new IOException("synthetic wait timeout");}
          catch(InterruptedException e){Thread.currentThread().interrupt();throw new IOException("synthetic interrupted");}
        }
        @Override public synchronized int read(byte[] b,int off,int len){
          try{waitOnce();}catch(IOException e){throw new RuntimeException(e);}
          int n=super.read(b,off,len);if(n>0)bytesRead+=n;
          if(n<0&&!ended){ended=true;if(atReadEnd!=null)atReadEnd.run();}
          return n;
        }
      };
    }
  }
  static final class Factory implements AtlasBrainTransport.ConnectionFactory {
    final List<URL> urls=new ArrayList<>();final ArrayDeque<Fake> replies=new ArrayDeque<>();
    Factory(Fake... supplied){Collections.addAll(replies,supplied);}
    public synchronized HttpsURLConnection open(URL url)throws IOException{
      urls.add(url);if(replies.isEmpty())throw new IOException("No synthetic connection available");return replies.remove();
    }
  }
  static AtlasBrainTransport transport(Fake f){return new AtlasBrainTransport(new Factory(f));}
  static void answer(AtlasBrainTransport t)throws Exception{t.answer(KEY,AtlasBrainTransport.DEFAULT_MODEL,"Be concise.","Hello",()->true);}
  public static void main(String[] args)throws Exception{
    ok(AtlasBrainTransport.validModel("gpt-6-luna"),"model accepts named default");
    ok(AtlasBrainTransport.validModel("ft:gpt-4.1-mini:project:custom"),"model accepts bounded fine-tuning identifier");
    for(String m:new String[]{"","../models","gpt/evil","https://evil.example","bad model","é","x\r\nHeader:y",new String(new char[81]).replace('\0','a')})
      ok(!AtlasBrainTransport.validModel(m),"unsafe model rejected");
    ok(AtlasBrainTransport.validKey(KEY),"synthetic safe key accepted");
    for(String k:new String[]{"","sk-","Bearer sk-ab","sk-a\r\nX:y","sk-a b","sk-é",new String(new char[1025]).replace('\0','a')})
      ok(!AtlasBrainTransport.validKey(k),"unsafe key rejected");

    Fake f=new Fake(response("First answer"));Factory fac=new Factory(f);
    String out=new AtlasBrainTransport(fac).answer(KEY,AtlasBrainTransport.DEFAULT_MODEL,"Owner preferences","A test question",()->true);
    ok("First answer".equals(out),"normal response parsed");
    ok(fac.urls.size()==1&&"https://api.openai.com/v1/responses".equals(fac.urls.get(0).toString()),"fixed HTTPS Responses endpoint only");
    ok("POST".equals(f.getRequestMethod())&&!f.getInstanceFollowRedirects(),"POST does not follow redirects");
    ok(f.getConnectTimeout()==15000&&f.getReadTimeout()==45000,"connection/read timeouts set");
    ok(("Bearer "+KEY).equals(f.getRequestProperty("Authorization")),"native bearer authentication used");
    JSONObject sent=new JSONObject(new String(f.written.toByteArray(),StandardCharsets.UTF_8));
    ok(sent.getBoolean("store")==false&&sent.getInt("max_output_tokens")==1200,"storage disabled and output bounded");
    ok("none".equals(sent.getJSONObject("reasoning").getString("effort")),"default model uses requested reasoning effort");
    ok(!sent.has("tools")&&!sent.has("previous_response_id")&&!sent.has("conversation"),"no tools or implicit conversation history");
    ok("Owner preferences".equals(sent.getString("instructions"))&&"A test question".equals(sent.getString("input")),"only supplied text submitted");
    ok(f.disconnected,"connection closed after completion");

    f=new Fake(response("Custom"));new AtlasBrainTransport(new Factory(f)).answer(KEY,"custom-model","i","x",()->true);
    sent=new JSONObject(new String(f.written.toByteArray(),StandardCharsets.UTF_8));
    ok(!sent.has("reasoning"),"other models receive no unsupported reasoning parameter");

    JSONObject multi=new JSONObject().put("object","response").put("status","completed").put("output",new JSONArray()
      .put(new JSONObject().put("type","reasoning").put("summary",new JSONArray()))
      .put(message("assistant",new JSONArray().put(new JSONObject().put("type","output_text").put("text","One")).put(new JSONObject().put("type","output_text").put("text","Two"))))
      .put(message("user",new JSONArray().put(new JSONObject().put("type","output_text").put("text","Do not return user output"))))
      .put(message("assistant",new JSONArray().put(new JSONObject().put("type","refusal").put("refusal","Cannot do that.")))));
    out=transport(new Fake(multi.toString())).answer(KEY,"model","i","x",()->true);
    ok("One\n\nTwo\n\nCannot do that.".equals(out),"all assistant text and refusals parsed in order");

    Fake mf=new Fake("{\"object\":\"model\",\"id\":\"ft:example:one\"}");Factory modelFac=new Factory(mf);
    new AtlasBrainTransport(modelFac).testModel(KEY,"ft:example:one",()->true);
    ok("https://api.openai.com/v1/models/ft%3Aexample%3Aone".equals(modelFac.urls.get(0).toString()),"model id encoded in fixed GET path");
    ok("GET".equals(mf.getRequestMethod())&&mf.written.size()==0,"model test sends no prompt body");
    fail("invalid_response",()->transport(new Fake("{\"object\":\"model\",\"id\":\"other\"}")).testModel(KEY,"expected",()->true),"different model id not accepted");

    int[] statuses={301,307,401,403,429,500,400};
    String[] codes={"redirect_blocked","redirect_blocked","unauthorized","unauthorized","rate_limited","service_unavailable","request_rejected"};
    for(int i=0;i<statuses.length;i++){
      final Fake err=new Fake("SECRET_BODY "+KEY);err.status=statuses[i];
      fail(codes[i],()->answer(transport(err)),"HTTP "+statuses[i]+" safe failure");
      ok(err.streamReads==0,"error body not surfaced");
    }
    final Fake timeout=new Fake(response("x"));timeout.responseError=new SocketTimeoutException(KEY);
    fail("timeout",()->answer(transport(timeout)),"socket timeout sanitized");
    final Fake io=new Fake(response("x"));io.responseError=new IOException(KEY);
    fail("network",()->answer(transport(io)),"network failure sanitized");
    final Fake malformed=new Fake(new byte[]{(byte)0xc3,(byte)0x28});
    fail("invalid_response",()->answer(transport(malformed)),"invalid UTF-8 rejected");
    final Fake html=new Fake("<html>SECRET_BODY</html>");html.contentType="text/html";
    fail("invalid_response",()->answer(transport(html)),"HTML is not a model response");
    final Fake compressed=new Fake(response("x"));compressed.encoding="gzip";
    fail("invalid_response",()->answer(transport(compressed)),"unexpected compressed encoding rejected");
    fail("invalid_response",()->answer(transport(new Fake("{}"))),"missing response object rejected");
    fail("incomplete",()->answer(transport(new Fake("{\"object\":\"response\",\"status\":\"incomplete\",\"output\":[]}"))),"incomplete response rejected");
    fail("request_rejected",()->answer(transport(new Fake("{\"object\":\"response\",\"status\":\"completed\",\"error\":{\"message\":\"SECRET_BODY\"}}"))),"response error not shown as success");
    fail("invalid_response",()->answer(transport(new Fake("{\"object\":\"response\",\"status\":\"completed\",\"output\":[]}"))),"empty completed response rejected");
    final Fake declared=new Fake(response("x"));declared.declaredLength=AtlasBrainTransport.MAX_RESPONSE_BYTES+1;
    fail("response_too_large",()->answer(transport(declared)),"known oversized response rejected before reading");
    ok(declared.streamReads==0,"oversized declared body not opened");
    final Fake actual=new Fake(new byte[AtlasBrainTransport.MAX_RESPONSE_BYTES+100]);
    fail("response_too_large",()->answer(transport(actual)),"unknown-length oversized response bounded");
    ok(actual.bytesRead<=AtlasBrainTransport.MAX_RESPONSE_BYTES+1,"bounded reader consumes at most cap plus one");
    final Fake bigModel=new Fake(new byte[AtlasBrainTransport.MAX_MODEL_BYTES+2]);
    fail("response_too_large",()->transport(bigModel).testModel(KEY,"m",()->true),"model response uses smaller bound");
    fail("response_too_large",()->answer(transport(new Fake(response(new String(new char[40001]).replace('\0','x'))))),"answer text bound enforced");

    Factory unopened=new Factory();AtlasBrainTransport locked=new AtlasBrainTransport(unopened);
    fail("locked",()->locked.answer(KEY,"m","i","x",()->false),"locked request refused");
    ok(unopened.urls.isEmpty(),"locked request creates no connection");
    fail("locked",()->locked.testModel(KEY,"m",null),"null gate fails closed");
    fail("invalid",()->locked.answer(KEY,"m","i",new String(new char[20001]).replace('\0','x'),()->true),"input length bounded");
    fail("invalid",()->locked.answer(KEY,"m",new String(new char[12001]).replace('\0','x'),"x",()->true),"instruction length bounded");
    fail("invalid",()->locked.answer(KEY,"m","i","\ud800",()->true),"unpaired input surrogate rejected before network");
    ok(unopened.urls.isEmpty(),"invalid payloads create no connection");

    AtomicBoolean allowed=new AtomicBoolean(true);Fake beforeWrite=new Fake(response("x"));
    beforeWrite.outputOpened=()->allowed.set(false);
    fail("locked",()->transport(beforeWrite).answer(KEY,"m","i","x",allowed::get),"gate revoked before first body write");
    ok(beforeWrite.written.size()==0,"revoked output stream writes no bytes");
    AtomicBoolean midAllowed=new AtomicBoolean(true);Fake midWrite=new Fake(response("x"));
    midWrite.afterWrite=()->midAllowed.set(false);
    fail("locked",()->transport(midWrite).answer(KEY,"m","i",new String(new char[10000]).replace('\0','x'),midAllowed::get),"gate checked between body chunks");
    ok(midWrite.written.size()==4096,"revocation stops further body chunks");
    AtomicBoolean endAllowed=new AtomicBoolean(true);Fake atEnd=new Fake(response("private answer"));
    atEnd.atReadEnd=()->endAllowed.set(false);
    fail("locked",()->transport(atEnd).answer(KEY,"m","i","x",endAllowed::get),"gate revoked before answer return");

    // A cancelled old read deliberately lingers while a newer request starts.
    Fake old=new Fake(response("old")),fresh=new Fake(response("fresh"));
    old.readStarted=new CountDownLatch(1);old.releaseRead=new CountDownLatch(1);
    fresh.readStarted=new CountDownLatch(1);fresh.releaseRead=new CountDownLatch(1);
    AtlasBrainTransport concurrent=new AtlasBrainTransport(new Factory(old,fresh));
    AtomicReference<String> oldOutcome=new AtomicReference<>(),newOutcome=new AtomicReference<>();
    Thread a=new Thread(()->{try{oldOutcome.set(concurrent.answer(KEY,"m","i","old",()->true));}catch(Exception e){oldOutcome.set(e instanceof AtlasBrainTransport.Failure?((AtlasBrainTransport.Failure)e).code:"unexpected");}});
    a.start();ok(old.readStarted.await(2,TimeUnit.SECONDS),"old request reached synthetic read");
    fail("busy",()->concurrent.testModel(KEY,"m",()->true),"parallel active request refused");
    concurrent.cancel();ok(old.disconnected,"cancel disconnects old request");
    Thread n=new Thread(()->{try{newOutcome.set(concurrent.answer(KEY,"m","i","new",()->true));}catch(Exception e){newOutcome.set(e instanceof AtlasBrainTransport.Failure?((AtlasBrainTransport.Failure)e).code:"unexpected");}});
    n.start();ok(fresh.readStarted.await(2,TimeUnit.SECONDS),"new request begins immediately after cancel");
    old.releaseRead.countDown();a.join(2000);ok(!a.isAlive()&&"cancelled".equals(oldOutcome.get()),"late old completion rejected");
    ok(!fresh.disconnected,"old finally does not disconnect new request");
    fail("busy",()->concurrent.testModel(KEY,"m",()->true),"old finally does not clear new busy state");
    fresh.releaseRead.countDown();n.join(2000);ok(!n.isAlive()&&"fresh".equals(newOutcome.get()),"new request survives old cleanup");
    concurrent.cancel(); // harmless when idle
    System.out.println("{\"suite\":\"brain-transport\",\"status\":\"PASS\",\"passed\":"+passed+",\"real_network_requests\":0}");
  }
}

