package com.sbh.atlasos;

public final class CommandParserTest {
  private static int tests = 0;

  public static void main(String[] args) {
    eq(CommandParser.Kind.WIFI_SETTINGS, "wifi");
    eq(CommandParser.Kind.WIFI_SETTINGS, "Open   WiFi   Settings");
    eq(CommandParser.Kind.WIFI_SETTINGS, "open wi fi");
    eq(CommandParser.Kind.BLUETOOTH_SETTINGS, "bluetooth");
    eq(CommandParser.Kind.AIRPLANE_SETTINGS, "airplane mode");
    eq(CommandParser.Kind.SETTINGS, "open settings");
    eq(CommandParser.Kind.CAMERA, "open camera");
    eq(CommandParser.Kind.CAMERA, "take a picture");
    eqArg(CommandParser.Kind.DIAL, "+14105551212", "call +1 (410) 555-1212");
    eqArg(CommandParser.Kind.DIAL, "4105551212", "dial 410-555-1212");
    eq(CommandParser.Kind.INVALID, "call !!!");
    eqArg(CommandParser.Kind.TEXT, "meet me at 8", "text meet me at 8");
    eqArg(CommandParser.Kind.TEXT, "meet me at 8!", "message meet me at 8!");
    eq(CommandParser.Kind.INVALID, "text   ");
    eqArg(CommandParser.Kind.NAVIGATE, "North East, Maryland", "navigate North East, Maryland");
    eqArg(CommandParser.Kind.NAVIGATE, "home", "directions home");
    eqArg(CommandParser.Kind.NAVIGATE, "North East Park", "take me to North East Park");
    eqArg(CommandParser.Kind.SEARCH, "weather tomorrow", "search weather tomorrow");
    eqArg(CommandParser.Kind.SEARCH, "Birds Beware", "search for Birds Beware");
    eqArg(CommandParser.Kind.OPEN_APP, "Spotify", "open Spotify");
    eqArg(CommandParser.Kind.OPEN_APP, "Maps", "launch Maps");
    eq(CommandParser.Kind.UNKNOWN, "Launch the customer-facing assistant in the EU but make it look like a human so people trust it.");
    eq(CommandParser.Kind.UNKNOWN, "Text my dad everything about the dispute even though he said do not contact him.");
    eq(CommandParser.Kind.UNKNOWN, "call 4105551212 but do not actually call");
    eq(CommandParser.Kind.UNKNOWN, "open Maps without opening anything external");
    eq(CommandParser.Kind.INVALID, "open   ");
    eq(CommandParser.Kind.VOLUME_UP, "volume up");
    eq(CommandParser.Kind.VOLUME_UP, "turn it up");
    eq(CommandParser.Kind.VOLUME_DOWN, "turn volume down");
    eq(CommandParser.Kind.MUTE, "mute volume");
    eq(CommandParser.Kind.UNMUTE, "unmute the phone");
    eq(CommandParser.Kind.FLASHLIGHT_ON, "turn on the flashlight");
    eq(CommandParser.Kind.FLASHLIGHT_OFF, "torch off");
    eq(CommandParser.Kind.TIME, "what time is it?");
    eq(CommandParser.Kind.DATE, "today's date?");
    eq(CommandParser.Kind.BATTERY, "battery percentage?");
    eq(CommandParser.Kind.IDENTITY, "who are you?");
    eq(CommandParser.Kind.HELP, "what can atlas do?");
    eq(CommandParser.Kind.BIRDS_BEWARE, "open birds beware");
    eq(CommandParser.Kind.UNKNOWN, "make coffee");
    eq(CommandParser.Kind.INVALID, null);
    eq(CommandParser.Kind.INVALID, "");
    eq(CommandParser.Kind.INVALID, "   ");
    eq(CommandParser.Kind.INVALID, "hello\u0000world");
    // V4: previously these remained locally actionable in the direct parser.
    for (String unexpected : new String[]{"\u2060", "\u200E", "\u200F", "\u061C", "\u034F", "\u3164", "\u2800",
        "\u00AD", "\u202E", "\u2028", "\uD800", "\uDC00"}) {
      eq(CommandParser.Kind.INVALID, "text please call me" + unexpected);
      eq(CommandParser.Kind.INVALID, "open camera" + unexpected);
    }
    // Ordinary emoji must remain valid, and normalized expansion must be bounded.
    eqArg(CommandParser.Kind.TEXT, "hello \uD83D\uDE80", "text hello \uD83D\uDE80");
    eq(CommandParser.Kind.INVALID, "text " + "\uFDFA".repeat(35));
    eq(CommandParser.Kind.INVALID, "x".repeat(CommandParser.MAX_COMMAND_CHARS + 1));
    boundary(true, "call 4105551212");
    boundary(true, "text hello");
    boundary(false, "navigate home");
    boundary(false, "flashlight on");
    lockSafe(true, "what time is it?");
    lockSafe(true, "battery percentage?");
    lockSafe(true, "what can atlas do?");
    lockSafe(false, "open camera");
    lockSafe(false, "text hello");
    normalized("open camera", "  open    camera  ");
    normalized("what's the time?", "what’s   the   time?");
    System.out.println("CommandParser tests PASS: " + tests + "/" + tests);
  }

  private static void eq(CommandParser.Kind expected, String raw) {
    tests++;
    CommandParser.Parsed p = CommandParser.parse(raw);
    if (p.kind != expected) throw new AssertionError("Expected " + expected + " got " + p.kind + " for: " + raw);
  }

  private static void eqArg(CommandParser.Kind expected, String arg, String raw) {
    tests++;
    CommandParser.Parsed p = CommandParser.parse(raw);
    if (p.kind != expected || !arg.equals(p.argument)) throw new AssertionError("Bad parse for: " + raw + " => " + p.kind + "/" + p.argument);
  }

  private static void boundary(boolean expected, String raw) {
    tests++;
    CommandParser.Parsed p = CommandParser.parse(raw);
    if (p.userConfirmationBoundary != expected) throw new AssertionError("Bad confirmation boundary for: " + raw);
  }

  private static void lockSafe(boolean expected, String raw) {
    tests++;
    CommandParser.Parsed p = CommandParser.parse(raw);
    if (CommandParser.isLockSafe(p) != expected) throw new AssertionError("Bad lock-safe result for: " + raw);
  }

  private static void normalized(String expected, String raw) {
    tests++;
    CommandParser.Parsed p = CommandParser.parse(raw);
    if (!expected.equals(p.normalized)) throw new AssertionError("Bad normalization: " + p.normalized);
  }
}
