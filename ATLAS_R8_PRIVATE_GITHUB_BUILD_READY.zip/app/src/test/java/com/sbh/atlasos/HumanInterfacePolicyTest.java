package com.sbh.atlasos;

public final class HumanInterfacePolicyTest {
  private static int n=0;
  private static void yes(boolean v,String m){n++;if(!v)throw new AssertionError(m);}
  private static void no(boolean v,String m){n++;if(v)throw new AssertionError(m);}
  private static void eq(Object e,Object a,String m){n++;if(e==null?a!=null:!e.equals(a))throw new AssertionError(m+" expected="+e+" actual="+a);}
  private static HumanInterfacePolicy.Input in(HumanInterfacePolicy.ExecutionPhase p){
    return new HumanInterfacePolicy.Input(p,HumanInterfacePolicy.RiskLevel.UNSPECIFIED,false,0.0,false,false,false,HumanInterfacePolicy.SensorState.unknown());
  }
  private static AuthenticatedInputRouter.Result route(String s,boolean auth,boolean backend){
    return AuthenticatedInputRouter.route(s,WorkflowIntentParser.Origin.UI_TEXT,auth,false,backend);
  }
  public static void main(String[] args){
    eq(HumanInterfacePolicy.ExpressiveState.CALM,HumanInterfacePolicy.render(HumanInterfacePolicy.Input.idle()).expressiveState,"default calm");
    eq(HumanInterfacePolicy.ExpressiveState.FOCUSED,HumanInterfacePolicy.render(in(HumanInterfacePolicy.ExecutionPhase.EXECUTING)).expressiveState,"executing focused");
    eq(HumanInterfacePolicy.ExpressiveState.SATISFIED,HumanInterfacePolicy.render(in(HumanInterfacePolicy.ExecutionPhase.DONE)).expressiveState,"done satisfied");
    eq(HumanInterfacePolicy.ExpressiveState.BLOCKED,HumanInterfacePolicy.render(in(HumanInterfacePolicy.ExecutionPhase.BLOCKED)).expressiveState,"blocked");
    eq(HumanInterfacePolicy.ExpressiveState.RECOVERING,HumanInterfacePolicy.render(in(HumanInterfacePolicy.ExecutionPhase.RECOVERING)).expressiveState,"recovering");

    HumanInterfacePolicy.Input critical=new HumanInterfacePolicy.Input(HumanInterfacePolicy.ExecutionPhase.IDLE,HumanInterfacePolicy.RiskLevel.CRITICAL,false,0,false,false,false,HumanInterfacePolicy.SensorState.unknown());
    HumanInterfacePolicy.Output alert=HumanInterfacePolicy.render(critical);
    eq(HumanInterfacePolicy.ExpressiveState.ALERT,alert.expressiveState,"critical alert");
    yes(alert.confirmationRequired,"critical confirmation");
    yes(alert.pitchMultiplier<=1.0&&alert.speechRate<=1.0,"alert not cheerful/high-speed");

    HumanInterfacePolicy.Input high=new HumanInterfacePolicy.Input(HumanInterfacePolicy.ExecutionPhase.IDLE,HumanInterfacePolicy.RiskLevel.HIGH,false,0,false,false,false,HumanInterfacePolicy.SensorState.unknown());
    eq(HumanInterfacePolicy.ExpressiveState.CONCERNED,HumanInterfacePolicy.render(high).expressiveState,"high concerned");

    HumanInterfacePolicy.Input lowConfidence=new HumanInterfacePolicy.Input(HumanInterfacePolicy.ExecutionPhase.THINKING,HumanInterfacePolicy.RiskLevel.UNSPECIFIED,true,0.2,false,false,false,HumanInterfacePolicy.SensorState.unknown());
    eq(HumanInterfacePolicy.ExpressiveState.UNCERTAIN,HumanInterfacePolicy.render(lowConfidence).expressiveState,"known low confidence uncertain");
    HumanInterfacePolicy.Input unknownConfidence=new HumanInterfacePolicy.Input(HumanInterfacePolicy.ExecutionPhase.THINKING,HumanInterfacePolicy.RiskLevel.UNSPECIFIED,false,0.0,false,false,false,HumanInterfacePolicy.SensorState.unknown());
    eq(HumanInterfacePolicy.ExpressiveState.CALM,HumanInterfacePolicy.render(unknownConfidence).expressiveState,"unknown confidence not fabricated");

    HumanInterfacePolicy.Input research=new HumanInterfacePolicy.Input(HumanInterfacePolicy.ExecutionPhase.THINKING,HumanInterfacePolicy.RiskLevel.UNSPECIFIED,false,0,true,false,false,HumanInterfacePolicy.SensorState.unknown());
    eq(HumanInterfacePolicy.ExpressiveState.CURIOUS,HumanInterfacePolicy.render(research).expressiveState,"research curious");

    boolean threw=false;try{new HumanInterfacePolicy.Input(HumanInterfacePolicy.ExecutionPhase.IDLE,HumanInterfacePolicy.RiskLevel.LOW,true,1.1,false,false,false,HumanInterfacePolicy.SensorState.unknown());}catch(IllegalArgumentException e){threw=true;}yes(threw,"invalid high confidence rejected");
    threw=false;try{new HumanInterfacePolicy.Input(HumanInterfacePolicy.ExecutionPhase.IDLE,HumanInterfacePolicy.RiskLevel.LOW,true,-0.1,false,false,false,HumanInterfacePolicy.SensorState.unknown());}catch(IllegalArgumentException e){threw=true;}yes(threw,"invalid low confidence rejected");

    for(HumanInterfacePolicy.ExecutionPhase p:HumanInterfacePolicy.ExecutionPhase.values()){
      for(HumanInterfacePolicy.RiskLevel r:HumanInterfacePolicy.RiskLevel.values()){
        HumanInterfacePolicy.Output o=HumanInterfacePolicy.render(new HumanInterfacePolicy.Input(p,r,false,0,false,false,false,HumanInterfacePolicy.SensorState.unknown()));
        no(o.authorityChangeAllowed,"never grants authority");
        no(o.emotionDiagnosisAllowed,"never diagnoses emotion");
        no(o.consciousnessClaimAllowed,"never claims consciousness");
        eq(p==HumanInterfacePolicy.ExecutionPhase.EXECUTING,o.showProgressAnimation,"progress only executing");
      }
    }

    eq("UNKNOWN",HumanInterfacePolicy.render(HumanInterfacePolicy.Input.idle()).privacyIndicator,"unknown sensors stay unknown");
    eq("OFF",HumanInterfacePolicy.render(new HumanInterfacePolicy.Input(HumanInterfacePolicy.ExecutionPhase.IDLE,HumanInterfacePolicy.RiskLevel.UNSPECIFIED,false,0,false,false,false,HumanInterfacePolicy.SensorState.known(false,false,false))).privacyIndicator,"known sensors off");
    eq("ACTIVE:MIC+CAMERA+NEURAL-SENSOR",HumanInterfacePolicy.render(new HumanInterfacePolicy.Input(HumanInterfacePolicy.ExecutionPhase.IDLE,HumanInterfacePolicy.RiskLevel.UNSPECIFIED,false,0,false,false,false,HumanInterfacePolicy.SensorState.known(true,true,true))).privacyIndicator,"sensor indicators");

    HumanInterfacePolicy.Output normalExec=HumanInterfacePolicy.render(in(HumanInterfacePolicy.ExecutionPhase.EXECUTING));
    HumanInterfacePolicy.Output quietExec=HumanInterfacePolicy.render(new HumanInterfacePolicy.Input(HumanInterfacePolicy.ExecutionPhase.EXECUTING,HumanInterfacePolicy.RiskLevel.UNSPECIFIED,false,0,false,true,false,HumanInterfacePolicy.SensorState.unknown()));
    yes(quietExec.energy<=normalExec.energy,"quiet lowers energy");
    eq("confirm",HumanInterfacePolicy.render(in(HumanInterfacePolicy.ExecutionPhase.DONE)).hapticSignal,"done confirm");
    eq("waiting",HumanInterfacePolicy.render(in(HumanInterfacePolicy.ExecutionPhase.BLOCKED)).hapticSignal,"blocked wait");

    HumanInterfacePolicy.Output locked=HumanInterfacePolicy.fromRoute(route("open camera",false,true),false,false,HumanInterfacePolicy.SensorState.unknown());
    eq(HumanInterfacePolicy.ExpressiveState.BLOCKED,locked.expressiveState,"locked route blocked");
    HumanInterfacePolicy.Output source=HumanInterfacePolicy.fromRoute(AuthenticatedInputRouter.route("ATLAS MAX",WorkflowIntentParser.Origin.REFERENCE_DATA,true,false,true),false,false,HumanInterfacePolicy.SensorState.unknown());
    eq(HumanInterfacePolicy.ExpressiveState.SATISFIED,source.expressiveState,"source data processed");
    HumanInterfacePolicy.Output localDone=HumanInterfacePolicy.fromRoute(route("open camera",true,true),true,false,HumanInterfacePolicy.SensorState.unknown());
    eq(HumanInterfacePolicy.ExpressiveState.SATISFIED,localDone.expressiveState,"completed local route");
    HumanInterfacePolicy.Output localNotRun=HumanInterfacePolicy.fromRoute(route("open camera",true,true),false,false,HumanInterfacePolicy.SensorState.unknown());
    eq(HumanInterfacePolicy.ExpressiveState.BLOCKED,localNotRun.expressiveState,"local route not run blocked");
    HumanInterfacePolicy.Output brainBlocked=HumanInterfacePolicy.fromRoute(route("Explain compound interest",true,false),false,false,HumanInterfacePolicy.SensorState.unknown());
    eq(HumanInterfacePolicy.ExpressiveState.BLOCKED,brainBlocked.expressiveState,"disconnected brain blocked");
    HumanInterfacePolicy.Output confirm=HumanInterfacePolicy.fromRoute(route("call 4105089274",true,true),false,false,HumanInterfacePolicy.SensorState.unknown());
    yes(confirm.confirmationRequired,"confirmation boundary rendered");

    AuthenticatedInputRouter.Result workflow=route("Build the app and test it",true,false);
    HumanInterfacePolicy.fromRoute(workflow,false,false,HumanInterfacePolicy.SensorState.unknown());
    no(workflow.grantsExecution,"presentation cannot mutate routing authority");
    no(workflow.shouldExecuteLocal,"presentation cannot promote workflow to local execution");

    System.out.println("HumanInterfacePolicyTest PASS "+n);
  }
}
