package com.sbh.atlasos;

public final class StorageImportPolicyTest {
  private static int checks;
  private static void yes(boolean ok){checks++;if(!ok)throw new AssertionError("case "+checks);}
  public static void main(String[] args){
    yes("resume.md".equals(StorageImportPolicy.safeName(" resume.md ")));
    yes("Birds Beware 2026.csv".equals(StorageImportPolicy.safeName("Birds Beware 2026.csv")));
    yes("my.FILE.JSON".equals(StorageImportPolicy.safeName("my.FILE.JSON")));
    yes(StorageImportPolicy.safeName(null)==null);
    yes(StorageImportPolicy.safeName(".env")==null);
    yes(StorageImportPolicy.safeName("../private.md")==null);
    yes(StorageImportPolicy.safeName("sub/secret.md")==null);
    yes(StorageImportPolicy.safeName("sub\\secret.md")==null);
    yes(StorageImportPolicy.safeName("C:secret.md")==null);
    yes(StorageImportPolicy.safeName("file..md")==null);
    yes(StorageImportPolicy.safeName("script.js")==null);
    yes(StorageImportPolicy.safeName("public.html")==null);
    yes(StorageImportPolicy.safeName("binary.exe")==null);
    yes(StorageImportPolicy.safeName("evil\u0000.md")==null);
    yes(StorageImportPolicy.safeName("evil\n.md")==null);
    yes(StorageImportPolicy.safeName("a".repeat(122)+".txt")==null);
    yes(StorageImportPolicy.declaredSizeAllowed(-1));
    yes(!StorageImportPolicy.declaredSizeAllowed(-2));
    yes(StorageImportPolicy.declaredSizeAllowed(0));
    yes(StorageImportPolicy.declaredSizeAllowed(StorageImportPolicy.MAX_DOCUMENT_BYTES));
    yes(!StorageImportPolicy.declaredSizeAllowed(StorageImportPolicy.MAX_DOCUMENT_BYTES+1));
    yes(!StorageImportPolicy.freeSpaceSafe(-1,50));
    yes(!StorageImportPolicy.freeSpaceSafe(1000,-1));
    yes(StorageImportPolicy.freeSpaceSafe(StorageImportPolicy.MAX_DOCUMENT_BYTES+StorageImportPolicy.MIN_FREE_HEADROOM_BYTES,-1));
    yes(!StorageImportPolicy.freeSpaceSafe(StorageImportPolicy.MAX_DOCUMENT_BYTES+StorageImportPolicy.MIN_FREE_HEADROOM_BYTES-1,-1));
    yes(StorageImportPolicy.freeSpaceSafe(StorageImportPolicy.MIN_FREE_HEADROOM_BYTES,0));
    System.out.println("StorageImportPolicy "+checks+"/"+checks+" PASS");
  }
}
