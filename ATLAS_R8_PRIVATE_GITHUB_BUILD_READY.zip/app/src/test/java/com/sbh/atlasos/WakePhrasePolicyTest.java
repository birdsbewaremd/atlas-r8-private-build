package com.sbh.atlasos;
public final class WakePhrasePolicyTest {
  private static int tests=0;
  public static void main(String[] args){
    cmd("","hey atlas"); cmd("open camera","Hey Atlas open camera"); cmd("open maps","hey, atlas open maps"); cmd("open camera","  HEY   ATLAS,   open camera ");
    cmd("open camera","OK Atlas open camera"); cmd("open camera","Okay Atlas, open camera"); cmd("","ok atlas"); cmd("","okay atlas");
    cmd("volume up","hey atlas: volume up"); cmd("search weather","hey atlas — search weather"); cmd("open camera","hey atlas! open camera");
    cmd("open camera","hey atlas? open camera"); cmd("open camera","hey atlas. open camera"); cmd("open camera","hey atlas; open camera");
    reject("not hey atlas open camera"); reject("okay hey atlas open camera"); reject("please ok atlas open camera"); reject("the video said hey atlas open camera");
    reject("okay atlasing open camera"); reject("hey atlasing open camera"); reject(null); reject("hello\u0000hey atlas"); reject("x".repeat(WakePhrasePolicy.MAX_TRANSCRIPT_CHARS+1));
    execute(true,"open camera",null,1000,0); execute(true,"open camera","volume up",1000,900); execute(false,"open camera","open camera",2000,1000);
    execute(true,"open camera","open camera",4000,1000); execute(true,"open camera","open camera",500,1000); execute(false,"","",4000,1000);
    System.out.println("WakePhrasePolicy tests PASS: "+tests+"/"+tests);
  }
  private static void cmd(String e,String r){tests++;String a=WakePhrasePolicy.extractCommand(r);if(!e.equals(a))throw new AssertionError("Expected '"+e+"' got '"+a+"' for "+r);}
  private static void reject(String r){tests++;if(WakePhrasePolicy.extractCommand(r)!=null)throw new AssertionError("Expected rejection: "+r);}
  private static void execute(boolean e,String c,String l,long n,long a){tests++;boolean x=WakePhrasePolicy.shouldExecute(c,l,n,a);if(x!=e)throw new AssertionError("Dedupe mismatch: "+c);}
}
