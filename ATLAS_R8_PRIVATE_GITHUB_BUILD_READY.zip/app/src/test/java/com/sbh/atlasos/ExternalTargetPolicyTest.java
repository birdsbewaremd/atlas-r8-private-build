package com.sbh.atlasos;
import java.util.*;

public final class ExternalTargetPolicyTest {
  private static int n=0;
  private static void yes(boolean v,String m){n++; if(!v) throw new AssertionError(m);}
  private static void no(boolean v,String m){n++; if(v) throw new AssertionError(m);}
  public static void main(String[] args){
    Set<String> a=new HashSet<>(Arrays.asList(
      "https://example.com/api/task",
      "https://example.com/api/next",
      "https://birdsbewaremd.com/"
    ));
    yes(ExternalTargetPolicy.isExactTargetAllowed("https://EXAMPLE.com/api/task",a),"host case canonical");
    yes(ExternalTargetPolicy.isExactTargetAllowed("https://example.com:443/api/task",a),"default TLS port canonical");
    no(ExternalTargetPolicy.isExactTargetAllowed("https://example.com/api/other",a),"path substitution");
    no(ExternalTargetPolicy.isExactTargetAllowed("https://sub.example.com/api/task",a),"subdomain substitution");
    no(ExternalTargetPolicy.isExactTargetAllowed("http://example.com/api/task",a),"scheme downgrade");
    no(ExternalTargetPolicy.isExactTargetAllowed("https://evil.com/api/task",a),"different host");
    no(ExternalTargetPolicy.isExactTargetAllowed("https://u:p@example.com/api/task",a),"userinfo forbidden");
    no(ExternalTargetPolicy.isExactTargetAllowed("not a uri",a),"invalid uri");
    no(ExternalTargetPolicy.isExactTargetAllowed("https://example.com/api/task#x",a),"fragment forbidden");
    no(ExternalTargetPolicy.isExactTargetAllowed("https://example.com:444/api/task",a),"non-default port");
    no(ExternalTargetPolicy.isExactTargetAllowed("https://localhost/api/task",a),"localhost forbidden");
    no(ExternalTargetPolicy.isExactTargetAllowed("https://127.0.0.1/api/task",a),"IPv4 literal forbidden");
    no(ExternalTargetPolicy.isExactTargetAllowed("https://[::1]/api/task",a),"IPv6 literal forbidden");
    no(ExternalTargetPolicy.isExactTargetAllowed("https://example.com/api/../api/task",a),"dot-segment alias forbidden");
    no(ExternalTargetPolicy.isExactTargetAllowed("https://example.com\\@evil.com/api/task",a),"backslash parser ambiguity forbidden");
    yes(ExternalTargetPolicy.isRedirectChainAllowed(Arrays.asList(
      "https://example.com/api/task","https://example.com/api/next"),a),"explicit redirect chain");
    no(ExternalTargetPolicy.isRedirectChainAllowed(Arrays.asList(
      "https://example.com/api/task","https://short.example/x","https://example.com/api/next"),a),"unlisted shortener hop");
    no(ExternalTargetPolicy.isRedirectChainAllowed(Arrays.asList(
      "https://example.com/api/task","https://example.com/api/task"),a),"redirect cycle");
    no(ExternalTargetPolicy.isRedirectChainAllowed(Arrays.asList(
      "https://example.com/api/task","https://example.com/api/next","https://birdsbewaremd.com/","https://example.com/api/task","https://example.com/api/next"),a),"redirect hop ceiling");
    System.out.println("ExternalTargetPolicyTest PASS "+n);
  }
}
