package com.sbh.atlasos;

import java.io.*;
import java.nio.file.*;
import java.security.GeneralSecurityException;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Real host JCE encryption, not Android Keystore or an installed-device test. */
public final class VaultFileCodecTest {
  interface Test { void run() throws Exception; }
  private static int passed;
  private static Path root;
  private static SecretKey key;
  private static final VaultFileCodec.Authorization ALLOW = () -> true;
  private static final byte[] SAMPLE = "synthetic private vault test; not Shaun's data".getBytes(java.nio.charset.StandardCharsets.UTF_8);

  private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
  private static void run(String name, Test test) throws Exception {
    test.run(); passed++; System.out.println("PASS " + name);
  }
  private static void rejects(Class<? extends Exception> type, Test action) throws Exception {
    try { action.run(); }
    catch (Exception error) { if (type.isInstance(error)) return; throw error; }
    throw new AssertionError("expected " + type.getSimpleName());
  }
  private static Path fresh() { return root.resolve("new-" + UUID.randomUUID() + ".atlasenc"); }
  private static byte[] encrypt(byte[] plain) throws Exception {
    Path out = fresh();
    long n = VaultFileCodec.encryptNew(new ByteArrayInputStream(plain), out.toFile(), key, plain.length, ALLOW);
    check(n == plain.length, "wrong byte count");
    return Files.readAllBytes(out);
  }
  private static byte[] decode(byte[] encrypted, int limit) throws Exception {
    return VaultFileCodec.decrypt(new ByteArrayInputStream(encrypted), key, limit, ALLOW);
  }
  private static byte[] archive() throws Exception {
    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
    try (ZipOutputStream zip = new ZipOutputStream(bytes)) {
      zip.putNextEntry(new ZipEntry("folder/note.txt")); zip.write(SAMPLE); zip.closeEntry();
      zip.putNextEntry(new ZipEntry("empty.txt")); zip.closeEntry();
    }
    return bytes.toByteArray();
  }
  private static List<Path> children(Path p) throws IOException {
    try (java.util.stream.Stream<Path> stream = Files.list(p)) {
      List<Path> result = new ArrayList<>(); stream.forEach(result::add); return result;
    }
  }
  private static class ShortReads extends FilterInputStream {
    boolean returnZero = true;
    ShortReads(InputStream input) { super(input); }
    @Override public int read(byte[] b, int off, int len) throws IOException {
      if (returnZero && len > 0) { returnZero = false; return 0; }
      returnZero = true; return super.read(b, off, Math.min(1, len));
    }
  }

  public static void main(String[] args) throws Exception {
    root = Files.createTempDirectory("atlas-real-crypto-");
    KeyGenerator generator = KeyGenerator.getInstance("AES"); generator.init(256); key = generator.generateKey();
    try {
      run("roundtrip empty, chunk-boundary and 1MiB inputs", () -> {
        for (int length : new int[]{0,1,15,16,17,1024,65535,65536,65537,VaultFileCodec.TEXT_LIMIT}) {
          byte[] data = new byte[length]; new Random(length).nextBytes(data);
          check(Arrays.equals(data,decode(encrypt(data),length)),"roundtrip " + length);
        }
      });
      run("ATL1 header and provider-generated 12-byte IV", () -> {
        byte[] encoded=encrypt(SAMPLE);
        check(encoded[0]=='A'&&encoded[1]=='T'&&encoded[2]=='L'&&encoded[3]=='1'&&encoded[4]==12,"header");
        check(encoded.length==SAMPLE.length+33,"format size");
      });
      run("same plaintext encrypts differently", () -> {
        byte[] a=encrypt(SAMPLE),b=encrypt(SAMPLE);
        check(!Arrays.equals(Arrays.copyOfRange(a,5,17),Arrays.copyOfRange(b,5,17)),"IV reused");
        check(!Arrays.equals(a,b),"ciphertext repeated");
      });
      run("legacy ATL1 file remains readable", () -> {
        byte[] iv=new byte[12];new java.security.SecureRandom().nextBytes(iv);
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key,new GCMParameterSpec(128,iv));
        ByteArrayOutputStream out=new ByteArrayOutputStream();out.write(new byte[]{'A','T','L','1',12});out.write(iv);out.write(c.doFinal(SAMPLE));
        check(Arrays.equals(SAMPLE,decode(out.toByteArray(),1000)),"legacy decode");
      });
      run("all prefixes of a truncated file reject", () -> {
        byte[] valid=encrypt(SAMPLE);
        for(int cut=0;cut<valid.length;cut++){
          final byte[] truncated=Arrays.copyOf(valid,cut);
          rejects(Exception.class,()->decode(truncated,1000));
        }
      });
      run("tampered magic rejects", () -> {byte[] b=encrypt(SAMPLE);b[0]^=1;rejects(IOException.class,()->decode(b,1000));});
      run("invalid IV lengths reject", () -> {
        for(int n:new int[]{0,1,11,33,127,255}){byte[] b=encrypt(SAMPLE);b[4]=(byte)n;rejects(IOException.class,()->decode(b,1000));}
      });
      run("tampered IV fails authentication", () -> {byte[] b=encrypt(SAMPLE);b[5]^=1;rejects(AEADBadTagException.class,()->decode(b,1000));});
      run("tampered ciphertext fails authentication", () -> {byte[] b=encrypt(SAMPLE);b[18]^=1;rejects(AEADBadTagException.class,()->decode(b,1000));});
      run("tampered tag fails authentication", () -> {byte[] b=encrypt(SAMPLE);b[b.length-1]^=1;rejects(AEADBadTagException.class,()->decode(b,1000));});
      run("wrong key fails authentication", () -> {
        byte[] b=encrypt(SAMPLE);SecretKey other=generator.generateKey();
        rejects(AEADBadTagException.class,()->VaultFileCodec.decrypt(new ByteArrayInputStream(b),other,1000,ALLOW));
      });
      run("appended garbage rejects", () -> {byte[] b=encrypt(SAMPLE);rejects(AEADBadTagException.class,()->decode(Arrays.copyOf(b,b.length+1),1000));});
      run("over-limit read rejects before plaintext return", () -> {
        byte[] b=encrypt(SAMPLE);rejects(VaultFileCodec.SizeLimitException.class,()->decode(b,SAMPLE.length-1));
      });
      run("read limit rejects after at most one excess ciphertext byte", () -> {
        byte[] b=encrypt(new byte[4096]);
        class Counted extends ByteArrayInputStream {int count;Counted(){super(b);}
          @Override public synchronized int read(){int n=super.read();if(n>=0)count++;return n;}
          @Override public synchronized int read(byte[] a,int o,int l){int n=super.read(a,o,l);if(n>0)count+=n;return n;}}
        Counted in=new Counted();rejects(VaultFileCodec.SizeLimitException.class,()->VaultFileCodec.decrypt(in,key,128,ALLOW));
        check(in.count<=17+128+16+1,"unbounded ciphertext read");
      });
      run("existing file is neither replaced nor deleted", () -> {
        Path p=fresh();Files.write(p,SAMPLE);
        rejects(FileAlreadyExistsException.class,()->VaultFileCodec.encryptNew(new ByteArrayInputStream(SAMPLE),p.toFile(),key,1000,ALLOW));
        check(Arrays.equals(Files.readAllBytes(p),SAMPLE),"existing file changed");
      });
      run("symlink destination does not alter its target", () -> {
        Path target=fresh(),link=fresh();Files.write(target,SAMPLE);Files.createSymbolicLink(link,target);
        rejects(FileAlreadyExistsException.class,()->VaultFileCodec.encryptNew(new ByteArrayInputStream(SAMPLE),link.toFile(),key,1000,ALLOW));
        check(Arrays.equals(SAMPLE,Files.readAllBytes(target))&&Files.isSymbolicLink(link),"symlink/target changed");
      });
      run("write overflow removes only newly created output", () -> {
        Path p=fresh();rejects(VaultFileCodec.SizeLimitException.class,()->VaultFileCodec.encryptNew(new ByteArrayInputStream(SAMPLE),p.toFile(),key,1,ALLOW));
        check(!Files.exists(p),"partial output left");
      });
      run("read exception removes newly created output", () -> {
        Path p=fresh();InputStream bad=new InputStream(){@Override public int read()throws IOException{throw new IOException("synthetic source failure");}};
        rejects(IOException.class,()->VaultFileCodec.encryptNew(bad,p.toFile(),key,1000,ALLOW));check(!Files.exists(p),"failed output left");
      });
      run("denied authorization creates no file", () -> {
        Path p=fresh();rejects(IOException.class,()->VaultFileCodec.encryptNew(new ByteArrayInputStream(SAMPLE),p.toFile(),key,1000,()->false));
        check(!Files.exists(p),"locked writer created a file");
      });
      run("authorization loss during encryption removes partial output", () -> {
        Path p=fresh();AtomicBoolean active=new AtomicBoolean(true);
        InputStream in=new ByteArrayInputStream(new byte[70000]){@Override public synchronized int read(byte[] b,int o,int n){int got=super.read(b,o,n);active.set(false);return got;}};
        rejects(IOException.class,()->VaultFileCodec.encryptNew(in,p.toFile(),key,100000,active::get));check(!Files.exists(p),"revoked output left");
      });
      run("denied authorization returns no plaintext", () -> {
        byte[] b=encrypt(SAMPLE);rejects(IOException.class,()->VaultFileCodec.decrypt(new ByteArrayInputStream(b),key,1000,()->false));
      });
      run("authorization loss during decryption returns no plaintext", () -> {
        byte[] b=encrypt(SAMPLE);AtomicBoolean active=new AtomicBoolean(true);
        InputStream in=new ByteArrayInputStream(b){@Override public synchronized int read(byte[] a,int o,int n){int got=super.read(a,o,n);if(pos>=b.length)active.set(false);return got;}};
        rejects(IOException.class,()->VaultFileCodec.decrypt(in,key,1000,active::get));
      });
      run("zero and short reads do not silently truncate encryption", () -> {
        Path p=fresh();VaultFileCodec.encryptNew(new ShortReads(new ByteArrayInputStream(SAMPLE)),p.toFile(),key,1000,ALLOW);
        check(Arrays.equals(SAMPLE,decode(Files.readAllBytes(p),1000)),"short-read encryption");
      });
      run("zero and short reads do not silently truncate decryption", () -> {
        byte[] b=encrypt(SAMPLE);check(Arrays.equals(SAMPLE,VaultFileCodec.decrypt(new ShortReads(new ByteArrayInputStream(b)),key,1000,ALLOW)),"short-read decode");
      });
      run("invalid encryption budgets reject without output", () -> {
        for(long limit:new long[]{-1,Long.MAX_VALUE}){Path p=fresh();rejects(IllegalArgumentException.class,()->VaultFileCodec.encryptNew(new ByteArrayInputStream(SAMPLE),p.toFile(),key,limit,ALLOW));check(!Files.exists(p),"invalid budget output");}
      });
      run("invalid bridge budgets reject", () -> {
        byte[] b=encrypt(SAMPLE);for(int limit:new int[]{-1,Integer.MAX_VALUE,VaultFileCodec.IMAGE_LIMIT+1})rejects(IllegalArgumentException.class,()->decode(b,limit));
      });
      run("caller input stream stays open", () -> {
        class Owned extends ByteArrayInputStream{boolean closed;Owned(byte[] b){super(b);}@Override public void close(){closed=true;}}
        Owned plain=new Owned(SAMPLE);Path p=fresh();VaultFileCodec.encryptNew(plain,p.toFile(),key,1000,ALLOW);check(!plain.closed,"input closed during encrypt");
        Owned encoded=new Owned(Files.readAllBytes(p));VaultFileCodec.decrypt(encoded,key,1000,ALLOW);check(!encoded.closed,"input closed during decode");
      });
      run("transactional ZIP import uses real encryption for each file", () -> {
        Path dir=Files.createTempDirectory(root,"real-import-");File vault=dir.resolve("vault").toFile();
        TransactionalSeedImporter.Result result=TransactionalSeedImporter.importNew(new ByteArrayInputStream(archive()),dir.toFile(),vault,
          (in,out,limit)->VaultFileCodec.encryptNew(in,out,key,limit,ALLOW),()->true);
        check(result.files==2&&result.bytes==SAMPLE.length,"import totals");
        byte[] note=Files.readAllBytes(vault.toPath().resolve(result.directory).resolve("folder/note.txt.atlasenc"));
        check(Arrays.equals(SAMPLE,decode(note,1000)),"import decrypted content");check(!Arrays.equals(SAMPLE,note),"plaintext written");
        check(decode(Files.readAllBytes(vault.toPath().resolve(result.directory).resolve("empty.txt.atlasenc")),0).length==0,"empty imported file");
      });
      run("truncated ZIP rolls back real encrypted writes", () -> {
        Path dir=Files.createTempDirectory(root,"truncated-");Path vault=Files.createDirectory(dir.resolve("vault"));Path sentinel=vault.resolve("existing.atlasenc");Files.write(sentinel,SAMPLE);
        byte[] zip=archive();rejects(IOException.class,()->TransactionalSeedImporter.importNew(new ByteArrayInputStream(Arrays.copyOf(zip,zip.length-10)),dir.toFile(),vault.toFile(),
          (in,out,limit)->VaultFileCodec.encryptNew(in,out,key,limit,ALLOW),()->true));
        check(Arrays.equals(SAMPLE,Files.readAllBytes(sentinel)),"original changed");check(children(vault).size()==1&&children(dir).size()==1,"staging/commit left");
      });
      run("mid-import session loss does not publish encrypted files", () -> {
        Path dir=Files.createTempDirectory(root,"revoked-import-");Path vault=Files.createDirectory(dir.resolve("vault"));AtomicBoolean active=new AtomicBoolean(true);
        rejects(IOException.class,()->TransactionalSeedImporter.importNew(new ByteArrayInputStream(archive()),dir.toFile(),vault.toFile(),(in,out,limit)->{
          long n=VaultFileCodec.encryptNew(in,out,key,limit,active::get);active.set(false);return n;
        },active::get));check(children(vault).isEmpty()&&children(dir).size()==1,"revoked import published");
      });
      System.out.println("VAULT_REAL_CRYPTO_CASES_PASSED="+passed);
      System.out.println("CRYPTO_PROVIDER="+Cipher.getInstance("AES/GCM/NoPadding").getProvider().getName());
      System.out.println("ANDROID_KEYSTORE_EXECUTED=false");
    } finally {
      try(java.util.stream.Stream<Path> paths=Files.walk(root)){paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(IOException e){throw new java.io.UncheckedIOException(e);}});}
    }
  }
}
