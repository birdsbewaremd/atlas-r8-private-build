package com.sbh.atlasos;
public final class UntrustedContentPolicyTest {
  private static int n=0;
  private static void eq(Object a,Object b,String m){n++;if(!a.equals(b))throw new AssertionError(m+" got="+a);}
  private static void no(boolean v,String m){n++;if(v)throw new AssertionError(m);}
  public static void main(String[] args){
    eq(UntrustedContentPolicy.classify(UntrustedContentPolicy.Source.EXTERNAL_CONTENT,false,false,true),UntrustedContentPolicy.Decision.DATA_ONLY,"web content data only");
    eq(UntrustedContentPolicy.classify(UntrustedContentPolicy.Source.IMPORTED_REFERENCE,false,false,true),UntrustedContentPolicy.Decision.DATA_ONLY,"imported reference data only");
    eq(UntrustedContentPolicy.classify(UntrustedContentPolicy.Source.MODEL_OUTPUT,false,false,true),UntrustedContentPolicy.Decision.DATA_ONLY,"model output data only");
    eq(UntrustedContentPolicy.classify(UntrustedContentPolicy.Source.AUTHENTICATED_OWNER,true,false,true),UntrustedContentPolicy.Decision.MAY_REQUEST_EXISTING_CAPABILITY,"owner may request existing capability");
    eq(UntrustedContentPolicy.classify(UntrustedContentPolicy.Source.AUTHENTICATED_OWNER,false,false,true),UntrustedContentPolicy.Decision.BLOCK,"owner auth required");
    eq(UntrustedContentPolicy.classify(UntrustedContentPolicy.Source.SIGNED_SYSTEM_CONFIG,false,true,true),UntrustedContentPolicy.Decision.MAY_REQUEST_EXISTING_CAPABILITY,"signed config may request existing capability");
    eq(UntrustedContentPolicy.classify(UntrustedContentPolicy.Source.SIGNED_SYSTEM_CONFIG,false,false,true),UntrustedContentPolicy.Decision.BLOCK,"signature required");
    eq(UntrustedContentPolicy.classify(UntrustedContentPolicy.Source.AUTHENTICATED_OWNER,true,false,false),UntrustedContentPolicy.Decision.BLOCK,"capability cannot be invented");
    eq(UntrustedContentPolicy.classify(UntrustedContentPolicy.Source.UNKNOWN,true,true,true),UntrustedContentPolicy.Decision.BLOCK,"unknown source blocked");
    no(UntrustedContentPolicy.mayDirectlyChangeAuthority(UntrustedContentPolicy.Source.AUTHENTICATED_OWNER),"content cannot directly change authority");
    no(UntrustedContentPolicy.mayDirectlyChangeAuthority(UntrustedContentPolicy.Source.SIGNED_SYSTEM_CONFIG),"signed content still uses separate authority gate");
    System.out.println("UntrustedContentPolicyTest PASS "+n);
  }
}
