package com.sbh.atlasos;

/** Isolated synthetic tests; production integrations and real limits are untested. */
public final class RequestRecoveryPolicyTest {
  private static int assertions=0;
  private static void ck(boolean ok,String message){assertions++;if(!ok)throw new AssertionError(message);}
  private static RequestRecoveryPolicy.Event e(int status,String code,int prior,
      String retryAfter,long remaining,long jitter,boolean online,boolean session,
      boolean proof,boolean idem,boolean readOnly,boolean partial){
    return new RequestRecoveryPolicy.Event(status,code,prior,retryAfter,remaining,jitter,
      online,session,proof,idem,readOnly,partial);
  }
  private static RequestRecoveryPolicy.Result normal(int status,String code,int prior,String after){
    return RequestRecoveryPolicy.evaluate(e(status,code,prior,after,100000L,0L,
      true,true,true,true,true,false));
  }
  private static void action(RequestRecoveryPolicy.Event event,RequestRecoveryPolicy.Action a,String why){
    RequestRecoveryPolicy.Result result=RequestRecoveryPolicy.evaluate(event);
    ck(result.action==a,why+": "+result.reason);
    ck(!result.grantsAccess,"rate handling must never elevate access");
  }
  public static void main(String[]args){
    RequestRecoveryPolicy.Action RETRY=RequestRecoveryPolicy.Action.RETRY_AFTER;
    RequestRecoveryPolicy.Action PARK=RequestRecoveryPolicy.Action.PARK;
    RequestRecoveryPolicy.Action STOP=RequestRecoveryPolicy.Action.STOP;
    RequestRecoveryPolicy.Action DONE=RequestRecoveryPolicy.Action.COMPLETE;
    action(e(429,"slow_down",0,null,100000,0,true,true,true,true,true,false),RETRY,"first 429 retry");
    ck(normal(429,"slow_down",0,null).delayMs==1000L,"first attempt delay");
    ck(normal(429,"rate_limit_error",2,"5").delayMs==5000L,"server minimum 5 seconds");
    ck(normal(429,"slow_down",1,"1").delayMs==2000L,"backoff dominates shorter minimum");
    ck(normal(503,"server_is_overloaded",3,"20").delayMs==20000L,"503 retry after");
    action(e(503,"server_is_overloaded",4,null,100000,0,true,true,true,true,true,false),PARK,"attempt exhaustion");
    action(e(429,"insufficient_quota",0,null,100000,0,true,true,true,true,true,false),STOP,"quota not retried");
    action(e(429,"billing_hard_limit_reached",0,null,100000,0,true,true,true,true,true,false),STOP,"billing not retried");
    action(e(429,"rate_limit_error",0,"61",100000,0,true,true,true,true,true,false),PARK,"respect >max delay");
    action(e(429,"rate_limit_error",0,"60",100000,0,true,true,true,true,true,false),RETRY,"retry after 60s within cap");
    action(e(429,"rate_limit_error",0,"60",40000,0,true,true,true,true,true,false),PARK,"total deadline");
    action(e(429,"slow_down",0,"Fri, 11 Oct 2026 04:00:00 GMT",100000,0,true,true,true,true,true,false),PARK,"HTTP date parsed by transport");
    action(e(429,"rate_limit_error",0,"-1",100000,0,true,true,true,true,true,false),PARK,"invalid header no retry");
    action(e(429,"rate_limit_error",0,"9999999999999",100000,0,true,true,true,true,true,false),PARK,"huge header no retry");
    action(e(429,"other",0,null,100000,0,true,true,true,true,true,false),PARK,"unknown 429 code");
    action(e(503,"other",0,null,100000,0,true,true,true,true,true,false),PARK,"unknown 503 code");
    action(e(400,"bad_request",0,null,100000,0,true,true,true,true,true,false),STOP,"client error non retry");
    action(e(401,"unauthorized",0,null,100000,0,true,true,true,true,true,false),STOP,"auth error non retry");
    action(e(403,"forbidden",0,null,100000,0,true,true,true,true,true,false),STOP,"policy denial non retry");
    action(e(500,"unknown",0,null,100000,0,true,true,true,true,true,false),STOP,"500 not auto replayed");
    action(e(429,"slow_down",0,null,100000,0,false,true,true,true,true,false),PARK,"offline must park");
    action(e(429,"slow_down",0,null,100000,0,true,false,true,true,true,false),PARK,"expired session must park");
    action(e(429,"slow_down",0,null,100000,0,true,true,false,true,true,false),PARK,"unbound proof must park");
    action(e(429,"slow_down",0,null,100000,0,true,true,true,false,true,false),STOP,"nonidempotent cannot replay");
    action(e(429,"slow_down",0,null,100000,0,true,true,true,true,false,false),STOP,"write cannot replay");
    action(e(429,"slow_down",0,null,100000,0,true,true,true,true,true,true),STOP,"partial stream cannot replay");
    action(e(200,"",0,null,100000,0,true,true,true,true,true,false),DONE,"success acknowledges");
    action(e(200,"",0,null,100000,0,true,false,true,true,true,false),PARK,"locked success cannot be exposed");
    action(e(429,"slow_down",-1,null,100000,0,true,true,true,true,true,false),STOP,"invalid prior count");
    action(e(429,"slow_down",0,null,-1,0,true,true,true,true,true,false),STOP,"invalid deadline");
    action(e(429,"slow_down",0,null,100000,1001,true,true,true,true,true,false),STOP,"invalid jitter");
    action(null,STOP,"null event");
    ck(normal(429,"slow_down",0,null).delayMs==1000L,"deterministic first delay");
    ck(RequestRecoveryPolicy.evaluate(e(429,"slow_down",1,null,100000,500,true,true,true,true,true,false)).delayMs==2500L,"bounded jitter");
    ck(RequestRecoveryPolicy.parseRetryAfterMs("0")==0L,"zero valid");
    ck(RequestRecoveryPolicy.parseRetryAfterMs("001")==1000L,"leading zeros valid");
    ck(RequestRecoveryPolicy.parseRetryAfterMs("1.5")==-1L,"fraction unsupported");
    ck(RequestRecoveryPolicy.parseRetryAfterMs("9999999999999")==-1L,"overflow guard");
    System.out.println("RequestRecoveryPolicyTest: "+assertions+"/"+assertions+" PASS");
  }
}
