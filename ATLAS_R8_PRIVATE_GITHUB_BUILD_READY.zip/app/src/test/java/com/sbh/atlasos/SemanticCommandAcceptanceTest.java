package com.sbh.atlasos;

import java.util.Arrays;
import java.util.List;

/** Generated from the owner-reviewed 40-case semantic acceptance specification. */
public final class SemanticCommandAcceptanceTest {
  private static final class Case {
    final String input;
    final WorkflowIntentParser.Recognition recognition;
    final List<String> stack;
    Case(String input, WorkflowIntentParser.Recognition recognition, String[] stack) {
      this.input = input;
      this.recognition = recognition;
      this.stack = Arrays.asList(stack);
    }
  }

  private static final Case[] CASES = new Case[]{
    new Case("Make this message 1 million times better and go over it again.", WorkflowIntentParser.Recognition.COMBINED, new String[]{"ATLAS MAX", "ATLAS MESSAGE FORGE", "ATLAS FINAL PASS"}),
    new Case("Do it better than last time but keep the price and phone number exactly the same.", WorkflowIntentParser.Recognition.COMBINED, new String[]{"ATLAS MAX", "ATLAS LOCK X", "ATLAS NO REGRESSION"}),
    new Case("Price this gutter cleaning job.", WorkflowIntentParser.Recognition.MATCHED, new String[]{"PRICE THIS"}),
    new Case("Build the app, test it, and don't break anything already working.", WorkflowIntentParser.Recognition.COMBINED, new String[]{"ATLAS APP BUILD", "ATLAS BUILD", "ATLAS NO REGRESSION", "ATLAS VERIFY"}),
    new Case("Research everything relevant about this and tell me the truth.", WorkflowIntentParser.Recognition.COMBINED, new String[]{"ATLAS RESEARCH", "ATLAS FULL COVERAGE", "HARD TRUTH MODE"}),
    new Case("From now on, when I say clean close, summarize what got done, what failed, and the exact next move. Make it a command.", WorkflowIntentParser.Recognition.CREATED, new String[]{"ATLAS COMMANDIZE"}),
    new Case("What's 2 plus 2?", WorkflowIntentParser.Recognition.NORMAL_REQUEST, new String[]{}),
    new Case("Google my business profile.", WorkflowIntentParser.Recognition.NORMAL_REQUEST, new String[]{}),
    new Case("Atlas, make my cat Atlas smarter.", WorkflowIntentParser.Recognition.COMBINED, new String[]{"ATLAS RESEARCH", "ATLAS DECIDE"}),
    new Case("Deep sink everything and keep it short.", WorkflowIntentParser.Recognition.COMBINED, new String[]{"ATLAS DEEP SYNC", "EVERYTHING", "ATLAS SHORT"}),
    new Case("Draft the customer message but don't send it.", WorkflowIntentParser.Recognition.COMBINED, new String[]{"CUSTOMER REPLY", "ASK FIRST"}),
    new Case("Publish this now.", WorkflowIntentParser.Recognition.PARTIAL_MATCH, new String[]{"ATLAS INTENT CHECK"}),
    new Case("Make this the best possible version.", WorkflowIntentParser.Recognition.MATCHED, new String[]{"ATLAS MAX"}),
    new Case("Red team forged googol this.", WorkflowIntentParser.Recognition.MATCHED, new String[]{"ATLAS MAX"}),
    new Case("Check it one more time and only change real problems.", WorkflowIntentParser.Recognition.MATCHED, new String[]{"ATLAS FINAL PASS"}),
    new Case("Find the real answer using current sources.", WorkflowIntentParser.Recognition.COMBINED, new String[]{"ATLAS RESEARCH", "ATLAS VERIFY"}),
    new Case("What is the best chess move here?", WorkflowIntentParser.Recognition.MATCHED, new String[]{"ATLAS DECIDE"}),
    new Case("Make this sound like me but more professional.", WorkflowIntentParser.Recognition.COMBINED, new String[]{"ATLAS MESSAGE FORGE", "ATLAS IN MY VOICE", "PROFESSIONAL"}),
    new Case("Keep everything the same except the opening sentence.", WorkflowIntentParser.Recognition.MATCHED, new String[]{"KEEP EVERYTHING THE SAME EXCEPT X"}),
    new Case("Remember this rule for future chats.", WorkflowIntentParser.Recognition.MATCHED, new String[]{"REMEMBER THIS"}),
    new Case("Show me every command.", WorkflowIntentParser.Recognition.MATCHED, new String[]{"ATLAS COMMANDS"}),
    new Case("Tell me the actual current status.", WorkflowIntentParser.Recognition.COMBINED, new String[]{"ATLAS STATUS", "ATLAS CURRENT"}),
    new Case("Fix the website and verify the live domain.", WorkflowIntentParser.Recognition.COMBINED, new String[]{"WEBSITE MODE", "WEBSITE FORGE", "ATLAS VERIFY"}),
    new Case("Should I buy this equipment?", WorkflowIntentParser.Recognition.COMBINED, new String[]{"DO I BUY IT?", "ATLAS DECIDE"}),
    new Case("Make a customer estimate from these photos.", WorkflowIntentParser.Recognition.MATCHED, new String[]{"ESTIMATE THIS"}),
    new Case("Save a checkpoint so I can continue later.", WorkflowIntentParser.Recognition.MATCHED, new String[]{"ATLAS CHECKPOINT"}),
    new Case("Pause this and handle the new emergency first.", WorkflowIntentParser.Recognition.MATCHED, new String[]{"INTERRUPT"}),
    new Case("Add this without dropping anything I already told you.", WorkflowIntentParser.Recognition.COMBINED, new String[]{"ADD THIS TOO", "ATLAS NO REGRESSION"}),
    new Case("Use all my relevant history and files.", WorkflowIntentParser.Recognition.COMBINED, new String[]{"USE MEMORY", "USE LIBRARY", "USE SHAUN OS"}),
    new Case("Make a public-safe version.", WorkflowIntentParser.Recognition.COMBINED, new String[]{"ATLAS PUBLIC", "ATLAS SHARE-SAFE"}),
    new Case("Lock the price at $475.", WorkflowIntentParser.Recognition.MATCHED, new String[]{"ATLAS LOCK X"}),
    new Case("Unlock only the headline.", WorkflowIntentParser.Recognition.MATCHED, new String[]{"ATLAS UNLOCK X"}),
    new Case("Give me the next highest-value move.", WorkflowIntentParser.Recognition.MATCHED, new String[]{"ATLAS NEXT MOVE"}),
    new Case("Make this shorter without losing anything important.", WorkflowIntentParser.Recognition.COMBINED, new String[]{"SHORTER", "ATLAS NO REGRESSION"}),
    new Case("Tell me the hard truth.", WorkflowIntentParser.Recognition.MATCHED, new String[]{"HARD TRUTH MODE"}),
    new Case("Continue from the newest reliable checkpoint.", WorkflowIntentParser.Recognition.MATCHED, new String[]{"ATLAS RESUME"}),
    new Case("Back this up with hashes and restore steps.", WorkflowIntentParser.Recognition.MATCHED, new String[]{"ATLAS RED BUTTON"}),
    new Case("Check for security risks without changing anything.", WorkflowIntentParser.Recognition.MATCHED, new String[]{"ATLAS SENTINEL"}),
    new Case("Make this a repeatable command called Clean Close.", WorkflowIntentParser.Recognition.CREATED, new String[]{"ATLAS COMMANDIZE"}),
    new Case("I need a normal explanation of compound interest.", WorkflowIntentParser.Recognition.NORMAL_REQUEST, new String[]{})
  };

  public static void main(String[] args) {
    int assertions = 0;
    int created = 0;
    for (int i = 0; i < CASES.length; i++) {
      Case c = CASES[i];
      WorkflowIntentParser.Result parsed = WorkflowIntentParser.parse(c.input, WorkflowIntentParser.Origin.UI_TEXT);
      eq(c.recognition, parsed.requestedRecognition, "case " + (i + 1) + " recognition"); assertions++;
      eq(c.stack, parsed.commandStack, "case " + (i + 1) + " stack"); assertions++;
      check(!parsed.grantsExecution, "case " + (i + 1) + " parser cannot grant execution"); assertions++;

      AuthenticatedInputRouter.Result routed = AuthenticatedInputRouter.route(
        c.input, WorkflowIntentParser.Origin.UI_TEXT, true, false, false);
      check(!routed.grantsExecution, "case " + (i + 1) + " router cannot grant execution"); assertions++;
      if (!c.stack.isEmpty()) {
        eq(c.stack, routed.commandStack, "case " + (i + 1) + " routed stack"); assertions++;
      } else {
        check(routed.workflow.commandStack.isEmpty(), "case " + (i + 1) + " no workflow stack"); assertions++;
      }
      if (c.recognition == WorkflowIntentParser.Recognition.CREATED) {
        created++;
        eq(WorkflowIntentParser.Recognition.PARTIAL_MATCH, routed.recognition,
          "case " + (i + 1) + " unpersisted creation is partial"); assertions++;
        check(routed.constraints.contains("command_creation_not_persisted"),
          "case " + (i + 1) + " unpersisted guard"); assertions++;
        AuthenticatedInputRouter.Result confirmed = AuthenticatedInputRouter.route(
          c.input, WorkflowIntentParser.Origin.UI_TEXT, true, true, false);
        eq(WorkflowIntentParser.Recognition.CREATED, confirmed.recognition,
          "case " + (i + 1) + " persisted creation is created"); assertions++;
        check(confirmed.persistenceConfirmed, "case " + (i + 1) + " persistence confirmed"); assertions++;
      } else if (!c.stack.isEmpty()) {
        eq(c.recognition, routed.recognition, "case " + (i + 1) + " routed recognition"); assertions++;
      } else {
        check(routed.route == AuthenticatedInputRouter.Route.BRAIN_HANDOFF
            || routed.route == AuthenticatedInputRouter.Route.LOCAL_DEVICE,
          "case " + (i + 1) + " normal request route"); assertions++;
      }
    }
    eq(40, CASES.length, "case count"); assertions++;
    eq(2, created, "created case count"); assertions++;
    System.out.println("SemanticCommandAcceptanceTest: PASS cases=" + CASES.length + " assertions=" + assertions);
  }

  private static void check(boolean ok, String label) {
    if (!ok) throw new AssertionError(label);
  }
  private static void eq(Object expected, Object actual, String label) {
    if (expected == null ? actual != null : !expected.equals(actual)) {
      throw new AssertionError(label + " expected=" + expected + " actual=" + actual);
    }
  }
}
