package com.sbh.atlasos;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import javax.crypto.*;

/** Runs the actual product-photo codec and bounded-input rules with host JCE. */
public final class ProductMediaPolicyTest {
  interface Action {void run()throws Exception;}
  static int passed;
  static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);passed++;}
  static void rejects(Action a,String why)throws Exception{try{a.run();}catch(Exception expected){passed++;return;}throw new AssertionError(why);}
  public static void main(String[] args)throws Exception{
    String id="pm-0123456789abcdef0123456789abcdef",other="pm-fedcba9876543210fedcba9876543210";
    check(AtlasProductMediaStore.validId(id),"valid id");
    for(String bad:new String[]{"", "../"+id,id+"/x",id.toUpperCase()," pm-0123456789abcdef0123456789abcdef",id+"\n"})
      check(!AtlasProductMediaStore.validId(bad),"unsafe reference");
    check(!AtlasProductMediaStore.validId(null),"null reference");
    check(AtlasProductMediaStore.dimensionsAllowed(4000,3000),"normal camera dimensions");
    check(!AtlasProductMediaStore.dimensionsAllowed(16001,1),"excess edge");
    check(!AtlasProductMediaStore.dimensionsAllowed(8000,8000),"pixel bomb");
    check(!AtlasProductMediaStore.dimensionsAllowed(0,1),"empty dimensions");
    check(AtlasProductMediaStore.userMessage(new AtlasProductMediaStore.PhotoException("low_storage")).contains("32 MiB"),"accurate free-space remedy");
    check(AtlasProductMediaStore.userMessage(new AtlasProductMediaStore.PhotoException("library_full")).contains("48-image"),"accurate full-library remedy");
    check(AtlasProductMediaStore.userMessage(new AtlasProductMediaStore.PhotoException("key_unavailable")).contains("key is unavailable"),"accurate key-loss remedy");
    check(!AtlasProductMediaStore.userMessage(new IOException("PRIVATE_PROVIDER_TEXT")).contains("PRIVATE_PROVIDER_TEXT"),"provider details not exposed");
    byte[] image=new byte[4096];new Random(42).nextBytes(image);image[0]=(byte)255;image[1]=(byte)216;image[image.length-2]=(byte)255;image[image.length-1]=(byte)217;
    AtlasProductMediaStore.Entry e=new AtlasProductMediaStore.Entry(id,1000,64,64,image);
    byte[] payload=AtlasProductMediaStore.encode(e);
    check(Arrays.equals(AtlasProductMediaStore.decode(payload,id).jpeg,image),"content roundtrip");
    check(AtlasProductMediaStore.decode(payload,id).createdAt==1000,"metadata roundtrip");
    rejects(()->AtlasProductMediaStore.decode(payload,other),"renamed ciphertext must not bind another image");
    rejects(()->AtlasProductMediaStore.decode(Arrays.copyOf(payload,payload.length-1),id),"truncated image");
    rejects(()->AtlasProductMediaStore.decode(Arrays.copyOf(payload,payload.length+1),id),"trailing bytes");
    byte[] tampered=payload.clone();tampered[tampered.length-5]^=1;
    rejects(()->AtlasProductMediaStore.decode(tampered,id),"image integrity");
    rejects(()->AtlasProductMediaStore.encode(new AtlasProductMediaStore.Entry(id,1,1025,1,image)),"excess output dimensions");
    rejects(()->AtlasProductMediaStore.encode(new AtlasProductMediaStore.Entry(id,0,64,64,image)),"missing creation time");
    byte[] noJpeg=image.clone();noJpeg[0]=0;
    rejects(()->AtlasProductMediaStore.encode(new AtlasProductMediaStore.Entry(id,1,64,64,noJpeg)),"unexpected image type");
    check(Arrays.equals(image,AtlasProductMediaStore.readBounded(new ByteArrayInputStream(image),image.length,()->true)),"exact input limit");
    rejects(()->AtlasProductMediaStore.readBounded(new ByteArrayInputStream(image),image.length-1,()->true),"oversized input");
    rejects(()->AtlasProductMediaStore.readBounded(new ByteArrayInputStream(image),image.length,()->false),"unauthorized input");
    InputStream zeroStream=new ByteArrayInputStream(image){boolean first=true;public synchronized int read(byte[] b,int o,int n){if(first){first=false;return 0;}return super.read(b,o,n);}};
    check(Arrays.equals(image,AtlasProductMediaStore.readBounded(zeroStream,image.length,()->true)),"zero length provider read");
    final int[] calls={0};
    rejects(()->AtlasProductMediaStore.readBounded(new ByteArrayInputStream(image),image.length,()->++calls[0]<2),"revoked input");
    KeyGenerator generator=KeyGenerator.getInstance("AES");generator.init(256);SecretKey key=generator.generateKey();
    Path dir=Files.createTempDirectory("atlas-product-media-test-");
    try{
      File a=dir.resolve("a").toFile(),b=dir.resolve("b").toFile();
      VaultFileCodec.encryptNew(new ByteArrayInputStream(payload),a,key,AtlasProductMediaStore.MAX_PAYLOAD,()->true);
      VaultFileCodec.encryptNew(new ByteArrayInputStream(payload),b,key,AtlasProductMediaStore.MAX_PAYLOAD,()->true);
      byte[] encrypted=Files.readAllBytes(a.toPath());
      check(!Arrays.equals(encrypted,Files.readAllBytes(b.toPath())),"independent randomized ciphertext");
      byte[] plain=VaultFileCodec.decrypt(new ByteArrayInputStream(encrypted),key,AtlasProductMediaStore.MAX_PAYLOAD,()->true);
      check(Arrays.equals(image,AtlasProductMediaStore.decode(plain,id).jpeg),"authenticated codec roundtrip");
      rejects(()->AtlasProductMediaStore.decode(plain,other),"authenticated metadata image binding");
      byte[] bad=encrypted.clone();bad[bad.length-1]^=1;
      rejects(()->VaultFileCodec.decrypt(new ByteArrayInputStream(bad),key,AtlasProductMediaStore.MAX_PAYLOAD,()->true),"ciphertext authentication");
      rejects(()->VaultFileCodec.decrypt(new ByteArrayInputStream(encrypted),key,AtlasProductMediaStore.MAX_PAYLOAD,()->false),"locked image read");
      rejects(()->VaultFileCodec.encryptNew(new ByteArrayInputStream(payload),a,key,AtlasProductMediaStore.MAX_PAYLOAD,()->true),"overwrite original");
      check(Arrays.equals(encrypted,Files.readAllBytes(a.toPath())),"original file preserved");
      final int[] checks={0};File failed=dir.resolve("failed").toFile();
      rejects(()->VaultFileCodec.encryptNew(new ByteArrayInputStream(payload),failed,key,AtlasProductMediaStore.MAX_PAYLOAD,()->++checks[0]<3),"revoked write");
      check(!failed.exists(),"failed new file cleaned");
    }finally{try(java.util.stream.Stream<Path> paths=Files.walk(dir)){paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(IOException ex){throw new RuntimeException(ex);}});}}
    System.out.println("{\"suite\":\"product-media-policy\",\"status\":\"PASS\",\"passed\":"+passed+"}");
  }
}
