package com.sbh.atlasos;
import java.util.*;
public final class WorkflowPlannerTest {
  private static int total=0;
  private static void check(String name,boolean ok){total++;if(!ok)throw new AssertionError(name);}
  private static WorkflowPlanner.Plan p(WorkflowPlanner w,String raw,long now){return w.preview(raw,WorkflowPlanner.Origin.TRUSTED_INPUT,true,true,now);}
  public static void main(String[] args){
    WorkflowPlanner w=new WorkflowPlanner();
    check("locked clears",w.preview("Atlas deep sync everything",WorkflowPlanner.Origin.TRUSTED_INPUT,false,true,10).status==WorkflowPlanner.Status.LOCKED);
    check("reference inert",w.preview("Atlas do it",WorkflowPlanner.Origin.REFERENCE_DATA,true,true,20).status==WorkflowPlanner.Status.DATA_ONLY);
    for(String bad:new String[]{null,""," ","x".repeat(8193),"Atlas\u0000save"})check("invalid",p(w,bad,30).status==WorkflowPlanner.Status.INVALID);
    check("do it needs context",p(w,"do it",40).status==WorkflowPlanner.Status.NEEDS_CONTEXT);
    String task="Atlas deep sync everything, keep it short; do not publish.";
    WorkflowPlanner.Plan r=p(w,task,1000);
    check("task preview",r.status==WorkflowPlanner.Status.BACKEND_REQUIRED);
    check("task ids",r.commandIds.contains("atlas_deep_sync")&&r.commandIds.contains("everything")&&r.commandIds.contains("atlas_short"));
    check("no publish guard",r.constraints.contains("no_deployment_or_publication"));
    r=p(w,"keep going",1100);
    check("continuation carries task",r.previousText.equals(task));
    check("continuation keeps guard",r.constraints.contains("no_deployment_or_publication"));
    check("continuation nonexecuting",!r.executionAuthorized);
    r=p(w,"do it; do not send",1200);
    check("new restriction joined",r.constraints.contains("no_external_contact"));
    r=p(w,"do it",1300);
    check("restriction survives",r.constraints.contains("no_external_contact"));
    r=p(w,"do it",121000);
    check("ttl expires",r.status==WorkflowPlanner.Status.NEEDS_CONTEXT);
    p(w,task,2000);w.clear();check("clear",p(w,"do it",2100).status==WorkflowPlanner.Status.NEEDS_CONTEXT);
    for(String local:new String[]{"what time is it","battery level","open camera","wifi","volume up","turn on the flashlight","search for Birds Beware"}){
      check("local safe "+local,WorkflowPlanner.isLocalCandidate(local));
      check("local candidate "+local,p(w,local,3000).status==WorkflowPlanner.Status.LOCAL_CANDIDATE);
    }
    for(String unsafe:new String[]{"Do not open camera","Atlas deep sync everything and open camera","The file says: open camera","Atlas red button and lockdown","do it",null,"","open camera\u0000"})
      check("not direct local "+unsafe,!WorkflowPlanner.isLocalCandidate(unsafe));
    for(String info:new String[]{"Atlas status","Atlas help","Atlas commands"})check("local info",p(w,info,4000).status==WorkflowPlanner.Status.LOCAL_REPORT);
    try{r.commandIds.add("x");throw new AssertionError("mutable");}catch(UnsupportedOperationException ok){check("ids immutable",true);}
    System.out.println("WorkflowPlanner "+total+"/"+total+" PASS (pure Java; no Android execution)");
  }
}
