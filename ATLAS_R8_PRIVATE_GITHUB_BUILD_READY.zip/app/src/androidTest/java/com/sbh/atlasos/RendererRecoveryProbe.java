package com.sbh.atlasos;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import java.lang.reflect.Field;

/** Explicit callback probe, separate from successful WebView page rendering.
 * Candidate-only. Uses synthetic process-local session/picker values; never
 * enrolls a PIN, reads private records, deletes files or changes preferences.
 */
final class RendererRecoveryProbe {
  private static Object field(Object value,String name)throws Exception{Field f=value.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(value);}
  private static void field(Object value,String name,Object contents)throws Exception{Field f=value.getClass().getDeclaredField(name);f.setAccessible(true);f.set(value,contents);}
  private static void check(boolean value,String reason){if(!value)throw new AssertionError(reason);}
  private static boolean text(View view,String expected){
    if(view instanceof TextView&&expected.equals(((TextView)view).getText().toString()))return true;
    if(view instanceof ViewGroup){ViewGroup group=(ViewGroup)view;for(int i=0;i<group.getChildCount();i++)if(text(group.getChildAt(i),expected))return true;}
    return false;
  }
  static void run(Instrumentation probe){
    Bundle out=new Bundle();int[] passed={0};Throwable[] failure={null};Activity[] activity={null};boolean ok=false;
    try{
      check("com.sbh.atlasos.candidate".equals(probe.getTargetContext().getPackageName()),"candidate package required");
      activity[0]=probe.startActivitySync(new Intent(probe.getTargetContext(),MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
      probe.runOnMainSync(()->{
        try{
          MainActivity main=(MainActivity)activity[0];WebView web=(WebView)field(main,"web");
          check(web!=null&&web.getWebViewClient()!=null,"web/client absent");passed[0]++;
          check((main.getWindow().getAttributes().flags&WindowManager.LayoutParams.FLAG_SECURE)!=0,"secure flag absent");passed[0]++;
          WebViewClient client=web.getWebViewClient();
          field(main,"pendingSeedUri",Uri.parse("content://synthetic.invalid/seed"));field(main,"seedPickerOutstanding",true);
          field(main,"pendingDocumentUri",Uri.parse("content://synthetic.invalid/document"));field(main,"pendingDocumentName","synthetic.txt");field(main,"documentPickerOutstanding",true);
          OwnerSessionGate.setForeground(true);OwnerSessionGate.setActive(true);
          RenderProcessGoneDetail detail=new RenderProcessGoneDetail(){@Override public boolean didCrash(){return true;}@Override public int rendererPriorityAtExit(){return WebView.RENDERER_PRIORITY_IMPORTANT;}};
          check(client.onRenderProcessGone(web,detail),"callback not handled");passed[0]++;
          check(field(main,"web")==null,"failed view retained");passed[0]++;
          check(Boolean.TRUE.equals(field(main,"rendererUnavailable")),"recovery state absent");passed[0]++;
          check(!OwnerSessionGate.isForeground()&&!OwnerSessionGate.isActive(main),"owner session not revoked");passed[0]++;
          check(field(main,"pendingSeedUri")==null&&field(main,"pendingDocumentUri")==null&&field(main,"pendingDocumentName")==null&&!Boolean.TRUE.equals(field(main,"seedPickerOutstanding"))&&!Boolean.TRUE.equals(field(main,"documentPickerOutstanding")),"pending picker state retained");passed[0]++;
          View content=main.findViewById(android.R.id.content);
          check(text(content,"ATLAS display stopped")&&text(content,"Retry ATLAS")&&text(content,"Close"),"native manual recovery missing");passed[0]++;
          check((main.getWindow().getAttributes().flags&WindowManager.LayoutParams.FLAG_SECURE)!=0,"secure flag changed");passed[0]++;
          client.onPageFinished(web,"file:///android_asset/www/index.html");
          check(!Boolean.TRUE.equals(field(main,"pageReady"))&&field(main,"web")==null,"stale page callback revived view");passed[0]++;
          check(client.onRenderProcessGone(web,detail)&&field(main,"web")==null&&main.findViewById(android.R.id.content)==content,"stale crash callback changed recovery");passed[0]++;
        }catch(Throwable error){failure[0]=error;}
      });
      if(failure[0]!=null)throw failure[0];ok=true;
    }catch(Throwable error){out.putString("error_type",error.getClass().getSimpleName());}
    finally{
      probe.runOnMainSync(()->{OwnerSessionGate.clear();if(activity[0]!=null)activity[0].finish();});
      out.putString("suite","renderer-recovery-callback");out.putBoolean("page_rendering_certified",false);
      out.putInt("passed",passed[0]);out.putInt("expected",11);out.putString("status",ok?"PASS":"FAIL");
      probe.finish(ok?Activity.RESULT_OK:Activity.RESULT_CANCELED,out);
    }
  }
}
