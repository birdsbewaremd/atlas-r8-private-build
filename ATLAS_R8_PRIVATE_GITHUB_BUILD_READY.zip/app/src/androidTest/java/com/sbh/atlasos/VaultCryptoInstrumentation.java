package com.sbh.atlasos;

import android.app.Activity;
import android.app.Instrumentation;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.Arrays;
import java.util.UUID;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Prepared device probe; NOT run by the host suites. No JUnit/AndroidX dependency.
 * Refuses the owner package. Uses a fresh test-only key and cache directory;
 * never reads, changes or deletes the owner's key, PIN, recovery state or vault.
 */
public final class VaultCryptoInstrumentation extends Instrumentation {
  private boolean rendererProbe;
  private boolean deviceInsightsProbe;
  private boolean productMediaProbe;
  @Override public void onCreate(Bundle arguments) {
    super.onCreate(arguments);
    rendererProbe=arguments!=null&&"renderer-recovery".equals(arguments.getString("suite"));
    deviceInsightsProbe=arguments!=null&&"device-insights".equals(arguments.getString("suite"));
    productMediaProbe=arguments!=null&&"product-media".equals(arguments.getString("suite"));
    start();
  }
  private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
  @Override public void onStart() {
    if(rendererProbe){RendererRecoveryProbe.run(this);return;}
    if(deviceInsightsProbe){DeviceInsightsProbe.run(this);return;}
    if(productMediaProbe){ProductMediaProbe.run(this);return;}
    Bundle result = new Bundle();
    String alias = "atlas_crypto_probe_" + UUID.randomUUID();
    KeyStore store = null; Path directory = null; boolean keyCreated = false;
    int passed = 0; boolean success = false;
    try {
      check("com.sbh.atlasos.candidate".equals(getTargetContext().getPackageName()), "candidate package required");
      store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
      check(!store.containsAlias(alias), "test alias already exists");
      KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
      generator.init(new KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setRandomizedEncryptionRequired(true).build());
      SecretKey key = generator.generateKey(); keyCreated = true;
      // This reproduces the rc3 initialization mismatch on a real Android provider.
      boolean rejected = false;
      try {
        Cipher old = Cipher.getInstance("AES/GCM/NoPadding");
        old.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(128, new byte[12]));
      } catch (InvalidAlgorithmParameterException expected) { rejected = true; }
      check(rejected, "caller-supplied encryption IV was not rejected"); passed++;
      directory = Files.createTempDirectory(getTargetContext().getCacheDir().toPath(), "atlas-crypto-probe-");
      Path file = directory.resolve("synthetic.atlasenc");
      byte[] plain = "synthetic Android encryption probe".getBytes(java.nio.charset.StandardCharsets.UTF_8);
      long n = VaultFileCodec.encryptNew(new ByteArrayInputStream(plain), file.toFile(), key, plain.length, () -> true);
      check(n == plain.length, "wrong encrypted byte count"); passed++;
      byte[] encoded = Files.readAllBytes(file);
      byte[] decoded = VaultFileCodec.decrypt(new ByteArrayInputStream(encoded), key, plain.length, () -> true);
      check(Arrays.equals(plain, decoded), "roundtrip failed"); Arrays.fill(decoded,(byte)0); passed++;
      Path second = directory.resolve("second.atlasenc");
      VaultFileCodec.encryptNew(new ByteArrayInputStream(plain), second.toFile(), key, plain.length, () -> true);
      check(!Arrays.equals(encoded, Files.readAllBytes(second)), "ciphertext/IV repeated"); passed++;
      byte[] tampered = encoded.clone(); tampered[tampered.length - 1] ^= 1;
      boolean tamperRejected = false;
      try { VaultFileCodec.decrypt(new ByteArrayInputStream(tampered), key, plain.length, () -> true); }
      catch (AEADBadTagException expected) { tamperRejected = true; }
      check(tamperRejected, "tampering was accepted"); passed++;
      boolean bounded = false;
      try { VaultFileCodec.decrypt(new ByteArrayInputStream(encoded), key, plain.length - 1, () -> true); }
      catch (VaultFileCodec.SizeLimitException expected) { bounded = true; }
      check(bounded, "read limit was not enforced"); passed++;
      boolean locked = false;
      try { VaultFileCodec.decrypt(new ByteArrayInputStream(encoded), key, plain.length, () -> false); }
      catch (IOException expected) { locked = true; }
      check(locked, "locked read was accepted"); passed++;
      // Synthetic streaming export tests exercise Android's real JsonReader and
      // Android Keystore. The original owner vault and authentication are untouched.
      File indexVault=directory.resolve("vault").toFile();indexVault.mkdirs();
      String export="[{\"id\":\"c1\",\"title\":\"Synthetic Unicode 🌎\",\"create_time\":1,\"mapping\":{"+
        "\"late\":{\"parent\":\"early\",\"message\":{\"id\":\"m2\",\"author\":{\"role\":\"assistant\"},\"create_time\":2,\"content\":{\"parts\":[\"SECOND_REPLY\"]}}},"+
        "\"early\":{\"parent\":null,\"message\":{\"id\":\"m1\",\"author\":{\"role\":\"user\"},\"create_time\":1,\"content\":{\"parts\":[\"FIRST_EXACT 🌎 line\\nnext\",{\"asset_pointer\":\"synthetic-image\"}]}}}}}]";
      final SecretKey indexKey=key;
      TransactionalSeedImporter.EncryptedWriter encryptedWriter=(entry,out,limit)->VaultFileCodec.encryptNew(entry,out,indexKey,limit,()->true);
      ChatGptTextIndexer.Result indexed=ChatGptTextIndexer.index(new ByteArrayInputStream(export.getBytes(java.nio.charset.StandardCharsets.UTF_8)),directory.toFile(),indexVault,encryptedWriter,()->true);
      check(indexed.conversations==1&&indexed.messages==2&&indexed.nonTextParts==1&&indexed.files==1,"chat counts mismatch");passed++;
      Path firstText=indexVault.toPath().resolve(indexed.directory).resolve("chat-00001-part-001.txt.atlasenc");
      byte[] textBytes;try(InputStream firstInput=new FileInputStream(firstText.toFile())){textBytes=VaultFileCodec.decrypt(firstInput,key,VaultSearchReader.MAX_TEXT_BYTES,()->true);}
      String text=new String(textBytes,java.nio.charset.StandardCharsets.UTF_8);Arrays.fill(textBytes,(byte)0);
      check(text.contains("FIRST_EXACT 🌎 line\nnext")&&text.contains("Role: user")&&text.indexOf("FIRST_EXACT")<text.indexOf("SECOND_REPLY"),"chat text fidelity or order");passed++;
      check(!new String(Files.readAllBytes(firstText),java.nio.charset.StandardCharsets.ISO_8859_1).contains("FIRST_EXACT"),"index plaintext on disk");passed++;
      long before;try(java.util.stream.Stream<Path> paths=Files.walk(indexVault.toPath())){before=paths.count();}
      char[] giant=new char[140000];Arrays.fill(giant,'x');
      boolean bigRejected=false;try{ChatGptTextIndexer.index(new ByteArrayInputStream(("[{\"unknown\":\""+new String(giant)+"\"}]").getBytes(java.nio.charset.StandardCharsets.UTF_8)),directory.toFile(),indexVault,encryptedWriter,()->true);}catch(IOException expected){bigRejected=true;}
      check(bigRejected,"oversized unknown JSON string accepted");passed++;
      long after;try(java.util.stream.Stream<Path> paths=Files.walk(indexVault.toPath())){after=paths.count();}
      check(before==after&&Files.exists(firstText),"failed index changed existing snapshot");passed++;
      boolean malformedRejected=false;try{ChatGptTextIndexer.index(new ByteArrayInputStream("[{\"mapping\": {".getBytes(java.nio.charset.StandardCharsets.UTF_8)),directory.toFile(),indexVault,encryptedWriter,()->true);}catch(IOException expected){malformedRejected=true;}
      check(malformedRejected,"truncated JSON accepted");passed++;
      boolean lockedIndex=false;try{ChatGptTextIndexer.index(new ByteArrayInputStream(export.getBytes(java.nio.charset.StandardCharsets.UTF_8)),directory.toFile(),indexVault,encryptedWriter,()->false);}catch(IOException expected){lockedIndex=true;}
      check(lockedIndex,"locked index accepted");passed++;
      Path exportFile=directory.resolve("synthetic-export.atlasenc");
      VaultFileCodec.encryptNew(new ByteArrayInputStream(export.getBytes(java.nio.charset.StandardCharsets.UTF_8)),exportFile.toFile(),key,1024*1024,()->true);
      ChatGptTextIndexer.Result streamIndex;
      try(InputStream authenticatedSource=openTestSource(exportFile.toFile(),key)){
        streamIndex=ChatGptTextIndexer.index(authenticatedSource,directory.toFile(),indexVault,encryptedWriter,()->true);
      }
      check(streamIndex.messages==2,"authenticated streaming index failed");passed++;
      long streamBefore;try(java.util.stream.Stream<Path> paths=Files.walk(indexVault.toPath())){streamBefore=paths.count();}
      byte[] badExport=Files.readAllBytes(exportFile);badExport[badExport.length-1]^=1;Files.write(exportFile,badExport);
      boolean badStreamRejected=false;
      try(InputStream unauthenticated=openTestSource(exportFile.toFile(),key)){
        ChatGptTextIndexer.index(unauthenticated,directory.toFile(),indexVault,encryptedWriter,()->true);
      }catch(Exception expected){badStreamRejected=true;}
      check(badStreamRejected,"tampered encrypted export accepted");passed++;
      long streamAfter;try(java.util.stream.Stream<Path> paths=Files.walk(indexVault.toPath())){streamAfter=paths.count();}
      check(streamBefore==streamAfter,"tampered stream published partial index");passed++;
      result.putBoolean("android_json_reader_executed",true);
      result.putString("status", "PASS"); success = true;
    } catch (Throwable error) {
      result.putString("status", "FAIL"); result.putString("error_type", error.getClass().getSimpleName());
      // No plaintext, key bytes, PINs or recovery secrets in the report.
    } finally {
      try {
        if (directory != null) {
          Files.walkFileTree(directory,new SimpleFileVisitor<Path>(){
            @Override public FileVisitResult visitFile(Path file,java.nio.file.attribute.BasicFileAttributes attributes)throws IOException{Files.delete(file);return FileVisitResult.CONTINUE;}
            @Override public FileVisitResult postVisitDirectory(Path path,IOException error)throws IOException{if(error!=null)throw error;Files.delete(path);return FileVisitResult.CONTINUE;}
          });
        }
      } catch (Exception cleanup) { result.putString("file_cleanup", "FAILED"); success = false; }
      try { if (keyCreated && store != null) store.deleteEntry(alias); }
      catch (Exception cleanup) { result.putString("key_cleanup", "FAILED"); success = false; }
      result.putInt("passed", passed); result.putInt("expected", 17);
      result.putBoolean("android_keystore_executed", keyCreated);
      if (!success) result.putString("status", "FAIL");
      finish(success ? Activity.RESULT_OK : Activity.RESULT_CANCELED, result);
    }
  }
  private static InputStream openTestSource(File file,SecretKey key)throws Exception{
    DataInputStream input=new DataInputStream(new FileInputStream(file));
    try{
      if(input.readInt()!=0x41544c31)throw new IOException("header");
      int length=input.readUnsignedByte();byte[] iv=new byte[length];input.readFully(iv);
      Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,iv));
      return new CipherInputStream(input,cipher);
    }catch(Exception failure){input.close();throw failure;}
  }

}
