package com.sbh.atlasos;

import android.app.*;
import android.content.Context;
import android.graphics.*;
import android.os.*;
import android.util.Base64;
import java.io.*;
import java.nio.file.*;
import java.security.KeyStore;
import java.util.*;
import org.json.*;

/** Isolated synthetic Android photo-store checks. Never opens the owner photo picker. */
final class ProductMediaProbe {
  private static int passed;
  private static void check(boolean b,String label){if(!b)throw new AssertionError(label);passed++;}
  interface Attempt{void run()throws Exception;}
  private static void rejects(Attempt a,String label)throws Exception{try{a.run();}catch(Exception expected){passed++;return;}throw new AssertionError(label);}
  static void run(Instrumentation instrumentation){
    Bundle result=new Bundle();result.putString("suite","product-media");passed=0;
    Context c=instrumentation.getTargetContext();File folder=new File(c.getNoBackupFilesDir(),AtlasProductMediaStore.DIRECTORY);
    boolean isolated=false,success=false;KeyStore keys=null;
    try{
      check("com.sbh.atlasos.candidate".equals(c.getPackageName()),"candidate required");
      check(Build.HARDWARE.contains("ranchu")||Build.HARDWARE.contains("goldfish"),"isolated emulator required");
      KeyguardManager guard=(KeyguardManager)c.getSystemService(Context.KEYGUARD_SERVICE);
      check(guard!=null&&!guard.isDeviceLocked(),"already unlocked test emulator required");
      keys=KeyStore.getInstance("AndroidKeyStore");keys.load(null);
      check(!keys.containsAlias(AtlasProductMediaStore.ALIAS),"no prior product media key");
      check(!folder.exists(),"no prior product media folder");isolated=true;
      OwnerSessionGate.setForeground(false);
      rejects(()->AtlasProductMediaStore.list(c),"locked list");
      rejects(()->AtlasProductMediaStore.read(c,"pm-0123456789abcdef0123456789abcdef"),"locked read");
      check(!folder.exists()&&!keys.containsAlias(AtlasProductMediaStore.ALIAS),"locked calls create nothing");
      OwnerSessionGate.setForeground(true);OwnerSessionGate.setActive(true);
      long generation=OwnerSessionGate.capture(c);check(generation!=0,"test owner gate");
      check(AtlasProductMediaStore.list(c).getJSONArray("images").length()==0,"default empty library");
      Bitmap original=Bitmap.createBitmap(80,60,Bitmap.Config.ARGB_8888);original.eraseColor(Color.rgb(61,42,184));
      ByteArrayOutputStream encoded=new ByteArrayOutputStream();original.compress(Bitmap.CompressFormat.JPEG,85,encoded);original.recycle();
      byte[] jpeg=encoded.toByteArray();JSONObject saved=AtlasProductMediaStore.save(c,jpeg,80,60,generation);
      check("ok".equals(saved.getString("status"))&&!saved.getBoolean("duplicate"),"photo saved");
      String id=saved.getString("id");check(AtlasProductMediaStore.validId(id),"generated reference");
      check(keys.containsAlias(AtlasProductMediaStore.ALIAS),"independent keystore key");
      File image=new File(folder,id+".atlasphoto");byte[] ciphertext=Files.readAllBytes(image.toPath());
      check(ciphertext.length>jpeg.length&&!Arrays.equals(ciphertext,jpeg),"encrypted file");
      check(!new String(ciphertext,java.nio.charset.StandardCharsets.ISO_8859_1).contains(id),"metadata encrypted");
      JSONObject listing=AtlasProductMediaStore.list(c);check(listing.getJSONArray("images").length()==1,"one library entry");
      check(listing.getJSONArray("images").getJSONObject(0).getInt("width")==80,"dimensions retained");
      JSONObject read=AtlasProductMediaStore.read(c,id);String data=read.getString("dataUri");
      byte[] roundtrip=Base64.decode(data.substring(data.indexOf(',')+1),Base64.DEFAULT);
      check(Arrays.equals(jpeg,roundtrip),"actual Android Keystore roundtrip");
      Bitmap decoded=BitmapFactory.decodeByteArray(roundtrip,0,roundtrip.length);
      check(decoded!=null&&decoded.getWidth()==80&&decoded.getHeight()==60,"returned image decodes");if(decoded!=null)decoded.recycle();
      JSONObject duplicate=AtlasProductMediaStore.save(c,jpeg,80,60,generation);
      check(duplicate.getBoolean("duplicate")&&id.equals(duplicate.getString("id")),"same image deduplicated");
      check(folder.list().length==1&&Arrays.equals(ciphertext,Files.readAllBytes(image.toPath())),"dedup preserves original bytes");
      OwnerSessionGate.setForeground(false);
      rejects(()->AtlasProductMediaStore.read(c,id),"photo inaccessible after pause");
      rejects(()->AtlasProductMediaStore.save(c,jpeg,80,60,generation),"stale generation cannot write");
      OwnerSessionGate.setForeground(true);OwnerSessionGate.setActive(true);long next=OwnerSessionGate.capture(c);
      rejects(()->AtlasProductMediaStore.save(c,jpeg,80,60,generation),"relogin does not revive former generation");
      check(AtlasProductMediaStore.read(c,id).getString("status").equals("ok"),"fresh login reads existing photo");
      byte[] tampered=ciphertext.clone();tampered[tampered.length-1]^=1;Files.write(image.toPath(),tampered);
      rejects(()->AtlasProductMediaStore.read(c,id),"tampered photo rejected");
      JSONObject partial=AtlasProductMediaStore.list(c);check(partial.getInt("unreadableCount")==1&&partial.getJSONArray("images").length()==0,"unreadable photo warning");
      rejects(()->AtlasProductMediaStore.save(c,jpeg,80,60,next),"corrupt archive blocks mutation");
      check(Arrays.equals(tampered,Files.readAllBytes(image.toPath())),"corrupt bytes retained");
      Files.write(image.toPath(),ciphertext);keys.deleteEntry(AtlasProductMediaStore.ALIAS);
      rejects(()->AtlasProductMediaStore.read(c,id),"missing key read refused");
      rejects(()->AtlasProductMediaStore.save(c,jpeg,80,60,next),"missing key not recreated over existing photos");
      check(!keys.containsAlias(AtlasProductMediaStore.ALIAS)&&Arrays.equals(ciphertext,Files.readAllBytes(image.toPath())),"key loss preserves original archive");
      success=true;
    }catch(Throwable failure){result.putString("error_type",failure.getClass().getSimpleName());}
    finally{
      OwnerSessionGate.setForeground(false);
      if(isolated){
        try{
          if(folder.exists())try(java.util.stream.Stream<java.nio.file.Path> paths=Files.walk(folder.toPath())){paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(IOException e){throw new RuntimeException(e);}});}
          if(keys!=null&&keys.containsAlias(AtlasProductMediaStore.ALIAS))keys.deleteEntry(AtlasProductMediaStore.ALIAS);
          result.putString("cleanup","PASS");
        }catch(Exception failed){success=false;result.putString("cleanup","FAIL");}
      }
      result.putInt("passed",passed);result.putString("status",success?"PASS":"FAIL");
      result.putBoolean("owner_photo_picker_executed",false);result.putBoolean("owner_vault_touched",false);
      instrumentation.finish(success?Activity.RESULT_OK:Activity.RESULT_CANCELED,result);
    }
  }
}
