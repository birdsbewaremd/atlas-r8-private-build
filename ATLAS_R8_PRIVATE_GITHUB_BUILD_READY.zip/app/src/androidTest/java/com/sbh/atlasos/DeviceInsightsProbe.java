package com.sbh.atlasos;

import android.app.Activity;
import android.app.Instrumentation;
import android.app.KeyguardManager;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Locale;
import java.util.UUID;
import javax.crypto.AEADBadTagException;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import org.json.JSONObject;

/**
 * Explicit suite=device-insights only. Refuses phones, the owner package, existing
 * battery preferences/files/key/job, any capture file/key, and granted Usage Access.
 * Uses real Android battery/Keystore APIs on a disposable candidate emulator.
 * Never launches an Activity, requests a permission, records a screen, or touches
 * the owner PIN, recovery state, vault, or a previously saved recording.
 */
public final class DeviceInsightsProbe {
  private static final String BATTERY_PREFS = "atlas_device_insights_v1";
  private static final String BATTERY_ALIAS = "atlas_device_battery_history_v1";
  private static final String BATTERY_FILE = "atlas_device_battery_history_v1.aesgcm";
  private static final String CAPTURE_ALIAS = "atlas_local_screen_capture_aes_v1";
  private int passed;
  private String lastCheck = "preflight";

  private void check(boolean ok, String label) {
    lastCheck = label;
    if (!ok) throw new AssertionError(label);
    passed++;
  }

  public static void run(Instrumentation instrumentation) {
    new DeviceInsightsProbe().execute(instrumentation);
  }

  private void execute(Instrumentation instrumentation) {
    Bundle report = new Bundle();
    Context context = instrumentation.getTargetContext();
    String codecAlias = "atlas_device_insights_probe_" + UUID.randomUUID();
    KeyStore keys = null;
    Path scratch = null;
    File batteryFile = null;
    boolean batteryOwned = false, codecKeyOwned = false, success = false;
    try {
      check("com.sbh.atlasos.candidate".equals(context.getPackageName()), "candidate package required");
      String hardware = (Build.HARDWARE + " " + Build.MODEL + " " + Build.PRODUCT).toLowerCase(Locale.ROOT);
      check(hardware.contains("ranchu") || hardware.contains("goldfish")
          || hardware.contains("sdk_gphone") || hardware.contains("android sdk"), "isolated emulator required");
      KeyguardManager keyguard = context.getSystemService(KeyguardManager.class);
      check(keyguard != null && !keyguard.isDeviceLocked(), "emulator must already be unlocked");
      keys = KeyStore.getInstance("AndroidKeyStore"); keys.load(null);
      check(!keys.containsAlias(BATTERY_ALIAS), "refuse existing battery key");
      check(!keys.containsAlias(CAPTURE_ALIAS), "refuse existing capture key");
      check(!keys.containsAlias(codecAlias), "fresh codec alias required");
      batteryFile = new File(context.getNoBackupFilesDir(), BATTERY_FILE);
      check(!batteryFile.exists() && !new File(batteryFile.getPath() + ".bak").exists()
          && !new File(batteryFile.getPath() + ".new").exists(), "refuse existing battery files");
      File preferencesFile = new File(new File(context.getApplicationInfo().dataDir, "shared_prefs"), BATTERY_PREFS + ".xml");
      SharedPreferences preferences = context.getSharedPreferences(BATTERY_PREFS, Context.MODE_PRIVATE);
      check(!preferencesFile.exists() && !new File(preferencesFile.getPath() + ".bak").exists()
          && preferences.getAll().isEmpty(), "refuse existing battery preferences");
      File captures = new File(context.getNoBackupFilesDir(), "atlas-local-captures-v1");
      check(!containsFile(captures), "refuse existing recording or pending capture files");
      JobScheduler jobs = context.getSystemService(JobScheduler.class);
      check(jobs != null && jobs.getPendingJob(AtlasDeviceInsights.BATTERY_JOB_ID) == null,
          "refuse existing battery job");
      check(!AppUsageReader.hasSpecialAccess(context), "Usage Access must already be absent; probe never changes permissions");
      report.putBoolean("preflight_passed", true);

      OwnerSessionGate.setForeground(false);
      check("locked".equals(AtlasDeviceInsights.snapshot(context).optString("status")), "locked snapshot refused");
      check("locked".equals(AtlasDeviceInsights.getHistory(context).optString("status")), "locked history refused");
      check("locked".equals(AtlasDeviceInsights.setTracking(context, true).optString("status")), "locked opt-in refused");
      check("owner_locked".equals(AtlasDeviceInsights.usageToday(context).optString("error")), "locked usage refused");
      check(!batteryFile.exists() && !keys.containsAlias(BATTERY_ALIAS), "locked calls create no battery history or key");

      // Test-only process-local owner state; never verifies or changes a stored PIN.
      OwnerSessionGate.setForeground(true); OwnerSessionGate.setActive(true);
      check(OwnerSessionGate.isActive(context), "synthetic current owner session established");
      JSONObject live = AtlasDeviceInsights.snapshot(context);
      check("ok".equals(live.optString("status")), "actual Android battery snapshot available");
      int level = live.getJSONObject("battery").getInt("level");
      check(level >= 0 && level <= 100, "actual battery percentage bounded");
      check(Math.abs(System.currentTimeMillis() - live.getLong("atMs")) < 10_000L, "battery timestamp is current");
      check(!live.getBoolean("tracking") && live.getJSONArray("samples").length() == 0, "tracking off by default with no invented history");
      check(!batteryFile.exists() && !keys.containsAlias(BATTERY_ALIAS), "off snapshot creates no store or key");
      JSONObject usage = AtlasDeviceInsights.usageToday(context);
      check("permission_required".equals(usage.optString("status")), "absent Usage Access is permission_required");
      check(usage.isNull("totalForegroundMs") && usage.getJSONArray("apps").length() == 0,
          "permission denial does not fabricate zero use");

      // From this point cleanup owns only this previously absent candidate feature state.
      batteryOwned = true;
      JSONObject enabled = AtlasDeviceInsights.setTracking(context, true);
      check("ok".equals(enabled.optString("actionStatus")) && enabled.optBoolean("tracking"), "explicit native opt-in succeeds");
      check(enabled.getJSONArray("samples").length() == 1, "first real battery sample saved");
      check(enabled.getJSONArray("samples").getJSONObject(0).getInt("level")
          == enabled.getJSONObject("battery").getInt("level"), "saved sample matches the actual battery reading");
      check(batteryFile.isFile() && batteryFile.getCanonicalFile().getParentFile()
          .equals(context.getNoBackupFilesDir().getCanonicalFile()), "battery history lives only in no-backup storage");
      byte[] encryptedBattery = Files.readAllBytes(batteryFile.toPath());
      check(encryptedBattery.length > 32 && ByteBuffer.wrap(encryptedBattery).getInt() == 0x41424931,
          "battery uses versioned encrypted envelope");
      check(!new String(encryptedBattery, StandardCharsets.ISO_8859_1).contains("\"samples\""),
          "battery plaintext JSON absent from stored bytes");
      check(keys.containsAlias(BATTERY_ALIAS), "separate battery Keystore key created");
      ByteBuffer envelope = ByteBuffer.wrap(encryptedBattery); envelope.getInt();
      byte[] iv = new byte[12]; envelope.get(iv);
      byte[] ciphertext = new byte[envelope.remaining()]; envelope.get(ciphertext);
      Cipher decrypt = Cipher.getInstance("AES/GCM/NoPadding");
      decrypt.init(Cipher.DECRYPT_MODE, (SecretKey) keys.getKey(BATTERY_ALIAS, null), new GCMParameterSpec(128, iv));
      decrypt.updateAAD(("atlas-device-battery-history-v1:" + context.getPackageName()).getBytes(StandardCharsets.UTF_8));
      byte[] plainBattery = decrypt.doFinal(ciphertext);
      try {
        check(new JSONObject(new String(plainBattery, StandardCharsets.UTF_8)).getJSONArray("samples").length() == 1,
            "real Android Keystore authenticates battery history");
      } finally { Arrays.fill(plainBattery, (byte) 0); }
      JobInfo scheduled = jobs.getPendingJob(AtlasDeviceInsights.BATTERY_JOB_ID);
      check(scheduled != null && scheduled.isPeriodic() && scheduled.getIntervalMillis() >= 900_000L,
          "opt-in schedules bounded periodic battery work");
      JSONObject stopped = AtlasDeviceInsights.setTracking(context, false);
      check("ok".equals(stopped.optString("actionStatus")) && !stopped.optBoolean("tracking"), "explicit stop persists off");
      check(jobs.getPendingJob(AtlasDeviceInsights.BATTERY_JOB_ID) == null, "stop cancels periodic job");
      check(Arrays.equals(encryptedBattery, Files.readAllBytes(batteryFile.toPath())), "stop preserves exact encrypted history bytes");
      check("off".equals(AtlasDeviceInsights.sample(context).optString("status")), "stopped background writer refuses work");
      check(Arrays.equals(encryptedBattery, Files.readAllBytes(batteryFile.toPath())), "stopped sample cannot rewrite history");

      byte[] tampered = encryptedBattery.clone(); tampered[tampered.length - 1] ^= 1;
      Files.write(batteryFile.toPath(), tampered);
      JSONObject corrupt = AtlasDeviceInsights.setTracking(context, true);
      check("error".equals(corrupt.optString("actionStatus")) && !corrupt.optBoolean("tracking"), "corrupt battery history prevents opt-in");
      check(Arrays.equals(tampered, Files.readAllBytes(batteryFile.toPath())), "corrupt battery file is preserved without reset");
      // Restore only the synthetic probe-owned bytes before the independent key-loss case.
      Files.write(batteryFile.toPath(), encryptedBattery);
      keys.deleteEntry(BATTERY_ALIAS);
      JSONObject lostKey = AtlasDeviceInsights.setTracking(context, true);
      check("error".equals(lostKey.optString("actionStatus")), "missing battery key prevents opt-in");
      check(!keys.containsAlias(BATTERY_ALIAS), "missing key is never silently regenerated");
      check(Arrays.equals(encryptedBattery, Files.readAllBytes(batteryFile.toPath())), "key loss preserves encrypted history");
      report.putBoolean("battery_history_executed", true);
      report.putBoolean("battery_key_loss_executed", true);

      scratch = Files.createTempDirectory(context.getCacheDir().toPath(), "atlas-device-insights-probe-");
      codecKeyOwned = true;
      KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
      generator.init(new KeyGenParameterSpec.Builder(codecAlias,
          KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
          .setKeySize(256).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
          .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
          .setRandomizedEncryptionRequired(true).build());
      SecretKey codecKey = generator.generateKey();
      byte[] plain = new byte[600_123]; new SecureRandom().nextBytes(plain);
      byte[] marker = "SYNTHETIC_CAPTURE_CODEC_ONLY".getBytes(StandardCharsets.US_ASCII);
      System.arraycopy(marker, 0, plain, 0, marker.length);
      File source = scratch.resolve("synthetic.bin").toFile(); Files.write(source.toPath(), plain);
      String id = UUID.randomUUID().toString().replace("-", "");
      AtlasCaptureStore.Clip clip = new AtlasCaptureStore.Clip(id, System.currentTimeMillis(), 2000L, plain.length);
      File encoded = scratch.resolve("codec.acap").toFile(), decoded = scratch.resolve("decoded.bin").toFile();
      AtlasCaptureStore.encrypt(source, encoded, codecKey, clip, () -> true);
      byte[] original = Files.readAllBytes(encoded.toPath());
      check(!new String(original, StandardCharsets.ISO_8859_1).contains("SYNTHETIC_CAPTURE_CODEC_ONLY"),
          "capture codec stores no synthetic plaintext marker");
      AtlasCaptureStore.Clip opened = AtlasCaptureStore.decrypt(encoded, decoded, codecKey, id, () -> true);
      check(Arrays.equals(plain, Files.readAllBytes(decoded.toPath())), "real Keystore multi-chunk capture roundtrip");
      check(opened.bytes == clip.bytes && opened.durationMs == clip.durationMs && opened.id.equals(id),
          "capture metadata remains authenticated");
      File second = scratch.resolve("second.acap").toFile();
      AtlasCaptureStore.encrypt(source, second, codecKey, clip, () -> true);
      check(!Arrays.equals(original, Files.readAllBytes(second.toPath())), "Android generates fresh capture encryption nonces");
      byte[] bad = original.clone(); bad[bad.length - 1] ^= 1;
      File corruptClip = scratch.resolve("tampered.acap").toFile(); Files.write(corruptClip.toPath(), bad);
      boolean tagRejected = false;
      try { AtlasCaptureStore.decrypt(corruptClip, scratch.resolve("rejected.bin").toFile(), codecKey, id, () -> true); }
      catch (AEADBadTagException expected) { tagRejected = true; }
      check(tagRejected, "real Android Keystore rejects late capture chunk tampering");
      boolean lockedRejected = false;
      try { AtlasCaptureStore.decrypt(encoded, scratch.resolve("locked.bin").toFile(), codecKey, id, () -> false); }
      catch (IOException expected) { lockedRejected = true; }
      check(lockedRejected, "capture codec refuses revoked access");
      check(Arrays.equals(original, Files.readAllBytes(encoded.toPath())), "codec failures preserve original ciphertext");
      Arrays.fill(plain, (byte) 0);
      report.putBoolean("capture_codec_executed", true);
      success = true;
    } catch (Throwable failure) {
      report.putString("error_type", failure.getClass().getSimpleName());
      report.putString("last_check", lastCheck);
    } finally {
      OwnerSessionGate.setForeground(false); OwnerSessionGate.clear();
      try {
        if (batteryOwned) {
          JobScheduler jobs = context.getSystemService(JobScheduler.class);
          if (jobs != null) jobs.cancel(AtlasDeviceInsights.BATTERY_JOB_ID);
          context.getSharedPreferences(BATTERY_PREFS, Context.MODE_PRIVATE).edit().clear().commit();
          context.deleteSharedPreferences(BATTERY_PREFS);
          for (String suffix : new String[]{"", ".bak", ".new"})
            Files.deleteIfExists(new File(batteryFile.getPath() + suffix).toPath());
          if (keys != null && keys.containsAlias(BATTERY_ALIAS)) keys.deleteEntry(BATTERY_ALIAS);
          File prefsFile = new File(new File(context.getApplicationInfo().dataDir, "shared_prefs"), BATTERY_PREFS + ".xml");
          if (batteryFile.exists() || new File(batteryFile.getPath() + ".bak").exists()
              || new File(batteryFile.getPath() + ".new").exists() || prefsFile.exists()
              || new File(prefsFile.getPath() + ".bak").exists()
              || (keys != null && keys.containsAlias(BATTERY_ALIAS))
              || (jobs != null && jobs.getPendingJob(AtlasDeviceInsights.BATTERY_JOB_ID) != null))
            throw new IOException("Battery probe cleanup incomplete");
        }
        report.putString("battery_cleanup", "PASS");
      } catch (Exception cleanup) { report.putString("battery_cleanup", "FAILED"); success = false; }
      try {
        if (scratch != null) Files.walkFileTree(scratch, new SimpleFileVisitor<Path>() {
          @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attributes) throws IOException {
            Files.delete(file); return FileVisitResult.CONTINUE;
          }
          @Override public FileVisitResult postVisitDirectory(Path directory, IOException error) throws IOException {
            if (error != null) throw error;
            Files.delete(directory); return FileVisitResult.CONTINUE;
          }
        });
        report.putString("codec_file_cleanup", "PASS");
      } catch (Exception cleanup) { report.putString("codec_file_cleanup", "FAILED"); success = false; }
      try {
        if (codecKeyOwned && keys != null && keys.containsAlias(codecAlias)) keys.deleteEntry(codecAlias);
        report.putString("codec_key_cleanup", "PASS");
      } catch (Exception cleanup) { report.putString("codec_key_cleanup", "FAILED"); success = false; }
      report.putString("suite", "device-insights");
      report.putString("status", success ? "PASS" : "FAIL");
      report.putInt("passed", passed);
      report.putBoolean("media_projection_executed", false);
      report.putBoolean("usage_permission_changed", false);
      report.putBoolean("owner_vault_touched", false);
      instrumentation.finish(success ? Activity.RESULT_OK : Activity.RESULT_CANCELED, report);
    }
  }

  private static boolean containsFile(File path) throws IOException {
    if (!path.exists()) return false;
    if (Files.isSymbolicLink(path.toPath()) || !path.isDirectory()) return true;
    File[] children = path.listFiles();
    if (children == null) throw new IOException("Capture preflight unavailable");
    for (File child : children) if (containsFile(child)) return true;
    return false;
  }
}
