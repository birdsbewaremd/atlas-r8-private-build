package com.sbh.atlasos;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.BatteryManager;
import android.os.UserManager;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.AtomicFile;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import javax.crypto.AEADBadTagException;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Owner-only views and opt-in local device measurements. The background capability
 * is deliberately limited to battery measurements; it never calls an owner vault,
 * usage reader, accessibility API, microphone, network, or screen capture API.
 *
 * Integration must obtain a native, owner-confirmed action before setTracking(true).
 * All returned measurements are Android observations, never example records.
 */
public final class AtlasDeviceInsights {
  static final int BATTERY_JOB_ID = 0x41544C42;
  private static final Object STORE_LOCK = new Object();
  private static final String PREFS = "atlas_device_insights_v1";
  private static final String KEY_ALIAS = "atlas_device_battery_history_v1";
  private static final String FILE_NAME = "atlas_device_battery_history_v1.aesgcm";
  private static final int MAGIC = 0x41424931;
  private static final int MAX_PLAIN_BYTES = 512 * 1024;
  private static final long PERIOD_MS = 15L * 60L * 1000L;
  private static final long FOREGROUND_MIN_MS = 5L * 60L * 1000L;
  private static final long RETENTION_MS = 7L * 24L * 60L * 60L * 1000L;
  private static final int MAX_USAGE_EVENTS = 50_000;
  private static final int MAX_USAGE_PACKAGES = 1024;
  private static volatile boolean processStopped;
  private static final String SAMPLING_NOTE =
      "Android schedules battery checks about every 15 minutes and may delay or skip them. "
      + "Foreground checks are limited to one saved reading per 5 minutes. Gaps are not filled. "
      + "After a reboot or force-stop, open device insights to resume an enabled schedule. "
      + "Stopping keeps existing history; older readings are pruned only when a new reading is saved.";
  private static final String USAGE_NOTE =
      "Estimated app foreground time from Android activity events since local midnight. "
      + "Unmatched events are omitted; overlapping apps may both accrue time, so the sum is not screen time. "
      + "Android or device vendors may omit events. This lookup is local and is not saved.";

  private AtlasDeviceInsights() {}

  /** Live reading plus retained history. Saves a bounded foreground sample only after opt-in. */
  public static JSONObject snapshot(Context context) {
    return snapshot(context, true);
  }

  /** Owner-only retained history, using the same response shape without saving a new reading. */
  public static JSONObject getHistory(Context context) {
    return snapshot(context, false);
  }

  private static JSONObject snapshot(Context context, boolean sampleNow) {
    long owner = OwnerSessionGate.capture(context);
    if (owner == 0L) return locked();
    Context app = application(context);
    synchronized (STORE_LOCK) {
      if (!OwnerSessionGate.isCurrent(context, owner)) return locked();
      long now = System.currentTimeMillis();
      BatteryReading battery = readBattery(app, now);
      List<BatteryTrend.Sample> samples = new ArrayList<>();
      String historyStatus = "ok";
      String error = "";
      String sampleStatus = "off";
      boolean tracking;
      boolean scheduled = false;
      try {
        tracking = tracking(app);
        History history = readHistory(app);
        if (tracking && sampleNow) sampleStatus = appendSample(app, history, battery);
        samples = history.samples;
        historyStatus = samples.isEmpty() ? "empty" : "ok";
        if (tracking) {
          scheduled = schedule(app);
          if (!scheduled) error = "background_schedule_unavailable";
        }
      } catch (HistoryException failure) {
        error = failure.code;
        historyStatus = "error";
        haltTracking(app);
      } catch (RuntimeException unavailable) {
        error = "device_insights_unavailable";
        historyStatus = "error";
        haltTracking(app);
      }
      tracking = trackingSafely(app);
      JSONObject out = object("status", battery.level == null ? "unavailable" : "ok",
          "atMs", now, "tracking", tracking, "battery", battery.json(),
          "historyStatus", historyStatus, "samples", samplesJson(samples));
      BatteryTrend.Result trend = BatteryTrend.calculate(samples, now);
      JSONObject trendJson = trendJson(trend);
      if (!samples.isEmpty() && "ok".equals(trend.status)) {
        BatteryTrend.Sample last = samples.get(samples.size() - 1);
        if (!battery.chargingKnown || "unknown".equals(battery.plug)) {
          trendJson = unavailableTrend("power_state_unknown");
        } else if (last.charging != battery.charging || !last.plug.equals(battery.plug)) {
          // A live transition matters even while the next persisted sample is throttled.
          trendJson = unavailableTrend("power_state_changed");
        }
      }
      if ("error".equals(historyStatus)) {
        trendJson = unavailableTrend("unavailable");
      }
      JSONObject sampling = object("status", !error.isEmpty() ? "error" : tracking ? "enabled" : "off",
          "intervalMinutes", 15, "minimumForegroundMinutes", 5,
          "maxGapMinutes", 45, "retentionDays", 7, "maxSamples", BatteryTrend.MAX_SAMPLES,
          "scheduled", scheduled, "sampleStatus", sampleStatus,
          "lastAtMs", samples.isEmpty() ? JSONObject.NULL : samples.get(samples.size() - 1).atMs,
          "note", SAMPLING_NOTE);
      if (!error.isEmpty()) {
        put(out, "error", error);
        put(sampling, "error", error);
        put(sampling, "note", SAMPLING_NOTE + ("error".equals(historyStatus)
            ? " Battery history is unavailable. Tracking is stopped; existing history is preserved."
            : " Background scheduling is unavailable; only foreground sampling can run."));
      }
      if ("clock_changed".equals(sampleStatus)) {
        put(sampling, "note", SAMPLING_NOTE
            + " The clock moved backwards; no new reading was written across that change.");
      }
      put(out, "trend", trendJson);
      put(out, "sampling", sampling);
      return OwnerSessionGate.isCurrent(context, owner) ? out : locked();
    }
  }

  /** Caller must bind this mutation to the owner's explicit native confirmation. */
  public static JSONObject setTracking(Context context, boolean enabled) {
    long owner = OwnerSessionGate.capture(context);
    if (owner == 0L) return locked();
    Context app = application(context);
    synchronized (STORE_LOCK) {
      if (!OwnerSessionGate.isCurrent(context, owner)) return locked();
      if (!enabled) {
        // The cancellation and in-process fence also work when the history/key is unavailable.
        processStopped = true;
        cancelJob(app);
        boolean saved;
        try { saved = preferences(app).edit().putBoolean("tracking", false).commit(); }
        catch (RuntimeException failure) { saved = false; }
        if (!saved) return actionError("tracking_stop_not_persisted", false,
            "Sampling is stopped in this process and its job was cancelled, but saving the setting failed.");
        JSONObject out = snapshot(context, false);
        put(out, "actionStatus", "ok");
        return out;
      }
      try {
        History history = readHistory(app);
        if (!history.exists) writeHistory(app, history.samples, true);
        if (!OwnerSessionGate.isCurrent(context, owner)) return locked();
        SharedPreferences prefs = preferences(app);
        String segment = tracking(app) ? prefs.getString("segment", "") : "";
        if (segment == null || segment.isEmpty()) segment = UUID.randomUUID().toString();
        if (!prefs.edit().putBoolean("history_initialized", true)
            .putString("segment", segment).putBoolean("tracking", true).commit()) {
          haltTracking(app);
          return actionError("tracking_start_not_persisted", false, "The opt-in setting could not be saved.");
        }
        processStopped = false;
        JSONObject out = snapshot(context, true);
        put(out, "actionStatus", trackingSafely(app) ? "ok" : "error");
        return out;
      } catch (HistoryException failure) {
        haltTracking(app);
        return actionError(failure.code, false,
            "Existing history could not be authenticated or opened. It has not been reset or replaced.");
      } catch (RuntimeException unavailable) {
        haltTracking(app);
        return actionError("tracking_unavailable", false, "Battery tracking could not be started.");
      }
    }
  }

  /**
   * Limited battery-only writer for the JobService or foreground caller. Its result
   * contains no history, usage records, or vault data. It cannot enable tracking.
   */
  public static JSONObject sample(Context context) {
    Context app = application(context);
    if (app == null) return actionError("context_unavailable", false, "Device context is unavailable.");
    synchronized (STORE_LOCK) {
      try {
        if (!tracking(app)) return object("status", "off", "tracking", false);
        if (Thread.currentThread().isInterrupted()) return object("status", "skipped", "tracking", true);
        History history = readHistory(app);
        if (!history.exists) throw new HistoryException("history_missing");
        long now = System.currentTimeMillis();
        String status = appendSample(app, history, readBattery(app, now));
        return object("status", status, "atMs", now, "tracking", tracking(app));
      } catch (HistoryException failure) {
        if (Thread.currentThread().isInterrupted() || "sampling_cancelled".equals(failure.code))
          return object("status", "skipped", "tracking", trackingSafely(app));
        haltTracking(app);
        return actionError(failure.code, false, "Sampling stopped; existing history is preserved.");
      } catch (RuntimeException unavailable) {
        haltTracking(app);
        return actionError("sampling_unavailable", false, "Battery sampling is unavailable.");
      }
    }
  }

  private static String appendSample(Context app, History history, BatteryReading battery)
      throws HistoryException {
    if (!tracking(app) || Thread.currentThread().isInterrupted()) return "off";
    if (battery.level == null || !battery.chargingKnown) return "battery_unavailable";
    long now = battery.atMs;
    if (now <= 0L) return "clock_changed";
    String segment = preferences(app).getString("segment", "");
    if (segment == null || segment.isEmpty() || segment.length() > 64)
      throw new HistoryException("tracking_state_invalid");
    if (!history.samples.isEmpty()) {
      BatteryTrend.Sample last = history.samples.get(history.samples.size() - 1);
      if (now < last.atMs) return "clock_changed";
      if (now == last.atMs) return "too_soon";
      if (now - last.atMs < FOREGROUND_MIN_MS && segment.equals(last.segment)) return "too_soon";
    }
    ArrayList<BatteryTrend.Sample> next = new ArrayList<>();
    long earliest = Math.max(1L, now - RETENTION_MS);
    for (BatteryTrend.Sample s : history.samples) if (s.atMs >= earliest) next.add(s);
    next.add(new BatteryTrend.Sample(now, battery.level, battery.charging, battery.plug, segment));
    if (next.size() > BatteryTrend.MAX_SAMPLES)
      next = new ArrayList<>(next.subList(next.size() - BatteryTrend.MAX_SAMPLES, next.size()));
    if (!tracking(app) || Thread.currentThread().isInterrupted()) return "off";
    writeHistory(app, next, false);
    history.samples = next;
    return "recorded";
  }

  /** One owner-requested query. No timers, persistence, content inspection, or package export. */
  public static JSONObject usageToday(Context context) {
    long owner = OwnerSessionGate.capture(context);
    long now = System.currentTimeMillis();
    Calendar midnight = Calendar.getInstance();
    midnight.setTimeInMillis(now);
    midnight.set(Calendar.HOUR_OF_DAY, 0);
    midnight.set(Calendar.MINUTE, 0);
    midnight.set(Calendar.SECOND, 0);
    midnight.set(Calendar.MILLISECOND, 0);
    long start = midnight.getTimeInMillis();
    JSONObject empty = usageEnvelope("unavailable", start, now);
    if (owner == 0L) { put(empty, "error", "owner_locked"); return empty; }
    Context app = application(context);
    if (!AppUsageReader.hasSpecialAccess(app)) {
      put(empty, "status", "permission_required");
      put(empty, "note", "Android Usage Access is required. Grant it in system settings only if you want this lookup. "
          + "ATLAS does not request screen, text, audio, or accessibility access for this view.");
      return empty;
    }
    try {
      UserManager user = (UserManager) app.getSystemService(Context.USER_SERVICE);
      UsageStatsManager usage = (UsageStatsManager) app.getSystemService(Context.USAGE_STATS_SERVICE);
      if (user == null || !user.isUserUnlocked() || usage == null) {
        put(empty, "error", "usage_service_unavailable");
        return empty;
      }
      // Yesterday's events are used only to identify an activity already open at midnight.
      long queryStart = Math.max(0L, start - 24L * 60L * 60L * 1000L);
      UsageEvents events = usage.queryEvents(queryStart, now);
      if (events == null) { put(empty, "error", "usage_events_unavailable"); return empty; }
      Map<String, UsageWindow> active = new HashMap<>();
      Map<String, Long> totals = new HashMap<>();
      UsageEvents.Event row = new UsageEvents.Event();
      int scanned = 0, activityEvents = 0, unmatched = 0;
      long previousAt = queryStart;
      while (events.hasNextEvent()) {
        if (++scanned > MAX_USAGE_EVENTS) { put(empty, "error", "usage_event_limit"); return empty; }
        if ((scanned & 255) == 0 && !OwnerSessionGate.isCurrent(context, owner)) {
          put(empty, "error", "owner_locked"); return empty;
        }
        if (!events.getNextEvent(row)) { put(empty, "error", "usage_events_incomplete"); return empty; }
        long at = row.getTimeStamp();
        if (at < previousAt || at < queryStart || at > now) {
          put(empty, "error", "usage_clock_or_order_changed"); return empty;
        }
        previousAt = at;
        int type = row.getEventType();
        if (type == UsageEvents.Event.DEVICE_STARTUP) {
          // A missing shutdown gives no trustworthy closing time; discard open intervals.
          unmatched += active.size();
          active.clear();
          continue;
        }
        if (type == UsageEvents.Event.DEVICE_SHUTDOWN
            || type == UsageEvents.Event.SCREEN_NON_INTERACTIVE
            || type == UsageEvents.Event.KEYGUARD_SHOWN) {
          finishAll(active, totals, at, start);
          continue;
        }
        if (type != UsageEvents.Event.ACTIVITY_RESUMED
            && type != UsageEvents.Event.ACTIVITY_PAUSED
            && type != UsageEvents.Event.ACTIVITY_STOPPED) continue;
        String pkg = row.getPackageName();
        String activity = row.getClassName();
        if (pkg == null || pkg.isEmpty() || pkg.length() > 255
            || activity == null || activity.isEmpty() || activity.length() > 1024) {
          unmatched++; continue;
        }
        if (at >= start) activityEvents++;
        UsageWindow window = active.get(pkg);
        if (type == UsageEvents.Event.ACTIVITY_RESUMED) {
          if (window == null) {
            if (active.size() + totals.size() >= MAX_USAGE_PACKAGES) {
              put(empty, "error", "usage_package_limit"); return empty;
            }
            window = new UsageWindow(at);
            active.put(pkg, window);
          }
          if (window.classes.size() >= 256) { put(empty, "error", "usage_activity_limit"); return empty; }
          window.classes.add(activity);
        } else if (window != null && window.classes.remove(activity)) {
          if (window.classes.isEmpty()) {
            addUsage(totals, pkg, window.fromMs, at, start);
            active.remove(pkg);
          }
        } else if (type == UsageEvents.Event.ACTIVITY_PAUSED) {
          unmatched++;
        }
      }
      boolean ongoingIncluded = !active.isEmpty();
      finishAll(active, totals, now, start);
      if (!OwnerSessionGate.isCurrent(context, owner) || !AppUsageReader.hasSpecialAccess(app)) {
        put(empty, "error", "owner_or_usage_access_changed"); return empty;
      }
      List<Map.Entry<String, Long>> ordered = new ArrayList<>(totals.entrySet());
      Collections.sort(ordered, new Comparator<Map.Entry<String, Long>>() {
        @Override public int compare(Map.Entry<String, Long> a, Map.Entry<String, Long> b) {
          int duration = Long.compare(b.getValue(), a.getValue());
          return duration != 0 ? duration : a.getKey().compareTo(b.getKey());
        }
      });
      JSONArray apps = new JSONArray();
      long total = 0L;
      PackageManager packages = app.getPackageManager();
      for (Map.Entry<String, Long> entry : ordered) {
        if ((apps.length() & 31) == 0 && !OwnerSessionGate.isCurrent(context, owner)) {
          put(empty, "error", "owner_locked"); return empty;
        }
        long duration = entry.getValue();
        if (duration <= 0L) continue;
        total += duration;
        String label = entry.getKey();
        try {
          ApplicationInfo info = packages.getApplicationInfo(entry.getKey(), 0);
          CharSequence name = packages.getApplicationLabel(info);
          if (name != null && name.length() > 0) label = name.toString();
        } catch (PackageManager.NameNotFoundException | RuntimeException unavailable) {
          // Package visibility may hide the label; an observed package ID is still truthful.
        }
        if (label.length() > 200) label = label.substring(0, 200);
        apps.put(object("packageName", entry.getKey(), "label", label, "foregroundMs", duration));
      }
      if (!OwnerSessionGate.isCurrent(context, owner) || !AppUsageReader.hasSpecialAccess(app)) {
        put(empty, "error", "owner_or_usage_access_changed"); return empty;
      }
      if (apps.length() == 0) {
        put(empty, "error", activityEvents == 0 ? "no_usage_events" : "no_usable_usage_intervals");
        put(empty, "note", "Android returned no usable foreground events for today. This is not evidence of zero use. " + USAGE_NOTE);
        return empty;
      }
      JSONObject out = usageEnvelope("ok", start, now);
      put(out, "apps", apps);
      put(out, "totalForegroundMs", total);
      put(out, "unmatchedEvents", unmatched);
      put(out, "ongoingIncluded", ongoingIncluded);
      put(out, "activityEvents", activityEvents);
      return out;
    } catch (SecurityException denied) {
      put(empty, "status", "permission_required");
      put(empty, "error", "usage_access_denied");
      return empty;
    } catch (RuntimeException unavailable) {
      put(empty, "error", "usage_events_unavailable");
      return empty;
    }
  }

  private static JSONObject usageEnvelope(String status, long start, long end) {
    return object("status", status, "atMs", end, "apps", new JSONArray(),
        "totalForegroundMs", "ok".equals(status) ? 0L : JSONObject.NULL, "fromAtMs", start, "toAtMs", end,
        "range", object("fromAtMs", start, "toAtMs", end, "timeZone", java.util.TimeZone.getDefault().getID()),
        "source", "android_usage_events", "approximate", true, "persisted", false, "note", USAGE_NOTE);
  }

  private static final class UsageWindow {
    final long fromMs;
    final Set<String> classes = new HashSet<>();
    UsageWindow(long fromMs) { this.fromMs = fromMs; }
  }

  private static void finishAll(Map<String, UsageWindow> active, Map<String, Long> totals, long at, long start) {
    for (Map.Entry<String, UsageWindow> entry : active.entrySet())
      addUsage(totals, entry.getKey(), entry.getValue().fromMs, at, start);
    active.clear();
  }

  private static void addUsage(Map<String, Long> totals, String pkg, long from, long to, long start) {
    long duration = to - Math.max(from, start);
    if (duration <= 0L) return;
    Long before = totals.get(pkg);
    totals.put(pkg, (before == null ? 0L : before) + duration);
  }

  private static final class BatteryReading {
    final long atMs;
    Integer level;
    boolean charging;
    boolean chargingKnown;
    String plug = "unknown";
    Double temperatureC;
    Integer voltageMv;
    BatteryReading(long atMs) { this.atMs = atMs; }
    JSONObject json() {
      return object("level", level == null ? JSONObject.NULL : level, "charging", charging,
          "chargingKnown", chargingKnown, "plug", plug,
          "temperatureC", temperatureC == null ? JSONObject.NULL : temperatureC,
          "voltageMv", voltageMv == null ? JSONObject.NULL : voltageMv,
          "observedAtMs", atMs, "source", "android_battery");
    }
  }

  private static BatteryReading readBattery(Context app, long now) {
    BatteryReading out = new BatteryReading(now);
    if (app == null) return out;
    Intent sticky = null;
    try { sticky = app.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED)); }
    catch (RuntimeException unavailable) { /* BatteryManager remains a real fallback. */ }
    if (sticky != null && sticky.hasExtra(BatteryManager.EXTRA_PRESENT)
        && !sticky.getBooleanExtra(BatteryManager.EXTRA_PRESENT, true)) return out;
    if (sticky != null) {
      int raw = sticky.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
      int scale = sticky.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
      if (raw >= 0 && scale > 0 && raw <= scale)
        out.level = (int) Math.round(raw * 100.0 / scale);
      int status = sticky.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN);
      if (status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
          || status == BatteryManager.BATTERY_STATUS_DISCHARGING || status == BatteryManager.BATTERY_STATUS_NOT_CHARGING) {
        out.charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;
        out.chargingKnown = true;
      }
      int plug = sticky.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);
      if (plug == 0) out.plug = "none";
      else if (plug == BatteryManager.BATTERY_PLUGGED_AC) out.plug = "ac";
      else if (plug == BatteryManager.BATTERY_PLUGGED_USB) out.plug = "usb";
      else if (plug == BatteryManager.BATTERY_PLUGGED_WIRELESS) out.plug = "wireless";
      else if (plug == BatteryManager.BATTERY_PLUGGED_DOCK) out.plug = "dock";
      int temperature = sticky.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
      if (temperature >= -1000 && temperature <= 2000) out.temperatureC = temperature / 10.0;
      int voltage = sticky.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
      if (voltage > 0 && voltage <= 30_000) out.voltageMv = voltage;
    }
    try {
      BatteryManager manager = (BatteryManager) app.getSystemService(Context.BATTERY_SERVICE);
      if (manager != null) {
        if (out.level == null) {
          int capacity = manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
          if (capacity >= 0 && capacity <= 100) out.level = capacity;
        }
        if (!out.chargingKnown) {
          int status = manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS);
          if (status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
              || status == BatteryManager.BATTERY_STATUS_DISCHARGING || status == BatteryManager.BATTERY_STATUS_NOT_CHARGING) {
            out.charging = manager.isCharging();
            out.chargingKnown = true;
          }
        }
      }
    } catch (RuntimeException unavailable) { /* Missing readings stay null/unknown. */ }
    return out;
  }

  private static SharedPreferences preferences(Context app) {
    return app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
  }

  private static boolean tracking(Context app) {
    return app != null && !processStopped && preferences(app).getBoolean("tracking", false);
  }

  private static boolean trackingSafely(Context app) {
    try { return tracking(app); } catch (RuntimeException unavailable) { return false; }
  }

  private static void haltTracking(Context app) {
    processStopped = true;
    cancelJob(app);
    try { preferences(app).edit().putBoolean("tracking", false).commit(); }
    catch (RuntimeException unavailable) { /* Fence still prevents all writes this process. */ }
  }

  private static boolean schedule(Context app) {
    if (!trackingSafely(app)) return false;
    try {
      JobScheduler jobs = (JobScheduler) app.getSystemService(Context.JOB_SCHEDULER_SERVICE);
      if (jobs == null) return false;
      JobInfo prior = jobs.getPendingJob(BATTERY_JOB_ID);
      ComponentName service = new ComponentName(app, AtlasBatteryJobService.class);
      if (prior != null && service.equals(prior.getService()) && prior.isPeriodic()) return true;
      JobInfo job = new JobInfo.Builder(BATTERY_JOB_ID, service)
          .setPeriodic(Math.max(PERIOD_MS, JobInfo.getMinPeriodMillis()),
              Math.max(FOREGROUND_MIN_MS, JobInfo.getMinFlexMillis()))
          .setRequiredNetworkType(JobInfo.NETWORK_TYPE_NONE)
          .setPersisted(false)
          .build();
      return jobs.schedule(job) == JobScheduler.RESULT_SUCCESS;
    } catch (RuntimeException unavailable) { return false; }
  }

  private static void cancelJob(Context app) {
    if (app == null) return;
    try {
      JobScheduler jobs = (JobScheduler) app.getSystemService(Context.JOB_SCHEDULER_SERVICE);
      if (jobs != null) jobs.cancel(BATTERY_JOB_ID);
    } catch (RuntimeException unavailable) { /* Every worker also checks the persisted opt-in. */ }
  }

  private static final class History {
    final boolean exists;
    List<BatteryTrend.Sample> samples;
    History(boolean exists, List<BatteryTrend.Sample> samples) { this.exists = exists; this.samples = samples; }
  }

  private static final class HistoryException extends Exception {
    private static final long serialVersionUID = 1L;
    final String code;
    HistoryException(String code) { super(code); this.code = code; }
  }

  private static AtomicFile historyFile(Context app) throws HistoryException {
    File directory = app.getNoBackupFilesDir();
    if (directory == null || !directory.isDirectory()) throw new HistoryException("history_storage_unavailable");
    return new AtomicFile(new File(directory, FILE_NAME));
  }

  private static boolean hasCommittedFile(AtomicFile file) {
    return file.getBaseFile().exists() || new File(file.getBaseFile().getPath() + ".bak").exists();
  }

  private static History readHistory(Context app) throws HistoryException {
    try {
      AtomicFile file = historyFile(app);
      if (!hasCommittedFile(file)) {
        if (new File(file.getBaseFile().getPath() + ".new").exists())
          throw new HistoryException("history_incomplete_write");
        if (preferences(app).getBoolean("history_initialized", false) || keyExists())
          throw new HistoryException("history_missing");
        return new History(false, new ArrayList<BatteryTrend.Sample>());
      }
      byte[] blob = readBounded(file);
      if (blob.length < 32) throw new HistoryException("history_format_invalid");
      ByteBuffer envelope = ByteBuffer.wrap(blob);
      if (envelope.getInt() != MAGIC) throw new HistoryException("history_format_invalid");
      byte[] iv = new byte[12];
      envelope.get(iv);
      byte[] cipherText = new byte[envelope.remaining()];
      envelope.get(cipherText);
      Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
      cipher.init(Cipher.DECRYPT_MODE, key(false), new GCMParameterSpec(128, iv));
      cipher.updateAAD(aad(app));
      byte[] plain = cipher.doFinal(cipherText);
      if (plain.length > MAX_PLAIN_BYTES) throw new HistoryException("history_size_limit");
      JSONObject root = new JSONObject(new String(plain, StandardCharsets.UTF_8));
      if (integer(root, "version") != 1L) throw new HistoryException("history_format_invalid");
      JSONArray rows = root.getJSONArray("samples");
      if (rows.length() > BatteryTrend.MAX_SAMPLES) throw new HistoryException("history_size_limit");
      ArrayList<BatteryTrend.Sample> samples = new ArrayList<>();
      long previous = 0L;
      for (int i = 0; i < rows.length(); i++) {
        JSONObject row = rows.getJSONObject(i);
        long at = integer(row, "atMs");
        long level = integer(row, "level");
        Object charge = row.get("charging"), plug = row.get("plug"), segment = row.get("segment");
        if (!(charge instanceof Boolean) || !(plug instanceof String) || !(segment instanceof String)
            || level < 0L || level > 100L || at <= previous)
          throw new HistoryException("history_format_invalid");
        BatteryTrend.Sample s = new BatteryTrend.Sample(at, (int) level, (Boolean) charge, (String) plug, (String) segment);
        if (!BatteryTrend.valid(s)) throw new HistoryException("history_format_invalid");
        samples.add(s);
        previous = at;
      }
      return new History(true, samples);
    } catch (HistoryException known) { throw known; }
    catch (AEADBadTagException badTag) { throw new HistoryException("history_authentication_failed"); }
    catch (JSONException invalid) { throw new HistoryException("history_format_invalid"); }
    catch (Exception unavailable) { throw new HistoryException("history_unavailable"); }
  }

  private static long integer(JSONObject object, String key) throws JSONException, HistoryException {
    Object value = object.get(key);
    if (!(value instanceof Integer) && !(value instanceof Long)) throw new HistoryException("history_format_invalid");
    return ((Number) value).longValue();
  }

  private static byte[] readBounded(AtomicFile file) throws Exception {
    try (FileInputStream in = file.openRead(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
      byte[] buffer = new byte[4096];
      int count;
      while ((count = in.read(buffer)) != -1) {
        if (out.size() + count > MAX_PLAIN_BYTES + 32) throw new HistoryException("history_size_limit");
        out.write(buffer, 0, count);
      }
      return out.toByteArray();
    }
  }

  private static void writeHistory(Context app, List<BatteryTrend.Sample> samples, boolean initial)
      throws HistoryException {
    AtomicFile file = historyFile(app);
    FileOutputStream output = null;
    try {
      if (samples.size() > BatteryTrend.MAX_SAMPLES) throw new HistoryException("history_size_limit");
      // Never mint a replacement key for existing data or a previously initialized store.
      if (initial && (hasCommittedFile(file) || preferences(app).getBoolean("history_initialized", false)))
        throw new HistoryException("history_initialization_refused");
      byte[] plain = object("version", 1, "samples", samplesJson(samples)).toString().getBytes(StandardCharsets.UTF_8);
      if (plain.length > MAX_PLAIN_BYTES) throw new HistoryException("history_size_limit");
      Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
      cipher.init(Cipher.ENCRYPT_MODE, key(initial));
      cipher.updateAAD(aad(app));
      byte[] iv = cipher.getIV();
      if (iv == null || iv.length != 12) throw new HistoryException("history_nonce_invalid");
      byte[] encrypted = cipher.doFinal(plain);
      byte[] blob = ByteBuffer.allocate(4 + iv.length + encrypted.length).putInt(MAGIC).put(iv).put(encrypted).array();
      if (!initial && (!tracking(app) || Thread.currentThread().isInterrupted()))
        throw new HistoryException("sampling_cancelled");
      output = file.startWrite();
      output.write(blob);
      output.flush();
      output.getFD().sync();
      file.finishWrite(output);
      output = null;
      // AtomicFile logs some finish/rename failures instead of throwing. Verify exact bytes.
      byte[] persisted = readBounded(file);
      if (!java.security.MessageDigest.isEqual(blob, persisted)) throw new HistoryException("history_write_unconfirmed");
    } catch (HistoryException known) {
      if (output != null) file.failWrite(output);
      throw known;
    } catch (Exception unavailable) {
      if (output != null) file.failWrite(output);
      throw new HistoryException("history_write_failed");
    }
  }

  private static byte[] aad(Context app) {
    return ("atlas-device-battery-history-v1:" + app.getPackageName()).getBytes(StandardCharsets.UTF_8);
  }

  private static boolean keyExists() throws Exception {
    KeyStore store = KeyStore.getInstance("AndroidKeyStore");
    store.load(null);
    return store.containsAlias(KEY_ALIAS);
  }

  private static SecretKey key(boolean allowCreate) throws HistoryException {
    try {
      KeyStore store = KeyStore.getInstance("AndroidKeyStore");
      store.load(null);
      if (store.containsAlias(KEY_ALIAS)) {
        java.security.Key existing = store.getKey(KEY_ALIAS, null);
        if (existing instanceof SecretKey) return (SecretKey) existing;
        throw new HistoryException("history_key_unavailable");
      }
      if (!allowCreate) throw new HistoryException("history_key_missing");
      KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
      generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
          KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
          .setKeySize(256).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
          .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
          .setRandomizedEncryptionRequired(true)
          // This independent battery-only key permits opted-in jobs while the screen is locked.
          // No owner-vault key or owner-gate state is changed or reused.
          .setUserAuthenticationRequired(false).build());
      return generator.generateKey();
    } catch (HistoryException known) { throw known; }
    catch (Exception unavailable) { throw new HistoryException("history_key_unavailable"); }
  }

  private static JSONArray samplesJson(List<BatteryTrend.Sample> samples) {
    JSONArray rows = new JSONArray();
    for (BatteryTrend.Sample sample : samples)
      rows.put(object("atMs", sample.atMs, "level", sample.level, "charging", sample.charging,
          "plug", sample.plug, "segment", sample.segment));
    return rows;
  }

  private static JSONObject trendJson(BatteryTrend.Result trend) {
    return object("status", trend.status, "ratePerHour", trend.ratePerHour == null ? JSONObject.NULL : trend.ratePerHour,
        "observedMinutes", trend.observedMinutes, "direction", trend.direction, "samplesUsed", trend.samplesUsed,
        "fromAtMs", trend.fromAtMs == 0L ? JSONObject.NULL : trend.fromAtMs,
        "toAtMs", trend.toAtMs == 0L ? JSONObject.NULL : trend.toAtMs,
        "unit", "percentage_points_per_hour", "note", "Observed change only; not a time-to-empty or time-to-full prediction.");
  }

  private static JSONObject unavailableTrend(String status) {
    return object("status", status, "ratePerHour", JSONObject.NULL,
        "observedMinutes", 0.0, "direction", "unknown", "samplesUsed", 0,
        "unit", "percentage_points_per_hour");
  }

  private static Context application(Context context) {
    if (context == null) return null;
    Context app = context.getApplicationContext();
    return app == null ? context : app;
  }

  private static JSONObject locked() {
    return object("status", "locked", "error", "owner_locked", "tracking", false,
        "samples", new JSONArray(), "message", "Unlock the current ATLAS owner session to view device insights.");
  }

  private static JSONObject actionError(String code, boolean tracking, String message) {
    return object("status", "unavailable", "actionStatus", "error", "error", code,
        "tracking", tracking, "message", message);
  }

  private static JSONObject object(Object... pairs) {
    JSONObject value = new JSONObject();
    for (int i = 0; i < pairs.length; i += 2) put(value, (String) pairs[i], pairs[i + 1]);
    return value;
  }

  private static void put(JSONObject value, String key, Object entry) {
    try { value.put(key, entry == null ? JSONObject.NULL : entry); }
    catch (JSONException invalid) { throw new IllegalArgumentException("Invalid insights response", invalid); }
  }
}
