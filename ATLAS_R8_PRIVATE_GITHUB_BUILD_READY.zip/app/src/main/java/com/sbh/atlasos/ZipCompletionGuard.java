package com.sbh.atlasos;
import java.io.*;

/** Bounded stream + ZIP end-record check; rejects truncated prefixes and ZIP64/multidisk.
 * Not provenance authentication. ZipInputStream still validates local entry CRCs.
 */
final class ZipCompletionGuard extends FilterInputStream {
  private final byte[] tail=new byte[65557];
  private int end,used;private long count;private final long maxBytes;
  ZipCompletionGuard(InputStream in,long maxBytes){super(in);this.maxBytes=maxBytes;}
  private void remember(byte[] b,int off,int len)throws IOException{
    if(len<=0)return;
    if(count>maxBytes-len)throw new IOException("compressed archive exceeds limit");
    count+=len;
    if(len>=tail.length){System.arraycopy(b,off+len-tail.length,tail,0,tail.length);end=0;used=tail.length;return;}
    int first=Math.min(len,tail.length-end);System.arraycopy(b,off,tail,end,first);
    if(first<len)System.arraycopy(b,off+first,tail,0,len-first);
    end=(end+len)%tail.length;used=Math.min(tail.length,used+len);
  }
  @Override public int read()throws IOException{int b=in.read();if(b>=0){byte[] one={(byte)b};remember(one,0,1);}return b;}
  @Override public int read(byte[] b,int off,int len)throws IOException{int n=in.read(b,off,len);if(n>0)remember(b,off,n);return n;}
  void finish(int entries)throws IOException{
    byte[] buffer=new byte[8192];while(read(buffer,0,buffer.length)!=-1){}
    byte[] bytes=new byte[used];int start=(end-used+tail.length)%tail.length;
    for(int i=0;i<used;i++)bytes[i]=tail[(start+i)%tail.length];
    for(int i=used-22;i>=0;i--){
      if(u32(bytes,i)!=0x06054b50L)continue;
      int comment=u16(bytes,i+20);
      if(i+22+comment!=used)continue;
      long eocdAt=count-used+i,centralSize=u32(bytes,i+12),centralOffset=u32(bytes,i+16);
      int onDisk=u16(bytes,i+8),total=u16(bytes,i+10);
      if(u16(bytes,i+4)!=0||u16(bytes,i+6)!=0||total==65535||onDisk!=total||total!=entries
          ||centralSize==0xffffffffL||centralOffset==0xffffffffL
          ||centralSize<46L*entries||centralOffset+centralSize!=eocdAt)
        throw new IOException("unsupported or inconsistent ZIP end record");
      return;
    }
    throw new IOException("ZIP end record missing or truncated");
  }
  private static int u16(byte[] b,int i){return (b[i]&255)|((b[i+1]&255)<<8);}
  private static long u32(byte[] b,int i){return (long)u16(b,i)|((long)u16(b,i+2)<<16);}
}
