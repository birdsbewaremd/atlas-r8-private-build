package com.sbh.atlasos;

/** Bounded preservation of an explicit owner audio chooser, not an owner session. */
public final class ModuleLifecyclePolicy {
    private ModuleLifecyclePolicy() {}
    public static boolean shouldFinishOnStop(boolean changingConfigurations, boolean ownerAudioPickerPending) {
        return !changingConfigurations && !ownerAudioPickerPending;
    }
}
