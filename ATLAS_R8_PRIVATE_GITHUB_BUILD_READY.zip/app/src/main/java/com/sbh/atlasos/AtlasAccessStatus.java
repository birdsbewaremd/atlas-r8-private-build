package com.sbh.atlasos;

import android.Manifest;
import android.app.NotificationManager;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import org.json.JSONObject;

/** Read-only, live Android capability status. Does not access app data or grant permissions. */
public final class AtlasAccessStatus {
    private AtlasAccessStatus() {}

    public static String status(Context context, String item) {
        if (context == null || item == null) return "UNAVAILABLE";
        try {
            switch (item) {
                case "home": return role(context, RoleManager.ROLE_HOME);
                case "assistant": return role(context, RoleManager.ROLE_ASSISTANT);
                case "microphone": return permission(context, Manifest.permission.RECORD_AUDIO);
                case "camera": return permission(context, Manifest.permission.CAMERA);
                case "notifications": {
                    NotificationManager n = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
                    if (Build.VERSION.SDK_INT >= 33 &&
                        context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                        return "REVIEW";
                    return n != null && n.areNotificationsEnabled() ? "ALLOWED" : "REVIEW";
                }
                case "usage": return AppUsageReader.hasSpecialAccess(context) ? "ALLOWED" : "REVIEW";
                case "files": return "SELECT FILES AS NEEDED";
                case "messages": return "EXTERNAL APP";
                case "phone": return "EXTERNAL APP";
                case "bluetooth": return "ANDROID SETTINGS";
                case "wallpaper": return "ANDROID SETTINGS";
                case "app_settings": return "ANDROID SETTINGS";
                case "screen_capture": return "SYSTEM PROMPT REQUIRED";
                case "accessibility": return "NOT IMPLEMENTED";
                case "notification_reader": return "NOT IMPLEMENTED";
                case "other_app_data": return "RESTRICTED BY ANDROID";
                default: return "UNAVAILABLE";
            }
        } catch (RuntimeException blocked) { return "UNAVAILABLE"; }
    }

    private static String role(Context c, String role) {
        if (Build.VERSION.SDK_INT < 29) return "UNAVAILABLE";
        RoleManager rm = (RoleManager)c.getSystemService(Context.ROLE_SERVICE);
        if (rm == null || !rm.isRoleAvailable(role)) return "UNAVAILABLE";
        return rm.isRoleHeld(role) ? "ALLOWED" : "REVIEW";
    }

    private static String permission(Context c, String name) {
        return c.checkSelfPermission(name) == PackageManager.PERMISSION_GRANTED ? "ALLOWED" : "REVIEW";
    }

    public static String snapshot(Context context) {
        JSONObject o=new JSONObject();
        for (String id : new String[]{"home", "assistant", "microphone", "camera", "notifications",
            "usage", "files", "messages", "phone", "bluetooth", "wallpaper", "app_settings",
            "screen_capture", "accessibility", "notification_reader", "other_app_data"}) {
            try { o.put(id, status(context,id)); } catch (org.json.JSONException ignored) {}
        }
        return o.toString();
    }
}
