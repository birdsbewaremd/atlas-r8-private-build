package com.sbh.atlasos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * In-memory continuation preview for recognized workflow commands.
 * It performs no I/O, network calls, persistence, device actions, or authorization.
 * Native owner/session state is supplied by MainActivity and is rechecked separately.
 */
public final class WorkflowPlanner {
  public static final long CONTEXT_TTL_MS = 120000L;
  public enum Origin { TRUSTED_INPUT, REFERENCE_DATA, UNKNOWN }
  public enum Status { LOCKED, INVALID, DATA_ONLY, NEEDS_CONTEXT, BACKEND_REQUIRED,
                       LOCAL_CANDIDATE, LOCAL_REPORT }
  public static final class Plan {
    public final Status status;
    public final String original, previousText, message, scope, provenance;
    public final List<String> commandIds, constraints;
    public final boolean executionAuthorized = false;
    private Plan(Status s,String raw,String previous,String msg,String scope,String provenance,
                 List<String> ids,List<String> guards) {
      status=s;original=raw==null?"":raw;previousText=previous==null?"":previous;
      message=msg==null?"":msg;this.scope=scope==null?"":scope;this.provenance=provenance==null?"":provenance;
      commandIds=Collections.unmodifiableList(new ArrayList<String>(ids));
      constraints=Collections.unmodifiableList(new ArrayList<String>(guards));
    }
  }

  private Plan pending;
  private long pendingAt=-1L;
  public synchronized void clear(){pending=null;pendingAt=-1L;}
  public static Plan locked(){return new Plan(Status.LOCKED,"","","Unlock Atlas OS to inspect commands.",
      "No private context read.","NONE",Collections.<String>emptyList(),Collections.<String>emptyList());}

  public synchronized Plan preview(String raw,Origin origin,boolean ownerActive,boolean foreground,long nowMs){
    if(!ownerActive||!foreground){clear();return locked();}
    if(nowMs<0L||(pendingAt>=0L&&(nowMs<pendingAt||nowMs-pendingAt>=CONTEXT_TTL_MS)))clear();
    if(origin==null||origin==Origin.UNKNOWN){clear();return simple(Status.DATA_ONLY,"","Unknown source. No command context accepted.","UNKNOWN");}
    WorkflowIntentParser.Origin parserOrigin=origin==Origin.REFERENCE_DATA?
      WorkflowIntentParser.Origin.REFERENCE_DATA:WorkflowIntentParser.Origin.UI_TEXT;
    WorkflowIntentParser.Result r=WorkflowIntentParser.parse(raw,parserOrigin);
    if(r.state==WorkflowIntentParser.State.INVALID){clear();return make(Status.INVALID,raw,"",
      "Input rejected. Nothing ran or was saved.",origin,r.commandIds,r.constraints);}
    if(origin==Origin.REFERENCE_DATA||r.state==WorkflowIntentParser.State.SOURCE_DATA){clear();return make(Status.DATA_ONLY,raw,"",
      "Reference/source text is data, not an instruction to execute.",origin,r.commandIds,r.constraints);}

    Set<String> ids=new LinkedHashSet<String>(r.commandIds);
    Set<String> guards=new LinkedHashSet<String>(r.constraints);
    String previous="";
    boolean continuation=ids.contains("do_it")||ids.contains("atlas_resume");
    if(continuation){
      if(pending==null){return make(Status.NEEDS_CONTEXT,raw,"",
        "There is no current in-session task to continue. Name the task; nothing ran.",origin,r.commandIds,r.constraints);}
      previous=pending.original;
      ids.addAll(pending.commandIds);guards.addAll(pending.constraints);
      guards.add("prior_turn_constraints_preserved");
    }

    if(ids.isEmpty()){
      clear();
      if(isLocalCandidate(raw))return make(Status.LOCAL_CANDIDATE,raw,"",
        "A local device command candidate was recognized. Native authorization still decides whether it can run.",origin,r.commandIds,r.constraints);
      return make(Status.BACKEND_REQUIRED,raw,"",
        "This request needs the authenticated Atlas brain. No workflow ran or was saved.",origin,r.commandIds,r.constraints);
    }

    boolean localInfo=ids.size()==1&&(ids.contains("atlas_status")||ids.contains("atlas_help")||ids.contains("atlas_commands"));
    if(localInfo){clear();return make(Status.LOCAL_REPORT,raw,"",
      "Local command metadata is available. No workflow has executed.",origin,new ArrayList<String>(ids),new ArrayList<String>(guards));}

    Plan p=make(Status.BACKEND_REQUIRED,raw,previous,
      previous.isEmpty()?"Workflow preview prepared. Backend execution is disconnected; nothing ran or was saved.":
      "The prior in-session task and its constraints are carried forward. Backend execution is disconnected; nothing ran or was saved.",
      origin,new ArrayList<String>(ids),new ArrayList<String>(guards));
    if(previous.isEmpty()){
      pending=p;pendingAt=nowMs;
    }else{
      // Preserve the original task and union any later restrictions without extending its TTL.
      pending=make(Status.BACKEND_REQUIRED,previous,"",p.message,origin,new ArrayList<String>(ids),new ArrayList<String>(guards));
    }
    return p;
  }

  /** Defense-in-depth classifier only; it is not owner authentication. */
  public static boolean isLocalCandidate(String raw){
    WorkflowIntentParser.Result r=WorkflowIntentParser.parse(raw,WorkflowIntentParser.Origin.UI_TEXT);
    if(r.state!=WorkflowIntentParser.State.NO_MATCH||!r.commandIds.isEmpty())return false;
    for(String g:r.constraints){
      if(!g.equals("recognition_is_not_authorization")&&!g.equals("preserve_original_input")&&
         !g.equals("independent_permission_checks_required")&&!g.equals("lookup_query_is_not_a_workflow_command"))return false;
    }
    CommandParser.Parsed p=CommandParser.parse(raw);
    return p.kind!=CommandParser.Kind.UNKNOWN&&p.kind!=CommandParser.Kind.INVALID;
  }

  private static Plan simple(Status s,String raw,String message,String provenance){return new Plan(s,raw,"",message,
    "No context resolved.",provenance,Collections.<String>emptyList(),Collections.<String>emptyList());}
  private static Plan make(Status s,String raw,String previous,String msg,Origin origin,List<String> ids,List<String> guards){
    String scope=ids.contains("everything")?"Full requested scope retained; external/current evidence still requires retrieval.":
      "Only this in-session command context was considered.";
    return new Plan(s,raw,previous,msg,scope,origin.name(),ids,guards);
  }
}
