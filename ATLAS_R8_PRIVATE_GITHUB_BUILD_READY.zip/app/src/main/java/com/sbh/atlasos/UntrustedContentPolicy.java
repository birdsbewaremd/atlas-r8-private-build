package com.sbh.atlasos;

/**
 * Separates data-plane content from authority. Web pages, files, retrieved text and
 * model output cannot become instructions merely because they contain imperative text.
 */
public final class UntrustedContentPolicy {
  private UntrustedContentPolicy() {}

  public enum Source {
    AUTHENTICATED_OWNER,
    SIGNED_SYSTEM_CONFIG,
    EXTERNAL_CONTENT,
    IMPORTED_REFERENCE,
    MODEL_OUTPUT,
    UNKNOWN
  }
  public enum Decision { DATA_ONLY, MAY_REQUEST_EXISTING_CAPABILITY, BLOCK }

  public static Decision classify(
      Source source,
      boolean ownerAuthenticated,
      boolean configSignatureValid,
      boolean existingCapabilityAllowsRequest) {
    if (source == null || source == Source.UNKNOWN) return Decision.BLOCK;
    if (source == Source.EXTERNAL_CONTENT || source == Source.IMPORTED_REFERENCE || source == Source.MODEL_OUTPUT) {
      return Decision.DATA_ONLY;
    }
    if (!existingCapabilityAllowsRequest) return Decision.BLOCK;
    if (source == Source.AUTHENTICATED_OWNER) {
      return ownerAuthenticated ? Decision.MAY_REQUEST_EXISTING_CAPABILITY : Decision.BLOCK;
    }
    if (source == Source.SIGNED_SYSTEM_CONFIG) {
      return configSignatureValid ? Decision.MAY_REQUEST_EXISTING_CAPABILITY : Decision.BLOCK;
    }
    return Decision.BLOCK;
  }

  /** Authority changes must use AuthorityConfigPolicy; content classification never grants them. */
  public static boolean mayDirectlyChangeAuthority(Source source) { return false; }
}
