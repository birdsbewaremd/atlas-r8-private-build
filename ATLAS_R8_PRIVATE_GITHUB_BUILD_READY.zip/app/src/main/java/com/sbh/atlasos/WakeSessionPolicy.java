package com.sbh.atlasos;

/**
 * Pure-Java, session-generation-bound permit for the optional microphone listener.
 * This is not authentication; only OwnerSessionGate may supply valid generations.
 * A previous service may not resume merely because a different owner session exists.
 */
public final class WakeSessionPolicy {
  private long armedGeneration;

  /** Refuse zero/invalid credentials, and clear any previous permit on failure. */
  public synchronized boolean arm(long trustedGeneration) {
    if (trustedGeneration <= 0L) {
      revoke();
      return false;
    }
    // A live service cannot silently switch to another login generation.
    if (armedGeneration != 0L && armedGeneration != trustedGeneration) return false;
    armedGeneration = trustedGeneration;
    return true;
  }

  public synchronized boolean mayListen(long currentTrustedGeneration) {
    return armedGeneration > 0L && currentTrustedGeneration == armedGeneration;
  }

  public synchronized void revoke() { armedGeneration = 0L; }
}
