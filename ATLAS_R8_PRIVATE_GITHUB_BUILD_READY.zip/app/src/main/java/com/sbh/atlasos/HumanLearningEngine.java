package com.sbh.atlasos;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.function.BooleanSupplier;

/** Single-device owner learning model. No model, network, command execution or implicit consent. */
public final class HumanLearningEngine {
  public static final int MAX_ATTEMPTS=200, MAX_BYTES=65536;
  public interface Store { byte[] read() throws Exception; void write(byte[] data) throws Exception; void delete() throws Exception; }
  public static final class Failure extends Exception {
    public final String code;
    public Failure(String code){super(code);this.code=code;}
  }
  public static final class Preferences {
    public final String detail,practice; public final boolean examples;
    public Preferences(String detail,boolean examples,String practice)throws Failure {
      if(!Arrays.asList("brief","standard","detailed").contains(detail)||!Arrays.asList("optional","off").contains(practice))throw new Failure("INVALID_INPUT");
      this.detail=detail;this.examples=examples;this.practice=practice;
    }
  }
  public static final class Attempt {
    public final String id,lesson,digest; public final boolean correct,assisted; public final long at;
    Attempt(String id,String lesson,String digest,boolean correct,boolean assisted,long at){this.id=id;this.lesson=lesson;this.digest=digest;this.correct=correct;this.assisted=assisted;this.at=at;}
  }
  public static final class Profile {
    public final String generation; public final long revision,consentAt; public final boolean consent;
    public final Preferences preferences; public final List<Attempt> attempts;
    Profile(String gen,long rev,boolean consent,long at,Preferences p,List<Attempt> attempts){
      this.generation=gen;this.revision=rev;this.consent=consent;this.consentAt=at;this.preferences=p;
      this.attempts=Collections.unmodifiableList(new ArrayList<>(attempts));
    }
  }
  public static final class Lesson {
    public final String id,goal,explain,example,practice,answer,retry;
    Lesson(String id,String goal,String explain,String example,String practice,String answer,String retry){this.id=id;this.goal=goal;this.explain=explain;this.example=example;this.practice=practice;this.answer=answer;this.retry=retry;}
  }
  public static final Map<String,Lesson> LESSONS;
  static {
    Map<String,Lesson> m=new LinkedHashMap<>();
    m.put("job-contribution-v1",new Lesson("job-contribution-v1",
      "Separate cash collected from the amount left after direct job costs.",
      "Cash collected is not all profit. Subtract direct job costs first. Other overhead and taxes still remain.",
      "$300 collected minus $45 supplies, $25 disposal and $30 fuel leaves $200 before other overhead and taxes.",
      "Practice only: $400 collected, $50 supplies, $30 disposal and $20 fuel. What remains before other overhead and taxes? Enter a whole dollar amount.","300",
      "Add the costs first: 50 + 30 + 20 = 100. Then subtract 100 from 400."));
    m.put("deployment-evidence-v1",new Lesson("deployment-evidence-v1",
      "Distinguish tested source from a product installed on a phone.",
      "Passing source tests does not establish that an app was compiled, installed or tested on a device.",
      "Code that passes tests but has no verified installed app is staged, not deployed.",
      "Source tests passed. No installable app or real-device test is available. Classify the work: staged or deployed?","staged",
      "Ask what was actually checked: the code, or the app running on the phone? Only the code was checked here."));
    LESSONS=Collections.unmodifiableMap(m);
  }
  private final Store store; private final BooleanSupplier authorized;
  public HumanLearningEngine(Store store,BooleanSupplier authorized){this.store=Objects.requireNonNull(store);this.authorized=Objects.requireNonNull(authorized);}
  private void authorize()throws Failure {boolean ok=false;try{ok=authorized.getAsBoolean();}catch(Exception ignored){}if(!ok)throw new Failure("OWNER_UNLOCK_REQUIRED");}
  private Profile load()throws Exception {authorize();byte[] b=store.read();authorize();if(b==null)throw new Failure("NO_PROFILE");return decode(b);}
  private Profile save(Profile p)throws Exception {authorize();store.write(encode(p));return p;}
  private static void active(Profile p)throws Failure {if(!p.consent)throw new Failure("CONSENT_REQUIRED");}
  private static void match(Profile p,String generation,long revision)throws Failure {if(!p.generation.equals(generation)||p.revision!=revision)throw new Failure("REVISION_CONFLICT");}
  private static long increment(long n)throws Failure {if(n==Long.MAX_VALUE)throw new Failure("REVISION_LIMIT");return n+1;}
  public synchronized Profile inspect()throws Exception{return load();}
  public synchronized Profile create(boolean explicitConsent,Preferences p)throws Exception {
    authorize();if(!explicitConsent)throw new Failure("CONSENT_REQUIRED");if(store.read()!=null)throw new Failure("REVISION_CONFLICT");
    if(p==null)throw new Failure("INVALID_INPUT");
    return save(new Profile(UUID.randomUUID().toString(),1,true,System.currentTimeMillis(),p,Collections.emptyList()));
  }
  public synchronized Profile update(String gen,long rev,Preferences p)throws Exception {
    Profile old=load();match(old,gen,rev);active(old);if(p==null)throw new Failure("INVALID_INPUT");
    return save(new Profile(old.generation,increment(old.revision),true,old.consentAt,p,old.attempts));
  }
  public synchronized Profile consent(String gen,long rev,boolean enabled)throws Exception {
    Profile old=load();match(old,gen,rev);if(old.consent==enabled)return old;
    return save(new Profile(old.generation,increment(old.revision),enabled,System.currentTimeMillis(),old.preferences,old.attempts));
  }
  public synchronized void delete(String gen,long rev,boolean confirmed)throws Exception {
    Profile old=load();match(old,gen,rev);if(!confirmed)throw new Failure("CONFIRMATION_REQUIRED");authorize();store.delete();if(store.read()!=null)throw new Failure("STORAGE_FAILURE");
  }
  public synchronized Lesson lesson(String id,boolean urgent)throws Exception {
    Profile p=load();active(p);Lesson s=LESSONS.get(id);if(s==null)throw new Failure("INVALID_INPUT");
    return new Lesson(s.id,s.goal,s.explain,p.preferences.examples?s.example:null,!urgent&&p.preferences.practice.equals("optional")?s.practice:null,s.answer,s.retry);
  }
  public synchronized Profile submit(String gen,long rev,String id,String lesson,String answer,boolean assisted)throws Exception {
    Profile p=load();active(p);Lesson l=LESSONS.get(lesson);if(l==null||!uuid(id))throw new Failure("INVALID_INPUT");
    answer=plain(answer,120).toLowerCase(Locale.ROOT);String digest=digest(lesson+"\u0000"+answer+"\u0000"+assisted);
    for(Attempt a:p.attempts)if(a.id.equals(id)){
      if(!p.generation.equals(gen)||!a.digest.equals(digest))throw new Failure("REVISION_CONFLICT");return p;
    }
    match(p,gen,rev);if(p.attempts.size()>=MAX_ATTEMPTS)throw new Failure("ATTEMPT_LIMIT");
    List<Attempt> attempts=new ArrayList<>(p.attempts);attempts.add(new Attempt(id,lesson,digest,answer.equals(l.answer),assisted,System.currentTimeMillis()));
    return save(new Profile(p.generation,increment(p.revision),true,p.consentAt,p.preferences,attempts));
  }
  public static String feedback(Attempt a){return a.correct?"Correct for this exercise. This does not establish mastery or real-world performance.":LESSONS.get(a.lesson).retry;}
  public synchronized Profile progress()throws Exception{Profile p=load();active(p);return p;}
  public synchronized String render(String status,String outcome,String next,List<String> refs,List<String> details,List<String> blockers,List<String> warnings,String deadline)throws Exception {
    Profile p=load();active(p);return renderUpdate(p.preferences,status,outcome,next,refs,details,blockers,warnings,deadline);
  }
  public static String renderUpdate(Preferences p,String status,String outcome,String next,List<String> refs,List<String> details,List<String> blockers,List<String> warnings,String deadline)throws Failure {
    String prefix;switch(status){case "completed":prefix="Completed";break;case "staged":prefix="Prepared, not deployed";break;case "blocked":prefix="Blocked";break;case "unknown":prefix="Not verified";break;default:throw new Failure("INVALID_INPUT");}
    outcome=plain(outcome,240);next=plain(next,240);
    for(List<String> a:Arrays.asList(refs,details,blockers,warnings)){if(a==null||a.size()>12)throw new Failure("INVALID_INPUT");for(String s:a)plain(s,600);}
    if((status.equals("completed")||status.equals("staged"))&&refs.isEmpty())throw new Failure("EVIDENCE_REQUIRED");
    List<String> out=new ArrayList<>();out.add(prefix+": "+outcome.replaceAll("\\.+$","")+". Next: "+next.replaceAll("\\.+$","")+".");
    for(String s:warnings)out.add("Warning: "+s);for(String s:blockers)out.add("Blocker: "+s);
    if(deadline!=null)out.add("Deadline: "+plain(deadline,160));
    if(!p.detail.equals("brief"))out.addAll(details.subList(0,p.detail.equals("standard")?Math.min(2,details.size()):details.size()));
    if(!refs.isEmpty())out.add("Evidence: "+String.join("; ",refs));return String.join("\n\n",out);
  }
  public static String recognize(String text)throws Failure {
    String s=plain(text,4000).toLowerCase(Locale.ROOT).replaceAll("[.!]+$","").trim().replaceAll("\\s+"," ");
    switch(s){case "atlas deep sync":case "atlas deep sink":case "atlas deep sync everything":case "atlas deep sink everything":return "deep_sync";
      case "atlas red team forge":case "atlas red team forged":return "red_team_forge";
      case "do it":case "handle it":return "continue_current_task";case "draft only":case "do not execute":return "draft_only";default:return null;}
  }
  private static String plain(String s,int max)throws Failure{if(s==null||s.length()>max||s.trim().isEmpty())throw new Failure("INVALID_INPUT");for(char c:s.toCharArray())if(c<32&&c!='\n'&&c!='\t')throw new Failure("INVALID_INPUT");return s.trim();}
  private static boolean uuid(String s){try{return s!=null&&UUID.fromString(s).toString().equals(s);}catch(Exception e){return false;}}
  private static String digest(String s)throws Exception{StringBuilder b=new StringBuilder();for(byte x:MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8)))b.append(String.format(Locale.ROOT,"%02x",x&255));return b.toString();}
  static byte[] encode(Profile p)throws Exception{
    ByteArrayOutputStream b=new ByteArrayOutputStream();try(DataOutputStream d=new DataOutputStream(b)){
      d.writeInt(0x484c5031);d.writeUTF(p.generation);d.writeLong(p.revision);d.writeBoolean(p.consent);d.writeLong(p.consentAt);
      d.writeUTF(p.preferences.detail);d.writeBoolean(p.preferences.examples);d.writeUTF(p.preferences.practice);d.writeInt(p.attempts.size());
      for(Attempt a:p.attempts){d.writeUTF(a.id);d.writeUTF(a.lesson);d.writeUTF(a.digest);d.writeBoolean(a.correct);d.writeBoolean(a.assisted);d.writeLong(a.at);}}
    byte[] out=b.toByteArray();if(out.length>MAX_BYTES)throw new Failure("RECORD_LIMIT");return out;
  }
  static Profile decode(byte[] b)throws Exception{
    if(b.length>MAX_BYTES)throw new Failure("INVALID_RECORD");
    try(DataInputStream d=new DataInputStream(new ByteArrayInputStream(b))){
      if(d.readInt()!=0x484c5031)throw new Failure("INVALID_RECORD");String gen=d.readUTF();long rev=d.readLong();boolean consent=readBool(d);long at=d.readLong();
      if(!uuid(gen)||rev<1||at<0)throw new Failure("INVALID_RECORD");Preferences p=new Preferences(d.readUTF(),readBool(d),d.readUTF());
      int n=d.readInt();if(n<0||n>MAX_ATTEMPTS)throw new Failure("INVALID_RECORD");List<Attempt> a=new ArrayList<>();Set<String> ids=new HashSet<>();
      for(int i=0;i<n;i++){String id=d.readUTF(),lesson=d.readUTF(),hash=d.readUTF();boolean correct=readBool(d),assisted=readBool(d);long time=d.readLong();
        if(!uuid(id)||!ids.add(id)||!LESSONS.containsKey(lesson)||!hash.matches("[0-9a-f]{64}")||time<0)throw new Failure("INVALID_RECORD");a.add(new Attempt(id,lesson,hash,correct,assisted,time));}
      if(d.read()!=-1)throw new Failure("INVALID_RECORD");return new Profile(gen,rev,consent,at,p,a);
    }
  }
  private static boolean readBool(DataInputStream d)throws Exception{int n=d.readUnsignedByte();if(n>1)throw new Failure("INVALID_RECORD");return n==1;}
}
