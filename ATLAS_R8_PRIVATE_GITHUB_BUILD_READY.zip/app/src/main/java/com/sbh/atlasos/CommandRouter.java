package com.sbh.atlasos;

import android.content.*;
import android.content.pm.*;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.provider.MediaStore;
import android.provider.Settings;
import java.text.DateFormat;
import java.util.*;

/** Typed deterministic local command lane. It never pretends to be the authenticated Atlas brain. */
public final class CommandRouter {
  private CommandRouter() {}

  public static String runLockSafe(Context context, String raw) {
    CommandParser.Parsed p = CommandParser.parse(raw);
    if (!CommandParser.isLockSafe(p)) return "OWNER_UNLOCK_REQUIRED";
    return runParsed(context, p);
  }

  public static String run(Context context, String raw) {
    return runParsed(context, CommandParser.parse(raw));
  }

  private static String runParsed(Context context, CommandParser.Parsed parsed) {
    try {
      switch (parsed.kind) {
        case TIME:
          return "ANSWER:" + DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date());
        case DATE:
          return "ANSWER:" + DateFormat.getDateInstance(DateFormat.FULL).format(new Date());
        case BATTERY: {
          BatteryManager bm = (BatteryManager) context.getSystemService(Context.BATTERY_SERVICE);
          int pct = bm == null ? -1 : bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
          return pct >= 0 ? "ANSWER:Battery is at " + pct + " percent." : "BATTERY_UNAVAILABLE";
        }
        case IDENTITY:
          return "ANSWER:I'm Atlas, your private second-brain and device assistant interface.";
        case HELP:
          return "ANSWER:I can handle approved device commands locally, answer basic device facts, and hand broader questions to the authenticated Atlas brain when that backend is connected.";
        case WIFI_SETTINGS:
          return start(context, new Intent(Settings.ACTION_WIFI_SETTINGS), "OPENED_WIFI_SETTINGS");
        case BLUETOOTH_SETTINGS:
          return start(context, new Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "OPENED_BLUETOOTH_SETTINGS");
        case AIRPLANE_SETTINGS:
          return start(context, new Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS), "OPENED_AIRPLANE_SETTINGS");
        case SETTINGS:
          return start(context, new Intent(Settings.ACTION_SETTINGS), "OPENED_SETTINGS");
        case CAMERA:
          return start(context, new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), "OPENED_CAMERA");
        case DIAL:
          return start(context, new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + parsed.argument)), "OPENED_DIALER");
        case TEXT: {
          Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"));
          i.putExtra("sms_body", parsed.argument);
          return start(context, i, "OPENED_MESSAGE_COMPOSER");
        }
        case NAVIGATE:
          return start(context, new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(parsed.argument))), "OPENED_NAVIGATION");
        case SEARCH:
          return start(context, new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(parsed.argument))), "OPENED_SEARCH");
        case OPEN_APP: {
          String pkg = findPackageByLabel(context, parsed.argument);
          if (pkg == null) return "APP_NOT_FOUND_OR_AMBIGUOUS";
          Intent launch = context.getPackageManager().getLaunchIntentForPackage(pkg);
          if (launch == null) return "APP_NOT_LAUNCHABLE";
          return start(context, launch, "OPENED_APP:" + pkg);
        }
        case VOLUME_UP:
          return volume(context, AudioManager.ADJUST_RAISE, "VOLUME_UP");
        case VOLUME_DOWN:
          return volume(context, AudioManager.ADJUST_LOWER, "VOLUME_DOWN");
        case MUTE:
          return volume(context, AudioManager.ADJUST_MUTE, "MUTED");
        case UNMUTE:
          return volume(context, AudioManager.ADJUST_UNMUTE, "UNMUTED");
        case FLASHLIGHT_ON:
          return torch(context, true);
        case FLASHLIGHT_OFF:
          return torch(context, false);
        case BIRDS_BEWARE:
          return start(context, new Intent(Intent.ACTION_VIEW, Uri.parse("https://birdsbewaremd.com")), "OPENED_BIRDS_BEWARE");
        case INVALID:
          return "INVALID_COMMAND";
        case UNKNOWN:
        default:
          return "NO_LOCAL_MATCH";
      }
    } catch (SecurityException e) {
      return "PERMISSION_REQUIRED";
    } catch (ActivityNotFoundException e) {
      return "NO_HANDLER";
    } catch (Exception e) {
      return "COMMAND_FAILED";
    }
  }

  private static String start(Context context, Intent i, String ok) {
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    PackageManager pm = context.getPackageManager();
    if (i.resolveActivity(pm) == null) return "NO_HANDLER";
    context.startActivity(i);
    return ok;
  }

  private static String volume(Context context, int direction, String ok) {
    AudioManager a = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
    if (a == null) return "AUDIO_UNAVAILABLE";
    a.adjustVolume(direction, AudioManager.FLAG_SHOW_UI);
    return ok;
  }

  private static String torch(Context context, boolean on) throws Exception {
    CameraManager cm = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
    if (cm == null) return "CAMERA_UNAVAILABLE";
    for (String id : cm.getCameraIdList()) {
      Boolean flash = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
      if (Boolean.TRUE.equals(flash)) {
        cm.setTorchMode(id, on);
        return on ? "FLASHLIGHT_ON" : "FLASHLIGHT_OFF";
      }
    }
    return "FLASHLIGHT_UNAVAILABLE";
  }

  /** Exact label wins. Partial label is accepted only when exactly one package matches. */
  private static String findPackageByLabel(Context context, String wanted) {
    if (wanted == null || wanted.trim().isEmpty()) return null;
    PackageManager pm = context.getPackageManager();
    Intent main = new Intent(Intent.ACTION_MAIN, null);
    main.addCategory(Intent.CATEGORY_LAUNCHER);
    List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
    String needle = wanted.trim().toLowerCase(Locale.US);
    String partial = null;
    for (ResolveInfo r : apps) {
      String label = String.valueOf(r.loadLabel(pm));
      if (label.equalsIgnoreCase(wanted)) return r.activityInfo.packageName;
      if (label.toLowerCase(Locale.US).contains(needle)) {
        if (partial != null && !partial.equals(r.activityInfo.packageName)) return null;
        partial = r.activityInfo.packageName;
      }
    }
    return partial;
  }
}
