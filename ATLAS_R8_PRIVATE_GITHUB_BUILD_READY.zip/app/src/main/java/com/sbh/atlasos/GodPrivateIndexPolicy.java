package com.sbh.atlasos;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.List;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Private GOD goal index policy. DOES NOT grant authentication/permissions.
 * Neither goals, source prose nor private addresses are included in the APK.
 * The owner separately imports the exact hashed ZIP into encrypted vault storage.
 */
public final class GodPrivateIndexPolicy {
  public static final String INDEX_NAME = "god/GOD_PRIVATE_MASTER_V1.json";
  public static final String EXPECTED_SHA256 = "1330e91441fa1c03a2bfb376f7f5882f5cf56d254692a2343897b293896f25d0";
  private GodPrivateIndexPolicy() {}

  public static boolean isCandidatePath(String relative) {
    if(relative==null || relative.length()>256 || relative.indexOf('\\')>=0
       || relative.indexOf(':')>=0 || relative.indexOf((char)0)>=0)return false;
    String[] parts=relative.split("/",-1);
    if(parts.length!=4 || !parts[0].matches("import-[a-zA-Z0-9-]+")
       || !"files".equals(parts[1]) || !"god".equals(parts[2])
       || !"GOD_PRIVATE_MASTER_V1.json".equals(parts[3]))return false;
    for(String part:parts)if(part.isEmpty() || part.equals(".") || part.equals(".."))return false;
    return true;
  }

  public static List<String> candidatePaths(List<String> paths) {
    ArrayList<String> found=new ArrayList<>();
    if(paths==null)return found;
    for(String path:paths)if(isCandidatePath(path))found.add(path);
    return found;
  }

  public static boolean trustedContent(String text) {
    if(text==null || text.length()>200000 || text.length()<100)return false;
    try{
      byte[] content=text.getBytes(StandardCharsets.UTF_8);
      if(content.length>200000)return false;
      byte[] digest=MessageDigest.getInstance("SHA-256").digest(content);
      StringBuilder b=new StringBuilder(64);
      for(byte n:digest)b.append(String.format(Locale.ROOT,"%02x",n&0xff));
      return MessageDigest.isEqual(b.toString().getBytes(StandardCharsets.US_ASCII),EXPECTED_SHA256.getBytes(StandardCharsets.US_ASCII));
    }catch(Exception ex){return false;}
  }
}
