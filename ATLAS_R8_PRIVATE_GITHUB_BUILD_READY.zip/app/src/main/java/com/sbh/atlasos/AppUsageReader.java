package com.sbh.atlasos;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.os.Process;
import android.os.UserManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Owner-only, one-shot local Android usage lookup; no timers, disk, exports or network. */
public final class AppUsageReader {
  private AppUsageReader() {}

  public static boolean hasSpecialAccess(Context c) {
    if (c == null) return false;
    try {
      AppOpsManager ops = (AppOpsManager)c.getSystemService(Context.APP_OPS_SERVICE);
      return ops != null && ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
          Process.myUid(), c.getPackageName()) == AppOpsManager.MODE_ALLOWED;
    } catch (RuntimeException e) { return false; }
  }

  public static List<String> readOnce(Context c, long ownerGeneration) {
    if (c == null || !OwnerSessionGate.isCurrent(c, ownerGeneration)
        || !hasSpecialAccess(c)) return Collections.emptyList();
    try {
      UserManager manager = (UserManager)c.getSystemService(Context.USER_SERVICE);
      if (manager == null || !manager.isUserUnlocked()) return Collections.emptyList();
      UsageStatsManager usage = (UsageStatsManager)c.getSystemService(Context.USAGE_STATS_SERVICE);
      if (usage == null) return Collections.emptyList();
      final long now = System.currentTimeMillis();
      UsageEvents raw = usage.queryEvents(now - AppAwarenessPolicy.MAX_MINUTES * 60_000L, now);
      if (raw == null) return Collections.emptyList();
      ArrayList<AppAwarenessPolicy.EventRow> observed = new ArrayList<>();
      UsageEvents.Event row = new UsageEvents.Event();
      // Refuse to trust excessively large results; never turn this into a long-running monitor.
      int scanned = 0;
      while (raw.hasNextEvent()) {
        if (!OwnerSessionGate.isCurrent(c, ownerGeneration)) return Collections.emptyList();
        if (++scanned > AppAwarenessPolicy.MAX_EVENTS) return Collections.emptyList();
        if (!raw.getNextEvent(row)) break;
        int type = row.getEventType();
        if (type == UsageEvents.Event.ACTIVITY_RESUMED
            || type == UsageEvents.Event.MOVE_TO_FOREGROUND) {
          observed.add(new AppAwarenessPolicy.EventRow(row.getPackageName(), row.getTimeStamp()));
        }
      }
      if (!OwnerSessionGate.isCurrent(c, ownerGeneration)) return Collections.emptyList();
      return AppAwarenessPolicy.recentPackages(observed, now,
          AppAwarenessPolicy.MAX_MINUTES, c.getPackageName());
    } catch (RuntimeException refused) {
      return Collections.emptyList();
    }
  }
}
