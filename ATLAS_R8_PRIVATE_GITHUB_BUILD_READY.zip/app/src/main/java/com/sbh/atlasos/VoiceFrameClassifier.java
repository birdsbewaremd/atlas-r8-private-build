package com.sbh.atlasos;

import java.util.Locale;

/**
 * Conservative first-pass frame classifier for voice turns.
 * This does not answer knowledge questions; it only preserves the question's context
 * so the authenticated brain lane can avoid mixing fiction, private state, and real-world facts.
 */
public final class VoiceFrameClassifier {
  public enum Frame { REAL_WORLD, FICTION_LORE, SHAUN_PRIVATE, DEVICE_ACTION, HIGH_STAKES }
  private VoiceFrameClassifier() {}

  public static Frame classify(String raw) {
    String c = VoiceCommandParser.normalize(raw).toLowerCase(Locale.US);
    if (c.isEmpty()) return Frame.REAL_WORLD;

    if (looksLikeDeviceAction(c)) return Frame.DEVICE_ACTION;

    if (containsAny(c,
        "assassin's creed", "assassins creed", "abstergo", "templar", "animus",
        "in the game", "in that game", "in the movie", "in that movie", "in the show",
        "fictional", "fiction", "lore", "canon", "character", "universe")) {
      return Frame.FICTION_LORE;
    }

    if (containsAny(c,
        "hospital", "doctor", "medical", "medicine", "medication", "chest pain", "heart", "lung", "lungs",
        "head injury", "concussion", "legal", "lawyer", "attorney", "court", "charges", "police",
        "loan", "debt", "credit", "bank", "payment", "tax", "insurance claim",
        "password", "passcode", "api key", "secret key", "credential", "recovery code",
        "weapon", "gun", "suicide", "self harm", "self-harm")) {
      return Frame.HIGH_STAKES;
    }

    if (containsAny(c,
        "shaun os", "my atlas", "my calendar", "my email", "my gmail", "my files", "my drive",
        "my money", "my bank", "my health", "my medical", "my business", "my customers",
        "birds beware", "my dad", "my family", "my schedule", "my account", "my private")) {
      return Frame.SHAUN_PRIVATE;
    }

    return Frame.REAL_WORLD;
  }

  public static String classifyName(String raw) { return classify(raw).name(); }

  public static boolean looksLikeDeviceAction(String c) {
    return startsWithAny(c,
        "open ", "launch ", "navigate ", "navigate to ", "directions ", "directions to ",
        "take me to ", "go to ", "search ", "search for ", "look up ", "google ",
        "call ", "dial ", "text ", "message ")
        || equalsAny(c, "wifi", "wi fi", "bluetooth", "settings", "camera", "time", "date", "battery",
            "volume up", "volume down", "mute", "unmute", "flashlight on", "flashlight off",
            "turn on the flashlight", "turn off the flashlight", "take a photo", "take a picture")
        || c.contains(" settings") || c.contains("battery percent") || c.contains("battery percentage");
  }

  private static boolean containsAny(String s, String... xs) {
    for (String x : xs) if (s.contains(x)) return true;
    return false;
  }

  private static boolean startsWithAny(String s, String... xs) {
    for (String x : xs) if (s.startsWith(x)) return true;
    return false;
  }

  private static boolean equalsAny(String s, String... xs) {
    for (String x : xs) if (s.equals(x)) return true;
    return false;
  }
}
