package com.sbh.atlasos;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** User-directed Android permission and role review. No auto-grants, auto-launches, or covert access. */
public final class AtlasAccessCenterActivity extends Activity {
    private static final int BACK = Color.rgb(9,10,25);
    private static final int SURFACE = Color.rgb(28,25,52);
    private static final int VIOLET = Color.rgb(169,125,255);
    private static final int PALE = Color.rgb(199,205,227);
    private static final int REQUEST_AUDIO = 7131;
    private static final int REQUEST_CAMERA = 7132;
    private static final int REQUEST_NOTIFICATION = 7133;
    private LinearLayout content;
    private final java.util.Map<String,TextView> statusViews=new java.util.HashMap<>();
    private final java.util.Map<String,Button> actionViews=new java.util.HashMap<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BACK);
        getWindow().setNavigationBarColor(BACK);
        // The Access Center never draws over the secure Android lock screen.
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        draw();
    }
    @Override public void onResume() { super.onResume(); if (content != null) refreshStatuses(); }

    private int dp(int n) { return Math.round(n*getResources().getDisplayMetrics().density); }
    private GradientDrawable bg(int color,int radius){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;
    }
    private TextView text(String value,int font,int color,boolean strong){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(font);t.setTextColor(color);
        if(strong)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private void pad(View v,int n){v.setPadding(dp(n),dp(n),dp(n),dp(n));}
    private void gap(int n){View v=new View(this);content.addView(v,new LinearLayout.LayoutParams(1,dp(n)));}
    private void title(String value){content.addView(text(value,13,VIOLET,true));gap(6);}
    private Button actionButton(String label,Runnable fn) {
        Button b=new Button(this);b.setAllCaps(false);b.setText(label);b.setTextSize(13);b.setTextColor(Color.WHITE);
        b.setMinHeight(dp(49));b.setBackground(bg(Color.rgb(85,49,144),12));
        b.setOnClickListener(v->fn.run());return b;
    }

    private void draw(){
        statusViews.clear(); actionViews.clear();
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);scroll.setBackgroundColor(BACK);
        content=column();pad(content,16);scroll.addView(content);
        setContentView(scroll);
        TextView brand=text("ATLAS  /  ACCESS CENTER",13,VIOLET,true);content.addView(brand);gap(10);
        content.addView(text("Your phone. Your permissions.",28,Color.WHITE,true));gap(8);
        content.addView(text("Tap a capability to review it with Android. Nothing is enabled automatically. Status is checked live on this device.",14,PALE,false));
        gap(14);
        TextView policy=text("Quick setup · Approve only what you need. Android controls every protected grant; you can revoke access later in Settings.",13,Color.rgb(231,218,255),false);
        pad(policy,13);policy.setBackground(bg(Color.rgb(38,30,71),14));content.addView(policy);gap(17);
        title("ESSENTIAL SETUP");
        row("home","Default ATLAS Home","Switch from Samsung Home only if you choose. Samsung Home remains an option.",()->requestRole(RoleManager.ROLE_HOME,Settings.ACTION_HOME_SETTINGS));
        row("notifications","ATLAS notifications","Android can allow or deny the app's notifications.",()->requestRuntime("notifications",Manifest.permission.POST_NOTIFICATIONS,REQUEST_NOTIFICATION));
        row("microphone","Microphone","Used only by voice features you start; no permission enables the listener by itself.",()->requestRuntime("microphone",Manifest.permission.RECORD_AUDIO,REQUEST_AUDIO));
        row("camera","Camera","For future visible camera features; no hidden or continuous video capture.",()->requestRuntime("camera",Manifest.permission.CAMERA,REQUEST_CAMERA));
        row("assistant","Android Assistant","Optional assistant role. Not the same as always-on listening.",()->requestRole(RoleManager.ROLE_ASSISTANT,Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));
        gap(13);title("DATA & DEVICE");
        row("app_settings","All ATLAS permissions / revoke","Open ATLAS's exact App info page, then Permissions or Special access.",this::appInfo);
        row("usage","Usage Access","Optional, owner-initiated app-name/foreground-time review; no message reading.",()->settings(Settings.ACTION_USAGE_ACCESS_SETTINGS));
        row("files","Files & archives","No unrestricted storage. Select individual files inside private ATLAS Core.",()->core("Unlock ATLAS and use Library Transfer to select files."));
        row("bluetooth","Bluetooth controls","Open Bluetooth Settings. Pairing and device control require separate approval.",()->settings(Settings.ACTION_BLUETOOTH_SETTINGS));
        row("wallpaper","ATLAS lock-screen appearance","Customize wallpaper and clock. Android PIN, fingerprint, and emergencies remain intact.",()->settings(Settings.ACTION_WALLPAPER_SETTINGS));
        row("messages","Messages","Your installed Google Messages app works without ATLAS reading its private database.",()->openMessages());
        row("phone","Phone","Use the normal dialer; ATLAS does not need unrestricted calls or call logs.",()->safeOpen(new Intent(Intent.ACTION_DIAL)));
        gap(13);title("RESTRICTED / NOT ENABLED");
        informative("Accessibility / screen control", "No ATLAS Accessibility service is implemented in this build. Do not enable unknown services to grant 'everything'.");
        informative("Read every notification, SMS, other apps' private files", "Not granted and not built. Android isolates each app's data and requires separate, purpose-limited integrations.");
        informative("System lock-screen replacement", "Not supported for ordinary installed launchers. Android controls secure keyguard authentication.");
        gap(12);
        Button stop=actionButton("STOP ATLAS WAKE LISTENER",this::stopWake);
        content.addView(stop);gap(7);
        content.addView(text("This stops the existing ATLAS wake listener if present; it does not change Android microphone permission.",12,PALE,false));
        gap(8);
        Button settings=actionButton("OPEN ATLAS APP SETTINGS",this::appInfo);content.addView(settings);
        gap(12);
        content.addView(text("Private development source. Phone-side installation and grants not verified. No automatic settings, app control, or device changes are performed here.",12,PALE,false));
        gap(35);
    }
    private void row(String id,String heading,String details,Runnable action) {
        LinearLayout card=column();pad(card,12);card.setBackground(bg(SURFACE,15));
        LinearLayout headingLine=new LinearLayout(this);headingLine.setOrientation(LinearLayout.HORIZONTAL);headingLine.setGravity(Gravity.CENTER_VERTICAL);
        TextView name=text(heading,16,Color.WHITE,true);
        headingLine.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        String status=AtlasAccessStatus.status(this,id);
        TextView pill=text(status,10,"ALLOWED".equals(status)?Color.rgb(132,231,180):VIOLET,true);
        pill.setPadding(dp(8),dp(4),dp(8),dp(4));pill.setBackground(bg(BACK,8));headingLine.addView(pill);
        statusViews.put(id,pill);
        card.addView(headingLine);
        TextView desc=text(details,13,PALE,false);desc.setPadding(0,dp(7),0,dp(9));card.addView(desc);
        Button button=actionButton("ALLOWED".equals(status)?"Review or revoke in Android":"Review with Android",action);
        actionViews.put(id,button);card.addView(button);content.addView(card);gap(8);
    }
    private void refreshStatuses(){
        for(java.util.Map.Entry<String,TextView> e:statusViews.entrySet()){
            String status=AtlasAccessStatus.status(this,e.getKey());
            TextView badge=e.getValue();badge.setText(status);
            badge.setTextColor("ALLOWED".equals(status)?Color.rgb(132,231,180):VIOLET);
            Button action=actionViews.get(e.getKey());
            if(action!=null)action.setText("ALLOWED".equals(status)?"Review or revoke in Android":"Review with Android");
        }
    }
    private void informative(String label,String detail){
        LinearLayout card=column();pad(card,12);card.setBackground(bg(SURFACE,12));
        card.addView(text(label+" · NOT ENABLED",14,VIOLET,true));gap(1);
        card.addView(text(detail,12,PALE,false));content.addView(card);gap(7);
    }
    private void requestRuntime(String id,String permission,int code) {
        if("notifications".equals(id)&&Build.VERSION.SDK_INT<33){appNotificationSettings();return;}
        if(checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED){
            new AlertDialog.Builder(this).setTitle("Already allowed")
              .setMessage("Android reports "+id+" is allowed. To review or revoke, open ATLAS App info.")
              .setNegativeButton("Cancel",null).setPositiveButton("App info",(d,w)->appInfo()).show();return;
        }
        String purpose="microphone".equals(id)?"ATLAS voice features only when initiated or enabled by you.":
            "camera".equals(id)?"Visible camera features initiated by you; no silent recording.":
            "Notifications for ATLAS status and owner-approved features.";
        new AlertDialog.Builder(this).setTitle("Review "+id+" permission")
           .setMessage(purpose+" Android makes the final decision. You can deny or revoke this later.")
           .setNegativeButton("Not now",null)
           .setPositiveButton("Continue to Android",(d,w)->requestPermissions(new String[]{permission},code)).show();
    }
    private void requestRole(String name,String fallback){
        new AlertDialog.Builder(this).setTitle("Review Android default role")
          .setMessage("Android will ask if you want ATLAS as "+("android.app.role.HOME".equals(name)?"your Home app":"your assistant")+". No change occurs unless you select it. You can switch back.")
          .setNegativeButton("Cancel",null)
          .setPositiveButton("Open Android chooser",(d,w)->{
              try{RoleManager rm=(RoleManager)getSystemService(Context.ROLE_SERVICE);
                if(rm!=null&&rm.isRoleAvailable(name)){
                  if(rm.isRoleHeld(name)){notice("ATLAS already holds this role. To change it, use Android Settings.");settings(fallback);}
                  else startActivity(rm.createRequestRoleIntent(name));
                }else settings(fallback);
              }catch(RuntimeException refused){settings(fallback);}
          }).show();
    }
    private void settings(String action){safeOpen(new Intent(action));}
    private void appInfo(){safeOpen(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
        Uri.parse("package:"+getPackageName())));}
    private void appNotificationSettings(){
        Intent i=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
        i.putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName());safeOpen(i);
    }
    private void core(String msg){notice(msg);safeOpen(new Intent(this,MainActivity.class));}
    private void safeOpen(Intent intent){
        try{startActivity(intent);}
        catch(ActivityNotFoundException missing){notice("Android does not provide that screen on this device. Use Settings → Apps → ATLAS.");}
        catch(SecurityException denied){notice("Android denied this action. Use Settings → Apps → ATLAS.");}
        catch(RuntimeException failed){notice("This shortcut is unavailable; Settings → Apps → ATLAS remains available.");}
    }
    private void openMessages(){
        Intent i=Intent.makeMainSelectorActivity(Intent.ACTION_MAIN,Intent.CATEGORY_APP_MESSAGING);
        safeOpen(i);
    }
    private void stopWake(){
        // STOP is reversible and does not need additional permissions.
        try{Intent i=new Intent(this,AtlasWakeService.class).setAction(AtlasWakeService.ACTION_STOP);
            startService(i);notice("Wake stop requested. Android microphone permission remains unchanged.");}
        catch(RuntimeException failed){notice("Wake service was not running or Android blocked stopping it.");}
    }
    @Override public void onRequestPermissionsResult(int request,String[] names,int[] grants){
        super.onRequestPermissionsResult(request,names,grants);
        if(request==REQUEST_AUDIO||request==REQUEST_CAMERA||request==REQUEST_NOTIFICATION){
            boolean allowed=grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED;
            notice(allowed?"Android allowed this permission. Review it any time in Settings.":"Android did not grant this permission. Core phone functions remain available.");
            refreshStatuses();
        }
    }
    private void notice(String msg){Toast.makeText(this,msg,Toast.LENGTH_LONG).show();}
}
