package com.sbh.atlasos;
import android.content.Context;
import android.util.AtomicFile;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.io.*;
import java.security.KeyStore;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

/** Dedicated no-backup file, unrelated to Shaun OS/vault import. Single process writer only. */
final class AndroidLearningStore implements HumanLearningEngine.Store {
  private static final String ALIAS="atlas_human_learning_key_v1";
  private final AtomicFile file;
  AndroidLearningStore(Context c){file=new AtomicFile(new File(c.getNoBackupFilesDir(),"human_learning_v1.enc"));}
  private SecretKey key(boolean create)throws Exception{
    KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
    if(!ks.containsAlias(ALIAS)){
      if(!create)throw new IOException("key unavailable");
      KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
      kg.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setRandomizedEncryptionRequired(true).setKeySize(256).build());kg.generateKey();
    }
    return (SecretKey)ks.getKey(ALIAS,null);
  }
  @Override public byte[] read()throws Exception{
    try(InputStream in=file.openRead();ByteArrayOutputStream out=new ByteArrayOutputStream()){
      byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1){if(out.size()+n>HumanLearningEngine.MAX_BYTES+32)throw new IOException("record limit");out.write(b,0,n);}
      return LearningCipher.decrypt(out.toByteArray(),key(false));
    }catch(FileNotFoundException e){if(hasArtifacts())throw e;return null;}
  }
  @Override public void write(byte[] plain)throws Exception{
    byte[] blob=LearningCipher.encrypt(plain,key(true));FileOutputStream out=null;
    try{out=file.startWrite();out.write(blob);out.getFD().sync();file.finishWrite(out);out=null;
      byte[] persisted=read();if(!java.util.Arrays.equals(plain,persisted))throw new IOException("save not verified");
    }catch(Exception e){if(out!=null)file.failWrite(out);throw e;}
  }
  private boolean hasArtifacts(){
    File base=file.getBaseFile();
    // Failed recovery/rename must not be misreported as a never-created profile.
    return base.exists()||new File(base.getPath()+".bak").exists()||new File(base.getPath()+".new").exists();
  }
  @Override public void delete()throws Exception{file.delete();if(hasArtifacts())throw new IOException("delete failed");}
}
