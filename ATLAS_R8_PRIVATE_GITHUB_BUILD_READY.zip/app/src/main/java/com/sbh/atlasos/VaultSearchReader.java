package com.sbh.atlasos;

import java.io.*;
import java.nio.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.util.*;
import java.util.function.BooleanSupplier;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Bounded, read-only search access. Caller supplies the real owner-session check. */
public final class VaultSearchReader {
  public static final int MAX_TEXT_BYTES=256*1024;
  public static final int MAX_FILES=5000;
  public static final int MAX_VISITS=20000;
  private static final int MAX_DEPTH=32;
  private static final Set<String> TEXT=new HashSet<>(Arrays.asList("txt","md","json","jsonl","csv","tsv","log","yaml","yml"));
  private VaultSearchReader(){}

  public static final class Rejected extends IOException {
    public final String status;
    public Rejected(String status){super(status);this.status=status;}
  }
  public static final class Listing {
    public final List<String> paths;
    public final boolean truncated;
    public final int skipped;
    Listing(List<String> paths,boolean truncated,int skipped){this.paths=Collections.unmodifiableList(paths);this.truncated=truncated;this.skipped=skipped;}
  }
  private static void authorized(BooleanSupplier auth)throws Rejected {
    boolean permitted=false;
    try{permitted=auth!=null&&auth.getAsBoolean();}catch(RuntimeException ignored){}
    if(!permitted)throw new Rejected("locked");
  }
  public static boolean textPath(String relative){
    if(relative==null||relative.length()>2048||relative.indexOf('\\')>=0||relative.indexOf(':')>=0||relative.startsWith("/"))return false;
    for(String part:relative.split("/",-1))if(part.isEmpty()||part.equals(".")||part.equals("..")||part.startsWith("."))return false;
    for(int i=0;i<relative.length();i++)if(Character.isISOControl(relative.charAt(i)))return false;
    int dot=relative.lastIndexOf('.');
    return dot>relative.lastIndexOf('/')&&TEXT.contains(relative.substring(dot+1).toLowerCase(Locale.ROOT));
  }
  public static Listing list(File root,BooleanSupplier auth)throws IOException {
    authorized(auth);
    if(!root.exists())return new Listing(new ArrayList<>(),false,0);
    Path base=root.toPath().toAbsolutePath().normalize();
    if(Files.isSymbolicLink(base)||!Files.isDirectory(base,LinkOption.NOFOLLOW_LINKS))throw new Rejected("unreadable");
    List<String> out=new ArrayList<>();Deque<Path> todo=new ArrayDeque<>();todo.add(base);
    int visits=0,skipped=0;boolean truncated=false;
    while(!todo.isEmpty()){
      authorized(auth);Path dir=todo.removeFirst();
      if(base.relativize(dir).getNameCount()>MAX_DEPTH){truncated=true;skipped++;continue;}
      try(DirectoryStream<Path> children=Files.newDirectoryStream(dir)){
        for(Path p:children){
          authorized(auth);
          if(++visits>MAX_VISITS){truncated=true;break;}
          if(Files.isSymbolicLink(p)){skipped++;continue;}
          if(Files.isDirectory(p,LinkOption.NOFOLLOW_LINKS)){todo.add(p);continue;}
          if(!Files.isRegularFile(p,LinkOption.NOFOLLOW_LINKS))continue;
          String rel=base.relativize(p.toAbsolutePath().normalize()).toString().replace(File.separatorChar,'/');
          if(rel.endsWith(".atlasenc")){
            if(out.size()>=MAX_FILES){truncated=true;break;}
            out.add(rel.substring(0,rel.length()-9));
          }
        }
      }catch(DirectoryIteratorException ex){truncated=true;skipped++;}
      catch(IOException ex){if(ex instanceof Rejected)throw ex;truncated=true;skipped++;}
      if(visits>MAX_VISITS||out.size()>=MAX_FILES){if(!todo.isEmpty())truncated=true;break;}
    }
    authorized(auth);Collections.sort(out);return new Listing(out,truncated,skipped);
  }
  public static String read(File root,String relative,SecretKey key,BooleanSupplier auth)throws Exception {
    authorized(auth);
    if(!textPath(relative))throw new Rejected("unsupported");
    Path base=root.toPath().toAbsolutePath().normalize();
    Path file=base.resolve(relative+".atlasenc").normalize();
    if(!file.startsWith(base))throw new Rejected("unsupported");
    Path walk=base;
    if(Files.isSymbolicLink(base))throw new Rejected("unreadable");
    for(Path part:base.relativize(file)){walk=walk.resolve(part);if(Files.isSymbolicLink(walk))throw new Rejected("unreadable");}
    if(!Files.isRegularFile(file,LinkOption.NOFOLLOW_LINKS))throw new Rejected("unreadable");
    long length=Files.size(file);
    if(length>MAX_TEXT_BYTES+53L)throw new Rejected("too_large");
    if(length<33L)throw new Rejected("unreadable");
    byte[] encoded=null,plain=null;
    try{
      // Bound the actual read as well as the preflight size, including concurrent growth.
      try(InputStream in=Files.newInputStream(file,LinkOption.NOFOLLOW_LINKS);ByteArrayOutputStream out=new ByteArrayOutputStream()){
        byte[] buffer=new byte[8192];int n,total=0;
        while((n=in.read(buffer))!=-1){authorized(auth);total+=n;if(total>MAX_TEXT_BYTES+53)throw new Rejected("too_large");out.write(buffer,0,n);}
        encoded=out.toByteArray();
      }
      if(encoded.length<33||encoded[0]!='A'||encoded[1]!='T'||encoded[2]!='L'||encoded[3]!='1')throw new Rejected("unreadable");
      int ivLength=encoded[4]&255;
      if(ivLength<12||ivLength>32||encoded.length<5+ivLength+16)throw new Rejected("unreadable");
      if(encoded.length-(5+ivLength+16)>MAX_TEXT_BYTES)throw new Rejected("too_large");
      authorized(auth);
      Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
      cipher.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,Arrays.copyOfRange(encoded,5,5+ivLength)));
      // doFinal verifies the GCM authentication tag before any plaintext is returned.
      plain=cipher.doFinal(encoded,5+ivLength,encoded.length-5-ivLength);
      if(plain.length>MAX_TEXT_BYTES)throw new Rejected("too_large");
      authorized(auth);
      String result=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
        .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(plain)).toString();
      if(result.indexOf('\0')>=0)throw new Rejected("unsupported");
      authorized(auth);return result;
    }catch(Rejected ex){throw ex;}
    catch(Exception ex){throw new Rejected("unreadable");}
    finally{if(encoded!=null)Arrays.fill(encoded,(byte)0);if(plain!=null)Arrays.fill(plain,(byte)0);}
  }
}
