package com.sbh.atlasos;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * GODFORGE V3 keyword recognizer. READ-ONLY metadata for an independently
 * authenticated input route; this class does not authorize or execute actions.
 *
 * Intentionally rejects ambiguous prayer and religious discourse, especially
 * "God help me" and "God save me". Explicit ATLAS GOD or GOD: is needed
 * for those ambiguous imperative phrases, and still grants ZERO authority.
 */
public final class GodCommandPolicy {
  public static final int MAX_INPUT_CHARS = CommandParser.MAX_COMMAND_CHARS;
  public enum Scope { NONE, PORTFOLIO, TARGETED }
  private static final Pattern PREFIX = Pattern.compile(
      "^(atlas\\s*[,:-]?\\s+)?god\\b(.*)$", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
  private static final Pattern IMPERATIVE = Pattern.compile(
      "^(do|make|build|research|find|improve|audit|secure|sync|organize|plan|prototype|test|fix|run|verify|help|continue|prepare|create|save|design|develop|execute|check|study|read|compare|analyze|draft|investigate|review|implement|optimize|open|call|text|message|send|email|book|purchase|buy|sell|trade|drive|launch|deploy|delete|wipe|unlock|turn|switch|record|monitor|connect|install|publish)\\b(?:\\s+|\\s*:\\s*)(.+)$",
      Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
  private static final Pattern DISCUSSION = Pattern.compile(
      "^(is|was|means|exists|does|can|will|who|why|where|what|how|in|and|loves|bless|created|the father|isn't|the lord|forgive|hear|please)\\b.*$",
      Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
  private static final Pattern UNMARKED_PRAYER = Pattern.compile(
      "^(?:help\\s+me\\b.*|save\\s+me\\b.*|send\\s+me\\s+(?:a\\s+sign|an\\s+angel|a\\s+miracle)\\b.*|make\\s+me\\s+(?:holy|righteous|faithful)\\b.*|do\\s+(?:you|we|i|they)\\b.*)$",
      Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
  private static final Pattern EXPLICIT_TASK_QUESTION = Pattern.compile(
      "^(?:can\\s+we|how\\s+(?:do|can)\\s+we|what\\s+should\\s+(?:i|we))\\s+.+$",
      Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
  private static final Pattern DEICTIC = Pattern.compile(
      "^(?:do|make|fix|improve|continue|build|research|test|review|save)\\s+(?:it|that|this)(?:\\s+again)?\\.?$",
      Pattern.CASE_INSENSITIVE);
  private static final String[] PORTFOLIO = {
      "all", "everything", "absolute", "ultimate", "deep sync", "full",
      "full mode", "everything everything", "godforge infinity", "whatever"};

  public static final class Result {
    public final boolean activated;
    public final Scope scope;
    public final String task;
    public final boolean needsContext;
    public final boolean authorityGranted = false;
    public final String reason;
    private Result(boolean activated, Scope scope, String task, boolean needsContext, String reason) {
      this.activated = activated;
      this.scope = scope;
      this.task = task == null ? "" : task;
      this.needsContext = needsContext;
      this.reason = reason;
    }
  }
  private GodCommandPolicy() {}
  private static Result off(String why) { return new Result(false, Scope.NONE, "", false, why); }
  private static Result on(Scope s, String task, boolean context, String why) {
    return new Result(true, s, task, context, why);
  }
  private static boolean containsUnsafeFormat(String s) {
    // Use the SAME canonical policy as local device and workflow routing.
    return CommandParser.hasUnsafeControl(s);
  }

  public static Result parse(String raw) {
    if (raw == null || raw.length() > MAX_INPUT_CHARS) return off("invalid_bounds");
    if (containsUnsafeFormat(raw)) return off("unsafe_format");
    String message = Normalizer.normalize(raw, Normalizer.Form.NFKC).trim().replaceAll("\\s+", " ");
    if (message.length() > MAX_INPUT_CHARS || containsUnsafeFormat(message))
      return off("normalized_bounds_or_format");
    if (message.isEmpty()) return off("empty");
    Matcher p = PREFIX.matcher(message);
    if (!p.matches()) return off("not_command_prefix");
    String tail = p.group(2);
    boolean explicit = p.group(1) != null || tail.matches("^\\s*[:;\\u2014\\u2013-].*$");
    String suffix = tail.replaceFirst("^[\\s:,;!\\u2014\\u2013-]+", "").trim();
    if (suffix.isEmpty()) return on(Scope.PORTFOLIO, "", false, "standalone");
    String lower = suffix.toLowerCase(Locale.ROOT);
    for (String label : PORTFOLIO) {
      if (lower.equals(label)) return on(Scope.PORTFOLIO, "", false, "portfolio");
    }
    // Ordinary God questions, prayer, and theological statements are not commands.
    if (!explicit && (suffix.endsWith("?") || DISCUSSION.matcher(suffix).matches()
        || UNMARKED_PRAYER.matcher(suffix).matches())) return off("religious_or_ambiguous");
    if (DISCUSSION.matcher(suffix).matches()) {
      if (explicit && EXPLICIT_TASK_QUESTION.matcher(suffix).matches()) {
        return on(Scope.TARGETED, suffix, false, "explicit_question_no_authority");
      }
      return off("religious_discussion");
    }
    Matcher action = IMPERATIVE.matcher(suffix);
    if (!action.matches()) return off("ambiguous_suffix");
    if (!explicit && UNMARKED_PRAYER.matcher(suffix).matches()) return off("ambiguous_prayer");
    if (!explicit && suffix.endsWith("?")) return off("question");
    boolean needsContext = DEICTIC.matcher(suffix).matches();
    return on(Scope.TARGETED, suffix, needsContext, "imperative_no_authority");
  }
}
