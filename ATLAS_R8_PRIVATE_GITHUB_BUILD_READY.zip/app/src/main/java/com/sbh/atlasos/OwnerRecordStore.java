package com.sbh.atlasos;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Bounded encrypted records. No plaintext cache; one process-wide writer and authenticated revisions. */
public final class OwnerRecordStore {
  public static final int MAX_BYTES=256*1024;
  public static final int MAX_BLOB_BYTES=MAX_BYTES+44;
  public static final long MAX_REVISION=9007199254740991L;
  private static final int MAGIC=0x414f5231; // AOR1
  private static final Object STORE_LOCK=new Object();
  public interface Access { boolean allowed(); }
  public interface BlobStore {
    byte[] read(String key)throws Exception;
    /** Must preserve the prior committed blob on any failure before commit. */
    void write(String key,byte[] blob,Access access)throws Exception;
  }
  public interface KeySource { SecretKey get(boolean create)throws Exception; }
  public static final class LockedException extends Exception {}
  public static final class CorruptException extends Exception {}
  public static final class Result {
    public final String status,value;
    public final long revision;
    private Result(String s,String v,long r){status=s;value=v;revision=r;}
    static Result ok(String v,long r){return new Result("ok",v,r);}
    static Result error(String s){return new Result(s,null,0);}
  }
  private static final class Record {
    final String value; final long revision;
    Record(String v,long r){value=v;revision=r;}
  }
  private final BlobStore files;
  private final KeySource keys;
  public OwnerRecordStore(BlobStore files,KeySource keys){this.files=files;this.keys=keys;}
  public static boolean validKey(String key){
    return "notes".equals(key)||"tasks".equals(key)||"mailDrafts".equals(key)||"bookmarks".equals(key)
      ||"shopping".equals(key)||"calendar".equals(key)||"contacts".equals(key)||"projects".equals(key)||"goals".equals(key)||"lab".equals(key)||"activityMetrics".equals(key)
      ||"assistantProfile".equals(key)||"brainConnection".equals(key);
  }
  private static boolean allowed(Access access){try{return access!=null&&access.allowed();}catch(Exception ignored){return false;}}
  public static void require(Access access)throws LockedException {if(!allowed(access))throw new LockedException();}

  public Result read(String key,Access access){
    synchronized(STORE_LOCK){
      if(!allowed(access))return Result.error("locked");
      if(!validKey(key))return Result.error("invalid");
      try{
        Record record=load(key);
        require(access);
        return Result.ok(record.value,record.revision);
      }catch(Exception error){return failure(error,access);}
    }
  }
  public Result write(String key,String value,long expectedRevision,Access access){
    synchronized(STORE_LOCK){
      if(!allowed(access))return Result.error("locked");
      if(!validKey(key)||value==null||expectedRevision<0||expectedRevision>=MAX_REVISION)
        return Result.error("invalid");
      byte[] payload;
      try{
        ByteBuffer encoded=StandardCharsets.UTF_8.newEncoder().onMalformedInput(CodingErrorAction.REPORT)
          .onUnmappableCharacter(CodingErrorAction.REPORT).encode(CharBuffer.wrap(value));
        payload=new byte[encoded.remaining()];encoded.get(payload);
      }catch(Exception invalid){return Result.error("invalid");}
      if(payload.length>MAX_BYTES){Arrays.fill(payload,(byte)0);return Result.error("invalid");}
      byte[] plain=null;
      try{
        // A malformed/missing-key existing record is never reinterpreted as absent.
        Record current=load(key);
        require(access);
        if(current.revision!=expectedRevision)return Result.error("conflict");
        long revision=current.revision+1;
        plain=ByteBuffer.allocate(12+payload.length).putLong(revision).putInt(payload.length).put(payload).array();
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE,keys.get(true));
        cipher.updateAAD(aad(key));
        byte[] iv=cipher.getIV(),encrypted=cipher.doFinal(plain);
        if(iv.length!=12)throw new IllegalStateException("nonce format");
        byte[] blob=ByteBuffer.allocate(4+iv.length+encrypted.length).putInt(MAGIC).put(iv).put(encrypted).array();
        require(access);
        files.write(key,blob,access);
        require(access);
        return Result.ok(null,revision);
      }catch(Exception error){return failure(error,access);}
      finally{Arrays.fill(payload,(byte)0);if(plain!=null)Arrays.fill(plain,(byte)0);}
    }
  }
  private Result failure(Exception error,Access access){
    if(!allowed(access)||error instanceof LockedException)return Result.error("locked");
    return Result.error(error instanceof CorruptException?"corrupt":"unavailable");
  }
  private static byte[] aad(String key){return ("atlas-owner-record-v1:"+key).getBytes(StandardCharsets.UTF_8);}
  private Record load(String key)throws Exception {
    byte[] blob=files.read(key);
    if(blob==null)return new Record(null,0L);
    if(blob.length<44||blob.length>MAX_BLOB_BYTES)throw new CorruptException();
    // Key lookup failure remains unavailable, not absence/corruption or key recreation.
    SecretKey secret=keys.get(false);
    byte[] plain=null;
    try{
      ByteBuffer header=ByteBuffer.wrap(blob);
      if(header.getInt()!=MAGIC)throw new CorruptException();
      byte[] iv=new byte[12],encrypted=new byte[header.remaining()-12];header.get(iv);header.get(encrypted);
      Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
      cipher.init(Cipher.DECRYPT_MODE,secret,new GCMParameterSpec(128,iv));cipher.updateAAD(aad(key));
      plain=cipher.doFinal(encrypted);
      if(plain.length<12||plain.length>MAX_BYTES+12)throw new CorruptException();
      ByteBuffer record=ByteBuffer.wrap(plain);long revision=record.getLong();int length=record.getInt();
      if(revision<1||revision>MAX_REVISION||length<0||length!=record.remaining())throw new CorruptException();
      String value=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
        .onUnmappableCharacter(CodingErrorAction.REPORT).decode(record).toString();
      return new Record(value,revision);
    }catch(CorruptException e){throw e;}
    catch(Exception e){throw new CorruptException();}
    finally{if(plain!=null)Arrays.fill(plain,(byte)0);}
  }
}
