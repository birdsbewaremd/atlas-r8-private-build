package com.sbh.atlasos;

import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.function.BooleanSupplier;

/** Bounded, read-only duplicate detection. Same identity is never a second copy. */
public final class CleanupScanEngine {
    public interface Opener { InputStream open() throws IOException; }
    public static final class Item {
        public final String identity,name; public final long size; final Opener opener;
        public Item(String identity,String name,long size,Opener opener){
            this.identity=identity;this.name=name;this.size=size;this.opener=opener;
        }
    }
    public static final class Result {
        public final List<List<Item>> groups=new ArrayList<>();
        public int listed,unknown,hashed,errors,largeSkipped,budgetSkipped,repeatedIdentities;
        public long listedBytes,bytesRead,reclaimableBytes;
        public boolean cancelled;
    }
    private CleanupScanEngine(){}
    public static Result inspect(List<Item> input,long perFile,long total,BooleanSupplier cancelled){
        if(perFile<0||total<0)throw new IllegalArgumentException("negative limit");
        Result result=new Result();Set<String> identities=new HashSet<>();
        Map<Long,List<Item>> sizes=new TreeMap<>();
        for(Item item:input){
            if(!identities.add(item.identity)){result.repeatedIdentities++;continue;}
            result.listed++;
            if(item.size<0){result.unknown++;continue;}
            result.listedBytes=saturatingAdd(result.listedBytes,item.size);
            if(item.size==0)continue; // Empty files cannot recover meaningful space.
            if(item.size>perFile){result.largeSkipped++;continue;}
            sizes.computeIfAbsent(item.size,k->new ArrayList<>()).add(item);
        }
        Map<String,List<Item>> hashes=new LinkedHashMap<>();
        outer:for(List<Item> group:sizes.values()){
            if(group.size()<2)continue;
            for(Item item:group){
                if(cancelled.getAsBoolean()){result.cancelled=true;break outer;}
                if(item.size>total-result.bytesRead){result.budgetSkipped++;continue;}
                try {
                    MessageDigest digest=MessageDigest.getInstance("SHA-256");
                    try(InputStream in=item.opener.open()){
                        if(in==null)throw new IOException("unreadable");
                        byte[] buffer=new byte[32768];long seen=0;int emptyReads=0;
                        while(true){
                            if(cancelled.getAsBoolean()){result.cancelled=true;break outer;}
                            long remaining=total-result.bytesRead;
                            if(remaining==0){result.budgetSkipped++;throw new IOException("read budget exhausted");}
                            // The extra byte detects a provider returning more than its listed length.
                            int wanted=(int)Math.min(buffer.length,Math.min(remaining,item.size-seen+1));
                            if(wanted<1)throw new IOException("size changed");
                            int n=in.read(buffer,0,wanted);
                            if(n<0)break;
                            if(n==0){if(++emptyReads>3)throw new IOException("provider made no progress");continue;}
                            emptyReads=0;seen+=n;result.bytesRead+=n;
                            if(seen>item.size||seen>perFile)throw new IOException("size changed");
                            digest.update(buffer,0,n);
                        }
                        if(seen!=item.size)throw new IOException("size changed");
                    }
                    StringBuilder key=new StringBuilder().append(item.size).append(':');
                    for(byte b:digest.digest())key.append(String.format(Locale.US,"%02x",b&255));
                    hashes.computeIfAbsent(key.toString(),k->new ArrayList<>()).add(item);result.hashed++;
                }catch(IOException|SecurityException problem){result.errors++;}
                catch(NoSuchAlgorithmException impossible){throw new IllegalStateException(impossible);}
            }
        }
        for(List<Item> group:hashes.values())if(group.size()>1){
            result.groups.add(Collections.unmodifiableList(group));
            result.reclaimableBytes=saturatingAdd(result.reclaimableBytes,group.get(0).size*(group.size()-1L));
        }
        return result;
    }
    static long saturatingAdd(long a,long b){return b>Long.MAX_VALUE-a?Long.MAX_VALUE:a+b;}
}
