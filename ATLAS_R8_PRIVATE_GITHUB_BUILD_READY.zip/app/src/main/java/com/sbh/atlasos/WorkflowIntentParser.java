package com.sbh.atlasos;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Deterministic owner-command recognizer generated around the reviewed 92-entry catalog.
 * It classifies workflow intent only. It never grants authority, performs a workflow,
 * sends data, changes accounts, deploys software, or maps a workflow label to a device action.
 */
public final class WorkflowIntentParser {
  public static final int MAX_CHARS = 8192;

  public enum Origin {
    UI_TEXT,
    VOICE_TRANSCRIPT,
    WAKE_TRANSCRIPT,
    ASSISTANT_ACTION,
    REFERENCE_DATA
  }

  public enum State { RECOGNIZED, NO_MATCH, SOURCE_DATA, INVALID }

  public enum Recognition {
    MATCHED("🧭", "MATCHED"),
    COMBINED("🧩", "COMBINED"),
    CREATED("🆕", "CREATED"),
    NORMAL_REQUEST("💬", "NORMAL REQUEST"),
    PARTIAL_MATCH("⚠️", "PARTIAL MATCH");

    public final String emoji;
    public final String label;
    Recognition(String emoji, String label) { this.emoji = emoji; this.label = label; }
  }

  public static final class CommandMatch {
    public final String id;
    public final String label;
    CommandMatch(String id, String label) {
      this.id = id == null ? "" : id;
      this.label = label == null ? "" : label;
    }
  }

  public static final class Result {
    public final String original;
    public final String normalized;
    public final Origin origin;
    public final List<CommandMatch> matches;
    public final List<String> commandIds;
    public final List<String> commandStack;
    public final List<String> constraints;
    public final State state;
    public final Recognition requestedRecognition;
    public final boolean requiresContextLookup;
    public final boolean persistenceRequested;
    public final boolean grantsExecution = false;

    Result(String original, String normalized, Origin origin, List<CommandMatch> matches,
           Set<String> constraints, State state, Recognition requestedRecognition,
           boolean requiresContextLookup, boolean persistenceRequested) {
      this.original = original;
      this.normalized = normalized == null ? "" : normalized;
      this.origin = origin;
      this.matches = Collections.unmodifiableList(new ArrayList<CommandMatch>(matches));
      ArrayList<String> ids = new ArrayList<String>();
      ArrayList<String> stack = new ArrayList<String>();
      for (CommandMatch match : matches) { ids.add(match.id); stack.add(match.label); }
      this.commandIds = Collections.unmodifiableList(ids);
      this.commandStack = Collections.unmodifiableList(stack);
      this.constraints = Collections.unmodifiableList(new ArrayList<String>(constraints));
      this.state = state;
      this.requestedRecognition = requestedRecognition;
      this.requiresContextLookup = requiresContextLookup;
      this.persistenceRequested = persistenceRequested;
    }
  }

  private static final class Stack {
    final ArrayList<CommandMatch> rows = new ArrayList<CommandMatch>();
    final LinkedHashSet<String> keys = new LinkedHashSet<String>();

    void add(String id) {
      WorkflowCommandCatalog.Entry e = WorkflowCommandCatalog.byId(id);
      addLabel(id, e == null ? id : e.canonical);
    }

    void addLabel(String id, String label) {
      String key = id + "\u0000" + label;
      if (keys.add(key)) rows.add(new CommandMatch(id, label));
    }

    boolean hasId(String id) {
      for (CommandMatch row : rows) if (row.id.equals(id)) return true;
      return false;
    }

    void removeId(String id) {
      for (int i = rows.size() - 1; i >= 0; i--) {
        if (rows.get(i).id.equals(id)) {
          keys.remove(rows.get(i).id + "\u0000" + rows.get(i).label);
          rows.remove(i);
        }
      }
    }
  }

  private WorkflowIntentParser() {}

  public static Result parse(String raw) { return parse(raw, Origin.UI_TEXT); }

  public static Result parse(String raw, Origin origin) {
    LinkedHashSet<String> guards = new LinkedHashSet<String>();
    guards.add("recognition_is_not_authorization");
    guards.add("preserve_original_input");
    guards.add("independent_permission_checks_required");
    Stack stack = new Stack();

    if (raw == null || origin == null || raw.length() > MAX_CHARS || unsafe(raw)) {
      return result(raw, "", origin, stack, guards, State.INVALID, Recognition.PARTIAL_MATCH, false, false);
    }
    String text = normalize(raw);
    if (text.isEmpty() || text.length() > MAX_CHARS || unsafe(text))
      return result(raw, "", origin, stack, guards, State.INVALID, Recognition.PARTIAL_MATCH, false, false);
    if (origin == Origin.REFERENCE_DATA) {
      guards.add("source_text_is_data");
      return result(raw, text, origin, stack, guards, State.SOURCE_DATA, Recognition.NORMAL_REQUEST, false, false);
    }

    if (hit(text, "^(?:the )?(?:file|document|email|webpage|source|quote) (?:says|contains|reads)\\b")) {
      guards.add("source_text_is_data");
      return result(raw, text, origin, stack, guards, State.SOURCE_DATA, Recognition.NORMAL_REQUEST, false, false);
    }

    // Explicit lookup requests are data queries; names inside them are not workflow commands.
    if (hit(text, "^(?:atlas[ ,:]+)?(?:please )?(?:google|search|look up)\\b")
        || hit(text, "^(?:please )?use google (?:drive|account|maps|docs|calendar|sheets)\\b")) {
      guards.add("lookup_query_is_not_a_workflow_command");
      return result(raw, text, origin, stack, guards, State.NO_MATCH, Recognition.NORMAL_REQUEST, false, false);
    }

    String active = removeQuotedData(text);
    boolean noSend = hit(active, "\\b(?:do not|don't|never) (?:send|contact|message|call)\\b");
    boolean noDeploy = hit(active, "\\b(?:do not|don't|never) (?:deploy|release|publish|post)\\b");
    boolean noDelete = hit(active, "\\b(?:do not|don't|never) (?:delete|wipe|erase)\\b");
    boolean noChange = hit(active, "\\bwithout changing anything\\b|\\bdo not change anything\\b|\\bdon't change anything\\b");
    if (noSend) guards.add("no_external_contact");
    if (noDeploy) guards.add("no_deployment_or_publication");
    if (noDelete) guards.add("no_deletion");
    if (noChange) guards.add("read_only_security_review");
    if (hit(active, "\\bask first\\b")) guards.add("approval_required_for_specified_scope");
    if (hit(active, "\\b(?:keep|lock).*(?:price|phone number|number).*same\\b|\\bkeep the price and phone number exactly the same\\b")) guards.add("preserve_exact_consequential_details");
    if (hit(active, "\\b(?:save|remember|make this a command|repeatable command)\\b")) guards.add("verify_persistence_before_claiming_save");
    if (hit(active, "\\b(?:verify|test|tested|current sources|live domain|no regression)\\b")) guards.add("require_actual_verification_evidence");

    boolean partial = false;
    boolean commandize = hit(active, "\\b(?:make|turn|save) (?:this|it) (?:a|as a) command\\b|\\brepeatable command called\\b|\\bmake this a repeatable command\\b");
    if (commandize) {
      stack.add("atlas_commandize");
      guards.add("deduplicate_before_command_creation");
      guards.add("command_definition_body_is_data");
      return result(raw, text, origin, stack, guards, State.RECOGNIZED, Recognition.CREATED, true, true);
    }

    // Strongest quality loop supersedes the older Googol label for ordinary requests.
    boolean max = hit(active, "\\b(?:best possible|max this|one million times better|1 million times better|million times better|better than last time)\\b")
        || (hit(active, "\\bred[ -]?team forged?\\b") && hit(active, "\\bgoogol\\b"));
    if (max) {
      stack.add("atlas_max");
      guards.add("maximum_useful_rigor_not_literal_iteration_count");
    }

    boolean messageForge = hit(active, "\\bmake this message .*better\\b|\\bwrite this in my voice\\b|\\bmake this hit harder\\b")
        || (hit(active, "\\bsound like me\\b") && hit(active, "\\bprofessional\\b"));
    if (messageForge) stack.add("atlas_message_forge");

    boolean finalPass = hit(active, "\\bgo over it again\\b|\\bcheck it one more time\\b|\\bbeat the last version\\b|\\bonly change real problems\\b");
    if (finalPass) stack.add("atlas_final_pass");

    // App build composition is intentionally ordered: scope, build, regression, verification.
    boolean appBuild = hit(active, "\\b(?:build|fix|ship) the app\\b");
    if (appBuild) {
      stack.add("atlas_app_build");
      stack.add("atlas_build");
      if (hit(active, "\\bdon't break anything\\b|\\bdo not break anything\\b|\\bwithout breaking\\b|\\balready working\\b")) stack.add("atlas_no_regression");
      if (hit(active, "\\btest(?: it)?\\b|\\bverify\\b")) stack.add("atlas_verify");
    }

    boolean catAtlas = hit(active, "\\b(?:my )?cat atlas\\b") && hit(active, "\\bsmarter\\b");
    boolean research = hit(active, "\\bresearch (?:everything|this|all|every)\\b|\\bfind the real answer\\b|\\bcurrent sources\\b|\\bcheck everything relevant\\b");
    if (catAtlas) {
      stack.add("atlas_research");
      stack.add("atlas_decide");
      guards.add("resolve_atlas_entity_as_cat_from_grammar");
    } else if (research) {
      stack.add("atlas_research");
      if (hit(active, "\\beverything relevant\\b|\\ball relevant\\b|\\bevery accessible source\\b")) stack.add("atlas_full_coverage");
      if (hit(active, "\\btell me the truth\\b|\\bhard truth\\b")) stack.add("hard_truth_mode");
    }

    if (hit(active, "\\bdeep (?:sync|synch|sink)\\b")) stack.add("atlas_deep_sync");
    if (hit(active, "\\beverything\\b") && stack.hasId("atlas_deep_sync")) stack.add("everything");
    if (hit(active, "\\bkeep it short\\b") && stack.hasId("atlas_deep_sync")) stack.add("atlas_short");

    if (hit(active, "\\bdraft the customer message\\b|\\bcustomer reply\\b")) {
      stack.add("customer_reply");
      if (noSend || hit(active, "\\bask first\\b")) stack.add("ask_first");
    }

    if (hit(active, "^(?:please )?publish this now[.!]?$|^(?:please )?post this now[.!]?$")) {
      stack.add("atlas_intent_check");
      partial = true;
      guards.add("publication_target_account_and_authority_unresolved");
    }

    if (hit(active, "\\bwhat is the best chess move\\b|\\brun the chess moves\\b|\\btell me what i should do\\b")) stack.add("atlas_decide");

    if (hit(active, "\\bsound like me\\b")) stack.add("atlas_in_my_voice");
    if (hit(active, "\\bmore professional\\b|\\bprofessional\\b") && messageForge) stack.add("professional");

    boolean preserveExcept = hit(active, "\\bkeep everything the same except\\b");
    if (preserveExcept) {
      stack.add("keep_everything_the_same_except_x");
      guards.add("change_only_explicit_exception");
    }

    if (hit(active, "\\bremember this rule for future chats\\b|\\bremember this\\b")) stack.add("remember_this");
    if (hit(active, "\\bshow me every command\\b|\\bshow (?:me )?all commands\\b")) stack.add("atlas_commands");

    if (hit(active, "\\bactual current status\\b|\\bcurrent status\\b")) {
      stack.add("atlas_status");
      stack.add("atlas_current");
    }

    boolean website = hit(active, "\\b(?:fix|build|improve) the website\\b|\\bwebsite forge\\b");
    if (website) {
      stack.add("website_mode");
      stack.add("website_forge");
      if (hit(active, "\\bverify\\b|\\blive domain\\b")) stack.add("atlas_verify");
    }

    if (hit(active, "\\bshould i buy this\\b|\\bdo i buy it\\b")) {
      stack.add("do_i_buy_it");
      stack.add("atlas_decide");
    }

    if (hit(active, "\\b(?:make|create) (?:a )?(?:customer )?estimate\\b|\\bestimate this\\b")) stack.add("estimate_this");
    if (hit(active, "\\bprice this\\b|\\bprice this .*job\\b")) stack.add("price_this");
    if (hit(active, "\\bsave a checkpoint\\b|\\bcheckpoint so i can continue later\\b")) stack.add("atlas_checkpoint");
    if (hit(active, "\\bpause this and handle .* first\\b|^interrupt\\b")) stack.add("interrupt");

    if (hit(active, "\\badd this without dropping anything\\b|\\badd this too\\b")) {
      stack.add("add_this_too");
      if (hit(active, "\\bwithout dropping\\b|\\bdon't drop\\b")) stack.add("atlas_no_regression");
    }

    if (hit(active, "\\buse all my relevant history and files\\b")) {
      stack.addLabel("use_memory", "USE MEMORY");
      stack.addLabel("use_memory", "USE LIBRARY");
      stack.addLabel("use_memory", "USE SHAUN OS");
    }

    if (hit(active, "\\bpublic-safe version\\b|\\bpublic safe version\\b")) {
      stack.add("atlas_public");
      stack.add("atlas_share_safe");
    }

    if (!preserveExcept && hit(active, "\\block the price\\b|\\bkeep the price and phone number exactly the same\\b")) stack.add("atlas_lock_x");
    if (hit(active, "\\bunlock only\\b|\\bunlock the\\b|\\bunlock x\\b")) stack.add("atlas_unlock_x");
    if (hit(active, "\\bnext highest-value move\\b|\\bnext highest value move\\b|\\bnext move\\b")) stack.add("atlas_next_move");

    if (hit(active, "\\bmake this shorter\\b|^shorter\\b")) {
      stack.add("shorter");
      if (hit(active, "\\bwithout losing anything important\\b|\\bwithout losing\\b")) stack.add("atlas_no_regression");
    }

    if (hit(active, "\\btell me the hard truth\\b|^hard truth mode\\b")) stack.add("hard_truth_mode");
    if (hit(active, "\\bcontinue from the newest reliable checkpoint\\b|^atlas resume\\b|^resume\\b")) stack.add("atlas_resume");
    if (hit(active, "\\bback this up with hashes and restore steps\\b|^atlas red button\\b")) stack.add("atlas_red_button");
    if (hit(active, "\\bsecurity risks\\b|^atlas sentinel\\b|^sentinel\\b")) stack.add("atlas_sentinel");

    // Generic verification is added after domain-specific stacks so order stays useful.
    if (!appBuild && !website && hit(active, "\\bverify\\b|\\busing current sources\\b|\\bcurrent sources\\b")) stack.add("atlas_verify");

    if (max && hit(active, "\\bkeep the price and phone number exactly the same\\b")) {
      if (!stack.hasId("atlas_lock_x")) stack.add("atlas_lock_x");
      if (!stack.hasId("atlas_no_regression")) stack.add("atlas_no_regression");
    }

    // Exact canonical/alias fallback makes every catalog entry directly addressable.
    for (String clause : active.split("[,;.!]+|\bthen\b|\band\b|\bbut\b")) {
      String full = clause.trim().replaceFirst("^(?:please |also )+", "").trim();
      if (full.isEmpty()) continue;
      WorkflowCommandCatalog.Entry e = WorkflowCommandCatalog.exactOrAnchored(full);
      if (e == null) {
        String withoutAtlas = full.replaceFirst("^atlas[ ,:]*", "").trim();
        if (!withoutAtlas.isEmpty()) e = WorkflowCommandCatalog.exactOrAnchored(withoutAtlas);
      }
      if (e != null) stack.add(e.id);
    }

    // Supersession and no-regression cleanup.
    if (stack.hasId("atlas_max")) {
      stack.removeId("atlas_red_team_forge_googol");
      stack.removeId("atlas_red_team_forge");
      stack.removeId("better");
    }
    if (preserveExcept) stack.removeId("atlas_no_regression");
    if (stack.hasId("atlas_deep_sync")) { stack.removeId("atlas_deep"); stack.removeId("atlas_sync"); }

    if (stack.hasId("everything")) guards.add("full_requested_scope_with_explicit_gaps");
    if (stack.hasId("atlas_short") || stack.hasId("shorter")) guards.add("short_output_does_not_reduce_scope");
    if (stack.hasId("atlas_public") || stack.hasId("atlas_share_safe")) guards.add("audience_selection_does_not_authorize_sending");
    if (stack.hasId("atlas_sentinel") && noChange) guards.add("no_mutation_authorized");

    Recognition recognition;
    if (partial) recognition = Recognition.PARTIAL_MATCH;
    else if (commandize) recognition = Recognition.CREATED;
    else if (stack.rows.isEmpty()) recognition = Recognition.NORMAL_REQUEST;
    else if (stack.rows.size() == 1) recognition = Recognition.MATCHED;
    else recognition = Recognition.COMBINED;

    State state = stack.rows.isEmpty() ? State.NO_MATCH : State.RECOGNIZED;
    return result(raw, text, origin, stack, guards, state, recognition, !stack.rows.isEmpty(), commandize);
  }

  private static Result result(String raw, String normalized, Origin origin, Stack stack,
                               Set<String> guards, State state, Recognition recognition,
                               boolean context, boolean persistence) {
    return new Result(raw, normalized, origin, stack.rows, guards, state, recognition, context, persistence);
  }

  private static String normalize(String raw) {
    return Normalizer.normalize(raw, Normalizer.Form.NFKC).toLowerCase(Locale.ROOT)
      .replace('\u2019', (char)39).replace('\u2018', (char)39)
      .replace('\u201c', (char)34).replace('\u201d', (char)34)
      .replace('\u2014', '-').replace('\u2013', '-')
      .replaceAll("\\s+", " ").trim();
  }

  private static String removeQuotedData(String s) {
    return s.replaceAll("```[\\s\\S]*?```", " ")
      .replaceAll("`[^`]*`", " ")
      .replaceAll("\"[^\"]*\"", " ")
      .replaceAll("(?<![a-z])'[^']*'(?![a-z])", " ")
      .replaceAll("\\s+", " ").trim();
  }

  private static boolean hit(String text, String regex) {
    return Pattern.compile(regex).matcher(text).find();
  }

  private static boolean unsafe(String s) {
    return CommandParser.hasUnsafeControl(s);
  }
}
