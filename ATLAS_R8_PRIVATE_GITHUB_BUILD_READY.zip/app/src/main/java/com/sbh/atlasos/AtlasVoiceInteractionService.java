package com.sbh.atlasos;

import android.service.voice.VoiceInteractionService;

/** Lightweight system assistant service. Heavy UI/logic stays in the session/MainActivity. */
public final class AtlasVoiceInteractionService extends VoiceInteractionService {
  @Override public void onReady() { super.onReady(); }
  @Override public void onShutdown() { super.onShutdown(); }
}
