package com.sbh.atlasos;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.*;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Local capture storage. No vault namespace, shared-storage path, or network API. */
public final class AtlasCaptureStore {
    public static final long MAX_DURATION_MS = 10L * 60L * 1000L;
    public static final long MAX_BYTES = 100_000_000L;
    public static final long MAX_ARCHIVE_BYTES = 250_000_000L;
    static final long MIN_RECORDING_BUDGET = 5_000_000L;
    public static final long MIN_FREE_BYTES = 20_000_000L;
    static final long LAUNCH_WINDOW_MS = 90_000L;
    static final long CONSENT_WINDOW_MS = 120_000L;
    static final long PLAYBACK_WINDOW_MS = 15L * 60L * 1000L;
    private static final String KEY_ALIAS = "atlas_local_screen_capture_aes_v1";
    private static final String ROOT_NAME = "atlas-local-captures-v1";
    private static final int MAGIC = 0x41544350, VERSION = 1;
    private static final int CHUNK_BYTES = 256 * 1024, IV_BYTES = 12, TAG_BYTES = 16;
    private static final int HEADER_BYTES = 4 + 4 + 32 + 8 + 8 + 8 + 4;
    private static final SecureRandom RANDOM = new SecureRandom();
    private static boolean initialized;
    private AtlasCaptureStore() {}

    /** Safe at application startup: clears interrupted temporary files once per process only. */
    public static void cleanupInterrupted(Context context) throws Exception { initialize(context); }

    interface Access { boolean allowed(); }

    /** Pure one-use ticket policy; neither tickets nor authorization survive process death. */
    static final class LaunchTokens {
        private static final class Entry {
            final String scope;
            final long issued, expires;
            Entry(String scope, long issued, long expires) {
                this.scope = scope; this.issued = issued; this.expires = expires;
            }
        }
        private final Map<String, Entry> entries = new HashMap<>();
        private long lastTime = -1L;
        synchronized String issue(String scope, long now, long lifetime) {
            if (scope == null || scope.isEmpty() || now < 0 || lifetime <= 0
                    || lifetime > CONSENT_WINDOW_MS || now > Long.MAX_VALUE - lifetime)
                throw new IllegalArgumentException("Invalid capture ticket");
            if (lastTime > now) entries.clear();
            lastTime = now;
            entries.entrySet().removeIf(e -> e.getValue().expires <= now);
            // This process never needs a backlog of deferred launches.
            if (entries.size() >= 8) entries.clear();
            String token = randomId() + randomId();
            entries.put(token, new Entry(scope, now, now + lifetime));
            return token;
        }
        synchronized long consume(String token, String scope, long now) {
            if (lastTime > now) { entries.clear(); lastTime = now; return 0L; }
            lastTime = now;
            Entry entry = entries.remove(token);
            return entry != null && entry.scope.equals(scope) && now >= entry.issued
                    && now < entry.expires ? entry.expires : 0L;
        }
        synchronized void clear() { entries.clear(); }
    }

    static final class Clip {
        final String id;
        final long createdAtMs, durationMs, bytes;
        Clip(String id, long createdAtMs, long durationMs, long bytes) throws IOException {
            if (!isValidId(id) || createdAtMs <= 0 || durationMs <= 0
                    || durationMs > MAX_DURATION_MS || bytes <= 0 || bytes > MAX_BYTES)
                throw new IOException("Invalid recording metadata");
            this.id = id; this.createdAtMs = createdAtMs;
            this.durationMs = durationMs; this.bytes = bytes;
        }
        JSONObject json() throws Exception {
            return new JSONObject().put("id", id).put("createdAtMs", createdAtMs)
                    .put("durationMs", durationMs).put("bytes", bytes);
        }
    }

    static final class Library {
        final ArrayList<Clip> clips = new ArrayList<>();
        int unreadable;
        JSONArray json() throws Exception {
            JSONArray out = new JSONArray();
            for (Clip clip : clips) out.put(clip.json());
            return out;
        }
    }

    public static boolean isValidId(String id) {
        return id != null && id.matches("[a-f0-9]{32}");
    }

    static long remainingDuration(long startedElapsed, long nowElapsed) {
        if (startedElapsed < 0 || nowElapsed < startedElapsed) return 0L;
        return Math.max(0L, MAX_DURATION_MS - (nowElapsed - startedElapsed));
    }

    static long remainingBytes(long recordedBytes) {
        return Math.max(0L, MAX_BYTES - Math.max(0L, recordedBytes));
    }

    private static String randomId() {
        byte[] bytes = new byte[16]; RANDOM.nextBytes(bytes);
        StringBuilder out = new StringBuilder(32);
        for (byte value : bytes) out.append(String.format(Locale.US, "%02x", value & 255));
        return out.toString();
    }

    /** Deletes only unfinished capture/playback files on the first use in a new process. */
    static synchronized void initialize(Context context) throws Exception {
        File root = root(context);
        if (!initialized) {
            cleanTemporaryDirectory(directory(root, "pending"));
            cleanTemporaryDirectory(directory(root, "playback"));
            initialized = true;
        }
    }

    static void prepareForCapture(Context context) throws Exception {
        initialize(context);
        // Fail before recording if the separate encryption key cannot be used.
        SecretKey key = key(context, true);
        Cipher probe = Cipher.getInstance("AES/GCM/NoPadding");
        probe.init(Cipher.ENCRYPT_MODE, key);
        probe.doFinal(new byte[0]);
    }

    static File createRecordingFile(Context context) throws Exception {
        initialize(context);
        return privateTemp(directory(root(context), "pending"), "recording-", ".mp4.tmp");
    }

    static synchronized Clip commit(Context context, File plain, long createdAtMs, long durationMs) throws Exception {
        initialize(context);
        File base = root(context), pending = directory(base, "pending");
        requireChild(plain, pending);
        if (!plain.isFile()) throw new IOException("Recording was not finalized");
        Clip clip = new Clip(randomId(), createdAtMs, durationMs, plain.length());
        File staged = privateTemp(pending, "encrypted-", ".part");
        File target = clipFile(directory(base, "clips"), clip.id);
        boolean committed = false;
        try {
            encrypt(plain, staged, key(context, true), clip, () -> true);
            if (target.exists()) throw new IOException("Recording identifier collision");
            if (archiveBytes(context) > MAX_ARCHIVE_BYTES - staged.length())
                throw new IOException("Capture archive is full; existing recordings were preserved");
            // Same private volume; a failed commit never replaces an existing clip.
            Files.move(staged.toPath(), target.toPath(), StandardCopyOption.ATOMIC_MOVE);
            committed = true;
            return clip;
        } finally {
            if (!committed) deleteTemporary(staged);
            deleteTemporary(plain);
        }
    }

    static synchronized long archiveBytes(Context context) throws Exception {
        initialize(context);
        File directory = directory(root(context), "clips");
        File[] files = directory.listFiles();
        if (files == null) throw new IOException("Capture library unavailable");
        long total = 0L;
        for (File file : files) {
            if (!file.getName().endsWith(".acap")) continue;
            requireChild(file, directory);
            if (!file.isFile() || file.length() > Long.MAX_VALUE - total)
                throw new IOException("Invalid capture archive");
            total += file.length();
        }
        return total;
    }

    static long recordingBudget(Context context) throws Exception {
        return budgetForArchive(archiveBytes(context));
    }

    static long budgetForArchive(long used) {
        if (used < 0 || used >= MAX_ARCHIVE_BYTES) return 0L;
        long free = MAX_ARCHIVE_BYTES - used;
        long maxOverhead = HEADER_BYTES + IV_BYTES + TAG_BYTES
                + ((MAX_BYTES + CHUNK_BYTES - 1) / CHUNK_BYTES) * (IV_BYTES + TAG_BYTES);
        return Math.max(0L, Math.min(MAX_BYTES, free - maxOverhead));
    }

    static Clip metadata(Context context, String id) throws Exception {
        initialize(context);
        File file = clipFile(directory(root(context), "clips"), id);
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            return readHeader(in, key(context, false), id, file.length());
        }
    }

    /** Only the selected, authenticated recording is removed, after native confirmation. */
    static synchronized void deleteClip(Context context, String id, Access access) throws Exception {
        requireAccess(access);
        metadata(context, id);
        File file = clipFile(directory(root(context), "clips"), id);
        requireAccess(access);
        Files.delete(file.toPath());
    }

    static Library library(Context context) throws Exception {
        initialize(context);
        File clips = directory(root(context), "clips");
        File[] files = clips.listFiles();
        if (files == null) throw new IOException("Capture library is unavailable");
        Library result = new Library();
        if (files.length == 0) return result;
        SecretKey key = key(context, false);
        for (File file : files) {
            String name = file.getName();
            if (!name.endsWith(".acap")) continue;
            String id = name.substring(0, name.length() - 5);
            if (!isValidId(id)) { result.unreadable++; continue; }
            try {
                requireChild(file, clips);
                try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
                    result.clips.add(readHeader(in, key, id, file.length()));
                }
            } catch (Exception damaged) {
                // Keep damaged/unreadable originals intact for recovery.
                result.unreadable++;
            }
        }
        result.clips.sort((a, b) -> Long.compare(b.createdAtMs, a.createdAtMs));
        return result;
    }

    static File decryptForPlayback(Context context, String id, Access access) throws Exception {
        requireAccess(access);
        initialize(context);
        if (!isValidId(id)) throw new IOException("Invalid recording identifier");
        File base = root(context), clips = directory(base, "clips");
        File source = clipFile(clips, id);
        requireChild(source, clips);
        File output = privateTemp(directory(base, "playback"), "view-", ".mp4");
        boolean ready = false;
        try {
            decrypt(source, output, key(context, false), id, access);
            requireAccess(access);
            ready = true;
            return output;
        } finally {
            if (!ready) deleteTemporary(output);
        }
    }

    static boolean deleteTemporary(File file) {
        if (file == null) return true;
        try {
            // Callers supply only freshly created private temporary files.
            Files.deleteIfExists(file.toPath());
            return true;
        } catch (IOException ignored) {
            // A process-start cleanup retries interrupted/deferred deletion.
            return false;
        }
    }

    private static File root(Context context) throws IOException {
        if (context == null) throw new IOException("Capture context unavailable");
        File parent = context.getNoBackupFilesDir();
        return directory(parent, ROOT_NAME);
    }

    private static File directory(File parent, String child) throws IOException {
        File out = new File(parent, child);
        if (Files.isSymbolicLink(out.toPath())) throw new IOException("Unsafe capture directory");
        if (!out.isDirectory() && !out.mkdirs()) throw new IOException("Capture directory unavailable");
        if (!out.getCanonicalFile().getParentFile().equals(parent.getCanonicalFile()))
            throw new IOException("Capture directory escaped private storage");
        return out;
    }

    static File clipFile(File directory, String id) throws IOException {
        if (!isValidId(id)) throw new IOException("Invalid recording identifier");
        File file = new File(directory, id + ".acap");
        requireChild(file, directory);
        return file;
    }

    private static void requireChild(File file, File directory) throws IOException {
        if (file == null || Files.isSymbolicLink(file.toPath())
                || !file.getCanonicalFile().getParentFile().equals(directory.getCanonicalFile()))
            throw new IOException("Unsafe recording path");
    }

    private static File privateTemp(File directory, String prefix, String suffix) throws IOException {
        File file = File.createTempFile(prefix, suffix, directory);
        file.setReadable(false, false); file.setWritable(false, false);
        if (!file.setReadable(true, true) || !file.setWritable(true, true)) {
            deleteTemporary(file); throw new IOException("Private recording file unavailable");
        }
        return file;
    }

    private static void cleanTemporaryDirectory(File directory) throws IOException {
        File[] files = directory.listFiles();
        if (files == null) throw new IOException("Temporary capture storage unavailable");
        for (File file : files) {
            // Dedicated app-private temporary directories contain no committed originals.
            if (file.isDirectory() && !Files.isSymbolicLink(file.toPath()))
                throw new IOException("Unexpected capture temporary directory");
            Files.deleteIfExists(file.toPath());
        }
    }

    private static synchronized SecretKey key(Context context, boolean create) throws Exception {
        KeyStore keys = KeyStore.getInstance("AndroidKeyStore"); keys.load(null);
        if (keys.containsAlias(KEY_ALIAS)) {
            java.security.Key existing = keys.getKey(KEY_ALIAS, null);
            if (!(existing instanceof SecretKey)) throw new IOException("Capture key unavailable");
            return (SecretKey) existing;
        }
        File[] saved = directory(root(context), "clips").listFiles((dir, name) -> name.endsWith(".acap"));
        if (!create || saved == null || saved.length > 0)
            throw new IOException("Existing capture key unavailable; recordings preserved");
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setKeySize(256).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true).build());
        return generator.generateKey();
    }

    /* Chunk AEAD avoids buffering a 100 MB GCM plaintext in Android's crypto provider.
       Header + clip ID + chunk index are authenticated for every independent chunk. */
    static void encrypt(File plain, File output, SecretKey key, Clip clip, Access access) throws Exception {
        requireAccess(access);
        if (plain.getCanonicalFile().equals(output.getCanonicalFile()) || output.length() != 0L)
            throw new IOException("Capture encryption requires a new temporary file");
        if (plain.length() != clip.bytes) throw new IOException("Recording size changed");
        byte[] header = header(clip), buffer = new byte[CHUNK_BYTES];
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(plain)));
             FileOutputStream file = new FileOutputStream(output);
             DataOutputStream out = new DataOutputStream(new BufferedOutputStream(file))) {
            out.write(header);
            writeChunk(out, key, header, -1, new byte[0], 0);
            long remaining = clip.bytes; int index = 0;
            while (remaining > 0) {
                requireAccess(access);
                int length = (int) Math.min(buffer.length, remaining);
                in.readFully(buffer, 0, length);
                writeChunk(out, key, header, index++, buffer, length);
                Arrays.fill(buffer, 0, length, (byte) 0);
                remaining -= length;
            }
            if (in.read() != -1) throw new IOException("Recording size changed");
            requireAccess(access);
            out.flush(); file.getFD().sync();
        } finally { Arrays.fill(buffer, (byte) 0); }
    }

    static Clip decrypt(File input, File output, SecretKey key, String expectedId, Access access) throws Exception {
        requireAccess(access);
        if (input.getCanonicalFile().equals(output.getCanonicalFile()) || output.length() != 0L)
            throw new IOException("Capture playback requires a new temporary file");
        boolean ready = false;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(input)));
             FileOutputStream file = new FileOutputStream(output);
             BufferedOutputStream out = new BufferedOutputStream(file)) {
            Clip clip = readHeader(in, key, expectedId, input.length());
            byte[] header = header(clip);
            long remaining = clip.bytes; int index = 0;
            while (remaining > 0) {
                requireAccess(access);
                int length = (int) Math.min(CHUNK_BYTES, remaining);
                byte[] plain = readChunk(in, key, header, index++, length);
                try { requireAccess(access); out.write(plain); }
                finally { Arrays.fill(plain, (byte) 0); }
                remaining -= length;
            }
            if (in.read() != -1) throw new IOException("Unexpected recording data");
            requireAccess(access);
            out.flush(); file.getFD().sync();
            ready = true;
            return clip;
        } finally { if (!ready) deleteTemporary(output); }
    }

    private static Clip readHeader(DataInputStream in, SecretKey key, String expectedId, long encodedBytes) throws Exception {
        if (!isValidId(expectedId)) throw new IOException("Invalid recording identifier");
        byte[] raw = new byte[HEADER_BYTES]; in.readFully(raw);
        ByteBuffer bytes = ByteBuffer.wrap(raw);
        if (bytes.getInt() != MAGIC || bytes.getInt() != VERSION) throw new IOException("Unsupported recording format");
        byte[] id = new byte[32]; bytes.get(id);
        Clip clip = new Clip(new String(id, StandardCharsets.US_ASCII), bytes.getLong(), bytes.getLong(), bytes.getLong());
        if (!clip.id.equals(expectedId) || bytes.getInt() != CHUNK_BYTES)
            throw new IOException("Recording identity mismatch");
        long chunks = (clip.bytes + CHUNK_BYTES - 1) / CHUNK_BYTES;
        long expected = HEADER_BYTES + IV_BYTES + TAG_BYTES + clip.bytes + chunks * (IV_BYTES + TAG_BYTES);
        if (encodedBytes != expected) throw new IOException("Recording length mismatch");
        byte[] empty = readChunk(in, key, raw, -1, 0);
        if (empty.length != 0) throw new IOException("Recording header authentication failed");
        return clip;
    }

    private static byte[] header(Clip clip) {
        return ByteBuffer.allocate(HEADER_BYTES).putInt(MAGIC).putInt(VERSION)
                .put(clip.id.getBytes(StandardCharsets.US_ASCII)).putLong(clip.createdAtMs)
                .putLong(clip.durationMs).putLong(clip.bytes).putInt(CHUNK_BYTES).array();
    }

    private static byte[] aad(byte[] header, int index) {
        return ByteBuffer.allocate(header.length + 4).put(header).putInt(index).array();
    }

    private static void writeChunk(DataOutputStream out, SecretKey key, byte[] header,
                                   int index, byte[] plain, int length) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        // Android Keystore must generate the encryption nonce itself.
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] iv = cipher.getIV();
        if (iv == null || iv.length != IV_BYTES) throw new IOException("Capture nonce unavailable");
        cipher.updateAAD(aad(header, index));
        byte[] encoded = cipher.doFinal(plain, 0, length);
        if (encoded.length != length + TAG_BYTES) throw new IOException("Capture encryption failed");
        out.write(iv); out.write(encoded);
    }

    private static byte[] readChunk(DataInputStream in, SecretKey key, byte[] header,
                                    int index, int plainBytes) throws Exception {
        byte[] iv = new byte[IV_BYTES], encoded = new byte[plainBytes + TAG_BYTES];
        in.readFully(iv); in.readFully(encoded);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));
        cipher.updateAAD(aad(header, index));
        byte[] plain = cipher.doFinal(encoded);
        if (plain.length != plainBytes) { Arrays.fill(plain, (byte) 0); throw new IOException("Capture chunk length mismatch"); }
        return plain;
    }

    private static void requireAccess(Access access) throws IOException {
        if (access == null || !access.allowed() || Thread.currentThread().isInterrupted())
            throw new IOException("Capture access expired");
    }
}
