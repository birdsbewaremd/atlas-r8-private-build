package com.sbh.atlasos;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.speech.*;
import java.util.*;

/**
 * Opt-in foreground wake listener for Hey/OK/Okay Atlas.
 * This is intentionally not represented as privileged OEM/DSP always-on hotword support.
 * This lane does not persist raw microphone audio.
 * It emits one final wake event; it never directly executes a device command.
 */
public class AtlasWakeService extends Service implements RecognitionListener {
  public static final String CHANNEL_ID = "atlas_wake";
  public static final int NOTIFICATION_ID = 4105;
  public static final String ACTION_WAKE = "com.sbh.atlasos.HEY_ATLAS";
  public static final String ACTION_STOP = "com.sbh.atlasos.STOP_HEY_ATLAS";
  public static final String ACTION_ARM = "com.sbh.atlasos.ARM_HEY_ATLAS";
  private static final long BASE_RETRY_MS = 1200L;
  private static final long MAX_RETRY_MS = 30000L;

  private final WakeSessionPolicy wakePermit = new WakeSessionPolicy();
  private SpeechRecognizer recognizer;
  private Intent recognizerIntent;
  private boolean listening=false;
  private boolean wakeDetectedThisCycle=false;
  private long retryDelayMs=BASE_RETRY_MS;
  private String lastCommand=null;
  private long lastCommandAtMs=0L;
  private final Handler handler=new Handler(Looper.getMainLooper());
  // A recognition engine may remain quiet; audit owner authority even without callbacks.
  private static final long OWNER_WATCHDOG_MS=2000L;
  private final Runnable ownerWatchdog=new Runnable(){
    @Override public void run(){
      if(hasWakeAuthority())handler.postDelayed(this,OWNER_WATCHDOG_MS);
    }
  };
  private final Runnable retryRunnable=this::startListening;

  @Override public void onCreate(){
    super.onCreate();
    createChannel();
    if(!SpeechRecognizer.isRecognitionAvailable(this))return;
    recognizer=SpeechRecognizer.createSpeechRecognizer(this);
    recognizer.setRecognitionListener(this);
    recognizerIntent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
    recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
    recognizerIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
    recognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,5);
    recognizerIntent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true);
    recognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE,getPackageName());
  }

  @Override public int onStartCommand(Intent intent,int flags,int startId){
    // STOP always works, even if the owner session has expired.
    if(intent!=null&&ACTION_STOP.equals(intent.getAction())){
      stopForPrivacy();
      return START_NOT_STICKY;
    }
    // No silent restart after an OS kill, and no start by stale/unlocked UI state.
    if(intent==null||!ACTION_ARM.equals(intent.getAction())
        ||!wakePermit.arm(OwnerSessionGate.capture(this))){
      stopForPrivacy();
      return START_NOT_STICKY;
    }
    startForeground(NOTIFICATION_ID,notification("Hey Atlas listener active"));
    if(recognizer==null){
      notifyState("Speech recognition unavailable on this device");
      stopForPrivacy();
      return START_NOT_STICKY;
    }
    getSharedPreferences("atlas",MODE_PRIVATE).edit().putBoolean("wake_enabled",true).apply();
    handler.removeCallbacks(ownerWatchdog);
    handler.postDelayed(ownerWatchdog,OWNER_WATCHDOG_MS);
    startListening();
    return START_NOT_STICKY; // Never silently re-arm microphone after process death.
  }

  private void stopForPrivacy(){
    wakePermit.revoke();
    listening=false;
    handler.removeCallbacks(retryRunnable);
    handler.removeCallbacks(ownerWatchdog);
    getSharedPreferences("atlas",MODE_PRIVATE).edit().putBoolean("wake_enabled",false).apply();
    stopSelf();
  }

  private boolean hasWakeAuthority(){
    if(wakePermit.mayListen(OwnerSessionGate.capture(this)))return true;
    stopForPrivacy();
    return false;
  }

  private void startListening(){
    handler.removeCallbacks(retryRunnable);
    if(!hasWakeAuthority())return;
    if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
      getSharedPreferences("atlas",MODE_PRIVATE).edit().putBoolean("wake_enabled",false).apply();
      stopSelf(); return;
    }
    if(recognizer==null||recognizerIntent==null||listening)return;
    try{
      wakeDetectedThisCycle=false;
      listening=true;
      recognizer.startListening(recognizerIntent);
    }catch(Exception e){
      listening=false;
      scheduleRetry(retryDelayMs);
    }
  }

  private boolean inspectPartial(Bundle bundle){
    if(!hasWakeAuthority())return false;
    if(bundle==null)return false;
    ArrayList<String> rows=bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
    if(rows==null)return false;
    for(String s:rows){
      if(WakePhrasePolicy.extractCommand(s)!=null){
        notifyState("Wake word detected — listening");
        return true;
      }
    }
    return false;
  }

  private boolean inspectFinal(Bundle bundle){
    if(!hasWakeAuthority())return false;
    if(bundle==null)return false;
    ArrayList<String> rows=bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
    float[] confidence=bundle.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES);
    String selected=TranscriptSelector.choose(rows,confidence,true);
    if(selected.isEmpty())return false;
    String trailing=WakePhrasePolicy.extractCommand(selected);
    if(trailing==null)return false;
    if(wakeDetectedThisCycle)return true;
    if(!trailing.isEmpty()){
      long now=SystemClock.elapsedRealtime();
      if(!WakePhrasePolicy.shouldExecute(trailing,lastCommand,now,lastCommandAtMs)){
        notifyState("Duplicate Atlas command suppressed");
        return true;
      }
      lastCommand=trailing; lastCommandAtMs=now;
    }
    wakeDetectedThisCycle=true;
    Intent broadcast=new Intent(ACTION_WAKE).setPackage(getPackageName());
    broadcast.putExtra("phrase",selected);
    broadcast.putExtra("command",trailing);
    sendBroadcast(broadcast);
    notifyState(trailing.isEmpty()?"Hey Atlas heard — ready":"Atlas heard: "+trailing);
    return true;
  }

  private Notification notification(String text){
    Intent open=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
    PendingIntent content=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    Intent stopIntent=new Intent(this,AtlasWakeService.class).setAction(ACTION_STOP);
    PendingIntent stop=PendingIntent.getService(this,1,stopIntent,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    return new Notification.Builder(this,CHANNEL_ID)
      .setContentTitle("ATLAS")
      .setContentText(text)
      .setSmallIcon(android.R.drawable.ic_btn_speak_now)
      .setOngoing(true)
      .setOnlyAlertOnce(true)
      .setContentIntent(content)
      .addAction(new Notification.Action.Builder(null,"Stop",stop).build())
      .build();
  }

  private void notifyState(String text){
    NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    if(nm!=null)nm.notify(NOTIFICATION_ID,notification(text));
  }

  private void createChannel(){
    if(Build.VERSION.SDK_INT>=26){
      NotificationChannel c=new NotificationChannel(CHANNEL_ID,"Hey Atlas",NotificationManager.IMPORTANCE_LOW);
      c.setDescription("Foreground microphone service for the optional Hey Atlas listener.");
      NotificationManager n=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
      if(n!=null)n.createNotificationChannel(c);
    }
  }

  private void scheduleRetry(long requestedDelayMs){
    if(!hasWakeAuthority())return;
    listening=false;
    handler.removeCallbacks(retryRunnable);
    long delay=Math.max(BASE_RETRY_MS,Math.min(MAX_RETRY_MS,requestedDelayMs));
    handler.postDelayed(retryRunnable,delay);
    retryDelayMs=Math.min(MAX_RETRY_MS,Math.max(BASE_RETRY_MS,delay*2));
  }

  private void healthyCycle(){ retryDelayMs=BASE_RETRY_MS; }

  @Override public void onReadyForSpeech(Bundle params){ healthyCycle(); notifyState("Listening for Hey Atlas"); }
  @Override public void onBeginningOfSpeech(){ notifyState("Listening"); }
  @Override public void onRmsChanged(float rmsdB){}
  @Override public void onBufferReceived(byte[] buffer){}
  @Override public void onEndOfSpeech(){ notifyState("Processing speech"); }

  @Override public void onError(int error){
    if(!hasWakeAuthority())return;
    listening=false;
    long delay;
    switch(error){
      case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: delay=4000L; break;
      case SpeechRecognizer.ERROR_NETWORK:
      case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
      case SpeechRecognizer.ERROR_SERVER: delay=10000L; break;
      case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
        getSharedPreferences("atlas",MODE_PRIVATE).edit().putBoolean("wake_enabled",false).apply(); stopSelf(); return;
      case SpeechRecognizer.ERROR_NO_MATCH:
      case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: delay=BASE_RETRY_MS; break;
      default: delay=retryDelayMs;
    }
    scheduleRetry(delay);
  }

  @Override public void onResults(Bundle results){
    if(!hasWakeAuthority())return;
    inspectFinal(results);
    listening=false;
    healthyCycle();
    scheduleRetry(BASE_RETRY_MS);
  }
  @Override public void onPartialResults(Bundle partialResults){ inspectPartial(partialResults); }
  @Override public void onEvent(int eventType,Bundle params){}

  @Override public void onDestroy(){
    wakePermit.revoke();
    listening=false;
    handler.removeCallbacksAndMessages(null);
    getSharedPreferences("atlas",MODE_PRIVATE).edit().putBoolean("wake_enabled",false).apply();
    if(recognizer!=null){ try{recognizer.cancel();}catch(Exception ignored){} try{recognizer.destroy();}catch(Exception ignored){} }
    recognizer=null;
    if(Build.VERSION.SDK_INT>=24)stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
    super.onDestroy();
  }

  @Override public android.os.IBinder onBind(Intent intent){ return null; }
}
