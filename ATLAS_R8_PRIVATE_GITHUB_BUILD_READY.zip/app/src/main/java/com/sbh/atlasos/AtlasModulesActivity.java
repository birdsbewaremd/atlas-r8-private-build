package com.sbh.atlasos;

import android.app.*;
import android.os.Bundle;
import android.net.Uri;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Offline, owner-invoked collection of preserved HTML apps. No JS-to-native bridge. */
public final class AtlasModulesActivity extends Activity {
    private static final String HOST="appassets.androidplatform.net";
    private static final String BASE="https://"+HOST+"/atlas_modules/";
    private volatile WebView browser;
    private volatile boolean rendererUnavailable;
    private static final int PICK_OWNER_AUDIO=7521;
    private ValueCallback<Uri[]> pendingAudioFiles;
    private AlertDialog externalDialog;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7,11,18));
        LinearLayout actions=new LinearLayout(this);
        actions.setPadding(7,6,7,6);
        actions.setBackgroundColor(Color.rgb(16,31,46));
        addButton(actions,"← Back",()->{ WebView view=browser;if(!browserUsable(view))return;
            if(view.canGoBack())view.goBack();else loadPage("hub/index.html"); });
        addButton(actions,"Modules",()->loadPage("hub/index.html"));
        addButton(actions,"Storage",()->{if(browserUsable(browser))startActivity(new Intent(this,AtlasCleanupActivity.class));});
        addButton(actions,"Close",this::finish);
        root.addView(actions,new LinearLayout.LayoutParams(-1,-2));
        browser=new WebView(this);
        WebSettings ws=browser.getSettings();
        ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true);
        ws.setBlockNetworkLoads(true);
        ws.setAllowFileAccess(false);ws.setAllowContentAccess(false);
        ws.setAllowFileAccessFromFileURLs(false); ws.setAllowUniversalAccessFromFileURLs(false);
        ws.setJavaScriptCanOpenWindowsAutomatically(false);ws.setSupportMultipleWindows(false);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if(android.os.Build.VERSION.SDK_INT>=26)ws.setSafeBrowsingEnabled(true);
        browser.setWebChromeClient(new WebChromeClient(){
            @Override public void onPermissionRequest(PermissionRequest request){
                runOnUiThread(()->{try{request.deny();}catch(Exception ignored) {}});
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(!browserUsable(view)){
                    try{callback.onReceiveValue(null);}catch(RuntimeException ignored){}
                    return true;
                }
                // Only explicit owner-selected audio from a system picker.
                // This does not grant microphone or unrestricted disk access.
                String[] accepts=params==null?new String[0]:params.getAcceptTypes();
                boolean audio=false;
                for(String t:accepts)if(t!=null&&(t.equals("audio/*")||t.startsWith("audio/")||t.equals(".wav")||t.equals(".mp3")||t.equals(".m4a")))audio=true;
                if(!audio)return false;
                cancelPendingAudio();
                pendingAudioFiles=callback;
                try{
                    Intent pick=new Intent(Intent.ACTION_GET_CONTENT);
                    pick.setType("audio/*");
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(Intent.createChooser(pick,"Your own voice recording"),PICK_OWNER_AUDIO);
                    return true;
                }catch(Exception ignored){
                    cancelPendingAudio();return true;
                }
            }
        });
        browser.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest req){
                if(!browserUsable(v))return deniedResource();
                Uri u=req.getUrl();
                String rel=relativeAsset(u);
                if(rel!=null) return getAssetResponse(rel);
                String sch=u==null?"":u.getScheme();
                if("blob".equals(sch)||"data".equals(sch))return null;
                return deniedResource();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req){
                if(!browserUsable(v))return true;
                if(!req.isForMainFrame())return true;
                Uri u=req.getUrl();
                String path=relativeAsset(u);
                if(path!=null){
                    if(path.endsWith(".html")) loadPage(path);
                    return true;
                }
                if(u!=null&&"https".equals(u.getScheme())&&!HOST.equals(u.getHost())){
                    confirmExternal(u);
                }else{
                    Toast.makeText(AtlasModulesActivity.this,"Blocked external or unsafe link",Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            @Override public void onReceivedSslError(WebView v,SslErrorHandler h,android.net.http.SslError e){h.cancel();}
            @Override public boolean onRenderProcessGone(WebView view,RenderProcessGoneDetail detail){
                recoverRenderer(view);
                return true;
            }
        });
        root.addView(browser,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        loadPage("hub/index.html");
    }
    private void addButton(LinearLayout row,String title,Runnable click){
        Button b=new Button(this);b.setAllCaps(false);b.setText(title);
        b.setTextColor(Color.WHITE);b.setTextSize(12);b.setOnClickListener(v->click.run());
        row.addView(b,new LinearLayout.LayoutParams(0,Math.round(49*getResources().getDisplayMetrics().density),1));
    }
    private boolean browserUsable(WebView view){
        return view!=null&&view==browser&&!rendererUnavailable&&!isFinishing()&&!isDestroyed();
    }
    private void cancelPendingAudio(){
        ValueCallback<Uri[]> callback=pendingAudioFiles;pendingAudioFiles=null;
        if(callback!=null)try{callback.onReceiveValue(null);}catch(RuntimeException ignored){}
    }
    private void dismissExternalDialog(){
        AlertDialog dialog=externalDialog;externalDialog=null;
        if(dialog!=null)try{dialog.dismiss();}catch(RuntimeException ignored){}
    }
    private void disposeBrowser(WebView view,boolean rendererGone){
        if(view==null)return;
        // A dead renderer's WebView must not be reused or navigated. Detach it
        // and destroy only this view; persisted module data stays untouched.
        try{ViewParent parent=view.getParent();if(parent instanceof ViewGroup)((ViewGroup)parent).removeView(view);}catch(RuntimeException ignored){}
        if(!rendererGone)try{view.stopLoading();}catch(RuntimeException ignored){}
        try{view.destroy();}catch(RuntimeException ignored){}
    }
    private void recoverRenderer(WebView failed){
        if(failed!=browser){disposeBrowser(failed,true);return;}
        rendererUnavailable=true;browser=null;
        OwnerSessionGate.clear();
        cancelPendingAudio();dismissExternalDialog();disposeBrowser(failed,true);
        if(isFinishing()||isDestroyed())return;
        LinearLayout recovery=new LinearLayout(this);recovery.setOrientation(LinearLayout.VERTICAL);
        int padding=Math.round(24*getResources().getDisplayMetrics().density);
        recovery.setPadding(padding,padding,padding,padding);recovery.setBackgroundColor(Color.rgb(7,11,18));
        TextView title=new TextView(this);title.setText("ATLAS module stopped");title.setTextColor(Color.WHITE);title.setTextSize(24);
        recovery.addView(title,new LinearLayout.LayoutParams(-1,-2));
        TextView message=new TextView(this);message.setText("Android's web renderer stopped. Your owner session is locked and pending file selection is cancelled. Saved files and settings are unchanged.\n\nRetry returns to ATLAS. Unlock it, then reopen the module. No page will reload automatically.");
        message.setTextColor(Color.rgb(211,204,228));message.setTextSize(16);message.setPadding(0,padding,0,padding);
        recovery.addView(message,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout actions=new LinearLayout(this);
        addButton(actions,"Retry from ATLAS",()->{
            OwnerSessionGate.clear();
            try{startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP));finish();}
            catch(RuntimeException unavailable){Toast.makeText(this,"Close this screen and open ATLAS from your launcher.",Toast.LENGTH_LONG).show();}
        });
        addButton(actions,"Close",this::finish);
        recovery.addView(actions,new LinearLayout.LayoutParams(-1,-2));
        ScrollView scroll=new ScrollView(this);scroll.addView(recovery);setContentView(scroll);
    }
    private String relativeAsset(Uri uri){
        if(uri==null||!"https".equals(uri.getScheme())||!HOST.equals(uri.getHost()))return null;
        if(uri.getPort()!=-1||uri.getUserInfo()!=null)return null;
        String path=uri.getPath();
        String prefix="/atlas_modules/";
        if(path==null||!path.startsWith(prefix))return null;
        String rel=path.substring(prefix.length());
        if(!safe(rel))return null;
        return rel;
    }
    private boolean safe(String relative){
        if(relative==null||relative.isEmpty()||relative.length()>280||relative.contains("\\")||relative.contains("%")||relative.startsWith("/"))return false;
        for(String part:relative.split("/",-1)){
            if(part.isEmpty()||part.equals(".")||part.equals("..")||part.indexOf(':')!=-1)return false;
        }
        return true;
    }
    private String mime(String rel){
        String s=rel.toLowerCase(Locale.US);
        if(s.endsWith(".html"))return "text/html";
        if(s.endsWith(".css"))return "text/css";
        if(s.endsWith(".js"))return "text/javascript";
        if(s.endsWith(".json")||s.endsWith(".webmanifest"))return "application/json";
        if(s.endsWith(".svg"))return "image/svg+xml";
        if(s.endsWith(".png"))return "image/png";
        if(s.endsWith(".jpg")||s.endsWith(".jpeg"))return "image/jpeg";
        return "application/octet-stream";
    }
    private WebResourceResponse getAssetResponse(String relative){
        try {
            InputStream in=getAssets().open("atlas_modules/"+relative);
            WebResourceResponse response=new WebResourceResponse(mime(relative),"UTF-8",in);
            response.setResponseHeaders(Collections.singletonMap("Cache-Control","no-store"));
            return response;
        }catch(IOException ignored){return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));}
    }
    private WebResourceResponse deniedResource(){
        return new WebResourceResponse("text/plain","UTF-8",403,"Forbidden",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));
    }
    private void loadPage(String relative){
        final WebView view=browser;
        if(!browserUsable(view)||!safe(relative)||!relative.endsWith(".html"))return;
        try(InputStream in=getAssets().open("atlas_modules/"+relative)){
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
            while((n=in.read(buf))!=-1){bytes.write(buf,0,n);if(bytes.size()>8*1024*1024)throw new IOException("Oversized module");}
            if(browserUsable(view))view.loadDataWithBaseURL(BASE+relative,new String(bytes.toByteArray(),StandardCharsets.UTF_8),"text/html","UTF-8",BASE+relative);
        }catch(IOException e){Toast.makeText(this,"Offline module unavailable",Toast.LENGTH_LONG).show();}
    }
    private void confirmExternal(Uri uri){
        final WebView source=browser;if(!browserUsable(source))return;
        dismissExternalDialog();
        // The Android manifest deliberately declares no INTERNET permission.
        final AlertDialog dialog=new AlertDialog.Builder(this)
          .setTitle("Open outside ATLAS?")
          .setMessage("This link will open in another app or browser. It may use the internet.\n\n"+uri.toString())
          .setNegativeButton("Cancel",(d,w)->{})
          .setPositiveButton("Open",(d,w)->{
              if(!browserUsable(source))return;
              try{startActivity(new Intent(Intent.ACTION_VIEW,uri).addCategory(Intent.CATEGORY_BROWSABLE));}
              catch(Exception ex){Toast.makeText(this,"No browser available",Toast.LENGTH_SHORT).show();}
          }).create();
        externalDialog=dialog;
        dialog.setOnDismissListener(d->{if(externalDialog==dialog)externalDialog=null;});
        if(dialog.getWindow()!=null)dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        dialog.show();
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=PICK_OWNER_AUDIO)return;
        ValueCallback<Uri[]> cb=pendingAudioFiles;pendingAudioFiles=null;
        if(cb==null)return;
        Uri selected=(resultCode==Activity.RESULT_OK&&data!=null)?data.getData():null;
        try{
            if(!browserUsable(browser)||selected==null||!"content".equals(selected.getScheme()))cb.onReceiveValue(null);
            else cb.onReceiveValue(new Uri[]{selected});
        }catch(RuntimeException ignored){}
    }
    @Override protected void onPause(){if(browser!=null)browser.onPause();super.onPause();}
    @Override protected void onResume(){
        super.onResume();
        KeyguardManager keyguard=(KeyguardManager)getSystemService(KEYGUARD_SERVICE);
        if(keyguard==null||keyguard.isDeviceLocked()){finish();return;}
        if(browser!=null)browser.onResume();
    }
    @Override protected void onStop(){
        super.onStop();
        // Keep only this user-requested audio picker result alive. Ordinary
        // backgrounding still closes the module; no native owner login is restored.
        if(ModuleLifecyclePolicy.shouldFinishOnStop(isChangingConfigurations(),pendingAudioFiles!=null))finish();
    }
    @Override public void onBackPressed(){if(browser!=null&&browser.canGoBack())browser.goBack();else finish();}
    @Override protected void onDestroy(){
        cancelPendingAudio();dismissExternalDialog();
        WebView view=browser;browser=null;disposeBrowser(view,rendererUnavailable);
        super.onDestroy();
    }
}
