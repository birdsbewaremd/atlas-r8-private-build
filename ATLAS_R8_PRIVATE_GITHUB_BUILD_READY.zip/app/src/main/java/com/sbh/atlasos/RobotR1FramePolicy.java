package com.sbh.atlasos;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * ATLAS R1 v0.1: strictly offline, non-executing frame validator.
 * XOR is a typo detector, NEVER authentication. This class does not connect
 * to USB, Bluetooth, radios, robots, motors, or an Android permission bridge.
 * A real hardware adapter MUST require a separate authenticated command
 * channel, independent physical E-stop, and explicit owner approval.
 */
public final class RobotR1FramePolicy {
    private RobotR1FramePolicy() {}
    public static final class Command {
        public final int sequence;
        public final String verb;
        public final String argument;
        private Command(int n, String v, String a) {sequence=n; verb=v; argument=a;}
    }
    public static final class Decision {
        public final boolean accepted;
        public final String reason;
        public final Command command;
        private Decision(boolean a,String r,Command c) {accepted=a;reason=r;command=c;}
    }
    /** Per-session monotonic sequence enforcement and STOP latch (simulation-only). */
    public static final class Session {
        private int lastSequence;
        private boolean halted;
        public synchronized Decision accept(String packet) {
            if (halted) return new Decision(false,"HALTED",null);
            try {
                Command cmd=decode(packet);
                if(cmd.sequence<=lastSequence) return new Decision(false,"REPLAY_OR_REORDER",null);
                lastSequence=cmd.sequence;
                if("STOP".equals(cmd.verb)) halted=true;
                return new Decision(true,"VALID_SIM_ONLY",cmd);
            } catch (IllegalArgumentException e) {
                return new Decision(false,"MALFORMED_OR_UNSAFE_FRAME",null);
            }
        }
        public synchronized boolean isHalted() {return halted;}
        public synchronized int lastSequence() {return lastSequence;}
    }
    public static Command decode(String frame) {
        if(frame==null || frame.length()<20 || frame.length()>512 ||
                !frame.equals(frame.trim())) throw new IllegalArgumentException("frame length/whitespace");
        String[] f=frame.split("\\|",-1);
        if(f.length!=7 || !"R1".equals(f[0]) || !f[1].matches("[0-9]{4}") ||
                !"ATLAS".equals(f[2]) || !"PICO".equals(f[3]) ||
                !f[6].matches("[0-9A-F]{2}")) throw new IllegalArgumentException("header");
        int seq=Integer.parseInt(f[1]);
        if(seq<1) throw new IllegalArgumentException("sequence 0");
        String encoded=f[5];
        if(encoded.isEmpty() || encoded.length()>360) throw new IllegalArgumentException("argument size");
        byte[] bytes=new byte[encoded.length()];
        int n=0;
        for(int i=0;i<encoded.length();i++) {
            char c=encoded.charAt(i);
            if(c=='%') {
                if(i+2>=encoded.length() || !hex(encoded.charAt(i+1)) || !hex(encoded.charAt(i+2)))
                    throw new IllegalArgumentException("percent escape");
                bytes[n++]=(byte)((Character.digit(encoded.charAt(i+1),16)<<4) |
                        Character.digit(encoded.charAt(i+2),16));
                i+=2;
            }else if(allowedRaw(c)){
                bytes[n++]=(byte)c;
            }else throw new IllegalArgumentException("noncanonical argument");
        }
        String arg;
        try {
            arg=StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes,0,n)).toString();
        } catch(CharacterCodingException e) {
            throw new IllegalArgumentException("invalid UTF-8");
        }
        if(!percentEncode(arg).equals(encoded)) throw new IllegalArgumentException("ambiguous encoding");
        if(!checksum(frame.substring(0,frame.lastIndexOf('|'))).equals(f[6]))
            throw new IllegalArgumentException("checksum");
        if("-".equals(arg)) arg="";
        validateVerb(f[4],arg);
        return new Command(seq,f[4],arg);
    }
    /** Deterministic test-frame encoder. Do not use for real robot transports. */
    public static String encode(int seq,String verb,String arg) {
        if(seq<1 || seq>9999) throw new IllegalArgumentException("sequence");
        String a=arg==null?"":arg;
        validateVerb(verb,a);
        String body="R1|"+String.format(Locale.ROOT,"%04d",seq)+"|ATLAS|PICO|"+verb+"|"+percentEncode(a.isEmpty()?"-":a);
        if(body.length()>509) throw new IllegalArgumentException("frame too large");
        return body+"|"+checksum(body);
    }
    private static void validateVerb(String verb,String arg) {
        if(verb==null || arg==null) throw new IllegalArgumentException("null verb/arg");
        switch(verb) {
            case "SAY":
                if(arg.isEmpty() || arg.codePointCount(0,arg.length())>80 ||
                    arg.indexOf('"')>=0 || arg.indexOf('\n')>=0 || arg.indexOf('\r')>=0 ||
                    arg.codePoints().anyMatch(c->c<32 || c==127))
                    throw new IllegalArgumentException("invalid SAY");
                break;
            case "LED":
                if(!arg.matches("OFF|CYAN|AMBER|GREEN|RED"))throw new IllegalArgumentException("LED");
                break;
            case "MOVE":
                if(!arg.matches("(FORWARD|BACKWARD) [1-5]"))throw new IllegalArgumentException("MOVE");
                break;
            case "TURN":
                if(!arg.matches("(LEFT|RIGHT) (90|180|270)"))throw new IllegalArgumentException("TURN");
                break;
            case "WAIT":
                if(!arg.matches("([1-9][0-9]{0,2}|1000)"))throw new IllegalArgumentException("WAIT");
                break;
            case "SCAN":case "PING":case "STOP":
                if(!arg.isEmpty())throw new IllegalArgumentException("unexpected arg");
                break;
            default: throw new IllegalArgumentException("unknown verb");
        }
    }
    private static boolean hex(char c){return c>='0'&&c<='9'||c>='A'&&c<='F'||c>='a'&&c<='f';}
    private static boolean allowedRaw(char c) {
        return c>='a'&&c<='z'||c>='A'&&c<='Z'||c>='0'&&c<='9'||
            "-_.!~*'()".indexOf(c)>=0;
    }
    private static String percentEncode(String s) {
        StringBuilder sb=new StringBuilder();
        for(byte b:s.getBytes(StandardCharsets.UTF_8)) {
            int v=b&255;
            if(v<128&&allowedRaw((char)v)) sb.append((char)v);
            else {
                sb.append('%');
                sb.append("0123456789ABCDEF".charAt(v>>>4));
                sb.append("0123456789ABCDEF".charAt(v&15));
            }
        }
        return sb.toString();
    }
    private static String checksum(String s) {
        int x=0;
        for(byte b:s.getBytes(StandardCharsets.UTF_8)) x^=b&255;
        return String.format(Locale.ROOT,"%02X",x);
    }
}
