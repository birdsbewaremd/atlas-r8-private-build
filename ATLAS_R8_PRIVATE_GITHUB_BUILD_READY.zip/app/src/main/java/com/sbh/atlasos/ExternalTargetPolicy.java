package com.sbh.atlasos;

import java.net.IDN;
import java.net.URI;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Exact HTTPS destination policy for user-visible and future agent/network actions.
 *
 * This deliberately rejects HTTP, credentials in URLs, fragments, IP literals,
 * localhost/private-style hostnames, dot-segment aliases, non-default ports and
 * redirect chains that contain any non-allowlisted hop. Reachability is never
 * authorization.
 */
public final class ExternalTargetPolicy {
  public static final int MAX_REDIRECT_HOPS = 3;
  private ExternalTargetPolicy() {}

  public static boolean isExactTargetAllowed(String rawTarget, Set<String> allowedTargets) {
    if (rawTarget == null || allowedTargets == null || allowedTargets.isEmpty()) return false;
    String target = canonical(rawTarget);
    if (target == null) return false;
    for (String allowed : allowedTargets) {
      String candidate = canonical(allowed);
      if (candidate != null && candidate.equals(target)) return true;
    }
    return false;
  }

  /** Every hop, including the final destination, must itself be explicitly allowlisted. */
  public static boolean isRedirectChainAllowed(List<String> chain, Set<String> allowedTargets) {
    if (chain == null || chain.isEmpty() || chain.size() > MAX_REDIRECT_HOPS + 1) return false;
    HashSet<String> seen = new HashSet<String>();
    for (String raw : chain) {
      String c = canonical(raw);
      if (c == null || !seen.add(c) || !isExactTargetAllowed(c, allowedTargets)) return false;
    }
    return true;
  }

  static String canonicalForTest(String raw) { return canonical(raw); }

  private static String canonical(String raw) {
    try {
      if (raw == null) return null;
      String trimmed = raw.trim();
      if (trimmed.isEmpty() || trimmed.length() > 2048 || containsControl(trimmed) || trimmed.indexOf('\\') >= 0) return null;
      URI original = new URI(trimmed);
      if (original.isOpaque()) return null;
      URI u = original.normalize();
      String scheme = u.getScheme();
      String host = u.getHost();
      if (!"https".equalsIgnoreCase(scheme) || host == null || u.getUserInfo() != null || u.getFragment() != null) return null;
      if (original.getRawPath() != null && u.getRawPath() != null && !original.getRawPath().equals(u.getRawPath())) return null;

      String asciiHost = IDN.toASCII(host, IDN.USE_STD3_ASCII_RULES).toLowerCase(Locale.US);
      if (!safePublicHostname(asciiHost)) return null;
      int port = u.getPort();
      if (port != -1 && port != 443) return null;

      String path = u.getRawPath();
      if (path == null || path.isEmpty()) path = "/";
      if (!path.startsWith("/") || containsControl(path)) return null;
      String query = u.getRawQuery();
      if (query != null && containsControl(query)) return null;

      return "https://" + asciiHost + path + (query == null ? "" : "?" + query);
    } catch (Exception e) {
      return null;
    }
  }

  private static boolean containsControl(String s) {
    for (int i = 0; i < s.length(); i++) if (s.charAt(i) < 0x20 || s.charAt(i) == 0x7f) return true;
    return false;
  }

  private static boolean safePublicHostname(String host) {
    if (host == null || host.isEmpty() || host.length() > 253 || host.endsWith(".")) return false;
    if (host.indexOf(':') >= 0) return false; // IPv6 literal or malformed authority: blocked by default.
    if (host.matches("[0-9.]+")) return false; // IPv4 literal: blocked by default.
    if ("localhost".equals(host) || host.endsWith(".localhost") || host.endsWith(".local")
        || host.endsWith(".lan") || host.endsWith(".internal") || "home.arpa".equals(host)
        || host.endsWith(".home.arpa")) return false;
    if (host.indexOf('.') < 1) return false; // no single-label/intranet destinations in the external lane.
    String[] labels = host.split("\\.");
    for (String label : labels) {
      if (label.isEmpty() || label.length() > 63 || label.startsWith("-") || label.endsWith("-")
          || !label.matches("[a-z0-9-]+")) return false;
    }
    return true;
  }
}
