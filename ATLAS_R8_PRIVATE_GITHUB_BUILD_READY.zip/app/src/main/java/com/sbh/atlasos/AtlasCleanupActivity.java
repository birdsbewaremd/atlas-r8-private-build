package com.sbh.atlasos;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.*;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.file.Files;
import java.util.*;

/** Owner-invoked selected-file review. Only this app's temporary cache can be removed. */
public final class AtlasCleanupActivity extends Activity {
    private static final int PICK_TREE=6012,PICK_FILES=6013;
    private static final int MAX_FILES=240,MAX_FOLDERS=48,MAX_DEPTH=4;
    private static final long MAX_HASH_FILE=16L*1024*1024,MAX_HASH_TOTAL=128L*1024*1024;
    private static final long PICKER_WINDOW=120000,SCAN_WINDOW=60000;
    private TextView summary,report;private Button folderButton,filesButton,cancelButton;
    private volatile boolean scanning,resumed;private boolean pickerPending;
    private long pickerStarted;private volatile long generation,scanDeadline;
    private volatile InputStream activeInput;private volatile CancellationSignal querySignal;
    private ArrayList<Uri> pendingFiles;private Uri pendingTree;private boolean selectionClipped;
    private final Handler timeoutHandler=new Handler(Looper.getMainLooper());
    private static final String[] COLUMNS={DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE,
        DocumentsContract.Document.COLUMN_SIZE};
    private static final class DirItem {String id;int depth;DirItem(String i,int d){id=i;depth=d;}}
    private static final class Listing {
        final ArrayList<CleanupScanEngine.Item> files=new ArrayList<>();
        int folders,gaps,skippedFolders;boolean limit;
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        // Never restore a previous private report or a previously granted selection.
        if(state!=null){finish();return;}
        ScrollView scroll=new ScrollView(this);LinearLayout view=new LinearLayout(this);
        view.setOrientation(LinearLayout.VERTICAL);view.setBackgroundColor(Color.rgb(12,9,23));
        view.setPadding(dp(18),dp(20),dp(18),dp(40));scroll.addView(view);setContentView(scroll);
        title(view,"ATLAS STORAGE",26);
        note(view,"Review space on your phone. You choose every folder or file that ATLAS reads.");
        summary=note(view,"");summary.setTextSize(19);refreshSummary();
        button(view,"Open phone storage settings",()->openSystem(Settings.ACTION_INTERNAL_STORAGE_SETTINGS));
        button(view,"Review installed apps",()->openSystem(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS));
        title(view,"IF AN APK WILL NOT INSTALL",18);
        note(view,"On Samsung: Settings → Apps → choose an app → Storage → Clear cache. Clear data removes saved app data. My Files lets you review large downloads. Verify a backup before deleting originals. Freeing space may help installation; it does not diagnose every install error.");
        title(view,"REVIEW SELECTED FILES",19);
        note(view,"Choose local files from Downloads or another available folder. Android may block selection of a whole Downloads root; select individual files instead. ATLAS does not retain these permissions. A provider may still retrieve remote content if you select it.");
        filesButton=button(view,"Choose files (including Downloads)",()->choose(false));
        folderButton=button(view,"Choose a folder",()->choose(true));
        cancelButton=button(view,"Stop scan",()->{cancelScan();report.setText("Scan stopped. No selected files were modified.");});
        cancelButton.setEnabled(false);
        report=note(view,"No scan performed. This tool does not scan the whole phone or remove selected files.");
        report.setTextIsSelectable(true);
        title(view,"ATLAS TEMPORARY CACHE",19);
        note(view,"This can free only ATLAS temporary cache. It does not clear other apps, photos, downloads, messages or encrypted records.");
        button(view,"Review ATLAS cache cleanup",this::confirmCacheCleanup);
        button(view,"Close",this::finish);
    }
    private boolean unlocked(){
        try{KeyguardManager keyguard=(KeyguardManager)getSystemService(KEYGUARD_SERVICE);
            return keyguard!=null&&!keyguard.isDeviceLocked();}catch(Exception e){return false;}
    }
    private boolean usable(){return resumed&&!isFinishing()&&!isDestroyed()&&unlocked();}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView title(LinearLayout v,String s,int size){TextView t=note(v,s);t.setTextColor(Color.WHITE);t.setTextSize(size);
        try{t.setTypeface(android.graphics.Typeface.createFromAsset(getAssets(),"www/assets/fonts/ATLASDisplay-Regular.ttf"));}catch(RuntimeException unavailable){/* System font remains readable. */}return t;}
    private TextView note(LinearLayout v,String s){TextView t=new TextView(this);t.setText(s);
        t.setTextColor(Color.rgb(211,204,228));t.setTextSize(14);t.setPadding(0,dp(8),0,dp(14));v.addView(t);return t;}
    private Button button(LinearLayout v,String s,Runnable action){Button b=new Button(this);b.setAllCaps(false);
        b.setText(s);b.setMinHeight(dp(52));b.setOnClickListener(x->{if(usable())action.run();});
        v.addView(b,new LinearLayout.LayoutParams(-1,-2));return b;}
    private static String size(long n){
        if(n<1024)return n+" B";double value=n;String[] units={"B","KiB","MiB","GiB","TiB"};int unit=0;
        while(value>=1024&&unit<units.length-1){value/=1024;unit++;}
        return String.format(Locale.US,"%.2f %s",value,units[unit]);
    }
    private long cacheSize(File base,int depth){
        if(base==null||depth>20||Files.isSymbolicLink(base.toPath())||!base.exists())return 0;
        if(base.isFile())return base.length();long total=0;File[] files=base.listFiles();
        if(files!=null)for(File f:files)total=CleanupScanEngine.saturatingAdd(total,cacheSize(f,depth+1));return total;
    }
    private void refreshSummary(){if(summary==null)return;try{
        StatFs fs=new StatFs(Environment.getDataDirectory().getAbsolutePath());
        summary.setText(size(fs.getAvailableBytes())+" available\nDevice data volume: "+size(fs.getTotalBytes())
            +"\nATLAS cache: "+size(cacheSize(getCacheDir(),0)+cacheSize(getExternalCacheDir(),0))
            +"\nAndroid's storage display may use different units.");
    }catch(Exception e){summary.setText("Storage measurement unavailable.");}}
    private void openSystem(String action){cancelScan();try{startActivity(new Intent(action));}
        catch(Exception first){try{startActivity(new Intent(Settings.ACTION_SETTINGS));}
        catch(Exception second){Toast.makeText(this,"Settings unavailable",Toast.LENGTH_SHORT).show();}}}
    private void choose(boolean tree){
        if(scanning||pickerPending)return;
        Intent pick=new Intent(tree?Intent.ACTION_OPEN_DOCUMENT_TREE:Intent.ACTION_OPEN_DOCUMENT);
        pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);pick.putExtra(Intent.EXTRA_LOCAL_ONLY,true);
        if(!tree){pick.setType("*/*");pick.addCategory(Intent.CATEGORY_OPENABLE);pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);}
        pickerPending=true;pickerStarted=SystemClock.elapsedRealtime();
        try{startActivityForResult(pick,tree?PICK_TREE:PICK_FILES);}
        catch(Exception e){pickerPending=false;report.setText("No compatible Android file picker is available.");}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);if(request!=PICK_TREE&&request!=PICK_FILES)return;
        boolean valid=pickerPending&&SystemClock.elapsedRealtime()-pickerStarted>=0
            &&SystemClock.elapsedRealtime()-pickerStarted<PICKER_WINDOW;
        pickerPending=false;
        if(!valid||!unlocked()){finish();return;}
        if(result!=RESULT_OK||data==null){if(report!=null)report.setText("Selection cancelled. Nothing was read or changed.");return;}
        if(request==PICK_TREE){Uri uri=data.getData();if(uri!=null&&"content".equals(uri.getScheme()))pendingTree=uri;}
        else{
            pendingFiles=new ArrayList<>();Set<Uri> unique=new HashSet<>();ClipData clips=data.getClipData();
            int count=clips==null?1:clips.getItemCount();selectionClipped=count>MAX_FILES;
            for(int i=0;i<Math.min(count,MAX_FILES+1);i++){
                Uri uri=clips==null?data.getData():clips.getItemAt(i).getUri();
                if(uri!=null&&"content".equals(uri.getScheme())&&unique.add(uri))pendingFiles.add(uri);
            }
        }
        if(resumed)beginPendingScan();
    }
    private void beginPendingScan(){
        if(!usable()||(pendingTree==null&&pendingFiles==null))return;
        final Uri tree=pendingTree;final ArrayList<Uri> files=pendingFiles;final boolean clipped=selectionClipped;
        pendingTree=null;pendingFiles=null;selectionClipped=false;
        cancelScan();final long token=++generation;scanDeadline=SystemClock.elapsedRealtime()+SCAN_WINDOW;
        scanning=true;setScanningButtons(true);report.setText("Reviewing the selection… No selected files will be changed.");
        timeoutHandler.postDelayed(()->{if(token==generation&&scanning){cancelScan();
            if(usable())report.setText("Stopped after the 60-second scan window. Provider work may take time to close. No selected files were modified. Try fewer files.");}},SCAN_WINDOW);
        new Thread(()->{
            String answer;try{Listing listing=tree!=null?listTree(tree,token):listFiles(files,token);listing.limit|=clipped;
                CleanupScanEngine.Result found=CleanupScanEngine.inspect(listing.files,MAX_HASH_FILE,MAX_HASH_TOTAL,()->stopped(token));
                answer=format(listing,found);
            }catch(Exception e){answer="Scan ended: "+e.getClass().getSimpleName()+". No selected files were modified.";}
            final String text=answer;
            runOnUiThread(()->{if(token!=generation||!usable())return;scanning=false;setScanningButtons(false);report.setText(text);});
        },"atlas-selected-file-review").start();
    }
    private boolean stopped(long token){return token!=generation||!resumed||SystemClock.elapsedRealtime()>=scanDeadline||Thread.currentThread().isInterrupted();}
    private Cursor query(Uri uri,String[] projection,long token){
        if(stopped(token))return null;CancellationSignal signal=new CancellationSignal();querySignal=signal;
        try{return getContentResolver().query(uri,projection,null,null,null,signal);}
        finally{if(querySignal==signal)querySignal=null;}
    }
    private CleanupScanEngine.Item item(Uri uri,String name,long bytes,long token){
        return new CleanupScanEngine.Item(uri.toString(),name==null?"unnamed":name,bytes,()->{
            if(stopped(token))throw new IOException("scan stopped");
            InputStream raw=getContentResolver().openInputStream(uri);if(raw==null)throw new IOException("unreadable");
            FilterInputStream tracked=new FilterInputStream(raw){@Override public void close()throws IOException{
                try{super.close();}finally{if(activeInput==this)activeInput=null;}}};
            activeInput=tracked;if(stopped(token)){tracked.close();throw new IOException("scan stopped");}return tracked;
        });
    }
    private Listing listFiles(ArrayList<Uri> selected,long token){
        Listing out=new Listing();if(selected==null)return out;out.limit=selected.size()>MAX_FILES;
        for(int i=0;i<Math.min(selected.size(),MAX_FILES)&&!stopped(token);i++){
            Uri uri=selected.get(i);try(Cursor c=query(uri,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},token)){
                if(c==null||!c.moveToFirst()){out.gaps++;continue;}
                out.files.add(item(uri,c.getString(0),c.isNull(1)?-1:c.getLong(1),token));
            }catch(Exception e){out.gaps++;}
        }return out;
    }
    private Listing listTree(Uri tree,long token){
        Listing out=new Listing();ArrayDeque<DirItem> queue=new ArrayDeque<>();Set<String> visited=new HashSet<>();
        queue.add(new DirItem(DocumentsContract.getTreeDocumentId(tree),0));
        while(!queue.isEmpty()&&!stopped(token)&&out.files.size()<MAX_FILES&&out.folders<MAX_FOLDERS){
            DirItem dir=queue.remove();if(!visited.add(dir.id)){out.skippedFolders++;continue;}out.folders++;
            Uri child=DocumentsContract.buildChildDocumentsUriUsingTree(tree,dir.id);
            try(Cursor c=query(child,COLUMNS,token)){
                if(c==null){out.gaps++;continue;}
                while(c.moveToNext()&&!stopped(token)){
                    if(out.files.size()>=MAX_FILES){out.limit=true;break;}
                    String id=c.getString(0),name=c.getString(1),mime=c.getString(2);
                    if(id==null){out.gaps++;continue;}
                    if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)){
                        if(dir.depth<MAX_DEPTH&&out.folders+queue.size()<MAX_FOLDERS)queue.add(new DirItem(id,dir.depth+1));
                        else out.skippedFolders++;
                    }else out.files.add(item(DocumentsContract.buildDocumentUriUsingTree(tree,id),name,c.isNull(3)?-1:c.getLong(3),token));
                }
            }catch(Exception e){out.gaps++;}
        }
        if(!queue.isEmpty())out.limit=true;return out;
    }
    private String format(Listing listing,CleanupScanEngine.Result result){
        StringBuilder out=new StringBuilder("SELECTED-FILE REVIEW\n");
        out.append(result.listed).append(" distinct files listed; ").append(size(result.listedBytes)).append(" known file bytes.\n")
            .append(result.hashed).append(" files hashed; ").append(size(result.bytesRead)).append(" actually read.\n")
            .append("Limits: 240 files, 48 folders, depth 4, 16 MiB per hashed file, 128 MiB read, 60-second cancellation window. Slow providers may take longer to close.\n");
        int index=0;for(List<CleanupScanEngine.Item> group:result.groups){
            if(index++>=10)break;out.append("\nMatching SHA-256 content: ").append(size(group.get(0).size)).append(" each\n");
            for(int i=0;i<Math.min(group.size(),5);i++)out.append(" • ").append(group.get(i).name.replaceAll("[\\p{Cntrl}]"," ")).append('\n');
            if(group.size()>5)out.append(" + ").append(group.size()-5).append(" more matching files\n");
        }
        out.append("\n").append(result.groups.size()).append(" matching-content groups. Extra copies total ")
            .append(size(result.reclaimableBytes)).append(" within this selection; this is not free space yet.\n")
            .append("Matching content does not prove a copy is safe to remove. Verify backups and review files in My Files. Nothing selected was deleted.\n");
        out.append("\nCoverage: ").append(listing.folders).append(" folders visited; ").append(listing.skippedFolders)
            .append(" folders skipped; ").append(result.unknown).append(" unknown sizes; ").append(listing.gaps)
            .append(" provider gaps; ").append(result.errors).append(" read errors; ").append(result.largeSkipped)
            .append(" files above hash size limit; ").append(result.budgetSkipped).append(" budget skips.\n");
        if(listing.limit||listing.skippedFolders>0||listing.gaps>0||result.unknown>0||result.errors>0
            ||result.largeSkipped>0||result.budgetSkipped>0||result.cancelled)out.append("PARTIAL: unreviewed files may remain.\n");
        if(result.cancelled)out.append("The scan time limit was reached or the scan was stopped.\n");
        if(result.groups.size()>10)out.append("Only the first 10 matching groups are displayed.\n");return out.toString();
    }
    private void setScanningButtons(boolean value){if(folderButton!=null)folderButton.setEnabled(!value);
        if(filesButton!=null)filesButton.setEnabled(!value);if(cancelButton!=null)cancelButton.setEnabled(value);}
    private void cancelScan(){generation++;scanning=false;timeoutHandler.removeCallbacksAndMessages(null);CancellationSignal signal=querySignal;if(signal!=null)signal.cancel();
        InputStream input=activeInput;if(input!=null){try{input.close();}catch(IOException ignored){}}activeInput=null;setScanningButtons(false);}
    private void confirmCacheCleanup(){
        long bytes=cacheSize(getCacheDir(),0)+cacheSize(getExternalCacheDir(),0);
        new AlertDialog.Builder(this).setTitle("Clear only ATLAS temporary cache?")
            .setMessage("Measured cache: "+size(bytes)+". This permanently removes ATLAS temporary cache entries. It does not target saved records, downloads or other apps. Pages may reload more slowly.")
            .setNegativeButton("Cancel",null).setPositiveButton("Clear ATLAS cache",(d,w)->{if(usable())clearOnlyCache();}).show();
    }
    private void clearOnlyCache(){
        long before=cacheSize(getCacheDir(),0)+cacheSize(getExternalCacheDir(),0);
        int removed=deleteContents(getCacheDir(),0)+deleteContents(getExternalCacheDir(),0);
        long after=cacheSize(getCacheDir(),0)+cacheSize(getExternalCacheDir(),0);refreshSummary();
        new AlertDialog.Builder(this).setTitle("ATLAS cache result")
            .setMessage("Cache entries removed: "+removed+"\nMeasured cache-size reduction: "+size(Math.max(0,before-after))
                +"\nThe phone's available-space reading may change as other apps run.").setPositiveButton("Close",null).show();
    }
    private int deleteContents(File folder,int depth){
        if(folder==null||depth>20||Files.isSymbolicLink(folder.toPath())||!folder.isDirectory())return 0;
        File[] children=folder.listFiles();if(children==null)return 0;int deleted=0;
        for(File child:children){if(Files.isSymbolicLink(child.toPath()))continue;
            if(child.isDirectory())deleted+=deleteContents(child,depth+1);if(child.delete())deleted++;}return deleted;
    }
    @Override protected void onResume(){super.onResume();resumed=true;if(!unlocked()){finish();return;}
        if(pickerPending&&SystemClock.elapsedRealtime()-pickerStarted>=PICKER_WINDOW){finish();return;}
        refreshSummary();beginPendingScan();}
    @Override protected void onPause(){resumed=false;cancelScan();if(report!=null)report.setText("Private report cleared when leaving this screen.");super.onPause();}
    @Override protected void onStop(){super.onStop();if(!pickerPending)finish();}
    @Override protected void onDestroy(){resumed=false;pickerPending=false;pendingFiles=null;pendingTree=null;cancelScan();super.onDestroy();}
}
