package com.sbh.atlasos;
import android.content.Context;
import java.util.*;
import java.util.function.BooleanSupplier;
import org.json.*;

/** Strict JSON boundary. No client-selected owner, prompts, filesystem paths, endpoints or execution. */
final class HumanLearningBridge {
  private static final Object PROCESS_LOCK=new Object();
  private final HumanLearningEngine engine;
  private final BooleanSupplier authorized;
  HumanLearningBridge(Context c,BooleanSupplier owner){authorized=owner;engine=new HumanLearningEngine(new AndroidLearningStore(c),owner);}
  String request(String raw){synchronized(PROCESS_LOCK){
    try{
      authorize();
      if(raw==null||raw.length()>16000)throw new HumanLearningEngine.Failure("INVALID_INPUT");
      JSONObject q=new JSONObject(raw);String op=text(q,"op");JSONObject data;
      switch(op){
        case "inspect":keys(q,"op");data=profile(engine.inspect());break;
        case "create":keys(q,"op","consent","preferences");data=profile(engine.create(bool(q,"consent"),prefs(q.getJSONObject("preferences"))));break;
        case "update":keys(q,"op","generation","revision","preferences");data=profile(engine.update(text(q,"generation"),revision(q),prefs(q.getJSONObject("preferences"))));break;
        case "consent":keys(q,"op","generation","revision","active");data=profile(engine.consent(text(q,"generation"),revision(q),bool(q,"active")));break;
        case "delete":keys(q,"op","generation","revision","confirmed");engine.delete(text(q,"generation"),revision(q),bool(q,"confirmed"));data=new JSONObject().put("deleted",true);break;
        case "export":keys(q,"op");data=new JSONObject().put("profile",profile(engine.inspect())).put("scope","profile-only preview; no file or message sent");break;
        case "lesson":keys(q,"op","lesson_id","urgent");HumanLearningEngine.Lesson l=engine.lesson(text(q,"lesson_id"),bool(q,"urgent"));
          data=new JSONObject().put("lesson_id",l.id).put("goal",l.goal).put("explain",l.explain);if(l.example!=null)data.put("example",l.example);if(l.practice!=null)data.put("practice",l.practice);break;
        case "submit":keys(q,"op","generation","revision","attempt_id","lesson_id","answer","assisted");
          HumanLearningEngine.Profile p=engine.submit(text(q,"generation"),revision(q),text(q,"attempt_id"),text(q,"lesson_id"),text(q,"answer"),bool(q,"assisted"));
          HumanLearningEngine.Attempt found=null;for(HumanLearningEngine.Attempt a:p.attempts)if(a.id.equals(text(q,"attempt_id")))found=a;
          if(found==null)throw new HumanLearningEngine.Failure("INVALID_RECORD");
          data=new JSONObject().put("correct",found.correct).put("assisted",found.assisted).put("feedback",HumanLearningEngine.feedback(found)).put("profile",profile(p));break;
        case "progress":keys(q,"op");HumanLearningEngine.Profile progress=engine.progress();int correct=0,unassisted=0;
          for(HumanLearningEngine.Attempt a:progress.attempts)if(a.correct){correct++;if(!a.assisted)unassisted++;}
          data=new JSONObject().put("attempts",progress.attempts.size()).put("correct",correct).put("correct_reported_unassisted",unassisted)
            .put("independence_verified",false).put("retention_verified",false).put("real_world_performance_verified",false).put("mastery","not_established");break;
        case "render":keys(q,"op","update");JSONObject u=q.getJSONObject("update");keys(u,"status","outcome","next_action","evidence_refs","details","blockers","warnings","deadline");
          data=new JSONObject().put("text",engine.render(text(u,"status"),text(u,"outcome"),text(u,"next_action"),list(u,"evidence_refs"),list(u,"details"),list(u,"blockers"),list(u,"warnings"),u.isNull("deadline")?null:text(u,"deadline")));break;
        case "recognize":keys(q,"op","text");engine.inspect();String original=text(q,"text");data=new JSONObject().put("original",original).put("intent",nullable(HumanLearningEngine.recognize(original))).put("authority","none");break;
        default:throw new HumanLearningEngine.Failure("INVALID_INPUT");
      }
      authorize();
      return new JSONObject().put("ok",true).put("data",data).toString();
    }catch(HumanLearningEngine.Failure e){return error(e.code);}catch(JSONException|IllegalArgumentException e){return error("INVALID_INPUT");}catch(Exception e){return error("STORAGE_UNAVAILABLE");}
  }}
  private void authorize()throws HumanLearningEngine.Failure{boolean ok=false;try{ok=authorized.getAsBoolean();}catch(Exception ignored){}if(!ok)throw new HumanLearningEngine.Failure("OWNER_UNLOCK_REQUIRED");}
  private static String error(String code){return "{\"ok\":false,\"error\":\""+code+"\"}";}
  private static Object nullable(Object o){return o==null?JSONObject.NULL:o;}
  private static String text(JSONObject q,String key)throws JSONException{Object v=q.get(key);if(!(v instanceof String))throw new JSONException("text required");return (String)v;}
  private static boolean bool(JSONObject q,String key)throws JSONException{Object v=q.get(key);if(!(v instanceof Boolean))throw new JSONException("boolean required");return (Boolean)v;}
  private static long revision(JSONObject q)throws JSONException{Object v=q.get("revision");if(!(v instanceof Integer)&&!(v instanceof Long))throw new JSONException("integer required");long n=((Number)v).longValue();if(n<1)throw new JSONException("positive revision");return n;}
  private static void keys(JSONObject q,String... names)throws JSONException{Set<String> set=new HashSet<>(Arrays.asList(names));if(q.length()!=set.size())throw new JSONException("unexpected fields");Iterator<String> it=q.keys();while(it.hasNext())if(!set.contains(it.next()))throw new JSONException("unexpected field");}
  private static List<String> list(JSONObject q,String key)throws JSONException{JSONArray a=q.getJSONArray(key);if(a.length()>12)throw new JSONException("too many values");List<String> out=new ArrayList<>();for(int i=0;i<a.length();i++){Object v=a.get(i);if(!(v instanceof String))throw new JSONException("text required");out.add((String)v);}return out;}
  private static HumanLearningEngine.Preferences prefs(JSONObject q)throws Exception{keys(q,"detail","examples","practice");return new HumanLearningEngine.Preferences(text(q,"detail"),bool(q,"examples"),text(q,"practice"));}
  private static JSONObject profile(HumanLearningEngine.Profile p)throws JSONException{
    JSONObject out=new JSONObject().put("schema",1).put("generation",p.generation).put("revision",p.revision).put("consent_active",p.consent).put("consent_recorded_at_ms",p.consentAt)
      .put("sharing","disabled").put("preference_source","explicit_user").put("scope","this-device-owner")
      .put("preferences",new JSONObject().put("detail",p.preferences.detail).put("examples",p.preferences.examples).put("practice",p.preferences.practice));
    JSONArray a=new JSONArray();for(HumanLearningEngine.Attempt x:p.attempts)a.put(new JSONObject().put("attempt_id",x.id).put("lesson_id",x.lesson).put("correct",x.correct).put("assisted",x.assisted).put("recorded_at_ms",x.at));
    return out.put("attempts",a);
  }
}
