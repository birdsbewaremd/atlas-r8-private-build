package com.sbh.atlasos;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Generated from the owner-reviewed 92-entry registry. It contains names and aliases only. */
public final class WorkflowCommandCatalog {
  public static final String SCHEMA_VERSION = "2.0.0";
  public static final String RECORD_ID = "ATLAS-SEMANTIC-COMMAND-SYSTEM-V2-20261010";
  public static final String REGISTRY_SHA256 = "628ed9adb7e8f5f996873f5242a55e396cb2deccdcc172b675d57bed9d5e7ee9";
  public static final int TOTAL_ENTRIES = 92;

  public static final class Entry {
    public final String id;
    public final String canonical;
    public final String category;
    public final List<String> aliases;
    private Entry(String id, String canonical, String category, String[] aliases) {
      this.id = id;
      this.canonical = canonical;
      this.category = category;
      List<String> copy = new ArrayList<String>();
      if (aliases != null) Collections.addAll(copy, aliases);
      this.aliases = Collections.unmodifiableList(copy);
    }
  }

  private static final Entry[] DATA = new Entry[]{
    new Entry("atlas_save", "ATLAS SAVE", "Continuity", new String[]{}),
    new Entry("atlas_correct", "ATLAS CORRECT", "Continuity", new String[]{}),
    new Entry("atlas_deep_sync", "ATLAS DEEP SYNC", "Continuity", new String[]{"Atlas deep sink", "Atlas deep synch", "deep sync"}),
    new Entry("atlas_handoff", "ATLAS HANDOFF", "Continuity", new String[]{}),
    new Entry("atlas_outcome", "ATLAS OUTCOME", "Continuity", new String[]{}),
    new Entry("atlas_museum", "ATLAS MUSEUM", "Continuity", new String[]{}),
    new Entry("atlas_checkpoint", "ATLAS CHECKPOINT", "Continuity", new String[]{}),
    new Entry("add_this_too", "ADD THIS TOO", "Continuity", new String[]{}),
    new Entry("use_memory", "USE MEMORY", "Continuity", new String[]{"USE LIBRARY", "USE SHAUN OS"}),
    new Entry("remember_this", "REMEMBER THIS", "Continuity", new String[]{}),
    new Entry("shaun_os_consolidate_this_chat", "SHAUN OS — CONSOLIDATE THIS CHAT", "Continuity", new String[]{}),
    new Entry("atlas_sync", "ATLAS SYNC", "Continuity", new String[]{"SYNC"}),
    new Entry("atlas_resume", "ATLAS RESUME", "Continuity", new String[]{}),
    new Entry("atlas_current", "ATLAS CURRENT", "Evidence", new String[]{}),
    new Entry("atlas_verify", "ATLAS VERIFY", "Evidence", new String[]{}),
    new Entry("atlas_source", "ATLAS SOURCE", "Evidence", new String[]{}),
    new Entry("hard_truth_mode", "HARD TRUTH MODE", "Evidence", new String[]{}),
    new Entry("atlas_status", "ATLAS STATUS", "Evidence", new String[]{"STATUS"}),
    new Entry("atlas_deep", "ATLAS DEEP", "Quality", new String[]{}),
    new Entry("atlas_master_forge", "ATLAS MASTER FORGE", "Quality", new String[]{}),
    new Entry("atlas_crosscheck", "ATLAS CROSSCHECK", "Quality", new String[]{"ATLAS CROSSCHECK 100X"}),
    new Entry("atlas_red_team_forge", "ATLAS RED TEAM FORGE", "Quality", new String[]{"ATLAS REDTEAM FORGE", "Atlas red team forged"}),
    new Entry("take_your_time", "TAKE YOUR TIME", "Quality", new String[]{}),
    new Entry("atlas_forge", "ATLAS FORGE", "Quality", new String[]{"FORGE", "10X FORGE", "20FORGE", "100FORGE", "10² FORGE"}),
    new Entry("atlas_red_team_forge_googol", "ATLAS RED TEAM FORGE GOOGOL", "Quality", new String[]{"Atlas redteam forge googol", "Atlas red team forged googol", "Atlas red team forge Google"}),
    new Entry("atlas_short", "ATLAS SHORT", "Output", new String[]{}),
    new Entry("better", "BETTER", "Output", new String[]{}),
    new Entry("shorter", "SHORTER", "Output", new String[]{}),
    new Entry("be_the_boss", "BE THE BOSS", "Output", new String[]{}),
    new Entry("more_humble", "MORE HUMBLE", "Output", new String[]{}),
    new Entry("professional", "PROFESSIONAL", "Output", new String[]{}),
    new Entry("cocky", "COCKY", "Output", new String[]{"BIG-DICK ENERGY"}),
    new Entry("no_spacing", "NO SPACING", "Output", new String[]{}),
    new Entry("photo_rate", "PHOTO RATE", "Output", new String[]{}),
    new Entry("atlas_help", "ATLAS HELP", "Output", new String[]{"HELP"}),
    new Entry("reword", "REWORD", "Output", new String[]{}),
    new Entry("atlas_commands", "ATLAS COMMANDS", "Output", new String[]{}),
    new Entry("atlas_build", "ATLAS BUILD", "Execution", new String[]{}),
    new Entry("atlas_fork", "ATLAS FORK", "Execution", new String[]{}),
    new Entry("free_mode", "FREE MODE", "Execution", new String[]{}),
    new Entry("fast_smart_mode", "FAST SMART MODE", "Execution", new String[]{}),
    new Entry("stream", "STREAM", "Execution", new String[]{"MESSAGE INGESTION MODE"}),
    new Entry("full_autonomous", "FULL AUTONOMOUS", "Execution", new String[]{}),
    new Entry("do_it", "DO IT", "Execution", new String[]{"HANDLE IT", "FIX IT", "KEEP GOING", "DO IT RIGHT"}),
    new Entry("atlas_next_move", "ATLAS NEXT MOVE", "Execution", new String[]{}),
    new Entry("atlas_lock_x", "ATLAS LOCK X", "Revision", new String[]{}),
    new Entry("keep_everything_the_same_except_x", "KEEP EVERYTHING THE SAME EXCEPT X", "Revision", new String[]{}),
    new Entry("atlas_no_regression", "ATLAS NO REGRESSION", "Revision", new String[]{}),
    new Entry("atlas_unlock_x", "ATLAS UNLOCK X", "Revision", new String[]{}),
    new Entry("atlas_private", "ATLAS PRIVATE", "Privacy", new String[]{}),
    new Entry("atlas_shaun_only", "ATLAS SHAUN-ONLY", "Privacy", new String[]{}),
    new Entry("atlas_dad_safe", "ATLAS DAD-SAFE", "Privacy", new String[]{}),
    new Entry("atlas_share_safe", "ATLAS SHARE-SAFE", "Privacy", new String[]{}),
    new Entry("atlas_public", "ATLAS PUBLIC", "Privacy", new String[]{}),
    new Entry("everything", "EVERYTHING", "Scope", new String[]{"EVERYTHING EVERYTHING EVERYTHING"}),
    new Entry("atlas_full_coverage", "ATLAS FULL COVERAGE", "Scope", new String[]{}),
    new Entry("atlas_red_button", "ATLAS RED BUTTON", "Recovery", new String[]{}),
    new Entry("atlas_lockdown", "ATLAS LOCKDOWN", "Recovery", new String[]{}),
    new Entry("atlas_red_button_lockdown", "ATLAS RED BUTTON + LOCKDOWN", "Recovery", new String[]{}),
    new Entry("atlas_sentinel", "ATLAS SENTINEL", "Recovery", new String[]{"SENTINEL"}),
    new Entry("atlas_blackout", "ATLAS BLACKOUT", "Recovery", new String[]{"BLACKOUT"}),
    new Entry("new_lead", "NEW LEAD", "Business", new String[]{}),
    new Entry("estimate_this", "ESTIMATE THIS", "Business", new String[]{"MAKE AN ESTIMATE"}),
    new Entry("price_this", "PRICE THIS", "Business", new String[]{}),
    new Entry("schedule_this", "SCHEDULE THIS", "Business", new String[]{}),
    new Entry("customer_reply", "CUSTOMER REPLY", "Business", new String[]{}),
    new Entry("website_mode", "WEBSITE MODE", "Build", new String[]{}),
    new Entry("website_forge", "WEBSITE FORGE", "Build", new String[]{"ATLAS WEBSITE FORGE"}),
    new Entry("conversion_mode", "CONVERSION MODE", "Build", new String[]{}),
    new Entry("design_mode", "DESIGN MODE", "Build", new String[]{}),
    new Entry("website_critic", "WEBSITE CRITIC", "Build", new String[]{}),
    new Entry("seo_forge", "SEO FORGE", "Build", new String[]{}),
    new Entry("mobile_forge", "MOBILE FORGE", "Build", new String[]{}),
    new Entry("atlas_app_hyper_forge", "ATLAS APP HYPER-FORGE", "Build", new String[]{}),
    new Entry("do_i_buy_it", "DO I BUY IT?", "Money", new String[]{}),
    new Entry("money_mode", "MONEY MODE", "Money", new String[]{}),
    new Entry("queue", "QUEUE", "Control", new String[]{}),
    new Entry("interrupt", "INTERRUPT", "Control", new String[]{}),
    new Entry("parallel", "PARALLEL", "Control", new String[]{}),
    new Entry("ask_first", "ASK FIRST", "Control", new String[]{}),
    new Entry("atlas_trust_broker", "ATLAS TRUST BROKER", "Control", new String[]{}),
    new Entry("atlas_intent_check", "ATLAS INTENT CHECK", "Control", new String[]{}),
    new Entry("atlas_understand_me", "ATLAS UNDERSTAND ME", "Calibration", new String[]{"ATLAS LEARN ME"}),
    new Entry("atlas_learn_this", "ATLAS LEARN THIS", "Calibration", new String[]{}),
    new Entry("atlas_in_my_voice", "ATLAS IN MY VOICE", "Calibration", new String[]{"MAKE IT SOUND LIKE ME"}),
    new Entry("atlas_max", "ATLAS MAX", "Quality", new String[]{"MAX THIS", "BEST POSSIBLE", "MAKE THIS 1 MILLION TIMES BETTER", "RED TEAM FORGE GOOGOL"}),
    new Entry("atlas_commandize", "ATLAS COMMANDIZE", "Control", new String[]{"MAKE THIS A COMMAND", "TURN THIS INTO A COMMAND", "SAVE THIS AS A COMMAND"}),
    new Entry("atlas_final_pass", "ATLAS FINAL PASS", "Quality", new String[]{"GO OVER IT AGAIN", "CHECK IT ONE MORE TIME", "BEAT THE LAST VERSION"}),
    new Entry("atlas_research", "ATLAS RESEARCH", "Evidence", new String[]{"RESEARCH THIS", "FIND THE REAL ANSWER", "CHECK EVERYTHING RELEVANT"}),
    new Entry("atlas_decide", "ATLAS DECIDE", "Decision", new String[]{"WHAT IS THE BEST MOVE?", "RUN THE CHESS MOVES", "TELL ME WHAT I SHOULD DO"}),
    new Entry("atlas_message_forge", "ATLAS MESSAGE FORGE", "Output", new String[]{"MAKE THIS MESSAGE BETTER", "WRITE THIS IN MY VOICE", "MAKE THIS HIT HARDER"}),
    new Entry("atlas_app_build", "ATLAS APP BUILD", "Build", new String[]{"BUILD THE APP", "FIX THE APP", "SHIP THE APP"})
  };
  private static final Map<String, Entry> BY_ID;
  private static final List<Entry> ALL;
  static {
    LinkedHashMap<String, Entry> map = new LinkedHashMap<String, Entry>();
    ArrayList<Entry> all = new ArrayList<Entry>();
    for (Entry e : DATA) { map.put(e.id, e); all.add(e); }
    BY_ID = Collections.unmodifiableMap(map);
    ALL = Collections.unmodifiableList(all);
    if (BY_ID.size() != TOTAL_ENTRIES) throw new IllegalStateException("catalog count mismatch");
  }

  private WorkflowCommandCatalog() {}
  public static Entry byId(String id) { return BY_ID.get(id); }
  public static List<Entry> all() { return ALL; }

  /** Exact or clause-start catalog lookup. Canonical names outrank overlapping aliases. */
  public static Entry exactOrAnchored(String raw) {
    String text = normalize(raw);
    if (text.isEmpty()) return null;
    for (Entry e : DATA) if (exact(text, e.canonical)) return e;
    for (Entry e : DATA) for (String alias : e.aliases) if (exact(text, alias)) return e;
    for (Entry e : DATA) if (anchored(text, e.canonical)) return e;
    for (Entry e : DATA) for (String alias : e.aliases) if (anchored(text, alias)) return e;
    return null;
  }

  private static boolean exact(String text, String candidate) {
    String c = normalize(candidate);
    return !c.isEmpty() && text.equals(c);
  }

  private static boolean anchored(String text, String candidate) {
    String c = normalize(candidate);
    return c.length() >= 7 && c.indexOf(' ') >= 0 && text.startsWith(c + " ");
  }

  public static String normalize(String raw) {
    if (raw == null) return "";
    String s = Normalizer.normalize(raw, Normalizer.Form.NFKC).toLowerCase(Locale.ROOT)
      .replace('’', (char)39).replace('‘', (char)39)
      .replace('“', (char)34).replace('”', (char)34)
      .replace('—', '-').replace('–', '-');
    return s.replaceAll("\\s+", " ").trim();
  }
}
