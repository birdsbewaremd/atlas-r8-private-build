package com.sbh.atlasos;

import java.text.Normalizer;
import java.util.Locale;

/** Compatibility normalization helper for one-shot speech plus the canonical strict wake policy. */
public final class VoiceCommandParser {
  private VoiceCommandParser() {}

  public static String normalize(String raw) {
    if (raw == null) return "";
    String s = Normalizer.normalize(raw, Normalizer.Form.NFKC).trim();
    s = s.replace('\u2018', '\'').replace('\u2019', '\'');
    return s.replaceAll("\\s+", " ");
  }

  public static boolean containsWakePhrase(String raw) {
    return WakePhrasePolicy.containsWakePhrase(raw);
  }

  public static String extractWakeCommand(String raw) {
    return WakePhrasePolicy.extractCommand(raw);
  }

  public static String lower(String raw) {
    return normalize(raw).toLowerCase(Locale.US);
  }
}
