package com.sbh.atlasos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Pure, bounded filtering of manually requested recent foreground-app events. No persistence. */
public final class AppAwarenessPolicy {
  public static final int MAX_MINUTES = 15;
  public static final int MAX_EVENTS = 2500;
  public static final int MAX_RESULTS = 12;
  private AppAwarenessPolicy() {}

  public static final class EventRow {
    public final String packageName;
    public final long timestampMs;
    public EventRow(String packageName, long timestampMs) {
      this.packageName = packageName;
      this.timestampMs = timestampMs;
    }
  }

  public static boolean isValidPackage(String value) {
    if (value == null || value.length() < 3 || value.length() > 150) return false;
    return value.matches("[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+");
  }

  public static List<String> recentPackages(List<EventRow> events, long nowMs,
      int minutes, String ownPackage) {
    if (events == null || events.size() > MAX_EVENTS || nowMs <= 0
        || minutes < 1 || minutes > MAX_MINUTES) return Collections.emptyList();
    long window = 60_000L * minutes;
    long from = Math.max(0L, nowMs - window);
    Map<String, Long> latest = new HashMap<>();
    for (EventRow row : events) {
      if (row == null || !isValidPackage(row.packageName)
          || row.packageName.equals(ownPackage) || row.timestampMs < from
          || row.timestampMs > nowMs) continue;
      Long prior = latest.get(row.packageName);
      if (prior == null || row.timestampMs > prior) latest.put(row.packageName, row.timestampMs);
    }
    List<Map.Entry<String, Long>> ordered = new ArrayList<>(latest.entrySet());
    ordered.sort(Comparator.<Map.Entry<String, Long>, Long>comparing(Map.Entry::getValue)
      .reversed().thenComparing(Map.Entry::getKey));
    List<String> out = new ArrayList<>();
    for (Map.Entry<String, Long> entry : ordered) {
      if (out.size() == MAX_RESULTS) break;
      out.add(entry.getKey());
    }
    return out;
  }
}
