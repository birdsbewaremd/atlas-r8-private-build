package com.sbh.atlasos;

/** Keeps spoken replies concise and strips artifacts that are useful on-screen but poor in TTS. */
public final class SpokenTextPolicy {
  private SpokenTextPolicy() {}

  public static String prepare(String raw) { return prepare(raw, 360, 2); }

  public static String prepare(String raw, int maxChars, int maxSentences) {
    if (raw == null) return "";
    String s = raw.trim();
    if (s.isEmpty()) return "";

    s = s.replaceAll("https?://\\S+", "");
    s = s.replaceAll("sandbox:/\\S+", "");
    s = s.replaceAll("\\s+", " ").trim();

    if (maxSentences > 0) {
      int sentences = 0;
      int cut = -1;
      for (int i = 0; i < s.length(); i++) {
        char ch = s.charAt(i);
        if (ch == '.' || ch == '!' || ch == '?') {
          sentences++;
          if (sentences >= maxSentences) { cut = i + 1; break; }
        }
      }
      if (cut > 0 && cut < s.length()) s = s.substring(0, cut).trim();
    }

    if (maxChars > 0 && s.length() > maxChars) {
      int cut = s.lastIndexOf(' ', maxChars - 1);
      if (cut < maxChars / 2) cut = maxChars - 1;
      s = s.substring(0, Math.max(1, cut)).trim();
      if (!s.endsWith(".") && !s.endsWith("!") && !s.endsWith("?")) s += ".";
    }
    return s;
  }
}
