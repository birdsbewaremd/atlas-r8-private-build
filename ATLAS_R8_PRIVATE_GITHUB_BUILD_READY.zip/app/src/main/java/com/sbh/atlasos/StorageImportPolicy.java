package com.sbh.atlasos;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Owner-selected, bounded text-document import. No path traversal, bulk storage,
 * deletion, app-wide file permissions, or unreviewed extension execution.
 * Pure Java so it can be exercised independently of Android/Keystore.
 */
public final class StorageImportPolicy {
  public static final long MAX_DOCUMENT_BYTES = 8L * 1024L * 1024L;
  public static final long MIN_FREE_HEADROOM_BYTES = 16L * 1024L * 1024L;
  private static final Set<String> TEXT_TYPES = new HashSet<>(Arrays.asList(
      "txt", "md", "json", "jsonl", "csv", "tsv", "log", "yaml", "yml"));
  private StorageImportPolicy() {}

  /** Never trust a provider-reported display name as a path. */
  public static String safeName(String reported) {
    if(reported==null)return null;
    String name=reported.trim();
    if(name.length()<3||name.length()>120||name.startsWith(".")||name.endsWith("."))return null;
    if(name.indexOf('/')>=0||name.indexOf('\\')>=0||name.indexOf(':')>=0)return null;
    if(name.contains(".."))return null;
    for(int i=0;i<name.length();i++){
      char c=name.charAt(i);
      if(Character.isISOControl(c)||Character.isSurrogate(c)||c=='<'||c=='>'||c=='|'||c=='*'||c=='?'||c=='"')return null;
    }
    int dot=name.lastIndexOf('.');
    if(dot<1||dot==name.length()-1||!TEXT_TYPES.contains(name.substring(dot+1).toLowerCase(Locale.ROOT)))return null;
    return name;
  }

  public static boolean declaredSizeAllowed(long size) { return size>=-1 && size<=MAX_DOCUMENT_BYTES; }
  public static boolean freeSpaceSafe(long availableBytes,long declaredBytes) {
    if(availableBytes<0||!declaredSizeAllowed(declaredBytes))return false;
    // Unknown provider size gets the full bounded import allowance.
    long reserve=declaredBytes<0?MAX_DOCUMENT_BYTES:declaredBytes;
    return availableBytes>=reserve+MIN_FREE_HEADROOM_BYTES;
  }
}
