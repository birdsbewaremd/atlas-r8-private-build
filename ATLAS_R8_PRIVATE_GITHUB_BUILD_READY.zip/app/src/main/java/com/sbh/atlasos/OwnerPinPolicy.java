package com.sbh.atlasos;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Pure-Java owner PIN policy shared by Android auth and source tests. */
public final class OwnerPinPolicy {
  public static final int ITERATIONS = 250000;
  public static final int SALT_BYTES = 16;
  public static final int KEY_BITS = 256;
  private OwnerPinPolicy() {}

  public static boolean validPin(String pin) {
    if (pin == null || pin.length() != 6) return false;
    for (int i = 0; i < pin.length(); i++) {
      char c = pin.charAt(i);
      if (c < '0' || c > '9') return false;
    }
    return true;
  }

  public static byte[] derive(String pin, byte[] salt) throws GeneralSecurityException {
    if (!validPin(pin)) throw new GeneralSecurityException("invalid pin");
    if (salt == null || salt.length != SALT_BYTES) throw new GeneralSecurityException("invalid salt");
    PBEKeySpec spec = new PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, KEY_BITS);
    try {
      return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
    } finally {
      spec.clearPassword();
    }
  }

  public static boolean constantTimeEquals(byte[] a, byte[] b) {
    return a != null && b != null && MessageDigest.isEqual(a, b);
  }

  public static long lockoutMillisForFailures(int failures) {
    if (failures < 5) return 0L;
    if (failures == 5) return 30_000L;
    if (failures == 6) return 60_000L;
    if (failures == 7) return 120_000L;
    if (failures == 8) return 300_000L;
    if (failures == 9) return 900_000L;
    return 3_600_000L;
  }
}
