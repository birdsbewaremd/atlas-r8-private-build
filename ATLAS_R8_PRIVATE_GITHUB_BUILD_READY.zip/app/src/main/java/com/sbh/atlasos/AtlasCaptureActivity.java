package com.sbh.atlasos;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

/** Narrow, one-use owner handoff for screen consent, private playback, or confirmed deletion. */
public final class AtlasCaptureActivity extends Activity {
    private static final String ACTION_SESSION = "com.sbh.atlasos.capture.DISCLOSE";
    private static final String ACTION_PLAYBACK = "com.sbh.atlasos.capture.PLAYBACK";
    private static final String ACTION_DELETE = "com.sbh.atlasos.capture.DELETE";
    private static final String EXTRA_LAUNCH = "capture_launch_ticket", EXTRA_ID = "capture_clip_id";
    private static final int REQUEST_CAPTURE = 6402, REQUEST_NOTIFICATIONS = 6403;
    private static final AtlasCaptureStore.LaunchTokens launches = new AtlasCaptureStore.LaunchTokens();
    private static final AtlasCaptureStore.LaunchTokens serviceTickets = new AtlasCaptureStore.LaunchTokens();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private volatile boolean authorized, resumed;
    private boolean receiverRegistered, consentPending, notificationPending, permissionReady, workStarted;
    private long launchDeadline, consentStarted, playbackDeadline;
    private String action, clipId;
    private LinearLayout content;
    private TextView status, expiry;
    private Button startButton;
    private VideoView video;
    private volatile File playbackFile;
    private Thread privateWorker;
    private AlertDialog deleteDialog;

    /** Called only from the current owner login; pausing MainActivity may then revoke that login. */
    public static Intent createSessionIntent(Context context) {
        return authorizedIntent(context, ACTION_SESSION, null);
    }

    public static Intent createPlaybackIntent(Context context, String id) {
        return authorizedIntent(context, ACTION_PLAYBACK, id);
    }

    public static Intent createDeleteIntent(Context context, String id) {
        return authorizedIntent(context, ACTION_DELETE, id);
    }

    private static Intent authorizedIntent(Context context, String action, String id) {
        if (!OwnerSessionGate.isActive(context)) throw new SecurityException("Unlock ATLAS first");
        if (!ACTION_SESSION.equals(action) && !AtlasCaptureStore.isValidId(id))
            throw new IllegalArgumentException("Invalid recording identifier");
        String scope = scope(action, id);
        String ticket = launches.issue(scope, SystemClock.elapsedRealtime(), AtlasCaptureStore.LAUNCH_WINDOW_MS);
        Intent intent = new Intent(context, AtlasCaptureActivity.class).setAction(action)
                .putExtra(EXTRA_LAUNCH, ticket);
        if (id != null) intent.putExtra(EXTRA_ID, id);
        return intent;
    }

    private static String scope(String action, String id) { return action + ":" + (id == null ? "" : id); }

    static boolean consumeServiceTicket(String ticket) {
        return serviceTickets.consume(ticket, "single-consented-recording", SystemClock.elapsedRealtime()) != 0L;
    }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        // Recreating an Activity never restores a capture authority or private playback.
        if (saved != null || getIntent() == null) { finish(); return; }
        action = getIntent().getAction(); clipId = getIntent().getStringExtra(EXTRA_ID);
        if (!ACTION_SESSION.equals(action) && !ACTION_PLAYBACK.equals(action) && !ACTION_DELETE.equals(action)) {
            finish(); return;
        }
        if (!ACTION_SESSION.equals(action) && !AtlasCaptureStore.isValidId(clipId)) { finish(); return; }
        launchDeadline = launches.consume(getIntent().getStringExtra(EXTRA_LAUNCH), scope(action, clipId),
                SystemClock.elapsedRealtime());
        // Remove consumed launch material; none is persisted in savedInstanceState.
        getIntent().removeExtra(EXTRA_LAUNCH);
        if (launchDeadline == 0L || !AtlasCaptureService.screenUsable(this)) { finish(); return; }
        authorized = true;
        if (ACTION_PLAYBACK.equals(action)) playbackDeadline = SystemClock.elapsedRealtime() + AtlasCaptureStore.PLAYBACK_WINDOW_MS;
        makeLayout();
        IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenOff, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(screenOff, filter);
        receiverRegistered = true;
        if (ACTION_SESSION.equals(action)) showDisclosure();
        else if (ACTION_PLAYBACK.equals(action)) {
            heading("PRIVATE SCREEN RECORDING");
            status = note("Opening the selected encrypted clip…");
            note("Playback closes when you leave this view or lock the device. The temporary playback copy is then removed.");
            closeButton();
        } else {
            heading("REMOVE A SCREEN RECORDING");
            status = note("Checking the selected recording…");
            note("Only the selected local screen recording can be removed. You will confirm its date and duration first.");
            closeButton();
        }
    }

    private void makeLayout() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundColor(Color.rgb(12, 9, 23));
        int horizontal = dp(20), vertical = dp(18);
        content.setPadding(horizontal, vertical, horizontal, dp(28));
        scroll.addView(content);
        scroll.setOnApplyWindowInsetsListener((view, insets) -> {
            content.setPadding(horizontal + insets.getSystemWindowInsetLeft(),
                    vertical + insets.getSystemWindowInsetTop(),
                    horizontal + insets.getSystemWindowInsetRight(), dp(28) + insets.getSystemWindowInsetBottom());
            return insets;
        });
        setContentView(scroll);
    }

    private void showDisclosure() {
        heading("LOCAL SCREEN SESSION");
        note("Android will ask what to share. An entire-screen recording can include other visible apps and notification content. On supported devices you can choose one app instead.");
        note("Video only: no microphone, device audio, accessibility reading, or key logging. Android-protected screens, including ATLAS private views, remain protected and may appear blank.");
        note("Each session ends after at most 10 minutes or 100 MB, and sooner if storage is low. The complete encrypted recording archive is limited to 250 MB. Earlier clips are kept until you explicitly remove a selected recording.");
        note("A private temporary video is needed while recording. When stopped, ATLAS encrypts the completed clip on this phone and removes that temporary file. A failed or interrupted session can be lost. Nothing is uploaded or sent to another app.");
        note("Use the visible Stop notification or lock/turn off the screen to stop. Android can also stop sharing. Recording never restarts automatically. Rotation or a different app size may produce black bars.");
        status = note(AtlasCaptureService.isBusy()
                ? "A session is already running or being saved. Stop it and wait for saving to finish before creating another."
                : "Starting a full 100 MB session requires about 220 MB of free private storage. A nearly full archive allows a smaller recording.");
        expiry = note("");
        startButton = button("Start a screen session", this::startRequested);
        startButton.setEnabled(!AtlasCaptureService.isBusy());
        button("Open notification settings", () -> {
            if (!usable()) return;
            try { startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName())); }
            catch (RuntimeException unavailable) { Toast.makeText(this, "Notification settings are unavailable", Toast.LENGTH_SHORT).show(); }
            finish();
        });
        closeButton();
    }

    private void startRequested() {
        if (!usable() || SystemClock.elapsedRealtime() >= launchDeadline || consentPending || notificationPending) {
            expire("This Start authorization expired. Reopen Screen Session from unlocked ATLAS."); return;
        }
        if (AtlasCaptureService.isBusy()) { status.setText("Another session is active or being saved."); return; }
        AtlasCaptureService.ensureNotificationChannel(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            notificationPending = true;
            status.setText("Allow notifications so the recording has a visible Stop control. If denied, recording will not start.");
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
            return;
        }
        beginConsent();
    }

    private void beginConsent() {
        if (!usable() || SystemClock.elapsedRealtime() >= launchDeadline) {
            expire("Start authorization expired. Reopen this view from unlocked ATLAS."); return;
        }
        if (!AtlasCaptureService.notificationsAvailable(this)) {
            status.setText("Recording needs an enabled screen-recording notification with a Stop control. Enable it in notification settings, then reopen this view from unlocked ATLAS.");
            return;
        }
        try {
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            if (manager == null) throw new IllegalStateException("Screen sharing unavailable");
            consentPending = true; consentStarted = SystemClock.elapsedRealtime();
            startButton.setEnabled(false);
            status.setText("Waiting for your Android screen-sharing choice. Cancelling makes no recording.");
            startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
        } catch (RuntimeException unavailable) {
            consentPending = false;
            status.setText("Android screen sharing is unavailable. No recording was started.");
        }
    }

    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(request, permissions, grants);
        if (request != REQUEST_NOTIFICATIONS) return;
        boolean expected = notificationPending; notificationPending = false;
        if (!expected || !authorized || !AtlasCaptureService.screenUsable(this)
                || SystemClock.elapsedRealtime() >= launchDeadline) {
            expire("Start authorization expired. Reopen this view from unlocked ATLAS."); return;
        }
        if (grants.length == 0 || grants[0] != PackageManager.PERMISSION_GRANTED) {
            status.setText("Notifications were not allowed, so recording did not start. Enable notifications in Settings, then reopen this view from unlocked ATLAS to try again.");
            return;
        }
        if (resumed) beginConsent();
        else permissionReady = true;
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != REQUEST_CAPTURE) return;
        long now = SystemClock.elapsedRealtime();
        boolean valid = authorized && consentPending && now >= consentStarted
                && now - consentStarted < AtlasCaptureStore.CONSENT_WINDOW_MS
                && AtlasCaptureService.screenUsable(this);
        consentPending = false;
        if (!valid) { expire("Screen-sharing authorization ended. No recording was started."); return; }
        if (result != RESULT_OK || data == null) {
            authorized = false;
            status.setText("Screen sharing was cancelled. No recording was started. Reopen from unlocked ATLAS for a new session.");
            return;
        }
        if (!AtlasCaptureService.notificationsAvailable(this) || AtlasCaptureService.isBusy()) {
            expire("Recording did not start: the notification is unavailable or another session is active."); return;
        }
        String ticket = serviceTickets.issue("single-consented-recording", now, 10_000L);
        Intent service = new Intent(this, AtlasCaptureService.class).setAction(AtlasCaptureService.ACTION_START)
                .putExtra(AtlasCaptureService.EXTRA_TICKET, ticket)
                .putExtra(AtlasCaptureService.EXTRA_RESULT, result)
                .putExtra(AtlasCaptureService.EXTRA_DATA, data);
        authorized = false;
        try {
            startForegroundService(service);
            Toast.makeText(this, "Screen session requested. Check its Stop notification.", Toast.LENGTH_LONG).show();
        } catch (RuntimeException unavailable) {
            serviceTickets.clear();
            Toast.makeText(this, "Android could not start screen recording", Toast.LENGTH_LONG).show();
        }
        finish();
    }

    private void openPlayback() {
        if (workStarted || !privateAccess()) return;
        workStarted = true;
        privateWorker = new Thread(() -> {
            File file = null;
            try {
                AtlasCaptureStore.Clip metadata = AtlasCaptureStore.metadata(this, clipId);
                file = AtlasCaptureStore.decryptForPlayback(this, clipId, this::privateAccess);
                final File ready = file;
                handler.post(() -> {
                    if (!privateAccess()) { AtlasCaptureStore.deleteTemporary(ready); return; }
                    playbackFile = ready;
                    status.setText(label(metadata));
                    video = new VideoView(this); video.setSecure(true);
                    content.addView(video, Math.max(0, content.getChildCount() - 1),
                            new LinearLayout.LayoutParams(-1, dp(360)));
                    MediaController controls = new MediaController(this);
                    controls.setAnchorView(video); video.setMediaController(controls);
                    video.setOnPreparedListener(player -> {
                        if (privateAccess()) video.start(); else closePrivateView();
                    });
                    video.setOnCompletionListener(player -> { closePrivateView(); finish(); });
                    video.setOnErrorListener((player, what, extra) -> {
                        Toast.makeText(this, "This recording could not be played", Toast.LENGTH_LONG).show();
                        closePrivateView(); finish(); return true;
                    });
                    video.setVideoPath(ready.getAbsolutePath());
                });
                file = null; // UI owns cleanup, including a result arriving after onPause.
            } catch (Exception unavailable) {
                handler.post(() -> {
                    if (privateAccess()) status.setText("The selected recording is unavailable or could not be authenticated. Its encrypted original has been preserved.");
                });
            } finally { AtlasCaptureStore.deleteTemporary(file); }
        }, "atlas-private-recording-playback");
        privateWorker.start();
    }

    private void confirmDeletion() {
        if (workStarted || !privateAccess()) return;
        workStarted = true;
        privateWorker = new Thread(() -> {
            try {
                AtlasCaptureStore.Clip metadata = AtlasCaptureStore.metadata(this, clipId);
                handler.post(() -> {
                    if (!privateAccess()) return;
                    status.setText(label(metadata));
                    deleteDialog = new AlertDialog.Builder(this)
                            .setTitle("Delete this screen recording?")
                            .setMessage(label(metadata) + "\n\nThis permanently removes only this selected clip from this phone. It cannot be undone. Other recordings remain saved.")
                            .setNegativeButton("Keep recording", (dialog, which) -> finish())
                            .setPositiveButton("Delete selected clip", (dialog, which) -> deleteSelected())
                            .setOnCancelListener(dialog -> finish()).create();
                    deleteDialog.setOnShowListener(dialog -> {
                        if (deleteDialog.getWindow() != null)
                            deleteDialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
                    });
                    deleteDialog.show();
                });
            } catch (Exception unavailable) {
                handler.post(() -> {
                    if (privateAccess()) status.setText("This selected recording could not be authenticated. Nothing was removed.");
                });
            }
        }, "atlas-selected-recording-review");
        privateWorker.start();
    }

    private void deleteSelected() {
        if (!privateAccess()) { expire("Delete authorization expired. Reopen the selected recording from unlocked ATLAS."); return; }
        status.setText("Removing the selected recording…");
        privateWorker = new Thread(() -> {
            boolean deleted = false;
            try { AtlasCaptureStore.deleteClip(this, clipId, this::privateAccess); deleted = true; }
            catch (Exception unavailable) { /* Report failure without changing any other clip. */ }
            final boolean removed = deleted;
            handler.post(() -> {
                if (!isFinishing() && !isDestroyed()) {
                    Toast.makeText(this, removed ? "Selected screen recording deleted" : "Recording was not deleted", Toast.LENGTH_LONG).show();
                    finish();
                }
            });
        }, "atlas-selected-recording-delete");
        privateWorker.start();
    }

    private boolean usable() {
        return authorized && resumed && !isFinishing() && !isDestroyed()
                && AtlasCaptureService.screenUsable(this);
    }

    private boolean privateAccess() {
        long deadline = ACTION_PLAYBACK.equals(action) ? playbackDeadline : launchDeadline;
        return usable() && SystemClock.elapsedRealtime() < deadline;
    }

    private final BroadcastReceiver screenOff = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) {
                launches.clear(); serviceTickets.clear();
                closePrivateView(); finish();
            }
        }
    };

    private final Runnable watch = new Runnable() {
        @Override public void run() {
            if (isFinishing() || isDestroyed()) return;
            if (!AtlasCaptureService.screenUsable(AtlasCaptureActivity.this)) { closePrivateView(); finish(); return; }
            long now = SystemClock.elapsedRealtime();
            if (ACTION_SESSION.equals(action)) {
                if (consentPending && (now < consentStarted || now - consentStarted >= AtlasCaptureStore.CONSENT_WINDOW_MS)) {
                    expire("Android screen-sharing consent timed out. Reopen from unlocked ATLAS to try again."); finish(); return;
                }
                if (!consentPending && now >= launchDeadline && authorized) {
                    expire("Start authorization expired. Reopen Screen Session from unlocked ATLAS.");
                    if (notificationPending) finish();
                }
                if (expiry != null) expiry.setText(consentPending ? "Waiting for Android consent (up to 2 minutes)."
                        : "Start authorization: " + Math.max(0L, (launchDeadline - now + 999L) / 1000L) + " seconds remaining.");
            } else if (!privateAccess()) { closePrivateView(); finish(); return; }
            handler.postDelayed(this, 500L);
        }
    };

    @Override protected void onResume() {
        super.onResume(); resumed = true;
        if (!authorized || !AtlasCaptureService.screenUsable(this)) { finish(); return; }
        handler.removeCallbacks(watch); handler.post(watch);
        if (permissionReady) { permissionReady = false; beginConsent(); }
        if (ACTION_PLAYBACK.equals(action)) openPlayback();
        if (ACTION_DELETE.equals(action)) confirmDeletion();
    }

    @Override protected void onPause() {
        resumed = false;
        // Only the explicitly pending OS permission UI may retain narrow capture authority.
        if (!ACTION_SESSION.equals(action) || (!consentPending && !notificationPending)) {
            closePrivateView();
            if (!isFinishing()) finish();
        }
        super.onPause();
    }

    private void expire(String detail) {
        authorized = false; permissionReady = false;
        if (startButton != null) startButton.setEnabled(false);
        if (status != null) status.setText(detail);
        if (deleteDialog != null) deleteDialog.dismiss();
    }

    private void closePrivateView() {
        authorized = false; consentPending = false; notificationPending = false; permissionReady = false;
        if (privateWorker != null) privateWorker.interrupt();
        if (video != null) { try { video.stopPlayback(); } catch (RuntimeException ignored) { } video = null; }
        if (deleteDialog != null) { deleteDialog.dismiss(); deleteDialog = null; }
        AtlasCaptureStore.deleteTemporary(playbackFile); playbackFile = null;
    }

    @Override protected void onDestroy() {
        closePrivateView(); handler.removeCallbacks(watch);
        if (receiverRegistered) {
            try { unregisterReceiver(screenOff); } catch (RuntimeException ignored) { }
            receiverRegistered = false;
        }
        super.onDestroy();
    }

    private String label(AtlasCaptureStore.Clip clip) {
        return DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(new Date(clip.createdAtMs))
                + "\n" + String.format(Locale.US, "%d:%02d", clip.durationMs / 60_000L, (clip.durationMs / 1000L) % 60L)
                + " · " + String.format(Locale.US, "%.1f MB", clip.bytes / 1_000_000.0);
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private void heading(String text) { TextView title = note(text); title.setTextSize(24); title.setTextColor(Color.WHITE); }
    private TextView note(String text) {
        TextView label = new TextView(this); label.setText(text); label.setTextSize(15);
        label.setTextColor(Color.rgb(218, 212, 232)); label.setPadding(0, dp(8), 0, dp(12));
        content.addView(label); return label;
    }
    private Button button(String text, Runnable action) {
        Button button = new Button(this); button.setAllCaps(false); button.setText(text);
        button.setMinHeight(dp(52)); button.setOnClickListener(view -> action.run());
        content.addView(button, new LinearLayout.LayoutParams(-1, -2)); return button;
    }
    private void closeButton() { button("Close", this::finish); }
}
