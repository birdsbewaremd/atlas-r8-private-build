package com.sbh.atlasos;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Authenticated bounded envelope; caller supplies an Android Keystore key on device. */
public final class LearningCipher {
  private static final byte[] AAD="atlas-human-learning-v1".getBytes(StandardCharsets.UTF_8);
  private LearningCipher(){}
  public static byte[] encrypt(byte[] plain,SecretKey key)throws Exception{
    if(plain.length>HumanLearningEngine.MAX_BYTES)throw new IllegalArgumentException("record limit");
    Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key);c.updateAAD(AAD);
    byte[] iv=c.getIV(),cipher=c.doFinal(plain);if(iv.length!=12)throw new IllegalStateException("unexpected nonce size");
    return ByteBuffer.allocate(4+iv.length+cipher.length).putInt(0x484c4531).put(iv).put(cipher).array();
  }
  public static byte[] decrypt(byte[] blob,SecretKey key)throws Exception{
    if(blob.length<32||blob.length>HumanLearningEngine.MAX_BYTES+32)throw new IllegalArgumentException("envelope limit");
    ByteBuffer b=ByteBuffer.wrap(blob);if(b.getInt()!=0x484c4531)throw new IllegalArgumentException("envelope version");
    byte[] iv=new byte[12],cipher=new byte[b.remaining()-12];b.get(iv);b.get(cipher);
    Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,iv));c.updateAAD(AAD);return c.doFinal(cipher);
  }
}
