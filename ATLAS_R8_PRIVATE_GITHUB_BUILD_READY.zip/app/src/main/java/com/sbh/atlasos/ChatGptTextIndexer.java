package com.sbh.atlasos;

import android.util.JsonReader;
import android.util.JsonToken;
import java.io.*;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Derived, bounded readable text from a ChatGPT conversations.json export.
 * The original export is retained separately. All branches are included and
 * sorted by message timestamp, then source order; this is not a claim that the
 * export's branches form one linear conversation. Only encrypted output is
 * written to disk, and nothing is published until the complete input is read.
 */
public final class ChatGptTextIndexer {
  private static final int MAX_CONVERSATIONS=4000,MAX_MESSAGES=4000;
  private static final int MAX_CONVERSATION_CHARS=2*1024*1024,MAX_STRING_CHARS=128*1024;
  private static final int CHUNK_CHARS=48000,MAX_FILES=4500;
  public static final class Result {
    public final int files,conversations,messages,nonTextParts;
    public final String directory;
    Result(int f,int c,int m,int n,String d){files=f;conversations=c;messages=m;nonTextParts=n;directory=d;}
  }
  private static final class Message {
    String id="",node="",parent="",role="unknown",text="";
    double time=Double.POSITIVE_INFINITY;
    int order,nonText;boolean present;
  }
  private static final class Conversation {
    String id="",title="Untitled conversation",created="",updated="";
    final List<Message> messages=new ArrayList<>();
    int textChars;boolean mappingSeen;
  }
  private ChatGptTextIndexer(){}

  public static Result index(InputStream source,File privateRoot,File vault,
      TransactionalSeedImporter.EncryptedWriter writer,TransactionalSeedImporter.Authorization auth)throws Exception{
    if(!auth.allowed())throw new IOException("locked");
    Path parent=privateRoot.toPath().toAbsolutePath().normalize(),target=vault.toPath().toAbsolutePath().normalize();
    if(!target.getParent().equals(parent)||Files.isSymbolicLink(parent)||Files.isSymbolicLink(target))throw new IOException("unsafe root");
    Path staged=Files.createTempDirectory(parent,".atlas-chat-index-");
    Path reserved=null;boolean committed=false;
    int files=0,conversations=0,messages=0,nonText=0;
    try{
      Reader utf8=new InputStreamReader(source,StandardCharsets.UTF_8.newDecoder()
        .onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT));
      try(JsonReader reader=new JsonReader(new TokenLimitReader(utf8,auth))){
        reader.setLenient(false);reader.beginArray();
        while(reader.hasNext()){
          if(!auth.allowed())throw new IOException("locked");
          if(++conversations>MAX_CONVERSATIONS)throw new IOException("conversation count limit");
          Conversation conversation=readConversation(reader);
          Collections.sort(conversation.messages,(a,b)->{
            int order=Double.compare(a.time,b.time);return order!=0?order:Integer.compare(a.order,b.order);
          });
          StringBuilder text=new StringBuilder();
          text.append("# ").append(conversation.title).append("\n\n")
            .append("Source: ChatGPT export conversations.json; original retained unchanged.\n")
            .append("Conversation ID: ").append(conversation.id).append("\n")
            .append("Created (source timestamp): ").append(conversation.created).append("\n")
            .append("Updated (source timestamp): ").append(conversation.updated).append("\n")
            .append("Includes all exported message branches, sorted by timestamp then source order.\n")
            .append("Text below is decoded verbatim from exported text parts. Non-text parts remain in the original export.\n\n");
          for(Message message:conversation.messages){
            messages++;nonText+=message.nonText;
            text.append("\n---\nRole: ").append(message.role).append("\nMessage ID: ").append(message.id)
              .append("\nNode: ").append(message.node).append("\nParent node: ").append(message.parent)
              .append("\nSource timestamp: ").append(Double.isFinite(message.time)?String.valueOf(message.time):"not provided")
              .append("\nNon-text parts retained in original: ").append(message.nonText).append("\n\n")
              .append(message.text).append("\n");
          }
          if(conversation.messages.isEmpty())text.append("No message records in this exported conversation.\n");
          int offset=0,part=0;
          while(offset<text.length()){
            if(++files>MAX_FILES)throw new IOException("index file limit");
            int end=Math.min(text.length(),offset+CHUNK_CHARS);
            if(end<text.length()&&Character.isHighSurrogate(text.charAt(end-1)))end--;
            String chunk="[Derived conversation "+conversations+", part "+(++part)+"]\n"+text.substring(offset,end);
            java.nio.ByteBuffer encoded=StandardCharsets.UTF_8.newEncoder()
              .onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
              .encode(java.nio.CharBuffer.wrap(chunk));
            byte[] bytes=new byte[encoded.remaining()];encoded.get(bytes);
            if(bytes.length>VaultSearchReader.MAX_TEXT_BYTES)throw new IOException("index chunk limit");
            File out=staged.resolve(String.format(Locale.ROOT,"chat-%05d-part-%03d.txt",conversations,part)).toFile();
            try{writer.write(new ByteArrayInputStream(bytes),new File(out.getPath()+".atlasenc"),VaultSearchReader.MAX_TEXT_BYTES);}
            finally{Arrays.fill(bytes,(byte)0);}
            offset=end;
          }
        }
        reader.endArray();
        // Reading EOF also forces authentication of a CipherInputStream source
        // before the staged derived text can become visible.
        if(reader.peek()!=JsonToken.END_DOCUMENT)throw new IOException("trailing JSON");
      }
      if(!auth.allowed())throw new IOException("locked before commit");
      reserved=Files.createTempDirectory(target,"chatgpt-index-");
      Files.move(staged,reserved.resolve("files"),StandardCopyOption.ATOMIC_MOVE);
      committed=true;
      return new Result(files,conversations,messages,nonText,reserved.getFileName()+"/files");
    }finally{
      if(!committed){
        if(Files.exists(staged))Files.walkFileTree(staged,new SimpleFileVisitor<Path>(){
          @Override public FileVisitResult visitFile(Path file,java.nio.file.attribute.BasicFileAttributes attributes)throws IOException{Files.delete(file);return FileVisitResult.CONTINUE;}
          @Override public FileVisitResult postVisitDirectory(Path directory,IOException error)throws IOException{if(error!=null)throw error;Files.delete(directory);return FileVisitResult.CONTINUE;}
        });
        if(reserved!=null)Files.deleteIfExists(reserved);
      }
    }
  }

  private static Conversation readConversation(JsonReader r)throws IOException{
    Conversation c=new Conversation();r.beginObject();
    while(r.hasNext()){
      String key=r.nextName();
      if("id".equals(key)||"conversation_id".equals(key))c.id=scalar(r,512);
      else if("title".equals(key))c.title=scalar(r,2000);
      else if("create_time".equals(key))c.created=scalar(r,128);
      else if("update_time".equals(key))c.updated=scalar(r,128);
      else if("mapping".equals(key)&&r.peek()==JsonToken.BEGIN_OBJECT){
        c.mappingSeen=true;r.beginObject();int order=0;
        while(r.hasNext()){
          String node=r.nextName();if(node.length()>512)throw new IOException("node id limit");
          Message m=readNode(r);m.node=node;m.order=order++;
          if(m.present){
            if(c.messages.size()>=MAX_MESSAGES)throw new IOException("message count limit");
            c.textChars+=m.text.length();if(c.textChars>MAX_CONVERSATION_CHARS)throw new IOException("conversation text limit");
            c.messages.add(m);
          }
          if(order>MAX_MESSAGES*2)throw new IOException("node count limit");
        }r.endObject();
      }else r.skipValue();
    }r.endObject();if(!c.mappingSeen)throw new IOException("unsupported conversation layout");return c;
  }
  private static Message readNode(JsonReader r)throws IOException{
    Message m=new Message();
    if(r.peek()!=JsonToken.BEGIN_OBJECT){r.skipValue();return m;}
    r.beginObject();while(r.hasNext()){
      String key=r.nextName();
      if("parent".equals(key))m.parent=scalar(r,512);
      else if("message".equals(key)&&r.peek()==JsonToken.BEGIN_OBJECT)readMessage(r,m);
      else r.skipValue();
    }r.endObject();return m;
  }
  private static void readMessage(JsonReader r,Message m)throws IOException{
    m.present=true;r.beginObject();while(r.hasNext()){
      String key=r.nextName();
      if("id".equals(key))m.id=scalar(r,512);
      else if("create_time".equals(key)){
        String time=scalar(r,128);try{double value=Double.parseDouble(time);if(Double.isFinite(value))m.time=value;}catch(NumberFormatException ignored){}
      }else if("author".equals(key)&&r.peek()==JsonToken.BEGIN_OBJECT){
        r.beginObject();while(r.hasNext()){String field=r.nextName();if("role".equals(field))m.role=scalar(r,100);else r.skipValue();}r.endObject();
      }else if("content".equals(key)&&r.peek()==JsonToken.BEGIN_OBJECT)readContent(r,m);
      else r.skipValue();
    }r.endObject();
  }
  private static void readContent(JsonReader r,Message m)throws IOException{
    StringBuilder text=new StringBuilder();boolean representation=false;r.beginObject();
    while(r.hasNext()){
      String key=r.nextName();
      if("parts".equals(key)&&r.peek()==JsonToken.BEGIN_ARRAY){
        representation=true;r.beginArray();int parts=0;
        while(r.hasNext()){
          if(++parts>10000)throw new IOException("content part count limit");
          if(r.peek()==JsonToken.STRING)appendText(text,r.nextString());
          else if(r.peek()==JsonToken.BEGIN_OBJECT){
            boolean found=false;r.beginObject();
            while(r.hasNext()){String field=r.nextName();if("text".equals(field)&&r.peek()==JsonToken.STRING){appendText(text,r.nextString());found=true;}else r.skipValue();}
            r.endObject();if(!found)m.nonText++;
          }else{r.skipValue();m.nonText++;}
        }r.endArray();
      }else if("text".equals(key)&&r.peek()==JsonToken.STRING){representation=true;appendText(text,r.nextString());}
      else r.skipValue();
    }r.endObject();if(!representation)m.nonText++;m.text=text.toString();
  }
  private static void appendText(StringBuilder out,String text)throws IOException{
    if(out.length()+text.length()+2>MAX_CONVERSATION_CHARS)throw new IOException("message text limit");
    if(out.length()>0)out.append("\n\n");out.append(text);
  }
  private static String scalar(JsonReader r,int limit)throws IOException{
    if(r.peek()==JsonToken.NULL){r.nextNull();return "";}
    if(r.peek()!=JsonToken.STRING&&r.peek()!=JsonToken.NUMBER){r.skipValue();return "";}
    String value=r.nextString();if(value.length()>limit)throw new IOException("metadata limit");return value;
  }

  /** Bound JSON string tokens and nesting before JsonReader can allocate an
   * arbitrarily large token, including unknown values that it skips. */
  private static final class TokenLimitReader extends FilterReader {
    private final TransactionalSeedImporter.Authorization auth;
    private boolean string,escape;private int token,depth,bare;private long count;
    TokenLimitReader(Reader source,TransactionalSeedImporter.Authorization auth){super(source);this.auth=auth;}
    private void inspect(char c)throws IOException{
      if(++count>SeedImportPolicy.MAX_FILE_BYTES)throw new IOException("JSON character limit");
      if(string){
        if(++token>MAX_STRING_CHARS)throw new IOException("JSON string limit");
        if(escape){escape=false;return;}if(c=='\\'){escape=true;return;}if(c=='"'){string=false;token=0;}return;
      }
      if(c=='"'){string=true;token=0;bare=0;return;}
      if(c=='{'||c=='['){if(++depth>64)throw new IOException("JSON depth limit");bare=0;}
      else if(c=='}'||c==']'){if(--depth<0)throw new IOException("JSON depth invalid");bare=0;}
      else if(c==','||c==':'||Character.isWhitespace(c))bare=0;
      else if(++bare>128)throw new IOException("JSON scalar limit");
    }
    @Override public int read(char[] chars,int offset,int length)throws IOException{
      if(!auth.allowed())throw new IOException("locked");int read=super.read(chars,offset,Math.min(length,8192));
      for(int i=0;i<read;i++)inspect(chars[offset+i]);return read;
    }
    @Override public int read()throws IOException{char[] one=new char[1];return read(one,0,1)<0?-1:one[0];}
  }
}
