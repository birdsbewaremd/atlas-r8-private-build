package com.sbh.atlasos;

import java.util.List;

/** Pure, conservative math over observed battery readings. Never predicts an ETA. */
public final class BatteryTrend {
  public static final long MIN_OBSERVED_MS = 15L * 60L * 1000L;
  public static final long MAX_GAP_MS = 45L * 60L * 1000L;
  public static final long MAX_WINDOW_MS = 6L * 60L * 60L * 1000L;
  public static final int MAX_SAMPLES = 2048;

  private BatteryTrend() {}

  public static final class Sample {
    public final long atMs;
    public final int level;
    public final boolean charging;
    public final String plug;
    /** A new opt-in period starts a new segment even when its gap is short. */
    public final String segment;

    public Sample(long atMs, int level, boolean charging, String plug) {
      this(atMs, level, charging, plug, "default");
    }

    public Sample(long atMs, int level, boolean charging, String plug, String segment) {
      this.atMs = atMs;
      this.level = level;
      this.charging = charging;
      this.plug = plug;
      this.segment = segment;
    }
  }

  public static final class Result {
    public final String status;
    /** Signed percentage points per hour, or null when evidence is insufficient. */
    public final Double ratePerHour;
    public final double observedMinutes;
    public final String direction;
    public final int samplesUsed;
    public final long fromAtMs;
    public final long toAtMs;

    private Result(String status, Double rate, double minutes, String direction,
        int count, long from, long to) {
      this.status = status;
      this.ratePerHour = rate;
      this.observedMinutes = minutes;
      this.direction = direction;
      this.samplesUsed = count;
      this.fromAtMs = from;
      this.toAtMs = to;
    }
  }

  public static boolean valid(Sample s) {
    return s != null && s.atMs > 0L && s.level >= 0 && s.level <= 100
        && validPlug(s.plug) && s.segment != null
        && !s.segment.isEmpty() && s.segment.length() <= 64;
  }

  public static boolean validPlug(String plug) {
    return "none".equals(plug) || "ac".equals(plug) || "usb".equals(plug)
        || "wireless".equals(plug) || "dock".equals(plug) || "unknown".equals(plug);
  }

  private static Result unavailable(String status) {
    return new Result(status, null, 0.0, "unknown", 0, 0L, 0L);
  }

  public static Result calculate(List<Sample> samples, long nowMs) {
    if (nowMs <= 0L || samples == null || samples.size() > MAX_SAMPLES)
      return unavailable("invalid_data");
    if (samples.isEmpty()) return unavailable("insufficient_data");

    // Do not sort, drop malformed rows, or conceal a backwards wall clock.
    long previous = 0L;
    for (Sample s : samples) {
      if (!valid(s)) return unavailable("invalid_data");
      if (s.atMs <= previous || s.atMs > nowMs) return unavailable("clock_changed");
      previous = s.atMs;
    }
    int last = samples.size() - 1;
    Sample end = samples.get(last);
    if (nowMs - end.atMs > MAX_GAP_MS) return unavailable("stale");
    if ("unknown".equals(end.plug)) return unavailable("power_state_unknown");

    int first = last;
    String boundary = "insufficient_data";
    for (int i = last - 1; i >= 0; i--) {
      Sample earlier = samples.get(i);
      Sample later = samples.get(i + 1);
      if (!end.segment.equals(earlier.segment)) { boundary = "tracking_changed"; break; }
      if (earlier.charging != end.charging || !earlier.plug.equals(end.plug)) {
        boundary = "power_state_changed";
        break;
      }
      if (later.atMs - earlier.atMs > MAX_GAP_MS) { boundary = "gap"; break; }
      if (end.atMs - earlier.atMs > MAX_WINDOW_MS) break;
      first = i;
    }

    Sample start = samples.get(first);
    long observedMs = end.atMs - start.atMs;
    double minutes = observedMs / 60_000.0;
    int count = last - first + 1;
    if (count < 2 || observedMs < MIN_OBSERVED_MS)
      return new Result(boundary, null, minutes, "unknown", count, start.atMs, end.atMs);

    double rate = (end.level - start.level) * 3_600_000.0 / observedMs;
    String direction = rate > 0.0 ? "rising" : rate < 0.0 ? "falling" : "steady";
    return new Result("ok", rate, minutes, direction, count, start.atMs, end.atMs);
  }
}
