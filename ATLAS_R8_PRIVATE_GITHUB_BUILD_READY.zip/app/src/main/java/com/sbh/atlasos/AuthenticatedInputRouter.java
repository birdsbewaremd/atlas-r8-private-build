package com.sbh.atlasos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Pure-Java policy boundary for owner input. It decides where an input may be handed off.
 * It never performs Android actions, calls a backend, persists a command, or grants authority.
 */
public final class AuthenticatedInputRouter {
  public enum Route {
    LOCKED,
    INVALID,
    SOURCE_DATA,
    LOCAL_DEVICE,
    WORKFLOW_HANDOFF,
    BRAIN_HANDOFF
  }

  public static final class Result {
    public final String original;
    public final WorkflowIntentParser.Origin origin;
    public final Route route;
    public final WorkflowIntentParser.Result workflow;
    public final CommandParser.Parsed local;
    public final WorkflowIntentParser.Recognition recognition;
    public final String statusLine;
    public final List<String> commandIds;
    public final List<String> commandStack;
    public final List<String> constraints;
    public final boolean authenticated;
    public final boolean shouldExecuteLocal;
    public final boolean requiresBackend;
    public final boolean backendConnected;
    public final boolean persistenceConfirmed;
    public final boolean grantsExecution = false;

    Result(String original,
           WorkflowIntentParser.Origin origin,
           Route route,
           WorkflowIntentParser.Result workflow,
           CommandParser.Parsed local,
           WorkflowIntentParser.Recognition recognition,
           List<String> commandIds,
           List<String> commandStack,
           Set<String> constraints,
           boolean authenticated,
           boolean shouldExecuteLocal,
           boolean requiresBackend,
           boolean backendConnected,
           boolean persistenceConfirmed) {
      this.original = original;
      this.origin = origin;
      this.route = route;
      this.workflow = workflow;
      this.local = local;
      this.recognition = recognition;
      this.statusLine = recognition.emoji + " " + recognition.label;
      this.commandIds = Collections.unmodifiableList(new ArrayList<String>(commandIds));
      this.commandStack = Collections.unmodifiableList(new ArrayList<String>(commandStack));
      this.constraints = Collections.unmodifiableList(new ArrayList<String>(constraints));
      this.authenticated = authenticated;
      this.shouldExecuteLocal = shouldExecuteLocal;
      this.requiresBackend = requiresBackend;
      this.backendConnected = backendConnected;
      this.persistenceConfirmed = persistenceConfirmed;
    }
  }

  private AuthenticatedInputRouter() {}

  public static Result route(String raw,
                             WorkflowIntentParser.Origin origin,
                             boolean authenticated,
                             boolean persistenceConfirmed,
                             boolean backendConnected) {
    WorkflowIntentParser.Result workflow = WorkflowIntentParser.parse(raw, origin);
    CommandParser.Parsed local = CommandParser.parse(raw);
    LinkedHashSet<String> constraints = new LinkedHashSet<String>();
    constraints.addAll(workflow.constraints);
    constraints.add("routing_is_not_execution");
    constraints.add("origin_is_assigned_by_trusted_native_callsite");

    if (!authenticated) {
      constraints.add("owner_unlock_required");
      return make(raw, origin, Route.LOCKED, workflow, local,
        WorkflowIntentParser.Recognition.PARTIAL_MATCH,
        workflow.commandIds, workflow.commandStack, constraints,
        false, false, false, backendConnected, false);
    }

    if (workflow.state == WorkflowIntentParser.State.SOURCE_DATA) {
      constraints.add("source_data_not_executed");
      return make(raw, origin, Route.SOURCE_DATA, workflow, local,
        WorkflowIntentParser.Recognition.NORMAL_REQUEST,
        workflow.commandIds, workflow.commandStack, constraints,
        true, false, true, backendConnected, false);
    }

    if (workflow.state == WorkflowIntentParser.State.INVALID
        || local.kind == CommandParser.Kind.INVALID) {
      constraints.add("invalid_input_rejected");
      return make(raw, origin, Route.INVALID, workflow, local,
        WorkflowIntentParser.Recognition.PARTIAL_MATCH,
        workflow.commandIds, workflow.commandStack, constraints,
        true, false, false, backendConnected, false);
    }

    // GOD Genesis is a recognition/quality mode, not an Android command or an
    // authorization token. This interception runs only AFTER native unlock,
    // SOURCE_DATA, and malformed-input rejection. It NEVER reaches CommandRouter.
    GodCommandPolicy.Result god = GodCommandPolicy.parse(raw);
    if (god.activated) {
      constraints.add("god_recognition_never_authorizes_execution");
      constraints.add("model_cannot_self_authorize_external_actions");
      constraints.add("god_has_no_local_device_or_physical_authority");
      constraints.add("real_work_requires_independent_owner_permissions");
      if (god.needsContext) constraints.add("god_requires_prior_turn_context");
      if (!backendConnected) constraints.add("authenticated_brain_backend_disconnected");
      ArrayList<String> ids = new ArrayList<String>();
      ArrayList<String> stack = new ArrayList<String>();
      ids.add("atlas_godforge_v3");
      stack.add("GOD V3 · RECOGNIZED ONLY");
      return make(raw, origin, Route.BRAIN_HANDOFF, workflow, local,
        WorkflowIntentParser.Recognition.MATCHED,
        ids, stack, constraints,
        true, false, true, backendConnected, false);
    }

    if (workflow.state == WorkflowIntentParser.State.RECOGNIZED) {
      WorkflowIntentParser.Recognition display = workflow.requestedRecognition;
      boolean saved = workflow.persistenceRequested && persistenceConfirmed;
      if (workflow.persistenceRequested && !saved) {
        display = WorkflowIntentParser.Recognition.PARTIAL_MATCH;
        constraints.add("command_creation_not_persisted");
      }
      if (workflow.persistenceRequested && saved) constraints.add("command_creation_persistence_confirmed");
      if (!backendConnected) constraints.add("authenticated_brain_backend_disconnected");
      return make(raw, origin, Route.WORKFLOW_HANDOFF, workflow, local, display,
        workflow.commandIds, workflow.commandStack, constraints,
        true, false, true, backendConnected, saved);
    }

    if (local.kind != CommandParser.Kind.UNKNOWN) {
      ArrayList<String> ids = new ArrayList<String>();
      ArrayList<String> stack = new ArrayList<String>();
      ids.add("local_device:" + local.kind.name().toLowerCase(java.util.Locale.US));
      stack.add("LOCAL DEVICE · " + local.kind.name().replace('_', ' '));
      if (local.userConfirmationBoundary) constraints.add("user_confirmation_boundary_required");
      constraints.add("execute_only_after_native_owner_gate_recheck");
      return make(raw, origin, Route.LOCAL_DEVICE, workflow, local,
        WorkflowIntentParser.Recognition.MATCHED,
        ids, stack, constraints,
        true, true, false, backendConnected, false);
    }

    if (!backendConnected) constraints.add("authenticated_brain_backend_disconnected");
    return make(raw, origin, Route.BRAIN_HANDOFF, workflow, local,
      WorkflowIntentParser.Recognition.NORMAL_REQUEST,
      workflow.commandIds, workflow.commandStack, constraints,
      true, false, true, backendConnected, false);
  }

  private static Result make(String raw,
                             WorkflowIntentParser.Origin origin,
                             Route route,
                             WorkflowIntentParser.Result workflow,
                             CommandParser.Parsed local,
                             WorkflowIntentParser.Recognition recognition,
                             List<String> ids,
                             List<String> stack,
                             Set<String> constraints,
                             boolean authenticated,
                             boolean shouldExecuteLocal,
                             boolean requiresBackend,
                             boolean backendConnected,
                             boolean persistenceConfirmed) {
    return new Result(raw, origin, route, workflow, local, recognition, ids, stack,
      constraints, authenticated, shouldExecuteLocal, requiresBackend,
      backendConnected, persistenceConfirmed);
  }
}
