package com.sbh.atlasos;

import java.net.URI;

/** Explicit browser handoff only; no arbitrary Intent or non-HTTPS scheme. */
public final class BookmarkedUrlPolicy {
  private BookmarkedUrlPolicy(){}
  public static String validated(String value){
    if(value==null||value.length()==0||value.length()>4096||!value.equals(value.trim()))return null;
    for(int i=0;i<value.length();i++)if(Character.isISOControl(value.charAt(i)))return null;
    try{
      URI uri=new URI(value);
      if(!"https".equalsIgnoreCase(uri.getScheme())||uri.getHost()==null||uri.getHost().isEmpty()
        ||uri.getRawUserInfo()!=null||uri.getPort()==0||uri.getPort()>65535||uri.getPort() < -1)return null;
      return uri.toASCIIString();
    }catch(Exception invalid){return null;}
  }
}
