package com.sbh.atlasos;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/** Periodic, opted-in battery-only observation; never reads owner or app-usage data. */
public final class AtlasBatteryJobService extends JobService {
  private final ExecutorService worker = Executors.newSingleThreadExecutor();
  private final Handler main = new Handler(Looper.getMainLooper());
  private Task running;

  private static final class Task {
    final JobParameters parameters;
    final AtomicBoolean stopped = new AtomicBoolean();
    Future<?> future;
    Task(JobParameters parameters) { this.parameters = parameters; }
  }

  @Override public boolean onStartJob(JobParameters parameters) {
    if (parameters == null || parameters.getJobId() != AtlasDeviceInsights.BATTERY_JOB_ID) return false;
    final Task task = new Task(parameters);
    if (running != null) stop(running);
    running = task;
    try {
      task.future = worker.submit(new Runnable() {
        @Override public void run() {
          try {
            if (!task.stopped.get()) AtlasDeviceInsights.sample(getApplicationContext());
          } finally {
            main.post(new Runnable() {
              @Override public void run() {
                if (running == task) running = null;
                if (!task.stopped.get()) jobFinished(task.parameters, false);
              }
            });
          }
        }
      });
      return true;
    } catch (RuntimeException unavailable) {
      stop(task);
      if (running == task) running = null;
      return false;
    }
  }

  @Override public boolean onStopJob(JobParameters parameters) {
    if (running != null && (parameters == null || running.parameters.getJobId() == parameters.getJobId())) {
      stop(running);
      running = null;
    }
    // The periodic schedule owns future attempts; do not create an immediate retry loop.
    return false;
  }

  private static void stop(Task task) {
    task.stopped.set(true);
    if (task.future != null) task.future.cancel(true);
  }

  @Override public void onDestroy() {
    if (running != null) stop(running);
    running = null;
    worker.shutdownNow();
    super.onDestroy();
  }
}
