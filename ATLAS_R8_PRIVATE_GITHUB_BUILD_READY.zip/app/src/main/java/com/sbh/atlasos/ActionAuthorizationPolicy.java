package com.sbh.atlasos;

/** Pure-Java validation for a fresh, action-specific owner approval envelope. */
public final class ActionAuthorizationPolicy {
  public static final long MAX_TTL_MS = 2L * 60L * 1000L;
  private ActionAuthorizationPolicy() {}

  public static boolean isFreshAndBound(
      boolean ownerAuthenticated,
      long issuedElapsedMs,
      long nowElapsedMs,
      long ttlMs,
      long expectedGeneration,
      long actualGeneration,
      String expectedTargetSha256,
      String actualTargetSha256,
      String expectedPayloadSha256,
      String actualPayloadSha256,
      boolean consumed) {
    if (!ownerAuthenticated || consumed) return false;
    if (ttlMs <= 0L || ttlMs > MAX_TTL_MS || issuedElapsedMs < 0L || nowElapsedMs < issuedElapsedMs) return false;
    if (nowElapsedMs - issuedElapsedMs > ttlMs) return false;
    if (expectedGeneration <= 0L || expectedGeneration != actualGeneration) return false;
    return validHash(expectedTargetSha256) && expectedTargetSha256.equals(actualTargetSha256)
        && validHash(expectedPayloadSha256) && expectedPayloadSha256.equals(actualPayloadSha256);
  }

  private static boolean validHash(String value) {
    return value != null && value.matches("[0-9a-f]{64}");
  }
}
