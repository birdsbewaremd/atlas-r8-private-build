package com.sbh.atlasos;

/** Change-control gate for authority-bearing prompts, policies and tool manifests. */
public final class AuthorityConfigPolicy {
  private AuthorityConfigPolicy() {}

  public static boolean canActivate(
      boolean authorityBearing,
      String oldHash,
      String newHash,
      boolean authorizedAuthor,
      boolean reviewerApproved,
      boolean relevantTestsPassed,
      boolean rollbackAvailable,
      boolean auditReceiptReady) {
    if (newHash == null || newHash.trim().isEmpty()) return false;
    if (oldHash != null && oldHash.equals(newHash)) return false;
    if (!authorizedAuthor || !relevantTestsPassed || !rollbackAvailable || !auditReceiptReady) return false;
    return !authorityBearing || reviewerApproved;
  }
}
