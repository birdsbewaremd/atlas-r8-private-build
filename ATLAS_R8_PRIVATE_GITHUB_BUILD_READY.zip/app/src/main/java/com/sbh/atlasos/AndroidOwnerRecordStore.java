package com.sbh.atlasos;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.AtomicFile;
import java.io.*;
import java.security.KeyStore;
import java.util.Arrays;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

/** App-private, backup-excluded encrypted blobs; Android AtomicFile owns crash recovery. */
final class AndroidOwnerRecordStore implements OwnerRecordStore.BlobStore,OwnerRecordStore.KeySource {
  private static final String ALIAS="atlas_owner_records_key_v1";
  private final File directory;
  AndroidOwnerRecordStore(Context context){directory=new File(context.getNoBackupFilesDir(),"owner_records_v1");}
  private AtomicFile file(String key)throws IOException{
    if(!OwnerRecordStore.validKey(key))throw new IOException("record key");
    return new AtomicFile(new File(directory,key+".enc"));
  }
  private boolean artifacts(AtomicFile file){
    File base=file.getBaseFile();
    return base.exists()||new File(base.getPath()+".bak").exists()||new File(base.getPath()+".new").exists();
  }
  @Override public SecretKey get(boolean create)throws Exception{
    KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
    if(!store.containsAlias(ALIAS)){
      // Never recreate a lost key while ANY record artifacts remain.
      String[] existing=directory.list();
      if(!create||(directory.exists()&&(existing==null||existing.length!=0)))throw new IOException("record key unavailable");
      KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
      generator.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setRandomizedEncryptionRequired(true).setKeySize(256).build());
      generator.generateKey();
    }
    SecretKey key=(SecretKey)store.getKey(ALIAS,null);
    if(key==null)throw new IOException("record key unavailable");
    return key;
  }
  @Override public byte[] read(String key)throws Exception{
    AtomicFile file=file(key);
    try(InputStream in=file.openRead();ByteArrayOutputStream bytes=new ByteArrayOutputStream()){
      byte[] buffer=new byte[4096];int n;
      while((n=in.read(buffer))!=-1){
        if(bytes.size()+n>OwnerRecordStore.MAX_BLOB_BYTES)throw new OwnerRecordStore.CorruptException();
        bytes.write(buffer,0,n);
      }
      return bytes.toByteArray();
    }catch(FileNotFoundException missing){
      if(artifacts(file))throw new OwnerRecordStore.CorruptException();
      return null;
    }
  }
  @Override public void write(String key,byte[] blob,OwnerRecordStore.Access access)throws Exception{
    if(blob==null||blob.length>OwnerRecordStore.MAX_BLOB_BYTES)throw new IOException("record bound");
    OwnerRecordStore.require(access);
    AtomicFile file=file(key);FileOutputStream out=null;
    try{
      out=file.startWrite();out.write(blob);out.getFD().sync();
      // Lock/relogin cannot race past this final generation check and commit.
      // The access closure also checks MainActivity's volatile foreground flag.
      synchronized(OwnerSessionGate.class){
        OwnerRecordStore.require(access);
        file.finishWrite(out);out=null;
      }
      if(!Arrays.equals(blob,read(key)))throw new IOException("record commit not verified");
    }catch(Exception failure){if(out!=null)file.failWrite(out);throw failure;}
  }
}
