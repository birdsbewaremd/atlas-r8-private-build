package com.sbh.atlasos;

import android.Manifest;
import android.app.*;
import android.hardware.biometrics.BiometricPrompt;
import android.hardware.biometrics.BiometricManager;
import android.app.role.RoleManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Insets;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import android.provider.ContactsContract;
import android.view.View;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.os.StatFs;
import android.os.*;
import android.speech.*;
import android.speech.tts.*;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.text.InputFilter;
import android.text.InputType;
import android.view.WindowManager;
import javax.crypto.*;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.io.*;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.*;
import java.util.zip.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
  private volatile WebView web;
  private FrameLayout webContainer;
  private volatile boolean rendererUnavailable,activityDestroyed;
  private int viewportInsetTop,viewportInsetBottom,viewportInsetLeft,viewportInsetRight;
  private boolean keyboardVisible;
  private static final int PICK_SEED=4401, REQ_WAKE=4403, REQ_VOICE_TURN=4404, PICK_DOCUMENT=4405, PICK_PRODUCT_IMAGE=4406;
  private boolean wakeRequested=false, voiceTurnRequested=false, resumeWakeAfterVoiceTurn=false, pageReady=false;
  private BroadcastReceiver wakeReceiver;
  private SpeechRecognizer voiceRecognizer;
  private TextToSpeech tts;
  private boolean ttsReady=false;
  private long voiceStartGeneration=0L; // Owned by the Activity/UI thread.
  private final WorkflowPlanner workflowPlanner=new WorkflowPlanner();
  private HumanLearningBridge humanLearning;
  private OwnerRecordStore ownerRecords;
  private AtlasBrainController brain;
  private AlertDialog bookmarkDialog;
  private volatile boolean learningForeground=false;
  private final String HOME="file:///android_asset/www/index.html";
  private final String KEY_ALIAS="atlas_private_vault_v1";
  private static final String AUTH_PREFS="atlas_owner_auth_v2";
  private static final String AUTH_BIOMETRIC_ENABLED="biometric_unlock_opt_in_v1";
  private static final String AUTH_IDLE_SEC="owner_idle_sec_v1";
  private static final String AUTH_GRACE_SEC="owner_return_grace_sec_v1";
  private boolean biometricPending=false;
  private long biometricSuccessAt=0L;
  private BroadcastReceiver screenOffReceiver;

  private static final String AUTH_SALT="pin_salt";
  private static final String AUTH_VERIFIER="pin_verifier";
  private static final String AUTH_FAILURES="pin_failures";
  private static final String AUTH_LOCK_UNTIL="pin_lock_until";

  private static final String RECOVERY_SALT="recovery_salt_v1";
  private static final String RECOVERY_VERIFIER="recovery_verifier_v1";
  private static final String RECOVERY_FAILURES="recovery_failures_v1";
  private static final String RECOVERY_LOCK_UNTIL="recovery_lock_until_v1";
  private static final Set<String> SAFE_EXTERNAL_URLS=Collections.unmodifiableSet(new HashSet<String>(Arrays.asList(
    "https://birdsbewaremd.com/",
    "https://www.weather.gov/",
    "https://birdsbewaremd.com/legacy.html",
    "https://birdsbewaremd.com/birds.html",
    "https://birdsbewaremd.com/sbh.html",
    "https://birdsbewaremd.com/self-mastery-house.html"
  )));
  private AlertDialog credentialDialog;
  private Uri pendingSeedUri;
  private long pendingSeedAt;
  private boolean seedPickerOutstanding;
  private boolean seedPickerChatGpt,pendingSeedChatGpt;
  private Uri pendingDocumentUri;
  private String pendingDocumentName;
  private long pendingDocumentAt;
  private boolean documentPickerOutstanding;
  private final java.util.concurrent.atomic.AtomicBoolean documentImportBusy=new java.util.concurrent.atomic.AtomicBoolean(false);
  private final java.util.concurrent.atomic.AtomicBoolean importBusy=new java.util.concurrent.atomic.AtomicBoolean(false);
  private Uri pendingProductImageUri;
  private long productImagePickerAt,pendingProductImageAt;
  private boolean productImagePickerOutstanding;
  private final java.util.concurrent.atomic.AtomicBoolean productImageImportBusy=new java.util.concurrent.atomic.AtomicBoolean(false);

  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    final Context captureContext=getApplicationContext();
    new Thread(()->{
      try{AtlasCaptureStore.cleanupInterrupted(captureContext);}
      catch(Exception unavailable){android.util.Log.w("ATLAS","Interrupted recording cleanup is unavailable");}
    },"atlas-recording-temp-cleanup").start();
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    if(Build.VERSION.SDK_INT>=30)getWindow().setDecorFitsSystemWindows(false);
    OwnerSessionGate.clear();
    OwnerSessionGate.setIdleTimeoutSeconds(authPrefs().getInt(AUTH_IDLE_SEC,900));
    registerScreenOffReceiver();
    humanLearning=new HumanLearningBridge(this,()->learningForeground && OwnerSessionGate.isActive(this));
    AndroidOwnerRecordStore recordFiles=new AndroidOwnerRecordStore(this);
    ownerRecords=new OwnerRecordStore(recordFiles,recordFiles);
    brain=new AtlasBrainController(this,ownerRecords,new AtlasBrainController.Host(){
      public long capture(){return captureOwnerSession();}
      public boolean current(long session){
        return learningForeground&&!activityDestroyed&&!rendererUnavailable&&!isFinishing()&&!isDestroyed()
          &&OwnerSessionGate.isCurrent(MainActivity.this,session);
      }
      public void emit(long session,String detail){
        // The last UI hop must still belong to the exact owner login that requested it.
        final WebView target=web;
        runOnUiThread(()->{
          if(target!=web||!webUsable(target)||!pageReady||!current(session))return;
          target.evaluateJavascript("window.dispatchEvent(new CustomEvent('atlas-brain-result',{detail:"+detail+"}))",null);
        });
      }
      public String readText(long session,String path)throws Exception{
        return VaultSearchReader.read(vaultRoot(),path,vaultKey(),()->current(session));
      }
    });
    buildWeb();
    ensureVaultKey();
    registerWakeReceiver();
    initVoiceStack();
  }

  @Override protected void onNewIntent(Intent intent){
    super.onNewIntent(intent);
    setIntent(intent);
    if(Intent.ACTION_ASSIST.equals(intent.getAction())) dispatchAssistantInvocation();
  }

  // API 33+ explicitly rejects external senders. API 29–32 use the signature
  // permission declared in our manifest; lint does not resolve that dynamic name.
  @android.annotation.SuppressLint("UnspecifiedRegisterReceiverFlag")
  private void registerWakeReceiver(){
    wakeReceiver=new BroadcastReceiver(){ @Override public void onReceive(Context c,Intent i){
      String phrase=i.getStringExtra("phrase"),command=i.getStringExtra("command");
      String safeCommand=command==null?"":command.trim();
      if(safeCommand.isEmpty()){
        dispatchEvent("atlas-wake", "{phrase:"+JSONObject.quote(phrase==null?"Hey Atlas":phrase)+",command:"+JSONObject.quote("")+"}");
      }else{
        dispatchEvent("atlas-command-result", routeAuthenticatedInput(safeCommand,WorkflowIntentParser.Origin.WAKE_TRANSCRIPT));
      }
    }};
    IntentFilter f=new IntentFilter(AtlasWakeService.ACTION_WAKE);
    if(Build.VERSION.SDK_INT>=33) {
      registerReceiver(wakeReceiver,f,Context.RECEIVER_NOT_EXPORTED);
    } else {
      // Older Android releases use a signature permission so unrelated apps
      // cannot inject commands into the internal wake receiver.
      registerReceiver(wakeReceiver,f,getPackageName()+".permission.INTERNAL_WAKE",null);
    }
  }

  /** Screen lock always cancels session grace, including while ATLAS is not visible. */
  @android.annotation.SuppressLint("UnspecifiedRegisterReceiverFlag")
  private void registerScreenOffReceiver(){
    screenOffReceiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){
      if(Intent.ACTION_SCREEN_OFF.equals(i.getAction())){
        biometricPending=false;
        OwnerSessionGate.clear();
        workflowPlanner.clear();
        stopPrivateMedia();
        dispatchEvent("atlas-owner-locked","{}");
      }
    }};
    IntentFilter filter=new IntentFilter(Intent.ACTION_SCREEN_OFF);
    if(Build.VERSION.SDK_INT>=33)registerReceiver(screenOffReceiver,filter,Context.RECEIVER_NOT_EXPORTED);
    else registerReceiver(screenOffReceiver,filter);
  }

  @Override protected void onDestroy(){
    activityDestroyed=true;pageReady=false;learningForeground=false;
    if(brain!=null)brain.suspend();
    voiceStartGeneration++;
    dismissCredentialDialog();
    try{ if(wakeReceiver!=null)unregisterReceiver(wakeReceiver); }catch(Exception ignored){}
    try{ if(screenOffReceiver!=null)unregisterReceiver(screenOffReceiver); }catch(Exception ignored){}
    if(voiceRecognizer!=null){ try{ voiceRecognizer.cancel(); }catch(Exception ignored){} try{ voiceRecognizer.destroy(); }catch(Exception ignored){} voiceRecognizer=null; }
    if(tts!=null){ try{ tts.stop(); tts.shutdown(); }catch(Exception ignored){} tts=null; }
    OwnerSessionGate.setForeground(false);
    pendingSeedUri=null;pendingDocumentUri=null;pendingDocumentName=null;pendingProductImageUri=null;productImagePickerOutstanding=false;
    WebView old=web;web=null;disposeWebView(old,rendererUnavailable);
    super.onDestroy();
  }

  private void buildWeb(){
    webContainer=new FrameLayout(this);
    webContainer.setBackgroundColor(android.graphics.Color.rgb(7,9,15));
    web=new WebView(this);
    final WebView created=web;
    web.setBackgroundColor(android.graphics.Color.rgb(7,9,15));
    webContainer.addView(web,new FrameLayout.LayoutParams(
      android.view.ViewGroup.LayoutParams.MATCH_PARENT,android.view.ViewGroup.LayoutParams.MATCH_PARENT));
    setContentView(webContainer);
    if(Build.VERSION.SDK_INT>=30){
      // Native layout owns bar/cutout/IME padding once. The WebView receives the
      // remaining safe bounds, so CSS must not reserve these same insets again.
      webContainer.setOnApplyWindowInsetsListener((v,insets)->{
        if(!webUsable(created))return insets;
        int safeTypes=WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout();
        Insets safe=insets.getInsets(safeTypes),ime=insets.getInsets(WindowInsets.Type.ime());
        viewportInsetTop=safe.top;viewportInsetLeft=safe.left;viewportInsetRight=safe.right;
        viewportInsetBottom=Math.max(safe.bottom,ime.bottom);
        keyboardVisible=insets.isVisible(WindowInsets.Type.ime());
        v.setPadding(safe.left,safe.top,safe.right,viewportInsetBottom);
        created.post(()->{if(webUsable(created))dispatchViewport();});
        return new WindowInsets.Builder(insets)
          .setInsets(safeTypes|WindowInsets.Type.ime(),Insets.NONE)
          .setInsetsIgnoringVisibility(safeTypes,Insets.NONE).build();
      });
      webContainer.requestApplyInsets();
    }else webContainer.setFitsSystemWindows(true);
    web.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{
      if(webUsable(created)&&(r-l!=or-ol||b-t!=ob-ot))dispatchViewport();
    });
    WebSettings s=web.getSettings();
    s.setUseWideViewPort(true);s.setLoadWithOverviewMode(false);
    s.setTextZoom(Math.max(80,Math.min(300,Math.round(getResources().getConfiguration().fontScale*100))));
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(false);
    // This candidate intentionally ships without an in-WebView network path. External links
    // leave the WebView through ACTION_VIEW; private bridge surfaces stay on packaged assets.
    s.setBlockNetworkLoads(true);
    s.setAllowFileAccess(false); s.setAllowContentAccess(false);
    s.setAllowFileAccessFromFileURLs(false); s.setAllowUniversalAccessFromFileURLs(false);
    s.setJavaScriptCanOpenWindowsAutomatically(false); s.setSupportMultipleWindows(false);
    s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    WebView.setWebContentsDebuggingEnabled(false);
    // Keep WebView's normal viewport drawing; whole-document rendering is not needed for a paged home.
    if(Build.VERSION.SDK_INT>=26) s.setSafeBrowsingEnabled(true);
    web.addJavascriptInterface(new Bridge(),"ATLASNative");
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){
        if(!webUsable(v))return true;
        Uri u=r.getUrl(); String raw=u.toString();
        if(HOME.equals(raw)) return false;
        if(raw.startsWith("file:///android_asset/www/")){
          toast("Blocked unexpected local navigation");
          return true;
        }
        if(!ownerRequired()){ toast("Unlock Atlas OS first"); return true; }
        if(!ExternalTargetPolicy.isExactTargetAllowed(raw,SAFE_EXTERNAL_URLS)){ toast("Blocked unapproved external link"); return true; }
        OwnerSessionGate.touch();
        try{
          Intent i=new Intent(Intent.ACTION_VIEW,u);
          if(i.resolveActivity(getPackageManager())!=null)startActivity(i); else toast("No app can open that link");
        }catch(Exception ignored){ toast("Unable to open link"); }
        return true;
      }
      @Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap favicon){
        if(!webUsable(v))return;
        super.onPageStarted(v,url,favicon); pageReady=false;
      }
      @Override public void onPageFinished(WebView v,String url){
        if(!webUsable(v))return;
        super.onPageFinished(v,url);
        pageReady=HOME.equals(url);
        if(pageReady)dispatchViewport();
        if(pageReady&&Intent.ACTION_ASSIST.equals(getIntent().getAction())) dispatchAssistantInvocation();
      }
      @Override public boolean onRenderProcessGone(WebView failed,RenderProcessGoneDetail detail){
        recoverRenderer(failed);
        return true;
      }
    });
    web.setWebChromeClient(new WebChromeClient(){ @Override public void onPermissionRequest(PermissionRequest r){ runOnUiThread(()->handleWebPermission(r)); } });
    web.loadUrl(HOME);
  }

  private boolean webUsable(WebView view){
    return view!=null&&view==web&&!rendererUnavailable&&!activityDestroyed&&!isFinishing()&&!isDestroyed();
  }

  private void disposeWebView(WebView view,boolean rendererGone){
    if(view==null)return;
    try{
      android.view.ViewParent parent=view.getParent();
      if(parent instanceof android.view.ViewGroup)((android.view.ViewGroup)parent).removeView(view);
    }catch(RuntimeException ignored){}
    // A WebView whose renderer died cannot be navigated or reused. Destroying
    // this instance does not erase cookies, preferences or the encrypted vault.
    if(!rendererGone)try{view.stopLoading();}catch(RuntimeException ignored){}
    try{view.removeJavascriptInterface("ATLASNative");}catch(RuntimeException ignored){}
    try{view.destroy();}catch(RuntimeException ignored){}
  }

  private void recoverRenderer(WebView failed){
    if(failed!=web){disposeWebView(failed,true);return;} // Clean only the stale view; do not replace a newer screen.
    rendererUnavailable=true;pageReady=false;learningForeground=false;
    if(brain!=null)brain.suspend();
    OwnerSessionGate.setForeground(false);workflowPlanner.clear();stopPrivateMedia();
    dismissCredentialDialog();
    if(bookmarkDialog!=null){bookmarkDialog.dismiss();bookmarkDialog=null;}
    pendingSeedUri=null;pendingSeedAt=0;seedPickerOutstanding=false;seedPickerChatGpt=false;pendingSeedChatGpt=false;
    pendingDocumentUri=null;pendingDocumentName=null;pendingDocumentAt=0;documentPickerOutstanding=false;
    pendingProductImageUri=null;pendingProductImageAt=0;productImagePickerOutstanding=false;productImagePickerAt=0;
    // Existing worker authorization tokens are now invalid. Their normal
    // finally blocks remove only unfinished staging and release busy flags.
    web=null;disposeWebView(failed,true);
    if(activityDestroyed||isFinishing()||isDestroyed())return;
    android.widget.ScrollView scroll=new android.widget.ScrollView(this);
    scroll.setFillViewport(true);scroll.setBackgroundColor(android.graphics.Color.rgb(7,9,15));
    LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
    int pad=Math.round(24*getResources().getDisplayMetrics().density);box.setPadding(pad,pad,pad,pad);
    TextView title=new TextView(this);title.setText("ATLAS display stopped");title.setTextSize(24);title.setTextColor(android.graphics.Color.WHITE);
    box.addView(title,new LinearLayout.LayoutParams(-1,-2));
    TextView message=new TextView(this);message.setText("Android's web renderer stopped. ATLAS locked your session and cancelled pending file selections. Saved records, files, settings and your PIN are unchanged.\n\nChoose Retry to reopen ATLAS and unlock normally. The screen will not reload automatically.");
    message.setTextSize(16);message.setTextColor(android.graphics.Color.rgb(211,204,228));message.setPadding(0,pad,0,pad);box.addView(message,new LinearLayout.LayoutParams(-1,-2));
    android.widget.Button retry=new android.widget.Button(this);retry.setText("Retry ATLAS");retry.setFilterTouchesWhenObscured(true);
    retry.setOnClickListener(v->{
      if(!rendererUnavailable||activityDestroyed||isFinishing()||isDestroyed())return;
      retry.setEnabled(false);OwnerSessionGate.clear();recreate();
    });box.addView(retry,new LinearLayout.LayoutParams(-1,-2));
    android.widget.Button close=new android.widget.Button(this);close.setText("Close");close.setFilterTouchesWhenObscured(true);
    close.setOnClickListener(v->finish());box.addView(close,new LinearLayout.LayoutParams(-1,-2));scroll.addView(box);
    if(Build.VERSION.SDK_INT>=30)scroll.setOnApplyWindowInsetsListener((v,insets)->{
      Insets safe=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
      v.setPadding(safe.left,safe.top,safe.right,safe.bottom);return WindowInsets.CONSUMED;
    });else scroll.setFitsSystemWindows(true);
    setContentView(scroll);scroll.requestApplyInsets();
  }

  private void dispatchAssistantInvocation(){
    if(!pageReady||web==null)return;
    dispatchEvent("atlas-assist", "{}");
    try{ getIntent().setAction(null); }catch(Exception ignored){}
  }

  private void handleWebPermission(PermissionRequest r){
    // Temporary privacy hold: file:// pages do not provide a distinct trusted
    // frame origin for media grants. Native voice uses its separate owner gate.
    // Re-enable only after trusted-origin and Android lifecycle acceptance tests.
    if(r==null)return;
    try{r.deny();}catch(IllegalStateException ignored){} // A canceled request stays denied.
  }

  @Override public void onRequestPermissionsResult(int q,String[] p,int[] g){
    super.onRequestPermissionsResult(q,p,g);
    if(q==REQ_WAKE){
      boolean ok=g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED;
      if(ok&&wakeRequested&&ownerRequired())startWakeService(true); else if(!ok)toast("Microphone permission is required for Hey Atlas");
      wakeRequested=false;
    }
    if(q==REQ_VOICE_TURN){
      boolean ok=g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED;
      if(ok&&voiceTurnRequested)startVoiceTurn(); else if(!ok)voiceEvent("ERROR","Microphone permission is required.");
      voiceTurnRequested=false;
    }
  }

  @Override public void onBackPressed(){
    final WebView current=web;
    if(!webUsable(current)||!pageReady){super.onBackPressed();return;}
    // Give the trusted single-page UI one opportunity to dismiss its top panel.
    // A false/absent handler retains Android's normal navigation behavior.
    current.evaluateJavascript("(function(){try{return typeof window.ATLASHandleBack==='function' && window.ATLASHandleBack()===true;}catch(e){return false;}})()",value->{
      if(!webUsable(current)||"true".equals(value))return;
      if(current.canGoBack())current.goBack();else MainActivity.super.onBackPressed();
    });
  }

  private String viewportInfoNative(){
    JSONObject o=new JSONObject();
    try{
      float density=getResources().getDisplayMetrics().density;
      o.put("width",web==null?0:Math.round(web.getWidth()/density));
      o.put("height",web==null?0:Math.round(web.getHeight()/density));
      o.put("density",density);o.put("fontScale",getResources().getConfiguration().fontScale);
      o.put("keyboardVisible",keyboardVisible);o.put("nativeInsetsApplied",true);
      o.put("insets",new JSONObject().put("top",Math.round(viewportInsetTop/density))
        .put("bottom",Math.round(viewportInsetBottom/density)).put("left",Math.round(viewportInsetLeft/density))
        .put("right",Math.round(viewportInsetRight/density)));
    }catch(Exception ignored){}
    return o.toString();
  }

  private void dispatchViewport(){dispatchEvent("atlas-viewport",viewportInfoNative());}

  private Intent launcherCategory(String category){
    return Intent.makeMainSelectorActivity(Intent.ACTION_MAIN,category);
  }

  private void openNativeAppNative(String kind,long session){
    if(!OwnerSessionGate.isCurrent(this,session)){toast("Unlock ATLAS first");return;}
    Intent intent;
    if("camera".equals(kind))intent=new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
    else if("gallery".equals(kind)||"photos".equals(kind))intent=launcherCategory(Intent.CATEGORY_APP_GALLERY);
    else if("maps".equals(kind))intent=launcherCategory(Intent.CATEGORY_APP_MAPS);
    else if("phone".equals(kind))intent=new Intent(Intent.ACTION_DIAL);
    else if("clock".equals(kind)||"alarm".equals(kind))intent=new Intent(AlarmClock.ACTION_SHOW_ALARMS);
    else if("timer".equals(kind))intent=new Intent(AlarmClock.ACTION_SHOW_TIMERS);
    else if("calculator".equals(kind))intent=launcherCategory(Intent.CATEGORY_APP_CALCULATOR);
    else if("contacts".equals(kind))intent=new Intent(Intent.ACTION_VIEW,ContactsContract.Contacts.CONTENT_URI);
    else if("calendar".equals(kind))intent=launcherCategory(Intent.CATEGORY_APP_CALENDAR);
    else if("messages".equals(kind))intent=launcherCategory(Intent.CATEGORY_APP_MESSAGING);
    else if("email".equals(kind))intent=launcherCategory(Intent.CATEGORY_APP_EMAIL);
    else if("browser".equals(kind))intent=launcherCategory(Intent.CATEGORY_APP_BROWSER);
    else {toast("Unknown app shortcut");return;}
    OwnerSessionGate.touch();
    try{startActivity(intent);}
    catch(ActivityNotFoundException missing){toast("No installed app handles this shortcut. Open Apps to choose one.");}
    catch(SecurityException denied){toast("Android denied this app shortcut. Open the app from its own launcher.");}
    catch(RuntimeException failed){toast("Unable to open the selected app");}
  }

  private String installedAppsNative(){
    final long session=captureOwnerSession();
    if(session==0L)return "[]";
    JSONArray out=new JSONArray();
    try{
      Intent query=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
      List<ResolveInfo> rows=getPackageManager().queryIntentActivities(query,0);
      Collections.sort(rows,new ResolveInfo.DisplayNameComparator(getPackageManager()));
      Set<String> seen=new HashSet<>();
      for(ResolveInfo row:rows){
        if(!OwnerSessionGate.isCurrent(this,session))return "[]";
        if(row.activityInfo==null||!row.activityInfo.exported||!row.activityInfo.enabled)continue;
        ComponentName component=new ComponentName(row.activityInfo.packageName,row.activityInfo.name);
        String id=component.flattenToString();
        if(!seen.add(id)||getPackageName().equals(row.activityInfo.packageName))continue;
        JSONObject item=new JSONObject().put("id",id).put("packageName",row.activityInfo.packageName);
        String label=String.valueOf(row.loadLabel(getPackageManager()));
        item.put("label",label.length()>100?label.substring(0,100):label);
        try{
          Drawable drawable=row.loadIcon(getPackageManager());
          Bitmap bitmap=Bitmap.createBitmap(72,72,Bitmap.Config.ARGB_8888);
          drawable.setBounds(0,0,72,72);drawable.draw(new Canvas(bitmap));
          ByteArrayOutputStream bytes=new ByteArrayOutputStream();bitmap.compress(Bitmap.CompressFormat.PNG,100,bytes);bitmap.recycle();
          if(bytes.size()<=32768)item.put("icon","data:image/png;base64,"+Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP));
        }catch(Exception ignored){}
        out.put(item); // R7: no hardcoded 200-app cutoff; display all launchable current-profile activities.
      }
      if(!OwnerSessionGate.isCurrent(this,session))return "[]";
      OwnerSessionGate.touch();
    }catch(Exception ignored){}
    return out.toString();
  }

  private void openInstalledAppNative(String id,long session){
    if(!OwnerSessionGate.isCurrent(this,session)){toast("Unlock ATLAS first");return;}
    ComponentName component=id==null?null:ComponentName.unflattenFromString(id);
    if(component==null||id.length()>512){toast("Invalid app shortcut");return;}
    Intent query=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(component);
    List<ResolveInfo> rows=getPackageManager().queryIntentActivities(query,0);
    boolean allowed=false;
    for(ResolveInfo row:rows)if(row.activityInfo!=null&&row.activityInfo.enabled&&row.activityInfo.exported
      &&component.getPackageName().equals(row.activityInfo.packageName)&&component.getClassName().equals(row.activityInfo.name))allowed=true;
    if(!allowed){toast("This app is no longer available");return;}
    OwnerSessionGate.touch();
    try{startActivity(query.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED));}
    catch(RuntimeException failed){toast("Unable to open the selected app");}
  }

  private SharedPreferences authPrefs(){ return getSharedPreferences(AUTH_PREFS,MODE_PRIVATE); }

  private boolean ownerPinConfiguredNative(){ return authPrefs().contains(AUTH_VERIFIER)&&authPrefs().contains(AUTH_SALT); }

  // Initial enrollment only. Existing owners must use native fresh-PIN change/recovery dialogs.
  private synchronized boolean configureOwnerPinNative(String pin,String confirmation){
    if(rendererUnavailable||activityDestroyed||isFinishing()||isDestroyed())return false;
    if(ownerPinConfiguredNative()||!OwnerRecoveryPolicy.pinPairMatches(pin,confirmation))return false;
    if(!OwnerSessionGate.isForeground())return false;
    boolean saved=persistOwnerPinNative(pin,false,"pin_enrolled");
    if(saved&&!rendererUnavailable&&!activityDestroyed)OwnerSessionGate.setActive(true);
    else if(rendererUnavailable||activityDestroyed)OwnerSessionGate.clear();
    return saved;
  }

  private SharedPreferences.Editor addSecurityEvent(SharedPreferences.Editor edit,String event){
    JSONArray events;
    try{events=new JSONArray(authPrefs().getString("security_events","[]"));}
    catch(Exception e){events=new JSONArray();}
    JSONArray bounded=new JSONArray();
    for(int i=Math.max(0,events.length()-99);i<events.length();i++)bounded.put(events.opt(i));
    JSONObject row=new JSONObject();
    try{row.put("event",event);row.put("at_ms",System.currentTimeMillis());}catch(Exception ignored){}
    bounded.put(row);
    return edit.putString("security_events",bounded.toString());
  }

  private synchronized boolean persistOwnerPinNative(String pin,boolean consumeRecovery,String event){
    if(!OwnerPinPolicy.validPin(pin))return false;
    try{
      byte[] salt=new byte[OwnerPinPolicy.SALT_BYTES];new SecureRandom().nextBytes(salt);
      byte[] verifier=OwnerPinPolicy.derive(pin,salt);
      SharedPreferences.Editor edit=authPrefs().edit()
        .putString(AUTH_SALT,Base64.encodeToString(salt,Base64.NO_WRAP))
        .putString(AUTH_VERIFIER,Base64.encodeToString(verifier,Base64.NO_WRAP))
        .putInt(AUTH_FAILURES,0).remove(AUTH_LOCK_UNTIL).putBoolean(AUTH_BIOMETRIC_ENABLED,false);
      if(consumeRecovery)edit.remove(RECOVERY_SALT).remove(RECOVERY_VERIFIER)
        .remove(RECOVERY_FAILURES).remove(RECOVERY_LOCK_UNTIL);
      boolean committed=addSecurityEvent(edit,event).commit();
      java.util.Arrays.fill(verifier,(byte)0);
      OwnerSessionGate.clear();
      return committed;
    }catch(Exception e){OwnerSessionGate.clear();return false;}
  }

  private boolean recoveryConfiguredNative(){
    return authPrefs().contains(RECOVERY_SALT)&&authPrefs().contains(RECOVERY_VERIFIER);
  }

  private void dismissCredentialDialog(){
    if(credentialDialog!=null){credentialDialog.dismiss();credentialDialog=null;}
  }

  @Override protected void onStart(){
    super.onStart();
    OwnerSessionGate.setForeground(true); // Returning never restores a previous login.
  }

  @Override protected void onResume(){
    super.onResume();
    // Resume ONLY while an owner-enabled short grace is unexpired and keyguard
    // has not locked. Screen-off always revokes; no private web content while paused.
    OwnerSessionGate.setForeground(true);
    if(biometricPending){
      final boolean recent=(SystemClock.elapsedRealtime()-biometricSuccessAt)<30000L;
      biometricPending=false;
      KeyguardManager km=(KeyguardManager)getSystemService(KEYGUARD_SERVICE);
      if(recent && km!=null && !km.isDeviceLocked() && biometricConfiguredNative() && ownerPinConfiguredNative()){
        OwnerSessionGate.setActive(true);
        dispatchEvent("atlas-biometric-unlocked","{}");
      }
    }
    learningForeground=!rendererUnavailable&&!activityDestroyed;
    if(web!=null&&pageReady){
      final WebView current=web;
      if(ownerPinConfiguredNative()&&!ownerRequired()){
        current.evaluateJavascript("window.dispatchEvent(new CustomEvent('atlas-owner-locked'))", ignored->{
          if(webUsable(current)&&OwnerSessionGate.isForeground())current.setVisibility(android.view.View.VISIBLE);
        });
      }else if(webUsable(current))current.setVisibility(android.view.View.VISIBLE);
    }
  }

  @Override protected void onPause(){
    // onPause may occur WITHOUT onStop (e.g. translucent Activity, permission UI).
    // Always pause private capture/work immediately; optional grace retains no
    // authority while paused and does not bypass Samsung secure keyguard.
    learningForeground=false;
    if(brain!=null)brain.suspend();
    if(bookmarkDialog!=null){bookmarkDialog.dismiss();bookmarkDialog=null;}
    OwnerSessionGate.suspend(authPrefs().getInt(AUTH_GRACE_SEC,0));
    workflowPlanner.clear();
    stopPrivateMedia();
    if(web!=null)web.setVisibility(android.view.View.INVISIBLE);
    dispatchEvent("atlas-learning-locked","{}");
    if(!OwnerSessionGate.hasSuspendedSession())dispatchEvent("atlas-owner-locked","{}");
    else dispatchEvent("atlas-owner-suspended","{}");
    super.onPause();
  }

  private void stopPrivateMedia(){
    voiceStartGeneration++; // Invalidate queued recognition and wake restarts.
    wakeRequested=false;voiceTurnRequested=false;resumeWakeAfterVoiceTurn=false;
    if(voiceRecognizer!=null){try{voiceRecognizer.cancel();}catch(Exception ignored){}}
    if(tts!=null){try{tts.stop();}catch(Exception ignored){}}
    try{stopService(new Intent(this,AtlasWakeService.class));}catch(Exception ignored){}
  }

  @Override protected void onStop(){
    if(brain!=null)brain.suspend();
    dismissCredentialDialog(); // Never leave a credential-change flow live in the background.
    OwnerSessionGate.suspend(authPrefs().getInt(AUTH_GRACE_SEC,0));
    workflowPlanner.clear();
    learningForeground=false;
    stopPrivateMedia();
    if(web!=null)web.setVisibility(android.view.View.INVISIBLE);
    if(!OwnerSessionGate.hasSuspendedSession())dispatchEvent("atlas-owner-locked","{}");
    super.onStop();
  }

  private LinearLayout credentialBox(){
    LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
    int pad=(int)(20*getResources().getDisplayMetrics().density);box.setPadding(pad,pad,pad,pad);
    box.setImportantForAutofill(android.view.View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
    box.setFilterTouchesWhenObscured(true);return box;
  }

  private EditText credentialField(LinearLayout box,String hint,boolean pin){
    EditText field=new EditText(this);field.setHint(hint);field.setSingleLine(true);
    field.setInputType(pin?(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD)
      :(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD));
    field.setFilters(new InputFilter[]{new InputFilter.LengthFilter(pin?6:128)});
    field.setSaveEnabled(false);field.setFilterTouchesWhenObscured(true);box.addView(field);return field;
  }

  private AlertDialog credentialDialog(String title,LinearLayout box){
    if(credentialDialog!=null||isFinishing()||isDestroyed()||!OwnerSessionGate.isForeground())return null;
    AlertDialog dialog=new AlertDialog.Builder(this).setTitle(title).setView(box)
      .setPositiveButton("Continue",null).setNegativeButton("Cancel",(d,w)->d.dismiss()).create();
    credentialDialog=dialog;
    dialog.setOnDismissListener(d->{if(credentialDialog==dialog)credentialDialog=null;});
    dialog.show();
    if(dialog.getWindow()!=null)dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setFilterTouchesWhenObscured(true);
    return dialog;
  }

  private boolean credentialFlowValid(AlertDialog dialog,long started){
    boolean valid=credentialDialog==dialog&&!isFinishing()&&!isDestroyed()
      &&OwnerRecoveryPolicy.flowValid(started,SystemClock.elapsedRealtime());
    if(!valid){dialog.dismiss();toast("Credential flow expired. Start again.");}
    return valid;
  }

  private void beginOwnerRecoveryEnrollmentNative(){
    if(!ownerPinConfiguredNative()||!ownerRequired()){toast("Unlock Atlas OS first");return;}
    final long started=SystemClock.elapsedRealtime();
    LinearLayout box=credentialBox();
    EditText current=credentialField(box,"Current Atlas PIN",true);
    AlertDialog dialog=credentialDialog("Create an offline recovery code",box);if(dialog==null)return;
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
      if(!credentialFlowValid(dialog,started)||!ownerRequired())return;
      String pin=current.getText().toString();current.setText("");
      if(!unlockOwnerNative(pin)){toast("Current PIN was not accepted");dialog.dismiss();return;}
      final String verifierAtStart=authPrefs().getString(AUTH_VERIFIER,"");
      final String code=OwnerRecoveryPolicy.newCode(new SecureRandom());
      box.removeAllViews();
      TextView explanation=new TextView(this);
      explanation.setText("Store this code offline, separate from this phone. It can reset your Atlas PIN once. "
        +"No recovery code is sent to chat, email, clipboard, or a server. Re-enter it below before saving.\n\n"+code);
      explanation.setTextIsSelectable(false);box.addView(explanation);
      EditText confirm=credentialField(box,"Re-enter the recovery code",false);
      dialog.getButton(AlertDialog.BUTTON_POSITIVE).setText("Save verified recovery code");
      dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(save->{
        if(!credentialFlowValid(dialog,started)||!ownerRequired())return;
        String entered=confirm.getText().toString();
        String normalized=OwnerRecoveryPolicy.normalize(entered);
        if(normalized==null||!normalized.equals(OwnerRecoveryPolicy.normalize(code))){toast("Recovery codes do not match");return;}
        synchronized(MainActivity.this){
          if(!verifierAtStart.equals(authPrefs().getString(AUTH_VERIFIER,""))){dialog.dismiss();return;}
          try{
            byte[] salt=new byte[OwnerPinPolicy.SALT_BYTES];new SecureRandom().nextBytes(salt);
            byte[] digest=OwnerRecoveryPolicy.digest(code,salt);
            SharedPreferences.Editor edit=authPrefs().edit()
              .putString(RECOVERY_SALT,Base64.encodeToString(salt,Base64.NO_WRAP))
              .putString(RECOVERY_VERIFIER,Base64.encodeToString(digest,Base64.NO_WRAP))
              .remove(RECOVERY_FAILURES).remove(RECOVERY_LOCK_UNTIL);
            boolean saved=addSecurityEvent(edit,"recovery_enrolled").commit();
            java.util.Arrays.fill(digest,(byte)0);
            if(!saved){OwnerSessionGate.clear();dialog.dismiss();toast("Recovery persistence failed. Do not rely on this code; restart and check storage.");return;}
          }catch(Exception e){toast("Recovery was not saved");return;}
        }
        confirm.setText("");explanation.setText("");dialog.dismiss();toast("Offline recovery is enrolled");
      });
    });
  }

  private synchronized boolean recoverOwnerPinNative(String code,String pin,String confirmation,long started){
    if(!OwnerRecoveryPolicy.flowValid(started,SystemClock.elapsedRealtime())
        ||!recoveryConfiguredNative()||!OwnerRecoveryPolicy.pinPairMatches(pin,confirmation))return false;
    SharedPreferences prefs=authPrefs();
    if(prefs.getLong(RECOVERY_LOCK_UNTIL,0L)>System.currentTimeMillis())return false;
    boolean valid=false;
    try{
      valid=OwnerRecoveryPolicy.matches(code,Base64.decode(prefs.getString(RECOVERY_SALT,""),Base64.DEFAULT),
        Base64.decode(prefs.getString(RECOVERY_VERIFIER,""),Base64.DEFAULT));
    }catch(Exception ignored){}
    if(!valid){
      int failures=Math.min(100,prefs.getInt(RECOVERY_FAILURES,0)+1);
      SharedPreferences.Editor edit=prefs.edit().putInt(RECOVERY_FAILURES,failures);
      long delay=OwnerPinPolicy.lockoutMillisForFailures(failures);
      if(delay>0)edit.putLong(RECOVERY_LOCK_UNTIL,System.currentTimeMillis()+delay);
      edit.commit();return false; // Independent throttle: normal PIN authentication is unaffected.
    }
    return persistOwnerPinNative(pin,true,"recovery_used"); // Atomic consume + PIN update; no auto-login.
  }

  private void beginOwnerRecoveryNative(){
    if(!recoveryConfiguredNative()){toast("No offline recovery is enrolled. Existing data was not reset.");return;}
    final long started=SystemClock.elapsedRealtime();
    LinearLayout box=credentialBox();
    EditText code=credentialField(box,"Offline recovery code",false);
    EditText pin=credentialField(box,"New six-digit Atlas PIN",true);
    EditText confirmation=credentialField(box,"Confirm new Atlas PIN",true);
    AlertDialog dialog=credentialDialog("Recover Atlas owner access",box);if(dialog==null)return;
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
      if(!credentialFlowValid(dialog,started))return;
      if(!OwnerRecoveryPolicy.pinPairMatches(pin.getText().toString(),confirmation.getText().toString())){
        toast("Enter the same six-digit PIN twice");return;
      }
      if(!recoverOwnerPinNative(code.getText().toString(),pin.getText().toString(),confirmation.getText().toString(),started)){
        code.setText("");toast("Recovery was not accepted or is temporarily rate-limited");return;
      }
      code.setText("");pin.setText("");confirmation.setText("");dialog.dismiss();
      dispatchEvent("atlas-owner-credential-changed","{}");
      toast("PIN changed. Unlock normally, then enroll a new offline recovery code.");
    });
  }

  private void beginOwnerPinChangeNative(){
    if(!ownerPinConfiguredNative()||!ownerRequired()){toast("Unlock Atlas OS first");return;}
    final long started=SystemClock.elapsedRealtime();
    LinearLayout box=credentialBox();
    EditText current=credentialField(box,"Current Atlas PIN",true);
    EditText pin=credentialField(box,"New six-digit Atlas PIN",true);
    EditText confirmation=credentialField(box,"Confirm new Atlas PIN",true);
    AlertDialog dialog=credentialDialog("Change PIN; existing recovery will be invalidated",box);if(dialog==null)return;
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
      if(!credentialFlowValid(dialog,started)||!ownerRequired())return;
      if(!OwnerRecoveryPolicy.pinPairMatches(pin.getText().toString(),confirmation.getText().toString())){
        toast("Enter the same six-digit PIN twice");return;
      }
      synchronized(MainActivity.this){
        String old=current.getText().toString();current.setText("");
        if(!unlockOwnerNative(old)){toast("Current PIN was not accepted");dialog.dismiss();return;}
        if(!persistOwnerPinNative(pin.getText().toString(),true,"pin_changed")){toast("PIN change was not saved");return;}
      }
      pin.setText("");confirmation.setText("");dialog.dismiss();
      dispatchEvent("atlas-owner-credential-changed","{}");
      toast("PIN changed. Unlock normally, then enroll a new offline recovery code.");
    });
  }

  private boolean biometricSupportedNative(){
    if(Build.VERSION.SDK_INT<30)return false;
    try{
      BiometricManager manager=(BiometricManager)getSystemService(BIOMETRIC_SERVICE);
      return manager!=null && manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)==BiometricManager.BIOMETRIC_SUCCESS;
    }catch(Exception ignored){return false;}
  }
  private boolean biometricConfiguredNative(){return authPrefs().getBoolean(AUTH_BIOMETRIC_ENABLED,false);}

  private void beginBiometricEnrollmentNative(){
    if(!ownerPinConfiguredNative()||!ownerRequired()||!biometricSupportedNative()){
      toast("Unlock ATLAS and enroll a strong fingerprint in Android Settings first");return;
    }
    final long started=SystemClock.elapsedRealtime();
    LinearLayout box=credentialBox();
    EditText current=credentialField(box,"Confirm your ATLAS PIN",true);
    AlertDialog dialog=credentialDialog("Enable fingerprint unlock for ATLAS",box);
    if(dialog==null)return;
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
      if(!credentialFlowValid(dialog,started)||!ownerRequired())return;
      String pin=current.getText().toString();current.setText("");
      if(!unlockOwnerNative(pin)){
        toast("Incorrect ATLAS PIN; fingerprint remains disabled");dialog.dismiss();return;
      }
      if(!biometricSupportedNative()){
        toast("A strong enrolled fingerprint is required");dialog.dismiss();return;
      }
      authPrefs().edit().putBoolean(AUTH_BIOMETRIC_ENABLED,true).apply();
      dialog.dismiss();toast("Fingerprint option enabled. Your ATLAS PIN remains available.");
    });
  }
  private void requestBiometricUnlockNative(){
    if(isFinishing()||isDestroyed()||!OwnerSessionGate.isForeground()
      ||ownerLockoutSecondsNative()>0L||!ownerPinConfiguredNative()
      ||!biometricConfiguredNative()||!biometricSupportedNative()){
      toast("Fingerprint unavailable. Use the ATLAS PIN.");return;
    }
    try{
      final android.os.CancellationSignal cancel=new android.os.CancellationSignal();
      BiometricPrompt prompt=new BiometricPrompt.Builder(this)
        .setTitle("Unlock ATLAS OS")
        .setSubtitle("Owner-enabled strong fingerprint")
        .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        .setNegativeButton("Use ATLAS PIN",getMainExecutor(),(dialog,which)->cancel.cancel())
        .build();
      prompt.authenticate(cancel,getMainExecutor(),new BiometricPrompt.AuthenticationCallback(){
        @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result){
          if(isFinishing()||isDestroyed()||!biometricConfiguredNative()||!ownerPinConfiguredNative())return;
          KeyguardManager km=(KeyguardManager)getSystemService(KEYGUARD_SERVICE);
          if(km==null||km.isDeviceLocked())return;
          if(OwnerSessionGate.isForeground()){
            OwnerSessionGate.setActive(true);
            dispatchEvent("atlas-biometric-unlocked","{}");
          }else{
            biometricSuccessAt=SystemClock.elapsedRealtime();biometricPending=true;
          }
        }
        @Override public void onAuthenticationError(int code,CharSequence message){
          biometricPending=false;
          toast("Fingerprint not completed. Use your ATLAS PIN.");
        }
      });
    }catch(Exception ignored){toast("Fingerprint unavailable. Use the ATLAS PIN.");}
  }
  private int idleSeconds(){
    int secs=authPrefs().getInt(AUTH_IDLE_SEC,900);
    return secs==300||secs==900||secs==1800?secs:900;
  }
  private int graceSeconds(){
    int secs=authPrefs().getInt(AUTH_GRACE_SEC,0);
    return secs==30||secs==120?secs:0;
  }
  private String sessionPolicyJson(){
    JSONObject data=new JSONObject();
    try{
      data.put("idleSeconds",idleSeconds());data.put("returnGraceSeconds",graceSeconds());
      data.put("biometricEnabled",biometricConfiguredNative());
      data.put("biometricAvailable",biometricSupportedNative());
    }catch(Exception ignored){}
    return data.toString();
  }

  private long ownerLockoutSecondsNative(){
    long remaining=authPrefs().getLong(AUTH_LOCK_UNTIL,0L)-System.currentTimeMillis();
    return remaining<=0L?0L:(remaining+999L)/1000L;
  }

  private synchronized boolean unlockOwnerNative(String pin){
    if(rendererUnavailable||activityDestroyed||isFinishing()||isDestroyed()){OwnerSessionGate.clear();return false;}
    SharedPreferences prefs=authPrefs();
    if(!OwnerSessionGate.isForeground()||!ownerPinConfiguredNative()||!OwnerPinPolicy.validPin(pin)){ OwnerSessionGate.clear(); return false; }
    if(ownerLockoutSecondsNative()>0L){ OwnerSessionGate.clear(); return false; }
    try{
      byte[] salt=Base64.decode(prefs.getString(AUTH_SALT,""),Base64.DEFAULT);
      byte[] expected=Base64.decode(prefs.getString(AUTH_VERIFIER,""),Base64.DEFAULT);
      byte[] actual=OwnerPinPolicy.derive(pin,salt);
      if(OwnerPinPolicy.constantTimeEquals(expected,actual)){
        prefs.edit().putInt(AUTH_FAILURES,0).remove(AUTH_LOCK_UNTIL).apply();
        OwnerSessionGate.setActive(true);
        boolean active=ownerRequired();
        if(!active)OwnerSessionGate.clear();
        if(active)runOnUiThread(()->{offerPendingSeedImport();offerPendingDocumentImport();offerPendingProductImageImport();});
        return active;
      }
    }catch(Exception ignored){}
    int failures=Math.min(100,prefs.getInt(AUTH_FAILURES,0)+1);
    long delay=OwnerPinPolicy.lockoutMillisForFailures(failures);
    SharedPreferences.Editor edit=prefs.edit().putInt(AUTH_FAILURES,failures);
    if(delay>0L)edit.putLong(AUTH_LOCK_UNTIL,System.currentTimeMillis()+delay);
    edit.apply(); OwnerSessionGate.clear(); return false;
  }

  private boolean ownerRequired(){ return !rendererUnavailable&&!activityDestroyed&&!isFinishing()&&!isDestroyed()&&OwnerSessionGate.isActive(this); }
  private long captureOwnerSession(){return ownerRequired()?OwnerSessionGate.capture(this):0L;}

  /**
   * Single authenticated entry point for UI, one-shot voice and wake transcripts.
   * Trusted native call sites assign origin. Workflow recognition never directly reaches
   * CommandRouter; only an authenticated LOCAL_DEVICE route is eligible for that lane.
   */
  private synchronized String routeAuthenticatedInput(String command,WorkflowIntentParser.Origin origin){
    boolean authenticated=ownerRequired();
    if(authenticated)OwnerSessionGate.touch();
    // This local-command lane never initiates online requests. The separate Brain
    // panel requires a native preview and explicit confirmation for every question.
    boolean backendConnected=false;
    boolean persistenceConfirmed=false; // Command creation cannot be claimed until durable persistence returns success.
    WorkflowPlanner.Origin plannerOrigin=origin==WorkflowIntentParser.Origin.REFERENCE_DATA?WorkflowPlanner.Origin.REFERENCE_DATA:WorkflowPlanner.Origin.TRUSTED_INPUT;
    WorkflowPlanner.Plan workflowPlan=workflowPlanner.preview(command,plannerOrigin,authenticated,OwnerSessionGate.isForeground(),SystemClock.elapsedRealtime());
    AuthenticatedInputRouter.Result routed=AuthenticatedInputRouter.route(
      command,origin,authenticated,persistenceConfirmed,backendConnected);
    String localResult="";
    boolean localRouterInvoked=false;
    if(routed.route==AuthenticatedInputRouter.Route.LOCAL_DEVICE&&routed.shouldExecuteLocal
        &&OwnerSessionGate.isActive(this)){
      OwnerSessionGate.touch();
      localRouterInvoked=true;
      localResult=CommandRouter.run(this,command);
    }
    JSONObject out=routeJson(routed,localResult,localRouterInvoked,workflowPlan);
    appendRoutingAudit(routed,localResult,localRouterInvoked);
    return out.toString();
  }

  private JSONObject routeJson(AuthenticatedInputRouter.Result routed,String localResult,boolean localRouterInvoked,WorkflowPlanner.Plan workflowPlan){
    JSONObject out=new JSONObject();
    try{
      out.put("schemaVersion","1.0");
      out.put("registrySha256",WorkflowCommandCatalog.REGISTRY_SHA256);
      out.put("catalogEntries",WorkflowCommandCatalog.TOTAL_ENTRIES);
      out.put("requestId","route-"+System.currentTimeMillis()+"-"+Integer.toHexString(
        routed.original==null?0:routed.original.hashCode()));
      out.put("original",routed.original==null?"":routed.original);
      out.put("origin",routed.origin==null?"":routed.origin.name());
      out.put("route",routed.route.name());
      out.put("statusLine",routed.statusLine);
      out.put("recognition",routed.recognition.label);
      out.put("recognitionEmoji",routed.recognition.emoji);
      out.put("authenticated",routed.authenticated);
      out.put("requiresBackend",routed.requiresBackend);
      out.put("backendConnected",routed.backendConnected);
      out.put("persistenceConfirmed",routed.persistenceConfirmed);
      out.put("grantsExecution",routed.grantsExecution);
      out.put("localRouterInvoked",localRouterInvoked);
      out.put("localKind",routed.local==null?"":routed.local.kind.name());
      out.put("localResult",localResult==null?"":localResult);
      out.put("frame",VoiceFrameClassifier.classifyName(routed.original));
      JSONArray ids=new JSONArray();for(String id:routed.commandIds)ids.put(id);out.put("commandIds",ids);
      JSONArray stack=new JSONArray();for(String label:routed.commandStack)stack.put(label);out.put("commandStack",stack);
      JSONArray constraints=new JSONArray();for(String guard:routed.constraints)constraints.put(guard);out.put("constraints",constraints);
      if(workflowPlan!=null){
        out.put("workflowPlanStatus",workflowPlan.status.name());
        out.put("workflowContextCarried",!workflowPlan.previousText.isEmpty());
        out.put("workflowPreviousText",workflowPlan.previousText);
        JSONArray planConstraints=new JSONArray();for(String guard:workflowPlan.constraints)planConstraints.put(guard);out.put("workflowPlanConstraints",planConstraints);
      }
      String outcome=routeOutcome(routed,localResult);
      if(workflowPlan!=null&&workflowPlan.status==WorkflowPlanner.Status.NEEDS_CONTEXT)outcome=workflowPlan.message;
      else if(workflowPlan!=null&&!workflowPlan.previousText.isEmpty()&&routed.route==AuthenticatedInputRouter.Route.WORKFLOW_HANDOFF)outcome=workflowPlan.message;
      // Informational GOD recognition metadata only. A locked or reference-data
      // request never advertises GOD activation; no action authorization is added.
      GodCommandPolicy.Result god = GodCommandPolicy.parse(routed.original);
      boolean godVisible = routed.authenticated
        && routed.origin != WorkflowIntentParser.Origin.REFERENCE_DATA
        && routed.route == AuthenticatedInputRouter.Route.BRAIN_HANDOFF
        && god.activated;
      JSONObject godMode=new JSONObject();
      godMode.put("activated",godVisible);
      godMode.put("version","GODFORGE_V3");
      godMode.put("scope",godVisible?god.scope.name():"NONE");
      godMode.put("needsContext",godVisible&&god.needsContext);
      godMode.put("authorityGranted",false);
      godMode.put("isExecution",false);
      out.put("godMode",godMode);
      if(godVisible && !routed.backendConnected){
        outcome=god.needsContext
          ? "GOD V3 recognized the reference to a prior task. No private brain backend is connected; no work was performed."
          : "GOD V3 recognized your command. The private ATLAS brain is disconnected; no work was performed.";
      }
      out.put("outcome",outcome);
      out.put("interface",interfaceJson(routed,localRouterInvoked));
    }catch(Exception ignored){}
    return out;
  }

  private JSONObject interfaceJson(AuthenticatedInputRouter.Result routed,boolean localRouterInvoked){
    JSONObject out=new JSONObject();
    try{
      HumanInterfacePolicy.Output state=HumanInterfacePolicy.fromRoute(
        routed,localRouterInvoked,false,HumanInterfacePolicy.SensorState.unknown());
      out.put("expressiveState",state.expressiveState.name());
      out.put("statusMarker",state.primaryStatusMarker);
      out.put("speechRate",state.speechRate);
      out.put("pitchMultiplier",state.pitchMultiplier);
      out.put("energy",state.energy);
      out.put("pauseMs",state.pauseMs);
      out.put("textDensity",state.textDensity);
      out.put("eyeMotion",state.eyeMotion);
      out.put("hapticSignal",state.hapticSignal);
      out.put("lightSignal",state.lightSignal);
      out.put("interruptibility",state.interruptibility);
      out.put("confirmationRequired",state.confirmationRequired);
      out.put("showProgressAnimation",state.showProgressAnimation);
      out.put("privacyIndicator",state.privacyIndicator);
      out.put("authorityChangeAllowed",state.authorityChangeAllowed);
      out.put("emotionDiagnosisAllowed",state.emotionDiagnosisAllowed);
      out.put("consciousnessClaimAllowed",state.consciousnessClaimAllowed);
    }catch(Exception ignored){}
    return out;
  }

  private String routeOutcome(AuthenticatedInputRouter.Result routed,String localResult){
    switch(routed.route){
      case LOCKED:return "Unlock Atlas OS before using private commands or device actions.";
      case INVALID:return "That input was rejected as empty, malformed, unsafe, or too long.";
      case SOURCE_DATA:return "The text was preserved as reference data and was not executed.";
      case LOCAL_DEVICE:return localResult==null||localResult.isEmpty()?"The local command router returned no result.":localResult;
      case WORKFLOW_HANDOFF:
        if(routed.workflow.persistenceRequested&&!routed.persistenceConfirmed)
          return "The reusable-command request was recognized, but no command was saved because durable persistence is not connected.";
        return routed.backendConnected?"The authenticated workflow handoff is ready.":
          "The command was recognized, but the authenticated ATLAS brain backend is not connected in this source candidate.";
      case BRAIN_HANDOFF:return routed.backendConnected?"The authenticated brain handoff is ready.":
        "This normal request needs the authenticated ATLAS brain backend, which is not connected in this source candidate.";
      default:return "No route was selected.";
    }
  }

  /** Bounded metadata-only audit. Raw owner text is deliberately not stored here. */
  private void appendRoutingAudit(AuthenticatedInputRouter.Result routed,String localResult,boolean localRouterInvoked){
    try{
      SharedPreferences prefs=getSharedPreferences("atlas_routing_audit_v1",MODE_PRIVATE);
      JSONArray prior;
      try{prior=new JSONArray(prefs.getString("events","[]"));}catch(Exception e){prior=new JSONArray();}
      JSONArray bounded=new JSONArray();
      for(int i=Math.max(0,prior.length()-99);i<prior.length();i++)bounded.put(prior.opt(i));
      JSONObject row=new JSONObject();
      row.put("at_ms",System.currentTimeMillis());
      row.put("origin",routed.origin==null?"":routed.origin.name());
      row.put("route",routed.route.name());
      row.put("recognition",routed.recognition.label);
      row.put("input_length",routed.original==null?0:routed.original.length());
      JSONArray ids=new JSONArray();for(String id:routed.commandIds)ids.put(id);row.put("command_ids",ids);
      row.put("local_kind",routed.local==null?"":routed.local.kind.name());
      row.put("local_router_invoked",localRouterInvoked);
      String code=localResult==null?"":localResult;
      int colon=code.indexOf(':');if(colon>=0)code=code.substring(0,colon);
      row.put("local_result_code",code);
      bounded.put(row);
      prefs.edit().putString("events",bounded.toString()).apply();
    }catch(Exception ignored){}
  }

  /** Explicit native owner approval; recent-app package IDs never cross the JS bridge. */
  private void showRecentAppsOnceNative(){
    if(!ownerPinConfiguredNative()||!ownerRequired()){toast("Unlock Atlas OS first");return;}
    final long started=SystemClock.elapsedRealtime();
    final long initial=captureOwnerSession();
    LinearLayout box=credentialBox();
    TextView disclosure=new TextView(this);
    disclosure.setText("Read up to 15 minutes of recently opened app package names once, on this phone. "
      +"No screen text, passwords or app contents. Nothing is saved, sent or monitored in the background. "
      +"Android Usage Access must also be granted manually.");
    box.addView(disclosure);
    EditText current=credentialField(box,"Confirm current Atlas PIN",true);
    AlertDialog dialog=credentialDialog("Private app awareness — one-time review",box);
    if(dialog==null)return;
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
      if(!credentialFlowValid(dialog,started)||!OwnerSessionGate.isCurrent(this,initial))return;
      String pin=current.getText().toString();current.setText("");
      if(!unlockOwnerNative(pin)){dialog.dismiss();toast("PIN not accepted");return;}
      final long verified=captureOwnerSession();
      dialog.dismiss();
      if(!OwnerSessionGate.isCurrent(this,verified))return;
      if(!AppUsageReader.hasSpecialAccess(this)){
        new AlertDialog.Builder(this).setTitle("Android Usage Access required")
          .setMessage("Only you can grant or revoke Usage Access in Android Settings. "
            +"Return and unlock Atlas again after changing it. No access was granted automatically.")
          .setNegativeButton("Not now",null)
          .setPositiveButton("Open Android Settings",(d,w)->{
            if(!OwnerSessionGate.isCurrent(this,verified))return;
            try{startActivity(new Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS));}
            catch(RuntimeException e){toast("Usage Access settings unavailable");}
          }).show();
        return;
      }
      final java.util.List<String> apps=AppUsageReader.readOnce(this,verified);
      if(!OwnerSessionGate.isCurrent(this,verified))return;
      StringBuilder output=new StringBuilder();
      if(apps.isEmpty())output.append("No readable events in this 15-minute window, or Android refused access.");
      else {
        for(int i=0;i<apps.size();i++)output.append(i+1).append(". ").append(apps.get(i)).append('\n');
        output.append("\nPackage names only. This cannot see app logins, screen content, or messages.");
      }
      new AlertDialog.Builder(this).setTitle("Recent apps — local one-time result")
        .setMessage(output.toString()).setPositiveButton("Close",null).show();
    });
  }

  public class Bridge {
    @JavascriptInterface public String insightsSnapshot(){
      final long session=captureOwnerSession();
      if(!learningForeground||!OwnerSessionGate.isCurrent(MainActivity.this,session))return "{\"status\":\"locked\"}";
      String result=AtlasDeviceInsights.snapshot(MainActivity.this).toString();
      return OwnerSessionGate.isCurrent(MainActivity.this,session)?result:"{\"status\":\"locked\"}";
    }
    @JavascriptInterface public void insightsSetTracking(boolean enabled){
      final long session=captureOwnerSession();
      runOnUiThread(()->{
        if(!learningForeground||!OwnerSessionGate.isCurrent(MainActivity.this,session)){toast("Unlock ATLAS first");return;}
        if(!enabled){
          JSONObject result=AtlasDeviceInsights.setTracking(MainActivity.this,false);
          dispatchEvent("atlas-insights-updated",result.toString());
          toast("ok".equals(result.optString("actionStatus"))?"Battery history stopped; saved samples retained":
            "tracking_stop_not_persisted".equals(result.optString("error"))?"Sampling stopped for now; saving the setting failed. Open Device for details.":"Battery tracking could not be changed. Unlock ATLAS and try again.");return;
        }
        new AlertDialog.Builder(MainActivity.this).setTitle("Save battery history?")
          .setMessage("Save battery percentage and charging state locally, including occasional background samples while ATLAS is closed. Android may delay sampling. This does not read your screen, typing or other app contents. History is encrypted on this phone and bounded. You can stop future sampling in Device.")
          .setNegativeButton("Not now",null)
          .setPositiveButton("Start battery history",(dialog,which)->{
            if(!learningForeground||!OwnerSessionGate.isCurrent(MainActivity.this,session))return;
            JSONObject result=AtlasDeviceInsights.setTracking(MainActivity.this,true);
            dispatchEvent("atlas-insights-updated",result.toString());
            toast("ok".equals(result.optString("actionStatus"))?"Battery history enabled":"Battery history could not start; open Device for details");
          }).show();
      });
    }
    @JavascriptInterface public String insightsUsageToday(){
      final long session=captureOwnerSession();
      if(!learningForeground||!OwnerSessionGate.isCurrent(MainActivity.this,session))return "{\"status\":\"locked\"}";
      String result=AtlasDeviceInsights.usageToday(MainActivity.this).toString();
      return OwnerSessionGate.isCurrent(MainActivity.this,session)?result:"{\"status\":\"locked\"}";
    }
    @JavascriptInterface public void insightsUsageSettings(){
      final long session=captureOwnerSession();
      runOnUiThread(()->{
        if(!learningForeground||!OwnerSessionGate.isCurrent(MainActivity.this,session)){toast("Unlock ATLAS first");return;}
        new AlertDialog.Builder(MainActivity.this).setTitle("Android screen-time access")
          .setMessage("Android Usage Access lets ATLAS read app foreground durations when you choose Load today's usage. App content and typed text are not read. Grant or revoke access yourself in Android Settings, then return and unlock ATLAS.")
          .setNegativeButton("Cancel",null).setPositiveButton("Open settings",(dialog,which)->{
            if(!OwnerSessionGate.isCurrent(MainActivity.this,session))return;
            try{startActivity(new Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS));}
            catch(RuntimeException missing){toast("Usage Access settings unavailable");}
          }).show();
      });
    }
    @JavascriptInterface public String captureStatus(){
      final long session=captureOwnerSession();
      if(!learningForeground||!OwnerSessionGate.isCurrent(MainActivity.this,session))return "{\"status\":\"locked\",\"state\":\"locked\"}";
      String result;
      try{result=AtlasCaptureService.snapshot(MainActivity.this).toString();}
      catch(Exception unavailable){result="{\"status\":\"error\",\"state\":\"error\",\"message\":\"Recording history is unavailable. Existing files are preserved.\"}";}
      return OwnerSessionGate.isCurrent(MainActivity.this,session)?result:"{\"status\":\"locked\",\"state\":\"locked\"}";
    }
    @JavascriptInterface public void captureStart(){
      final long session=captureOwnerSession();
      runOnUiThread(()->{
        if(!learningForeground||!OwnerSessionGate.isCurrent(MainActivity.this,session)){toast("Unlock ATLAS first");return;}
        try{startActivity(AtlasCaptureActivity.createSessionIntent(MainActivity.this));}
        catch(RuntimeException unavailable){toast("Screen recording is unavailable. Reopen Activity and try again.");}
      });
    }
    @JavascriptInterface public void captureStop(){
      runOnUiThread(()->AtlasCaptureService.requestStop(MainActivity.this));
    }
    @JavascriptInterface public void capturePlay(String id){
      final long session=captureOwnerSession();
      runOnUiThread(()->{
        if(!learningForeground||!OwnerSessionGate.isCurrent(MainActivity.this,session)){toast("Unlock ATLAS first");return;}
        try{startActivity(AtlasCaptureActivity.createPlaybackIntent(MainActivity.this,id));}
        catch(RuntimeException unavailable){toast("This recording could not be opened");}
      });
    }
    @JavascriptInterface public void captureDelete(String id){
      final long session=captureOwnerSession();
      runOnUiThread(()->{
        if(!learningForeground||!OwnerSessionGate.isCurrent(MainActivity.this,session)){toast("Unlock ATLAS first");return;}
        try{startActivity(AtlasCaptureActivity.createDeleteIntent(MainActivity.this,id));}
        catch(RuntimeException unavailable){toast("This recording could not be selected for removal");}
      });
    }
    @JavascriptInterface public String ownerRecordsRequest(String request){
      final long session=captureOwnerSession();
      OwnerRecordStore.Access access=()->learningForeground&&OwnerSessionGate.isCurrent(MainActivity.this,session);
      if(!access.allowed())return "{\"status\":\"locked\"}";
      if(ownerRecords==null)return "{\"status\":\"unavailable\"}";
      if(request==null||request.length()>OwnerRecordStore.MAX_BYTES*6+1024)return "{\"status\":\"invalid\"}";
      try{
        JSONObject input=new JSONObject(request);
        Object operation=input.opt("op"),key=input.opt("key");
        if(!(operation instanceof String)||!(key instanceof String))return "{\"status\":\"invalid\"}";
        // Credentials are native-only even though they share the encrypted record format.
        if(AtlasBrainController.PRIVATE_RECORD.equals(key))return "{\"status\":\"invalid\"}";
        OwnerRecordStore.Result result;
        if("read".equals(operation))result=ownerRecords.read((String)key,access);
        else if("write".equals(operation)){
          Object value=input.opt("value"),expected=input.opt("expectedRevision");
          if(!(value instanceof String)||!(expected instanceof Number))return "{\"status\":\"invalid\"}";
          double revision=((Number)expected).doubleValue();
          if(Double.isNaN(revision)||Double.isInfinite(revision)||revision<0||revision>=OwnerRecordStore.MAX_REVISION||revision!=Math.floor(revision))return "{\"status\":\"invalid\"}";
          result=ownerRecords.write((String)key,(String)value,(long)revision,access);
        }else return "{\"status\":\"invalid\"}";
        if(!access.allowed())return "{\"status\":\"locked\"}";
        JSONObject output=new JSONObject().put("status",result.status);
        if("ok".equals(result.status)){
          output.put("revision",result.revision);
          if("read".equals(operation))output.put("value",result.value==null?JSONObject.NULL:result.value);
        }
        return output.toString();
      }catch(Exception invalid){return access.allowed()?"{\"status\":\"invalid\"}":"{\"status\":\"locked\"}";}
    }
    @JavascriptInterface public void openBookmarkedUrl(String url){
      final long session=captureOwnerSession();
      final String safe=BookmarkedUrlPolicy.validated(url);
      runOnUiThread(()->{
        if(!learningForeground||!OwnerSessionGate.isCurrent(MainActivity.this,session)){toast("Unlock ATLAS first");return;}
        if(safe==null){toast("Enter a valid HTTPS address without a username or password");return;}
        if(bookmarkDialog!=null)bookmarkDialog.dismiss();
        bookmarkDialog=new AlertDialog.Builder(MainActivity.this).setTitle("Open in browser or app?")
          .setMessage("This leaves ATLAS and may use the internet. Nothing opens until you choose Open.\n\n"+safe)
          .setNegativeButton("Cancel",null).setPositiveButton("Open",(dialog,which)->{
            if(!learningForeground||!OwnerSessionGate.isCurrent(MainActivity.this,session)){toast("Unlock ATLAS and try again");return;}
            try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(safe)).addCategory(Intent.CATEGORY_BROWSABLE));}
            catch(ActivityNotFoundException missing){toast("No browser or app can open that address");}
            catch(Exception failure){toast("Unable to open that address");}
          }).create();
        bookmarkDialog.setOnDismissListener(dialog->bookmarkDialog=null);
        bookmarkDialog.show();
      });
    }
    @JavascriptInterface public String humanLearningRequest(String request){
      if(humanLearning==null)return "{\"ok\":false,\"error\":\"STORAGE_UNAVAILABLE\"}";
      return humanLearning.request(request);
    }
    @JavascriptInterface public void openAtlasOne(){ runOnUiThread(()->{
      if(!ownerRequired()){toast("Unlock ATLAS first");return;}
      startActivity(new Intent(MainActivity.this,AtlasModulesActivity.class));
    }); }
    @JavascriptInterface public void openAtlasCleanup(){ runOnUiThread(()->{
      if(!ownerRequired()){toast("Unlock ATLAS first");return;}
      startActivity(new Intent(MainActivity.this,AtlasCleanupActivity.class));
    }); }
    @JavascriptInterface public boolean isNative(){ return true; }
    @JavascriptInterface public String viewportInfo(){return viewportInfoNative();}
    @JavascriptInterface public void openAccessCenter(){
      final long session=captureOwnerSession();
      runOnUiThread(()->{
        if(!OwnerSessionGate.isCurrent(MainActivity.this,session)){
          toast("Unlock ATLAS first");return;
        }
        try{startActivity(new Intent(MainActivity.this,AtlasAccessCenterActivity.class));}
        catch(RuntimeException error){toast("Access Center unavailable. Use Android App settings.");}
      });
    }
    @JavascriptInterface public String accessStatusJson(){
      if(!ownerRequired())return "{\"status\":\"locked\"}";
      return AtlasAccessStatus.snapshot(MainActivity.this);
    }
    @JavascriptInterface public void openNativeApp(String kind){
      final long session=captureOwnerSession();
      runOnUiThread(()->openNativeAppNative(kind,session));
    }
    @JavascriptInterface public String installedApps(){return installedAppsNative();}
    @JavascriptInterface public void openInstalledApp(String id){
      final long session=captureOwnerSession();
      runOnUiThread(()->openInstalledAppNative(id,session));
    }
    @JavascriptInterface public void showRecentAppsOnce(){ runOnUiThread(()->showRecentAppsOnceNative()); }
    @JavascriptInterface public String deviceStatus(){
      JSONObject o=new JSONObject();
      try{
        BatteryManager bm=(BatteryManager)getSystemService(BATTERY_SERVICE);
        int pct=bm==null?-1:bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        if(pct>=0&&pct<=100)o.put("battery",pct);
        o.put("model",Build.MODEL==null?"":Build.MODEL);
        o.put("sdk",Build.VERSION.SDK_INT);
        o.put("charging",bm!=null&&bm.isCharging());
        ConnectivityManager connectivity=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        NetworkCapabilities capabilities=connectivity==null?null:connectivity.getNetworkCapabilities(connectivity.getActiveNetwork());
        o.put("online",capabilities!=null&&capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED));
        o.put("network",capabilities==null?"offline":capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)?"wifi":
          capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)?"cellular":capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)?"ethernet":"connected");
      }catch(Exception ignored){}
      return o.toString();
    }
    @JavascriptInterface public void openUrl(String u){ runOnUiThread(()->{
      if(!ownerRequired()){ toast("Unlock Atlas OS first"); return; }
      if(!ExternalTargetPolicy.isExactTargetAllowed(u,SAFE_EXTERNAL_URLS)){ toast("Blocked unapproved external link"); return; }
      OwnerSessionGate.touch();
      try{
        Uri uri=Uri.parse(u); Intent i=new Intent(Intent.ACTION_VIEW,uri);
        if(i.resolveActivity(getPackageManager())==null){ toast("No app can open that link"); return; }
        startActivity(i);
      }catch(Exception e){ toast("Unable to open link"); }
    }); }
    @JavascriptInterface public void dial(String n){ runOnUiThread(()->{
      if(!ownerRequired()){ toast("Unlock Atlas OS first"); return; } OwnerSessionGate.touch();
      String safe=n==null?"":n.replaceAll("[^0-9+#*]","");
      if(safe.isEmpty()){ toast("Missing phone number"); return; }
      try{ startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+safe))); }catch(Exception e){ toast("Dialer unavailable"); }
    }); }
    @JavascriptInterface public void openSystemPanel(String kind){
      final long session=captureOwnerSession();
      runOnUiThread(()->{
        if(!OwnerSessionGate.isCurrent(MainActivity.this,session)){toast("Unlock ATLAS first");return;}
        String action;
        if("wifi".equals(kind))action=android.provider.Settings.Panel.ACTION_WIFI;
        else if("internet".equals(kind))action=android.provider.Settings.Panel.ACTION_INTERNET_CONNECTIVITY;
        else if("bt".equals(kind)||"bluetooth".equals(kind))action=android.provider.Settings.ACTION_BLUETOOTH_SETTINGS;
        else if("air".equals(kind)||"airplane".equals(kind))action=android.provider.Settings.ACTION_AIRPLANE_MODE_SETTINGS;
        else if("volume".equals(kind)||"sound".equals(kind))action=android.provider.Settings.Panel.ACTION_VOLUME;
        else if("display".equals(kind)||"brightness".equals(kind))action=android.provider.Settings.ACTION_DISPLAY_SETTINGS;
        else if("notifications".equals(kind))action=android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS;
        else if("apps".equals(kind))action=android.provider.Settings.ACTION_APPLICATION_SETTINGS;
        else if("home".equals(kind))action=android.provider.Settings.ACTION_HOME_SETTINGS;
        else if("battery".equals(kind))action=android.provider.Settings.ACTION_BATTERY_SAVER_SETTINGS;
        else if("accessibility".equals(kind))action=android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS;
        else if("settings".equals(kind)||"all".equals(kind))action=android.provider.Settings.ACTION_SETTINGS;
        else {toast("Unknown system setting");return;}
        OwnerSessionGate.touch();
        Intent intent=new Intent(action);
        if("notifications".equals(kind))intent.putExtra(android.provider.Settings.EXTRA_APP_PACKAGE,getPackageName());
        try{startActivity(intent);}catch(ActivityNotFoundException missing){toast("This setting is unavailable on this device");}
        catch(RuntimeException failure){toast("Unable to open Android Settings");}
      });
    }
    @JavascriptInterface public void requestAssistantRole(){ runOnUiThread(()->{ if(!ownerRequired()){toast("Unlock Atlas OS first");return;} OwnerSessionGate.touch(); try{ RoleManager rm=(RoleManager)getSystemService(ROLE_SERVICE); if(rm!=null&&rm.isRoleAvailable(RoleManager.ROLE_ASSISTANT)&&!rm.isRoleHeld(RoleManager.ROLE_ASSISTANT)) startActivity(rm.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT)); else toast("ATLAS assistant role is already active or unavailable"); }catch(Exception e){ toast("Assistant role unavailable"); }}); }
    @JavascriptInterface public void startHeyAtlas(){ runOnUiThread(()->{ if(!ownerRequired()){toast("Unlock Atlas OS first");return;} OwnerSessionGate.touch(); wakeRequested=true; if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_WAKE); return; } startWakeService(true); wakeRequested=false; }); }
    @JavascriptInterface public void stopHeyAtlas(){ runOnUiThread(()->{ Intent i=new Intent(MainActivity.this,AtlasWakeService.class).setAction(AtlasWakeService.ACTION_STOP); try{startService(i);}catch(Exception ignored){stopService(new Intent(MainActivity.this,AtlasWakeService.class));} toast("Hey Atlas stopped"); }); }
    @JavascriptInterface public boolean heyAtlasEnabled(){ return getSharedPreferences("atlas",MODE_PRIVATE).getBoolean("wake_enabled",false); }
    @JavascriptInterface public boolean biometricQuickUnlockAvailable(){
      return ownerPinConfiguredNative()&&biometricConfiguredNative()&&biometricSupportedNative();
    }
    @JavascriptInterface public void requestBiometricUnlock(){runOnUiThread(()->requestBiometricUnlockNative());}
    @JavascriptInterface public void beginBiometricEnrollment(){
      runOnUiThread(()->beginBiometricEnrollmentNative());
    }
    @JavascriptInterface public boolean disableBiometricUnlock(){
      if(!ownerRequired())return false;
      return authPrefs().edit().putBoolean(AUTH_BIOMETRIC_ENABLED,false).commit();
    }
    @JavascriptInterface public String ownerSessionPolicy(){return ownerRequired()?sessionPolicyJson():"{}";}
    @JavascriptInterface public boolean setOwnerSessionPolicy(int idle,int grace){
      if(!ownerRequired()||!(idle==300||idle==900||idle==1800)||!(grace==0||grace==30||grace==120))return false;
      if(!authPrefs().edit().putInt(AUTH_IDLE_SEC,idle).putInt(AUTH_GRACE_SEC,grace).commit())return false;
      return OwnerSessionGate.setIdleTimeoutSeconds(idle);
    }
    @JavascriptInterface public String homeRoleStatus(){
      if(!ownerRequired())return "LOCKED";
      try{
        RoleManager rm=(RoleManager)getSystemService(ROLE_SERVICE);
        if(rm==null||!rm.isRoleAvailable(RoleManager.ROLE_HOME))return "UNAVAILABLE";
        return rm.isRoleHeld(RoleManager.ROLE_HOME)?"ATLAS_SELECTED":"OTHER_SELECTED";
      }catch(Exception ignored){return "UNAVAILABLE";}
    }
    @JavascriptInterface public boolean ownerPinConfigured(){ return ownerPinConfiguredNative(); }
    @JavascriptInterface public boolean configureOwnerPinConfirmed(String pin,String confirmation){ return configureOwnerPinNative(pin,confirmation); }
    @JavascriptInterface public boolean ownerRecoveryConfigured(){ return recoveryConfiguredNative(); }
    @JavascriptInterface public void beginOwnerRecoveryEnrollment(){ runOnUiThread(()->beginOwnerRecoveryEnrollmentNative()); }
    @JavascriptInterface public void beginOwnerRecovery(){ runOnUiThread(()->beginOwnerRecoveryNative()); }
    @JavascriptInterface public void beginOwnerPinChange(){ runOnUiThread(()->beginOwnerPinChangeNative()); }
    @JavascriptInterface public boolean unlockOwner(String pin){ return unlockOwnerNative(pin); }
    @JavascriptInterface public long ownerLockoutSeconds(){ return ownerLockoutSecondsNative(); }
    @JavascriptInterface public void lockOwnerSession(){ workflowPlanner.clear(); OwnerSessionGate.clear(); runOnUiThread(()->{if(brain!=null)brain.suspend();stopPrivateMedia();dispatchEvent("atlas-learning-locked","{}");}); }
    @JavascriptInterface public boolean ownerSessionActive(){ return ownerRequired(); }
    @JavascriptInterface public String brainStatus(){return brain==null?"{\"status\":\"unavailable\"}":brain.status();}
    @JavascriptInterface public void brainConfigure(){if(brain!=null)brain.configure();}
    @JavascriptInterface public void brainTest(){if(brain!=null)brain.test();}
    @JavascriptInterface public void brainAsk(String text,String relativeFile){if(brain!=null)brain.ask(text,relativeFile);}
    @JavascriptInterface public void brainCancel(){if(brain!=null)brain.cancel();}
    @JavascriptInterface public void brainDisconnect(){if(brain!=null)brain.disconnect();}
    @JavascriptInterface public String classifyFrame(String text){ return VoiceFrameClassifier.classifyName(text); }
    @JavascriptInterface public String routeTextInput(String command){
      return routeAuthenticatedInput(command,WorkflowIntentParser.Origin.UI_TEXT);
    }
    /** Owner-gated, digest-pinned encrypted private goals. Never served from APK assets. */
    @JavascriptInterface public String godPrivateIndex(){
      final long session=captureOwnerSession();
      if(session==0L)return "{\"status\":\"locked\"}";
      try{
        VaultSearchReader.Listing listing=VaultSearchReader.list(vaultRoot(),
          ()->OwnerSessionGate.isCurrent(MainActivity.this,session));
        java.util.List<String> candidates=GodPrivateIndexPolicy.candidatePaths(listing.paths);
        if(listing.truncated)return "{\"status\":\"incomplete_inventory\"}";
        if(candidates.size()==0)return "{\"status\":\"not_imported\"}";
        if(candidates.size()>8)return "{\"status\":\"ambiguous\"}";
        String known=null;
        for(String path:candidates){
          String value=VaultSearchReader.read(vaultRoot(),path,vaultKey(),
            ()->OwnerSessionGate.isCurrent(MainActivity.this,session));
          if(!GodPrivateIndexPolicy.trustedContent(value))return "{\"status\":\"untrusted_source\"}";
          if(known!=null && !known.equals(value))return "{\"status\":\"ambiguous\"}";
          known=value;
        }
        JSONObject index=new JSONObject(known);
        if(!"atlas.god.private.index.v1".equals(index.optString("schema")))
          return "{\"status\":\"invalid_schema\"}";
        JSONArray goals=index.optJSONArray("goals");
        if(goals==null || goals.length()!=56)return "{\"status\":\"invalid_schema\"}";
        java.util.Set<String> ids=new java.util.HashSet<>();
        for(int i=0;i<goals.length();i++){
          JSONObject row=goals.optJSONObject(i);
          if(row==null || !row.optString("id").matches("G[0-9]{2}")
             || !ids.add(row.optString("id")))return "{\"status\":\"invalid_schema\"}";
        }
        if(!OwnerSessionGate.isCurrent(MainActivity.this,session))return "{\"status\":\"locked\"}";
        OwnerSessionGate.touch();
        return new JSONObject().put("status","ready").put("count",goals.length())
          .put("content_sha256",GodPrivateIndexPolicy.EXPECTED_SHA256)
          .put("goals",goals).toString();
      }catch(VaultSearchReader.Rejected rejected){
        if("locked".equals(rejected.status))return "{\"status\":\"locked\"}";
        return "{\"status\":\"unreadable\"}";
      }catch(Exception ex){return "{\"status\":\"unreadable\"}";}
    }
    @JavascriptInterface public String semanticCommandCatalog(){
      if(!OwnerSessionGate.isActive(MainActivity.this))return "[]";
      OwnerSessionGate.touch();
      JSONArray rows=new JSONArray();
      try{
        for(WorkflowCommandCatalog.Entry entry:WorkflowCommandCatalog.all()){
          JSONObject row=new JSONObject();row.put("id",entry.id);row.put("command",entry.canonical);row.put("category",entry.category);
          JSONArray aliases=new JSONArray();for(String alias:entry.aliases)aliases.put(alias);row.put("aliases",aliases);rows.put(row);
        }
      }catch(Exception ignored){}
      return rows.toString();
    }
    /** Legacy device-control bridge retained for fixed local controls; it now passes the same gateway. */
    @JavascriptInterface public String runCommand(String command){
      try{
        JSONObject routed=new JSONObject(routeAuthenticatedInput(command,WorkflowIntentParser.Origin.UI_TEXT));
        String route=routed.optString("route","");
        if("LOCKED".equals(route))return "OWNER_UNLOCK_REQUIRED";
        if("INVALID".equals(route))return "INVALID_COMMAND";
        if("LOCAL_DEVICE".equals(route))return routed.optString("localResult","COMMAND_FAILED");
        if("WORKFLOW_HANDOFF".equals(route))return "WORKFLOW_HANDOFF_REQUIRED";
        return "NO_LOCAL_MATCH";
      }catch(Exception e){return "COMMAND_FAILED";}
    }
    @JavascriptInterface public void listenOnce(){ runOnUiThread(()->{ if(!OwnerSessionGate.isActive(MainActivity.this)){ voiceEvent("LOCKED","Unlock Atlas OS to use private voice."); return; } OwnerSessionGate.touch(); requestVoiceTurn(); }); }
    @JavascriptInterface public void stopListening(){ runOnUiThread(()->{ voiceStartGeneration++; if(voiceRecognizer!=null){ try{voiceRecognizer.cancel();}catch(Exception ignored){} } restoreWakeAfterVoiceTurn(); voiceEvent("READY",""); }); }
    @JavascriptInterface public void speak(String text){ runOnUiThread(()->{ if(!ownerRequired())return; OwnerSessionGate.touch(); speakText(text); }); }
    @JavascriptInterface public void stopSpeaking(){ runOnUiThread(()->{ if(tts!=null)tts.stop(); voiceEvent("READY",""); }); }
    @JavascriptInterface public boolean isSpeaking(){ return tts!=null&&tts.isSpeaking(); }
    @JavascriptInterface public void importSeedZip(){runOnUiThread(()->beginZipImport(false));}
    @JavascriptInterface public void importChatGPTArchive(){runOnUiThread(()->beginZipImport(true));}
    @JavascriptInterface public String importStatus(){
      if(!ownerRequired())return "{\"status\":\"locked\"}";
      return getSharedPreferences("atlas_import_reports",MODE_PRIVATE).getString("last","{\"status\":\"idle\"}");
    }
    @JavascriptInterface public String storageStatus(){
      if(!ownerRequired())return "{\"status\":\"locked\"}";
      OwnerSessionGate.touch();
      try{
        StatFs stats=new StatFs(getFilesDir().getAbsolutePath());
        VaultSearchReader.Listing listing=VaultSearchReader.list(vaultRoot(),()->ownerRequired());
        long encryptedBytes=0L;
        File base=vaultRoot();
        for(String path:listing.paths){
          if(!ownerRequired())return "{\"status\":\"locked\"}";
          String safe=SeedImportPolicy.safeRelative(path+".atlasenc");
          if(safe==null)continue;
          File file=new File(base,safe);
          if(java.nio.file.Files.isRegularFile(file.toPath(),java.nio.file.LinkOption.NOFOLLOW_LINKS)){
            long bytes=file.length();
            if(bytes>0)encryptedBytes=Long.MAX_VALUE-encryptedBytes<bytes?Long.MAX_VALUE:encryptedBytes+bytes;
          }
        }
        if(!ownerRequired())return "{\"status\":\"locked\"}";
        JSONObject out=new JSONObject();
        out.put("status","ok");out.put("localFinite",true);
        out.put("totalBytes",stats.getTotalBytes());out.put("availableBytes",stats.getAvailableBytes());
        out.put("vaultEncryptedBytes",encryptedBytes);out.put("vaultFiles",listing.paths.size());
        out.put("vaultTruncated",listing.truncated);out.put("vaultSkipped",listing.skipped);
        out.put("maxSingleDocumentBytes",StorageImportPolicy.MAX_DOCUMENT_BYTES);
        out.put("backupPortable",false);
        return out.toString();
      }catch(Exception error){return "{\"status\":\"unavailable\"}";}
    }
    @JavascriptInterface public String productImages(){
      long generation=captureOwnerSession();if(generation==0)return "{\"status\":\"locked\",\"images\":[]}";
      try{
        JSONObject result=AtlasProductMediaStore.list(MainActivity.this);
        if(!OwnerSessionGate.isCurrent(MainActivity.this,generation))return "{\"status\":\"locked\",\"images\":[]}";
        return result.toString();
      }catch(Exception unavailable){return "{\"status\":\"unavailable\",\"images\":[],\"message\":\"Private photos are unavailable. Existing files are retained.\"}";}
    }
    @JavascriptInterface public String productImageRead(String id){
      long generation=captureOwnerSession();if(generation==0)return "{\"status\":\"locked\"}";
      try{
        JSONObject result=AtlasProductMediaStore.read(MainActivity.this,id);
        if(!OwnerSessionGate.isCurrent(MainActivity.this,generation))return "{\"status\":\"locked\"}";
        return result.toString();
      }catch(Exception unavailable){return "{\"status\":\"unavailable\",\"message\":\"This private photo is unavailable.\"}";}
    }
    @JavascriptInterface public void productImageImport(){runOnUiThread(()->{
      if(!ownerRequired()){toast("Unlock ATLAS first");return;}
      if(productImageImportBusy.get()||productImagePickerOutstanding||documentPickerOutstanding||seedPickerOutstanding||importBusy.get()||documentImportBusy.get()){
        toast("Finish the current import first");return;
      }
      pendingProductImageUri=null;OwnerSessionGate.touch();
      Intent intent;
      if(Build.VERSION.SDK_INT>=33){intent=new Intent(MediaStore.ACTION_PICK_IMAGES);intent.setType("image/*");}
      else{intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("image/*");}
      intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
      try{
        productImagePickerAt=SystemClock.elapsedRealtime();productImagePickerOutstanding=true;
        startActivityForResult(intent,PICK_PRODUCT_IMAGE);
      }catch(Exception unavailable){productImagePickerOutstanding=false;toast("Photo picker unavailable");}
    });}
    @JavascriptInterface public void importLocalDocument(){ runOnUiThread(()->{
      if(!ownerRequired()){toast("Unlock Atlas OS first");return;}
      if(documentImportBusy.get()||importBusy.get()||documentPickerOutstanding||seedPickerOutstanding){
        toast("An import or selection is already active");return;
      }
      pendingDocumentUri=null;pendingDocumentName=null;
      OwnerSessionGate.touch();
      Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
      intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("*/*");
      intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
      try{documentPickerOutstanding=true;startActivityForResult(intent,PICK_DOCUMENT);}
      catch(Exception unavailable){documentPickerOutstanding=false;toast("Document picker unavailable");}
    }); }
    @JavascriptInterface public int vaultCount(){ if(!OwnerSessionGate.isActive(MainActivity.this))return 0; OwnerSessionGate.touch(); return listVaultFiles(vaultRoot()).size(); }
    @JavascriptInterface public String listVault(){ if(!OwnerSessionGate.isActive(MainActivity.this))return "[]"; OwnerSessionGate.touch(); JSONArray a=new JSONArray(); for(File f:listVaultFiles(vaultRoot())){ String p=vaultRoot().toURI().relativize(f.toURI()).getPath(); if(p.endsWith(".atlasenc"))p=p.substring(0,p.length()-9); a.put(p); } return a.toString(); }
    @JavascriptInterface public String listVaultForSearch(){
      if(!ownerRequired())return "{\"status\":\"locked\",\"paths\":[]}";
      OwnerSessionGate.touch();
      try{
        VaultSearchReader.Listing result=VaultSearchReader.list(vaultRoot(),()->OwnerSessionGate.isActive(MainActivity.this));
        JSONObject out=new JSONObject().put("status","ok").put("truncated",result.truncated).put("skipped",result.skipped);
        JSONArray paths=new JSONArray();for(String path:result.paths)paths.put(path);out.put("paths",paths);return out.toString();
      }catch(VaultSearchReader.Rejected e){return "{\"status\":"+JSONObject.quote(e.status)+",\"paths\":[]}";}
      catch(Exception e){return "{\"status\":\"unreadable\",\"paths\":[]}";}
    }
    @JavascriptInterface public String readVaultTextForSearch(String relative){
      if(!ownerRequired())return "{\"status\":\"locked\"}";
      OwnerSessionGate.touch();
      try{
        String text=VaultSearchReader.read(vaultRoot(),relative,vaultKey(),()->OwnerSessionGate.isActive(MainActivity.this));
        return new JSONObject().put("status","ok").put("text",text).toString();
      }catch(VaultSearchReader.Rejected e){return "{\"status\":"+JSONObject.quote(e.status)+"}";}
      catch(Exception e){return "{\"status\":\"unreadable\"}";}
    }
    @JavascriptInterface public String readVaultText(String relative){
      if(!ownerRequired())return ""; OwnerSessionGate.touch(); byte[] bytes=null;
      try{
        bytes=decryptFile(safeVaultFile(relative+".atlasenc"),VaultFileCodec.TEXT_LIMIT);
        if(!ownerRequired())return "";
        return new String(bytes,java.nio.charset.StandardCharsets.UTF_8);
      }catch(VaultFileCodec.SizeLimitException tooLarge){return ownerRequired()?"[file too large for text bridge]":"";}
      catch(Exception unavailable){return "";}
      finally{if(bytes!=null)Arrays.fill(bytes,(byte)0);}
    }
    @JavascriptInterface public String readVaultImageDataUrl(String relative,String mime){
      if(!ownerRequired())return "";
      String safeMime=safeImageMime(mime); if(safeMime==null)return "";
      OwnerSessionGate.touch(); byte[] bytes=null;
      try{
        bytes=decryptFile(safeVaultFile(relative+".atlasenc"),VaultFileCodec.IMAGE_LIMIT);
        if(!ownerRequired())return "";
        return "data:"+safeMime+";base64,"+Base64.encodeToString(bytes,Base64.NO_WRAP);
      }catch(Exception unavailable){return "";}
      finally{if(bytes!=null)Arrays.fill(bytes,(byte)0);}
    }
  }

  private void initVoiceStack(){
    try{
      tts=new TextToSpeech(this,status->{
        if(status==TextToSpeech.SUCCESS&&tts!=null){
          ttsReady=true;
          int lang=tts.setLanguage(Locale.getDefault());
          if(lang==TextToSpeech.LANG_MISSING_DATA||lang==TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.US);
          tts.setSpeechRate(0.97f);
          tts.setPitch(0.98f);
          tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
            @Override public void onStart(String id){ runOnUiThread(()->voiceEvent("SPEAKING","")); }
            @Override public void onDone(String id){ runOnUiThread(()->voiceEvent("READY","")); }
            @Override public void onError(String id){ runOnUiThread(()->voiceEvent("ERROR","Speech output failed.")); }
          });
        }
      });
    }catch(Exception ignored){ ttsReady=false; }

    if(SpeechRecognizer.isRecognitionAvailable(this)){
      voiceRecognizer=SpeechRecognizer.createSpeechRecognizer(this);
      voiceRecognizer.setRecognitionListener(new RecognitionListener(){
        @Override public void onReadyForSpeech(Bundle params){ voiceEvent("LISTENING",""); }
        @Override public void onBeginningOfSpeech(){ voiceEvent("TRANSCRIBING",""); }
        @Override public void onRmsChanged(float rmsdB){}
        @Override public void onBufferReceived(byte[] buffer){}
        @Override public void onEndOfSpeech(){ voiceEvent("THINKING",""); }
        @Override public void onError(int error){
          String msg=(error==SpeechRecognizer.ERROR_NO_MATCH||error==SpeechRecognizer.ERROR_SPEECH_TIMEOUT)?"I didn't catch that.":"Voice recognition error " + error + ".";
          restoreWakeAfterVoiceTurn(); voiceEvent("ERROR",msg);
        }
        @Override public void onResults(Bundle results){
          ArrayList<String> rows=results==null?null:results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
          float[] confidence=results==null?null:results.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES);
          String best=TranscriptSelector.choose(rows,confidence,false);
          restoreWakeAfterVoiceTurn();
          if(best.isEmpty())voiceEvent("ERROR","I didn't catch that.");
          else{
            voiceEvent("RESULT",best);
            dispatchEvent("atlas-command-result",routeAuthenticatedInput(best,WorkflowIntentParser.Origin.VOICE_TRANSCRIPT));
          }
        }
        @Override public void onPartialResults(Bundle partialResults){
          ArrayList<String> rows=partialResults==null?null:partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
          if(rows!=null&&!rows.isEmpty()) voiceEvent("PARTIAL",VoiceCommandParser.normalize(rows.get(0)));
        }
        @Override public void onEvent(int eventType,Bundle params){}
      });
    }
  }

  private void requestVoiceTurn(){
    if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
      voiceTurnRequested=true; requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_VOICE_TURN); return;
    }
    startVoiceTurn();
  }

  private void startVoiceTurn(){
    final long ownerToken=captureOwnerSession();
    if(ownerToken==0L||isFinishing()||isDestroyed()){voiceEvent("LOCKED","Unlock Atlas OS to use private voice.");return;}
    if(voiceRecognizer==null){ voiceEvent("ERROR","Speech recognition is unavailable on this device."); return; }
    final long requestToken=++voiceStartGeneration;
    if(tts!=null&&tts.isSpeaking())tts.stop();
    resumeWakeAfterVoiceTurn=getSharedPreferences("atlas",MODE_PRIVATE).getBoolean("wake_enabled",false);
    if(resumeWakeAfterVoiceTurn) stopService(new Intent(this,AtlasWakeService.class));
    voiceEvent("LISTENING","");
    new Handler(Looper.getMainLooper()).postDelayed(()->{
      if(requestToken!=voiceStartGeneration||!OwnerSessionGate.isCurrent(this,ownerToken)
          ||isFinishing()||isDestroyed()||voiceRecognizer==null)return;
      try{
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3);
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE,getPackageName());
        voiceRecognizer.startListening(i);
      }catch(Exception e){ restoreWakeAfterVoiceTurn(); voiceEvent("ERROR","Unable to start listening."); }
    },resumeWakeAfterVoiceTurn?300:0);
  }

  private void restoreWakeAfterVoiceTurn(){
    if(!resumeWakeAfterVoiceTurn)return;
    resumeWakeAfterVoiceTurn=false;
    final long ownerToken=captureOwnerSession(), requestToken=voiceStartGeneration;
    if(ownerToken==0L)return;
    new Handler(Looper.getMainLooper()).postDelayed(()->{
      if(requestToken==voiceStartGeneration&&OwnerSessionGate.isCurrent(this,ownerToken)
          &&!isFinishing()&&!isDestroyed())startWakeService(false);
    },650);
  }

  private void speakText(String raw){
    String text=SpokenTextPolicy.prepare(raw);
    if(text.isEmpty())return;
    if(tts==null||!ttsReady){ voiceEvent("ERROR","Speech output is not ready."); return; }
    Bundle p=new Bundle(); p.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME,1.0f);
    tts.speak(text,TextToSpeech.QUEUE_FLUSH,p,"atlas-"+System.currentTimeMillis());
  }

  private void voiceEvent(String state,String text){
    if(("RESULT".equals(state)||"PARTIAL".equals(state))&&!ownerRequired())return;
    String safeText=text==null?"":text;
    String frame="RESULT".equals(state)?VoiceFrameClassifier.classifyName(safeText):"";
    dispatchEvent("atlas-voice", "{state:"+JSONObject.quote(state==null?"":state)+",text:"+JSONObject.quote(safeText)+",frame:"+JSONObject.quote(frame)+"}");
  }

  private void dispatchEvent(String name,String detailJson){
    if(web==null||!pageReady)return;
    js("window.dispatchEvent(new CustomEvent("+JSONObject.quote(name)+",{detail:"+detailJson+"}))");
  }

  private void startWakeService(boolean announce){
    if(!ownerRequired())return;
    Intent i=new Intent(this,AtlasWakeService.class).setAction(AtlasWakeService.ACTION_ARM);
    try{
      if(Build.VERSION.SDK_INT>=26)startForegroundService(i); else startService(i);
      if(announce)toast("Hey Atlas armed");
    }catch(Exception e){ if(announce)toast("Unable to start Hey Atlas"); }
  }

  @Override protected void onActivityResult(int r,int c,Intent data){
    super.onActivityResult(r,c,data);
    if(rendererUnavailable||activityDestroyed||isFinishing()||isDestroyed())return;
    if(r==PICK_PRODUCT_IMAGE){
      boolean requested=productImagePickerOutstanding;productImagePickerOutstanding=false;
      if(!requested||c!=RESULT_OK||data==null||data.getData()==null)return;
      if(!OwnerRecoveryPolicy.flowValid(productImagePickerAt,SystemClock.elapsedRealtime())){toast("Photo selection expired. Choose it again.");return;}
      Uri uri=data.getData();if(!"content".equalsIgnoreCase(uri.getScheme())){toast("Unsupported photo provider");return;}
      pendingProductImageUri=uri;pendingProductImageAt=SystemClock.elapsedRealtime();
      if(ownerRequired())offerPendingProductImageImport();
      else toast("Unlock ATLAS to save the selected photo. The original is unchanged.");
      return;
    }
    if(r==PICK_DOCUMENT){
      boolean requested=documentPickerOutstanding;documentPickerOutstanding=false;
      if(!requested||c!=RESULT_OK||data==null||data.getData()==null)return;
      Uri uri=data.getData();
      if(!"content".equalsIgnoreCase(uri.getScheme())){toast("Unsupported document provider");return;}
      String name=queryDocumentName(uri);
      if(name==null){toast("Unsupported name/type. Choose a text, Markdown, CSV, or JSON file.");return;}
      pendingDocumentUri=uri;pendingDocumentName=name;pendingDocumentAt=SystemClock.elapsedRealtime();
      if(ownerRequired())offerPendingDocumentImport();
      else toast("Unlock ATLAS and confirm the selected document. Nothing was imported.");
      return;
    }
    if(r!=PICK_SEED)return;
    boolean requested=seedPickerOutstanding;seedPickerOutstanding=false;
    if(!requested||c!=RESULT_OK||data==null||data.getData()==null)return;
    Uri u=data.getData();
    if(!"content".equalsIgnoreCase(u.getScheme())){toast("Unsupported file provider");return;}
    pendingSeedUri=u;pendingSeedAt=SystemClock.elapsedRealtime();pendingSeedChatGpt=seedPickerChatGpt;seedPickerChatGpt=false;
    // Keep only the temporary read grant. Never request a write or persistent grant.
    if(ownerRequired())offerPendingSeedImport();
    else toast("Unlock Atlas, then confirm the selected ZIP import. Nothing was changed.");
  }

  private void offerPendingProductImageImport(){
    if(pendingProductImageUri==null||!ownerRequired()||credentialDialog!=null)return;
    if(!OwnerRecoveryPolicy.flowValid(pendingProductImageAt,SystemClock.elapsedRealtime())){
      pendingProductImageUri=null;toast("Photo selection expired. Choose it again.");return;
    }
    final Uri selected=pendingProductImageUri;
    LinearLayout box=credentialBox();TextView explanation=new TextView(this);
    explanation.setText("Save an encrypted, phone-sized copy of the selected photo for ATLAS Shopping? "
      +"The original is unchanged. No upload. Select an image under 8 MiB; the saved copy is at most 1024 pixels and 384 KiB. "
      +"After saving, open a product's editor and choose Saved photos. It is not attached to a product automatically.");
    box.addView(explanation);AlertDialog dialog=credentialDialog("Save product photo",box);if(dialog==null)return;
    dialog.setOnCancelListener(ignored->{if(pendingProductImageUri==selected)pendingProductImageUri=null;});
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
      if(!ownerRequired()||pendingProductImageUri!=selected||!OwnerRecoveryPolicy.flowValid(pendingProductImageAt,SystemClock.elapsedRealtime())){dialog.dismiss();return;}
      if(!productImageImportBusy.compareAndSet(false,true)){toast("Photo import is running");return;}
      final long generation=captureOwnerSession();pendingProductImageUri=null;dialog.dismiss();
      new Thread(()->{
        try{
          JSONObject result=AtlasProductMediaStore.importImage(MainActivity.this,selected,generation);
          runOnUiThread(()->{
            if(!OwnerSessionGate.isCurrent(MainActivity.this,generation)||!ownerRequired())return;
            dispatchEvent("atlas-product-image",result.toString());
            toast(result.optBoolean("duplicate")?"This photo is already in Saved photos":"Photo saved. Choose it from Shopping → Edit → Saved photos.");
          });
        }catch(Exception unavailable){
          final String message=AtlasProductMediaStore.userMessage(unavailable);
          runOnUiThread(()->{if(OwnerSessionGate.isCurrent(MainActivity.this,generation)&&ownerRequired())toast(message);});
        }finally{productImageImportBusy.set(false);}
      },"atlas-product-photo-import").start();
    });
    dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v->{pendingProductImageUri=null;dialog.dismiss();});
  }

  private String queryDocumentName(Uri uri){
    if(uri==null)return null;
    try(Cursor cursor=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)){
      if(cursor==null||!cursor.moveToFirst())return null;
      int nameIndex=cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
      int sizeIndex=cursor.getColumnIndex(OpenableColumns.SIZE);
      if(nameIndex<0)return null;
      String name=StorageImportPolicy.safeName(cursor.getString(nameIndex));
      long size=sizeIndex>=0&&!cursor.isNull(sizeIndex)?cursor.getLong(sizeIndex):-1L;
      return name!=null&&StorageImportPolicy.declaredSizeAllowed(size)?name:null;
    }catch(Exception unavailable){return null;}
  }

  private void offerPendingDocumentImport(){
    if(pendingDocumentUri==null||pendingDocumentName==null||!ownerRequired()||credentialDialog!=null)return;
    if(!OwnerRecoveryPolicy.flowValid(pendingDocumentAt,SystemClock.elapsedRealtime())){
      pendingDocumentUri=null;pendingDocumentName=null;
      toast("Document selection expired. Choose again.");return;
    }
    final Uri uri=pendingDocumentUri;
    final String name=pendingDocumentName;
    LinearLayout box=credentialBox();
    TextView explanation=new TextView(this);
    explanation.setText("Import a new encrypted copy of '"+name+"' into ATLAS? Maximum 8 MiB. "
      +"The selected original stays unchanged. Data stays on this device. "
      +"This is NOT a portable backup: Android Keystore keys do not transfer on reinstall.");
    box.addView(explanation);
    AlertDialog dialog=credentialDialog("Confirm private document import",box);if(dialog==null)return;
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
      if(!ownerRequired()||pendingDocumentUri!=uri||!OwnerRecoveryPolicy.flowValid(pendingDocumentAt,SystemClock.elapsedRealtime())){
        dialog.dismiss();return;
      }
      if(!documentImportBusy.compareAndSet(false,true)){toast("An import is running");return;}
      final long session=captureOwnerSession();
      pendingDocumentUri=null;pendingDocumentName=null;dialog.dismiss();
      new Thread(()->importDocument(uri,name,session),"atlas-document-import").start();
    });
    dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v->{
      pendingDocumentUri=null;pendingDocumentName=null;dialog.dismiss();
    });
  }

  private void importDocument(Uri uri,String reportedName,long session){
    File folder=null,part=null;boolean committed=false;
    JSONObject report=new JSONObject();
    try{
      String name=StorageImportPolicy.safeName(reportedName);
      if(name==null||!OwnerSessionGate.isCurrent(this,session))throw new IOException("owner or document policy rejected");
      report.put("status","importing").put("kind","document").put("files",0).put("searchFiles",0)
        .put("startedAt",System.currentTimeMillis());publishImportStatus(report);
      StatFs stats=new StatFs(getFilesDir().getAbsolutePath());
      if(!StorageImportPolicy.freeSpaceSafe(stats.getAvailableBytes(),-1))throw new IOException("insufficient device space");
      byte[] random=new byte[12];new SecureRandom().nextBytes(random);
      StringBuilder id=new StringBuilder("copy-");
      for(byte b:random)id.append(String.format(Locale.ROOT,"%02x",b&255));
      folder=new File(new File(vaultRoot(),"owner-documents"),id.toString());
      if(!folder.mkdirs())throw new IOException("unable to stage unique folder");
      part=new File(folder,"pending.atlaspart");
      File target=new File(folder,name+".atlasenc");
      long bytes;
      try(InputStream in=getContentResolver().openInputStream(uri)){
        if(in==null)throw new IOException("source unavailable");
        bytes=VaultFileCodec.encryptNew(in,part,vaultKey(),StorageImportPolicy.MAX_DOCUMENT_BYTES,
          ()->OwnerSessionGate.isCurrent(this,session));
      }
      synchronized(OwnerSessionGate.class){
        if(!OwnerSessionGate.isCurrent(this,session))throw new IOException("owner session ended");
        if(target.exists())throw new IOException("destination already exists");
        java.nio.file.Files.move(part.toPath(),target.toPath(),java.nio.file.StandardCopyOption.ATOMIC_MOVE);
        committed=true;
      }
      boolean readable=false;
      if(bytes<=VaultSearchReader.MAX_TEXT_BYTES&&OwnerSessionGate.isCurrent(this,session)){
        try{
          VaultSearchReader.read(vaultRoot(),"owner-documents/"+id.toString()+"/"+name,vaultKey(),
            ()->OwnerSessionGate.isCurrent(this,session));readable=true;
        }catch(Exception unsupported){} // The original remains saved even when text search cannot read it.
      }
      report.put("status","saved").put("files",1).put("bytes",bytes).put("searchFiles",readable?1:0)
        .put("indexStatus",readable?"on_demand":"not_readable").put("finishedAt",System.currentTimeMillis());
      publishImportStatus(report);
      final long savedBytes=bytes;
      runOnUiThread(()->{
        if(!OwnerSessionGate.isCurrent(this,session))return;
        toast("Saved encrypted copy ("+savedBytes+" bytes); original unchanged");
        dispatchEvent("atlas-document-import","{status:"+JSONObject.quote("saved")+",bytes:"+savedBytes+"}");
      });
    }catch(Exception rejected){
      try{
        report.put("kind","document").put("status",committed?"saved":"rejected").put("files",committed?1:0)
          .put("searchFiles",0).put("indexStatus","not_readable").put("finishedAt",System.currentTimeMillis())
          .put("reason",committed?"Original saved; text readability was not confirmed."
            :"Check the file type, 8 MiB limit and free space. Keep ATLAS unlocked until the import finishes.");
        publishImportStatus(report);
      }catch(Exception ignored){}
      final boolean saved=committed;
      runOnUiThread(()->{if(OwnerSessionGate.isCurrent(this,session))toast(saved?"Original saved; text readability was not confirmed":"Import rejected or interrupted; existing files untouched");});
    }finally{
      if(part!=null)try{java.nio.file.Files.deleteIfExists(part.toPath());}catch(Exception ignored){}
      if(folder!=null)try{java.nio.file.Files.delete(folder.toPath());}catch(Exception ignored){}
      documentImportBusy.set(false);
    }
  }

  private void beginZipImport(boolean chatGpt){
    if(!ownerRequired()){toast("Unlock ATLAS first");return;}
    if(importBusy.get()||documentImportBusy.get()||seedPickerOutstanding||documentPickerOutstanding){toast("An import or file selection is already active");return;}
    OwnerSessionGate.touch();
    Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/zip");
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
    try{seedPickerOutstanding=true;seedPickerChatGpt=chatGpt;startActivityForResult(intent,PICK_SEED);}
    catch(RuntimeException unavailable){seedPickerOutstanding=false;seedPickerChatGpt=false;toast("File picker unavailable");}
  }

  private void offerPendingSeedImport(){
    if(pendingSeedUri==null||!ownerRequired()||credentialDialog!=null)return;
    if(!OwnerRecoveryPolicy.flowValid(pendingSeedAt,SystemClock.elapsedRealtime())){
      pendingSeedUri=null;toast("File selection expired. Select the ZIP again.");return;
    }
    final Uri selected=pendingSeedUri;final boolean chatGpt=pendingSeedChatGpt;
    LinearLayout box=credentialBox();TextView explanation=new TextView(this);
    explanation.setText(chatGpt
      ?"Import this ChatGPT export ZIP into encrypted ATLAS storage, then build readable chat text? Original ZIP stays unchanged. Limits: 1 GiB expanded total, 128 MiB per file, 5,000 files. Images and other files are preserved; their contents are not automatically understood. Keep ATLAS open."
      :"Import this ZIP into a new encrypted snapshot? Existing vault files will not be replaced. Limits: 1 GiB expanded total, 128 MiB per file, 5,000 files. Keep ATLAS open until it finishes.");
    box.addView(explanation);
    AlertDialog dialog=credentialDialog(chatGpt?"Import ChatGPT export":"Confirm private import",box);if(dialog==null)return;
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
      if(!ownerRequired()||pendingSeedUri!=selected
          ||!OwnerRecoveryPolicy.flowValid(pendingSeedAt,SystemClock.elapsedRealtime())){dialog.dismiss();return;}
      if(!importBusy.compareAndSet(false,true)){toast("Another import is running");return;}
      final long session=captureOwnerSession();
      pendingSeedUri=null;dialog.dismiss();new Thread(()->importZip(selected,chatGpt,session),"atlas-private-import").start();
    });
    dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v->{pendingSeedUri=null;pendingSeedChatGpt=false;dialog.dismiss();});
  }

  private void publishImportStatus(JSONObject status){
    final String report=status.toString();
    getSharedPreferences("atlas_import_reports",MODE_PRIVATE).edit().putString("last",report).apply();
    runOnUiThread(()->{if(ownerRequired())dispatchEvent("atlas-import-status",report);});
  }

  private InputStream openEncryptedIndexSource(File source,long session)throws Exception{
    if(!OwnerSessionGate.isCurrent(this,session)||source.length()>SeedImportPolicy.MAX_FILE_BYTES+53L)throw new IOException("source policy");
    DataInputStream input=new DataInputStream(new FileInputStream(source));
    try{
      if(input.readInt()!=0x41544c31)throw new IOException("invalid encrypted header");
      int ivLength=input.readUnsignedByte();if(ivLength<12||ivLength>32)throw new IOException("invalid IV");
      byte[] iv=new byte[ivLength];input.readFully(iv);
      Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
      cipher.init(Cipher.DECRYPT_MODE,vaultKey(),new javax.crypto.spec.GCMParameterSpec(128,iv));
      return new CipherInputStream(input,cipher);
    }catch(Exception failure){input.close();throw failure;}
  }

  private void importZip(Uri uri,boolean chatGpt,long session){
    JSONObject report=new JSONObject();boolean rawSaved=false;
    try{
      report.put("status","importing").put("kind",chatGpt?"chatgpt":"zip");publishImportStatus(report);
      if(!OwnerSessionGate.isCurrent(this,session))throw new IOException("session ended");
      StatFs space=new StatFs(getFilesDir().getAbsolutePath());
      if(space.getAvailableBytes()<16L*1024*1024)throw new IOException("insufficient space");
      TransactionalSeedImporter.Result result;
      try(InputStream raw=getContentResolver().openInputStream(uri)){
        if(raw==null)throw new IOException("missing source");
        result=TransactionalSeedImporter.importNew(raw,getFilesDir(),vaultRoot(),
          (entry,out,limit)->VaultFileCodec.encryptNew(entry,out,vaultKey(),limit,()->OwnerSessionGate.isCurrent(this,session)),
          ()->OwnerSessionGate.isCurrent(this,session));
      }
      rawSaved=true;
      report.put("files",result.files).put("bytes",result.bytes).put("directory",result.directory)
        .put("originalPreserved",true).put("searchFiles",0).put("conversations",0).put("messages",0).put("nonTextParts",0);
      if(chatGpt){
        report.put("status","indexing").put("indexStatus","pending");publishImportStatus(report);
        try{
          File imported=new File(vaultRoot(),result.directory);List<File> matches=new ArrayList<>();
          for(File entry:listVaultFiles(imported))if("conversations.json.atlasenc".equalsIgnoreCase(entry.getName()))matches.add(entry);
          if(matches.size()!=1)throw new IOException("missing or ambiguous conversations JSON");
          ChatGptTextIndexer.Result index;
          try(InputStream plain=openEncryptedIndexSource(matches.get(0),session)){
            index=ChatGptTextIndexer.index(plain,getFilesDir(),vaultRoot(),
              (entry,out,limit)->VaultFileCodec.encryptNew(entry,out,vaultKey(),limit,()->OwnerSessionGate.isCurrent(this,session)),
              ()->OwnerSessionGate.isCurrent(this,session));
          }
          report.put("status","saved").put("indexStatus","ready").put("searchFiles",index.files)
            .put("conversations",index.conversations).put("messages",index.messages).put("nonTextParts",index.nonTextParts)
            .put("indexDirectory",index.directory);
        }catch(Exception indexingFailed){
          report.put("status","saved_raw").put("indexStatus","pending")
            .put("reason","Original export imported. Search text needs a smaller/supported export or an offline conversion; indexing limits, format, or session prevented completion.");
        }
      }else report.put("status","saved").put("indexStatus","not_requested");
      publishImportStatus(report);
      runOnUiThread(()->{
        toast(chatGpt?"ChatGPT import finished. Open Transfer for the exact result.":"Imported "+result.files+" files; originals preserved");
        if(ownerRequired())dispatchEvent("atlas-native-import","{count:"+result.files+",bytes:"+result.bytes+"}");
      });
    }catch(Exception failure){
      try{report.put("status",rawSaved?"saved_raw":"rejected").put("indexStatus","pending")
        .put("reason",rawSaved?"Original imported; search index unfinished.":"Import rejected or interrupted. Check file limits, available space and keep ATLAS unlocked. Existing files unchanged.");
        publishImportStatus(report);
      }catch(Exception ignored){}
      final boolean importedOriginal=rawSaved;
      runOnUiThread(()->toast(importedOriginal?"Original imported; search index unfinished":"Import rejected or interrupted; existing files unchanged"));
    }finally{importBusy.set(false);}
  }

  private File vaultRoot(){ File f=new File(getFilesDir(),"vault"); f.mkdirs(); return f; }
  private String safeImageMime(String mime){
    if(mime==null)return null;
    String m=mime.toLowerCase(Locale.US).trim();
    if("image/png".equals(m)||"image/jpeg".equals(m)||"image/webp".equals(m)||"image/gif".equals(m))return m;
    return null;
  }

  private File safeVaultFile(String rel)throws IOException{ String safe=SeedImportPolicy.safeRelative(rel); if(safe==null)throw new IOException("unsafe path"); File base=vaultRoot().getCanonicalFile(), f=new File(base,safe).getCanonicalFile(); if(!f.getPath().startsWith(base.getPath()+File.separator)&&!f.equals(base))throw new IOException("escape"); return f; }
  private List<File> listVaultFiles(File d){ ArrayList<File> a=new ArrayList<>(); File[] fs=d.listFiles(); if(fs!=null)for(File f:fs){ if(f.isDirectory())a.addAll(listVaultFiles(f)); else if(f.getName().endsWith(".atlasenc"))a.add(f);} Collections.sort(a); return a; }
  private SecretKey vaultKey()throws Exception{ KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null); return (SecretKey)ks.getKey(KEY_ALIAS,null); }
  private void ensureVaultKey(){ try{ KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null); if(ks.containsAlias(KEY_ALIAS))return; KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore"); kg.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build()); kg.generateKey(); }catch(Exception e){toast("Vault key unavailable");} }
  private byte[] decryptFile(File file,int limit)throws Exception{
    if(!ownerRequired())throw new IOException("owner session ended");
    if(file.length()>(long)limit+4+1+32+16)throw new VaultFileCodec.SizeLimitException();
    try(InputStream input=java.nio.file.Files.newInputStream(file.toPath(),java.nio.file.LinkOption.NOFOLLOW_LINKS)){
      return VaultFileCodec.decrypt(input,vaultKey(),limit,()->ownerRequired());
    }
  }
  private void js(String x){
    final WebView target=web;
    runOnUiThread(()->{if(webUsable(target))target.evaluateJavascript(x,null);});
  }
  private void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
}
