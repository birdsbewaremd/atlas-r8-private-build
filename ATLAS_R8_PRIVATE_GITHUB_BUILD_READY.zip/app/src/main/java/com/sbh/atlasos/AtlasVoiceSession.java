package com.sbh.atlasos;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.service.voice.VoiceInteractionSession;

/** Bridges system assistant invocation into the authenticated ATLAS UI. */
public final class AtlasVoiceSession extends VoiceInteractionSession {
  public AtlasVoiceSession(Context context) { super(context); }

  @Override public void onShow(Bundle args, int showFlags) {
    super.onShow(args, showFlags);
    Intent i = new Intent(getContext(), MainActivity.class);
    i.setAction(Intent.ACTION_ASSIST);
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    try { startAssistantActivity(i); }
    catch (Exception ignored) { getContext().startActivity(i); }
    hide();
  }
}
