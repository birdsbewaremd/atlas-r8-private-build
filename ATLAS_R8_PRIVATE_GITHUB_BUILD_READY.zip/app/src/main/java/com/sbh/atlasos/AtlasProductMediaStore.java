package com.sbh.atlasos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.StatFs;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import org.json.JSONArray;
import org.json.JSONObject;

/** Selected product photos. Independent encrypted store; never mutates source photos or catalog records. */
public final class AtlasProductMediaStore {
  static final String ALIAS="atlas_product_media_v1";
  static final String DIRECTORY="product_media_v1";
  static final int MAX_INPUT=8*1024*1024, MAX_IMAGE=384*1024, MAX_PAYLOAD=MAX_IMAGE+2048;
  static final int MAX_COUNT=48, MAX_EDGE=1024;
  static final long MAX_ARCHIVE=25L*1024*1024;
  private static final Object MUTATION=new Object();
  private AtlasProductMediaStore(){}
  static final class PhotoException extends IOException {
    final String code;
    PhotoException(String code){super(code);this.code=code;}
  }
  static String userMessage(Throwable error){
    String code=error instanceof PhotoException?((PhotoException)error).code:"unavailable";
    switch(code){
      case "input_too_large":return "This photo is larger than 8 MiB. Choose a smaller copy; the original is unchanged.";
      case "dimensions":return "Choose a photo no larger than 40 megapixels or 16000 pixels on either edge.";
      case "low_storage":return "At least 32 MiB of free phone storage is needed for this import. Existing photos are retained.";
      case "library_full":return "The private photo library has reached its 48-image or 25 MiB limit. Existing photos are retained.";
      case "key_unavailable":return "The saved-photo encryption key is unavailable. Existing photos are retained; no new key replaces it.";
      case "archive_interrupted":return "An interrupted photo file needs recovery before another import. Existing files are retained.";
      case "archive_unreadable":return "The saved-photo library could not be verified. Existing photos are retained.";
      case "output_too_large":return "The optimized photo is still too detailed for the size limit. Choose a smaller copy.";
      default:return "This photo could not be imported. Choose another supported image and keep ATLAS open. Existing photos are retained.";
    }
  }

  static boolean validId(String id){return id!=null&&id.matches("pm-[a-f0-9]{32}");}
  static boolean dimensionsAllowed(int w,int h){return w>0&&h>0&&w<=16000&&h<=16000&&(long)w*h<=40000000L;}
  static void require(Context c,long generation)throws IOException{
    if(!OwnerSessionGate.isCurrent(c,generation))throw new IOException("owner session ended");
  }
  private static File root(Context c)throws IOException{
    File f=new File(c.getNoBackupFilesDir(),DIRECTORY);
    if(Files.isSymbolicLink(f.toPath())||(f.exists()&&!f.isDirectory()))throw new IOException("media location unavailable");
    return f;
  }
  private static File file(File folder,String id)throws IOException{
    if(!validId(id))throw new IOException("invalid image reference");
    File f=new File(folder,id+".atlasphoto");
    if(Files.isSymbolicLink(f.toPath()))throw new IOException("invalid image file");
    return f;
  }
  private static File[] files(File folder)throws IOException{
    if(!folder.exists())return new File[0];
    File[] all=folder.listFiles();if(all==null)throw new IOException("media listing unavailable");
    if(all.length>MAX_COUNT+16)throw new IOException("media archive contains too many files");
    Arrays.sort(all,Comparator.comparing(File::getName));return all;
  }
  private static SecretKey key(File folder,boolean create)throws Exception{
    KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
    if(!store.containsAlias(ALIAS)){
      if(!create||files(folder).length!=0)throw new PhotoException("key_unavailable");
      KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
      generator.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setRandomizedEncryptionRequired(true).setKeySize(256).build());
      generator.generateKey();
    }
    SecretKey k=(SecretKey)store.getKey(ALIAS,null);if(k==null)throw new PhotoException("key_unavailable");return k;
  }

  static final class Entry {
    final String id;final long createdAt;final int width,height;final byte[] jpeg,digest;
    Entry(String id,long at,int w,int h,byte[] image)throws Exception{
      this.id=id;createdAt=at;width=w;height=h;jpeg=image;digest=MessageDigest.getInstance("SHA-256").digest(image);
    }
    JSONObject metadata()throws Exception{
      return new JSONObject().put("id",id).put("createdAtMs",createdAt).put("width",width).put("height",height).put("bytes",jpeg.length);
    }
  }
  static byte[] encode(Entry e)throws Exception{
    if(!validId(e.id)||e.createdAt<=0||e.width<=0||e.height<=0||e.width>MAX_EDGE||e.height>MAX_EDGE
      ||e.jpeg==null||e.jpeg.length<4||e.jpeg.length>MAX_IMAGE||!jpegMarker(e.jpeg))throw new IOException("invalid photo");
    ByteArrayOutputStream bytes=new ByteArrayOutputStream();
    try(DataOutputStream out=new DataOutputStream(bytes)){
      out.writeInt(0x504d4431);out.writeUTF(e.id);out.writeLong(e.createdAt);out.writeInt(e.width);out.writeInt(e.height);
      out.write(e.digest);out.writeInt(e.jpeg.length);out.write(e.jpeg);
    }return bytes.toByteArray();
  }
  private static boolean jpegMarker(byte[] b){return b.length>=4&&(b[0]&255)==255&&(b[1]&255)==216&&(b[b.length-2]&255)==255&&(b[b.length-1]&255)==217;}
  static Entry decode(byte[] bytes,String expected)throws Exception{
    if(bytes==null||bytes.length>MAX_PAYLOAD||!validId(expected))throw new IOException("invalid photo envelope");
    try(DataInputStream in=new DataInputStream(new ByteArrayInputStream(bytes))){
      if(in.readInt()!=0x504d4431)throw new IOException("photo format");
      String id=in.readUTF();long at=in.readLong();int w=in.readInt(),h=in.readInt();
      if(!expected.equals(id)||!validId(id)||at<=0||w<1||h<1||w>MAX_EDGE||h>MAX_EDGE)throw new IOException("photo metadata");
      byte[] digest=new byte[32];in.readFully(digest);int n=in.readInt();
      if(n<4||n>MAX_IMAGE||n!=in.available())throw new IOException("photo size");
      byte[] image=new byte[n];in.readFully(image);Entry e=new Entry(id,at,w,h,image);
      if(!jpegMarker(image)||!MessageDigest.isEqual(digest,e.digest))throw new IOException("photo content");return e;
    }
  }
  static byte[] readBounded(InputStream in,int limit,VaultFileCodec.Authorization auth)throws IOException{
    if(limit<1||limit>MAX_INPUT)throw new IOException("input limit");
    ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
    while(true){
      if(!auth.allowed())throw new IOException("owner session ended");
      n=in.read(buf,0,Math.min(buf.length,limit-out.size()+1));if(n<0)break;
      if(n==0){int one=in.read();if(one<0)break;buf[0]=(byte)one;n=1;}
      if(n>limit-out.size())throw new PhotoException("input_too_large");out.write(buf,0,n);
    }if(!auth.allowed())throw new IOException("owner session ended");return out.toByteArray();
  }
  private static Entry readEntry(Context c,File folder,SecretKey k,String id,long gen)throws Exception{
    require(c,gen);File f=file(folder,id);
    if(!Files.isRegularFile(f.toPath(),LinkOption.NOFOLLOW_LINKS)||f.length()>MAX_PAYLOAD+64)throw new IOException("photo unavailable");
    byte[] plain=null;
    try(InputStream in=new FileInputStream(f)){
      plain=VaultFileCodec.decrypt(in,k,MAX_PAYLOAD,()->OwnerSessionGate.isCurrent(c,gen));
      Entry e=decode(plain,id);require(c,gen);return e;
    }finally{if(plain!=null)Arrays.fill(plain,(byte)0);}
  }
  public static JSONObject list(Context c)throws Exception{
    long gen=OwnerSessionGate.capture(c);require(c,gen);File folder=root(c);File[] items=files(folder);
    JSONArray images=new JSONArray();int unreadable=0;long total=0;SecretKey k=items.length==0?null:key(folder,false);
    ArrayList<JSONObject> entries=new ArrayList<>();
    for(File f:items){
      require(c,gen);if(Files.isRegularFile(f.toPath(),LinkOption.NOFOLLOW_LINKS))total+=f.length();
      String name=f.getName();
      if(!name.endsWith(".atlasphoto")){unreadable++;continue;}
      String id=name.substring(0,name.length()-11);
      try{
        Entry entry=readEntry(c,folder,k,id,gen);
        try{entries.add(entry.metadata());}finally{Arrays.fill(entry.jpeg,(byte)0);}
      }catch(Exception bad){require(c,gen);unreadable++;}
    }
    entries.sort((a,b)->Long.compare(b.optLong("createdAtMs"),a.optLong("createdAtMs")));
    for(JSONObject entry:entries)images.put(entry);
    require(c,gen);return new JSONObject().put("status",unreadable==0?"ok":"partial").put("images",images)
      .put("unreadableCount",unreadable).put("archiveBytes",total).put("maxCount",MAX_COUNT).put("maxBytes",MAX_ARCHIVE);
  }
  public static JSONObject read(Context c,String id)throws Exception{
    long gen=OwnerSessionGate.capture(c);require(c,gen);File folder=root(c);
    Entry e=readEntry(c,folder,key(folder,false),id,gen);
    try{
      String data="data:image/jpeg;base64,"+Base64.encodeToString(e.jpeg,Base64.NO_WRAP);
      require(c,gen);return e.metadata().put("status","ok").put("dataUri",data);
    }finally{Arrays.fill(e.jpeg,(byte)0);}
  }
  public static JSONObject importImage(Context c,Uri uri,long gen)throws Exception{
    if(uri==null||!"content".equalsIgnoreCase(uri.getScheme()))throw new IOException("choose a photo provider");
    require(c,gen);
    if(new StatFs(c.getNoBackupFilesDir().getAbsolutePath()).getAvailableBytes()<32L*1024*1024)throw new PhotoException("low_storage");
    byte[] original=null,jpeg=null;Bitmap bitmap=null,opaque=null;
    try(InputStream input=c.getContentResolver().openInputStream(uri)){
      if(input==null)throw new IOException("photo provider unavailable");
      original=readBounded(input,MAX_INPUT,()->OwnerSessionGate.isCurrent(c,gen));
      if(original.length==0)throw new IOException("empty photo");
      final boolean[] dimensionsRejected={false};
      try{bitmap=ImageDecoder.decodeBitmap(ImageDecoder.createSource(ByteBuffer.wrap(original)),(decoder,info,source)->{
        int w=info.getSize().getWidth(),h=info.getSize().getHeight();
        if(!dimensionsAllowed(w,h)){dimensionsRejected[0]=true;throw new IllegalArgumentException("photo dimensions exceed limit");}
        double scale=Math.min(1d,(double)MAX_EDGE/Math.max(w,h));
        decoder.setTargetSize(Math.max(1,(int)Math.round(w*scale)),Math.max(1,(int)Math.round(h*scale)));
        decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);decoder.setOnPartialImageListener(error->false);
      });}catch(Exception decodeFailure){if(dimensionsRejected[0])throw new PhotoException("dimensions");throw decodeFailure;}
      require(c,gen);
      opaque=Bitmap.createBitmap(bitmap.getWidth(),bitmap.getHeight(),Bitmap.Config.ARGB_8888);
      Canvas canvas=new Canvas(opaque);canvas.drawColor(Color.WHITE);canvas.drawBitmap(bitmap,0,0,null);
      for(int q:new int[]{88,76,64,52}){
        ByteArrayOutputStream data=new ByteArrayOutputStream();
        if(!opaque.compress(Bitmap.CompressFormat.JPEG,q,data))throw new IOException("photo conversion unavailable");
        jpeg=data.toByteArray();if(jpeg.length<=MAX_IMAGE)break;
      }
      if(jpeg.length>MAX_IMAGE)throw new PhotoException("output_too_large");
      require(c,gen);return save(c,jpeg,opaque.getWidth(),opaque.getHeight(),gen);
    }finally{
      if(bitmap!=null)bitmap.recycle();if(opaque!=null)opaque.recycle();
      if(original!=null)Arrays.fill(original,(byte)0);if(jpeg!=null)Arrays.fill(jpeg,(byte)0);
    }
  }
  static JSONObject save(Context c,byte[] jpeg,int width,int height,long gen)throws Exception{
    synchronized(MUTATION){
      require(c,gen);File folder=root(c);File[] items=files(folder);
      SecretKey k=key(folder,true);long archive=0;int count=0;
      byte[] digest=MessageDigest.getInstance("SHA-256").digest(jpeg);
      for(File f:items){
        require(c,gen);if(!Files.isRegularFile(f.toPath(),LinkOption.NOFOLLOW_LINKS))throw new PhotoException("archive_unreadable");
        archive+=f.length();String name=f.getName();
        if(!name.endsWith(".atlasphoto"))throw new PhotoException("archive_interrupted");
        Entry e;
        try{e=readEntry(c,folder,k,name.substring(0,name.length()-11),gen);}
        catch(Exception unreadable){require(c,gen);throw new PhotoException("archive_unreadable");}count++;
        boolean same=MessageDigest.isEqual(digest,e.digest);Arrays.fill(e.jpeg,(byte)0);
        if(same)return e.metadata().put("status","ok").put("duplicate",true);
      }
      if(count>=MAX_COUNT||archive+MAX_PAYLOAD+64>MAX_ARCHIVE)throw new PhotoException("library_full");
      if(!folder.exists()&&!folder.mkdirs())throw new IOException("photo directory unavailable");
      String id="pm-"+UUID.randomUUID().toString().replace("-","");
      Entry e=new Entry(id,System.currentTimeMillis(),width,height,jpeg);byte[] payload=encode(e);
      File part=new File(folder,id+".pending");File dest=file(folder,id);boolean committed=false;
      try{
        VaultFileCodec.encryptNew(new ByteArrayInputStream(payload),part,k,MAX_PAYLOAD,()->OwnerSessionGate.isCurrent(c,gen));
        try(RandomAccessFile sync=new RandomAccessFile(part,"rw")){sync.getFD().sync();}
        synchronized(OwnerSessionGate.class){
          require(c,gen);if(dest.exists())throw new IOException("photo reference collision");
          Files.move(part.toPath(),dest.toPath(),StandardCopyOption.ATOMIC_MOVE);committed=true;
        }
        require(c,gen);return e.metadata().put("status","ok").put("duplicate",false);
      }finally{
        Arrays.fill(payload,(byte)0);
        if(!committed)Files.deleteIfExists(part.toPath());
      }
    }
  }
}
