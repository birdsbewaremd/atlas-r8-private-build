package com.sbh.atlasos;

import java.util.List;

/** Deterministically selects a transcript while respecting recognizer confidence and wake context. */
public final class TranscriptSelector {
  private TranscriptSelector() {}

  public static String choose(List<String> candidates, float[] confidence, boolean requireWake) {
    if (candidates == null || candidates.isEmpty()) return "";
    int best = -1;
    float bestScore = -Float.MAX_VALUE;
    for (int i = 0; i < candidates.size(); i++) {
      String normalized = VoiceCommandParser.normalize(candidates.get(i));
      if (normalized.isEmpty()) continue;
      if (requireWake && !VoiceCommandParser.containsWakePhrase(normalized)) continue;
      float score = 0f;
      if (confidence != null && i < confidence.length && !Float.isNaN(confidence[i]) && confidence[i] >= 0f) {
        score = confidence[i];
      } else {
        score = 1f - (i * 0.01f); // preserve recognizer ordering when confidence is unavailable
      }
      if (requireWake && VoiceCommandParser.extractWakeCommand(normalized) != null) score += 0.25f;
      if (score > bestScore) { bestScore = score; best = i; }
    }
    return best < 0 ? "" : VoiceCommandParser.normalize(candidates.get(best));
  }
}
