package com.sbh.atlasos;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaMetadataRetriever;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.Display;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;

/** A single, explicitly consented local screen recording. Never restarts or captures audio. */
public final class AtlasCaptureService extends Service {
    static final String ACTION_START = "com.sbh.atlasos.capture.START";
    static final String EXTRA_RESULT = "capture_result";
    static final String EXTRA_DATA = "capture_data";
    static final String EXTRA_TICKET = "capture_ticket";
    private static final String ACTION_STOP = "com.sbh.atlasos.capture.STOP";
    private static final String CHANNEL = "atlas_screen_capture_v1";
    private static final int NOTIFICATION_ID = 6401;
    private static final Object STATUS_LOCK = new Object();
    private static AtlasCaptureService live;
    private static String state = "stopped", phase = "idle";
    private static String message = "No screen session is active. Saved clips remain on this phone.";
    private static long startedElapsed, startedAtMs, recordedBytes, currentByteLimit = AtlasCaptureStore.MAX_BYTES;

    private final Handler main = new Handler(Looper.getMainLooper());
    private HandlerThread workerThread;
    private Handler worker;
    private volatile boolean accepted, stopRequested, complete;
    private boolean finishing, recorderStarted, receiverRegistered;
    private File temporary;
    private MediaRecorder recorder;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private long beganElapsed, beganAtMs;
    private long byteLimit = AtlasCaptureStore.MAX_BYTES;
    private int notificationTicks;

    /** Owner-only metadata. Media bytes and private paths never enter the WebView bridge. */
    public static JSONObject snapshot(Context context) throws Exception {
        long owner = OwnerSessionGate.capture(context);
        if (owner == 0L) throw new SecurityException("Unlock ATLAS to view screen sessions");
        JSONObject out = new JSONObject();
        out.put("maxDurationMs", AtlasCaptureStore.MAX_DURATION_MS)
                .put("maxBytes", AtlasCaptureStore.MAX_BYTES).put("audio", false)
                .put("archiveLimitBytes", AtlasCaptureStore.MAX_ARCHIVE_BYTES);
        try {
            AtlasCaptureStore.Library library = AtlasCaptureStore.library(context);
            long archiveBytes = AtlasCaptureStore.archiveBytes(context);
            out.put("historyStatus", "ok").put("count", library.clips.size())
                    .put("recordings", library.json()).put("unreadableCount", library.unreadable)
                    .put("archiveBytes", archiveBytes)
                    .put("nextSessionMaxBytes", AtlasCaptureStore.budgetForArchive(archiveBytes));
        } catch (Exception unavailable) {
            // A key/storage failure must not hide a real recording or its Stop control.
            out.put("historyStatus", "error")
                    .put("historyMessage", "Saved recording history is temporarily unavailable. Existing recordings are preserved.")
                    .put("count", JSONObject.NULL).put("recordings", new JSONArray())
                    .put("unreadableCount", JSONObject.NULL).put("archiveBytes", JSONObject.NULL)
                    .put("nextSessionMaxBytes", JSONObject.NULL);
        }
        // Read live state after disk work so slow history does not return stale running state.
        synchronized (STATUS_LOCK) {
            boolean running = "running".equals(state);
            out.put("state", state).put("phase", phase).put("message", message)
                    .put("running", running).put("busy", live != null && live.accepted && !live.complete)
                    .put("startedAtMs", startedAtMs).put("recordedBytes", recordedBytes)
                    .put("remainingDurationMs", running ? AtlasCaptureStore.remainingDuration(startedElapsed,
                            SystemClock.elapsedRealtime()) : 0L)
                    .put("remainingBytes", running ? Math.max(0L, currentByteLimit - recordedBytes) : 0L)
                    .put("sessionMaxBytes", currentByteLimit);
        }
        if (!OwnerSessionGate.isCurrent(context, owner))
            throw new SecurityException("Owner session ended");
        return out;
    }

    /** Stopping is always safe. It cannot arm or launch a capture service. */
    public static boolean requestStop(Context context) {
        AtlasCaptureService current;
        synchronized (STATUS_LOCK) { current = live; }
        if (current == null || !current.accepted || current.complete) return false;
        current.scheduleStop("Stopped by the owner.", false);
        return true;
    }

    static boolean isBusy() {
        synchronized (STATUS_LOCK) { return live != null && live.accepted && !live.complete; }
    }

    static void ensureNotificationChannel(Context context) {
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL,
                "Active screen recording", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("A visible local screen-recording session with a Stop control.");
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        manager.createNotificationChannel(channel);
    }

    static boolean notificationsAvailable(Context context) {
        try {
            if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) return false;
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            if (manager == null || !manager.areNotificationsEnabled()) return false;
            NotificationChannel channel = manager.getNotificationChannel(CHANNEL);
            return channel != null && channel.getImportance() != NotificationManager.IMPORTANCE_NONE;
        } catch (RuntimeException unavailable) { return false; }
    }

    static boolean screenUsable(Context context) {
        try {
            KeyguardManager keyguard = context.getSystemService(KeyguardManager.class);
            PowerManager power = context.getSystemService(PowerManager.class);
            return keyguard != null && power != null && power.isInteractive()
                    && !keyguard.isDeviceLocked() && !keyguard.isKeyguardLocked();
        } catch (RuntimeException unavailable) { return false; }
    }

    @Override public void onCreate() {
        super.onCreate();
        workerThread = new HandlerThread("atlas-local-screen-session");
        workerThread.start(); worker = new Handler(workerThread.getLooper());
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            if (accepted) scheduleStop("Stopped from the recording notification.", false);
            else stopSelf(startId);
            return START_NOT_STICKY;
        }
        String ticket = intent == null ? null : intent.getStringExtra(EXTRA_TICKET);
        boolean authorized = intent != null && ACTION_START.equals(intent.getAction())
                && AtlasCaptureActivity.consumeServiceTicket(ticket);
        if (!authorized || accepted || !screenUsable(this)) {
            if (!accepted) stopSelf(startId);
            return START_NOT_STICKY;
        }
        Intent consent = Build.VERSION.SDK_INT >= 33
                ? intent.getParcelableExtra(EXTRA_DATA, Intent.class) : intent.getParcelableExtra(EXTRA_DATA);
        int result = intent.getIntExtra(EXTRA_RESULT, Activity.RESULT_CANCELED);
        if (result != Activity.RESULT_OK || consent == null) { stopSelf(startId); return START_NOT_STICKY; }
        ensureNotificationChannel(this);
        if (!notificationsAvailable(this)) {
            status("error", "idle", "Recording did not start: enable the screen-recording notification first.", 0L, 0L, 0L);
            stopSelf(startId); return START_NOT_STICKY;
        }
        try {
            startForeground(NOTIFICATION_ID, notification("Preparing local screen recording", false),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } catch (RuntimeException unavailable) {
            status("error", "idle", "Android did not allow the recording service to start. No recording was made.", 0L, 0L, 0L);
            stopSelf(startId); return START_NOT_STICKY;
        }
        accepted = true;
        synchronized (STATUS_LOCK) { live = this; }
        status("stopped", "preparing", "Android consent received. Preparing the private recorder.", 0L, 0L, 0L);
        IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenOff, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(screenOff, filter);
        receiverRegistered = true;
        worker.post(() -> beginRecording(result, consent));
        // Never retain a consent result in persistent state or request an automatic restart.
        return START_NOT_STICKY;
    }

    private final BroadcastReceiver screenOff = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction()))
                scheduleStop("Screen turned off or device locked.", false);
        }
    };

    private final MediaProjection.Callback projectionCallback = new MediaProjection.Callback() {
        @Override public void onStop() {
            stopRequested = true;
            stopRecording("Android stopped screen sharing.", false);
        }
    };

    private void beginRecording(int result, Intent consent) {
        try {
            if (stopRequested || !screenUsable(this)) { stopRecording("Cancelled before capture began.", false); return; }
            AtlasCaptureStore.prepareForCapture(this);
            byteLimit = AtlasCaptureStore.recordingBudget(this);
            if (byteLimit < AtlasCaptureStore.MIN_RECORDING_BUDGET) {
                stopRecording("The 250 MB recording archive is full. Remove a selected clip before starting another session.", true);
                return;
            }
            synchronized (STATUS_LOCK) { currentByteLimit = byteLimit; }
            if (availableBytes() < byteLimit * 2L + AtlasCaptureStore.MIN_FREE_BYTES)
                throw new IllegalStateException("Insufficient private storage");
            temporary = AtlasCaptureStore.createRecordingFile(this);
            int[] size = captureSize();
            recorder = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
            recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            recorder.setVideoSize(size[0], size[1]);
            recorder.setVideoFrameRate(24);
            recorder.setVideoEncodingBitRate(1_200_000);
            // Stop slightly before the retention bounds to leave room for encoder finalization.
            recorder.setMaxDuration((int) AtlasCaptureStore.MAX_DURATION_MS - 1_000);
            recorder.setMaxFileSize(byteLimit - 1_000_000L);
            recorder.setOutputFile(temporary.getAbsolutePath());
            recorder.setOnInfoListener((source, what, extra) -> {
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED)
                    scheduleStop("The 10-minute session limit was reached.", false);
                else if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_FILESIZE_REACHED
                        || what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_FILESIZE_APPROACHING)
                    scheduleStop("The recording storage limit was reached.", false);
            });
            recorder.setOnErrorListener((source, what, extra) -> scheduleStop("Android reported a recording error.", true));
            recorder.prepare();
            if (stopRequested || !screenUsable(this) || !notificationsAvailable(this)) {
                stopRecording("Cancelled before capture began.", false); return;
            }
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            if (manager == null) throw new IllegalStateException("Screen sharing is unavailable");
            // Foreground mediaProjection service is already visible before consuming consent.
            projection = manager.getMediaProjection(result, consent);
            if (projection == null) throw new IllegalStateException("Android consent is unavailable");
            projection.registerCallback(projectionCallback, worker);
            virtualDisplay = projection.createVirtualDisplay("ATLAS explicit local screen session",
                    size[0], size[1], size[2], DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    recorder.getSurface(), null, worker);
            if (virtualDisplay == null) throw new IllegalStateException("Screen sharing is unavailable");
            if (stopRequested || !screenUsable(this)) { stopRecording("Cancelled before capture began.", false); return; }
            beganAtMs = System.currentTimeMillis(); beganElapsed = SystemClock.elapsedRealtime();
            recorder.start(); recorderStarted = true;
            if (stopRequested || !screenUsable(this)) {
                stopRecording("Screen turned off or device locked.", false); return;
            }
            status("running", "recording", "Recording locally without audio. Use Stop or lock the device to end it.",
                    beganElapsed, beganAtMs, 0L);
            updateNotification("Screen recording is active · no audio", true);
            worker.post(tick);
        } catch (Exception failure) {
            String reason = availableBytes() < byteLimit * 2L + AtlasCaptureStore.MIN_FREE_BYTES
                    ? "Not enough private storage. This session needs at least "
                        + ((byteLimit * 2L + AtlasCaptureStore.MIN_FREE_BYTES + 999_999L) / 1_000_000L) + " MB free."
                    : "Screen recording could not start or continue on this device. No active session remains.";
            stopRecording(reason, true);
        }
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (finishing || complete || !recorderStarted) return;
            if (stopRequested) { stopRecording("Screen recording stopped.", false); return; }
            if (!screenUsable(AtlasCaptureService.this)) { stopRecording("Screen turned off or device locked.", false); return; }
            if (!notificationsAvailable(AtlasCaptureService.this)) {
                stopRecording("Recording stopped because its notification was disabled.", false); return;
            }
            long bytes = temporary == null ? 0L : temporary.length();
            synchronized (STATUS_LOCK) { recordedBytes = bytes; }
            if (AtlasCaptureStore.remainingDuration(beganElapsed, SystemClock.elapsedRealtime()) == 0L) {
                stopRecording("The 10-minute session limit was reached.", false); return;
            }
            if (bytes >= byteLimit - 1_000_000L) {
                stopRecording("The recording storage limit was reached.", false); return;
            }
            if (availableBytes() < bytes + AtlasCaptureStore.MIN_FREE_BYTES) {
                stopRecording("Recording stopped to leave space for encrypted storage.", false); return;
            }
            if (++notificationTicks % 5 == 0) updateNotification("Screen recording is active · no audio", true);
            worker.postDelayed(this, 1_000L);
        }
    };

    private void scheduleStop(String reason, boolean error) {
        stopRequested = true;
        if (worker != null) worker.post(() -> stopRecording(reason, error));
    }

    private void stopRecording(String reason, boolean error) {
        if (finishing || complete) return;
        finishing = true; stopRequested = true;
        worker.removeCallbacks(tick);
        if (virtualDisplay != null) {
            try { virtualDisplay.release(); } catch (RuntimeException ignored) { }
            virtualDisplay = null;
        }
        if (projection != null) {
            try { projection.unregisterCallback(projectionCallback); } catch (RuntimeException ignored) { }
            try { projection.stop(); } catch (RuntimeException ignored) { }
            projection = null;
        }
        status("stopped", "finalizing", "Capture stopped. Finalizing encrypted local storage.",
                beganElapsed, beganAtMs, temporary == null ? 0L : temporary.length());
        updateNotification("Capture stopped · saving private recording", false);
        boolean hadRecording = recorderStarted;
        if (recorder != null) {
            if (recorderStarted) {
                try { recorder.stop(); }
                catch (RuntimeException incomplete) { /* Validate the finalized MP4 before retaining anything. */ }
            }
            try { recorder.release(); } catch (RuntimeException ignored) { }
            recorder = null; recorderStarted = false;
        }
        String finalMessage = reason;
        try {
            if (hadRecording && temporary != null && temporary.isFile()) {
                if (temporary.length() <= 0 || temporary.length() > byteLimit)
                    throw new IllegalStateException("Recording size was outside the retention limit");
                long duration = measuredDuration(temporary);
                AtlasCaptureStore.commit(this, temporary, beganAtMs, duration);
                finalMessage = reason + " An encrypted clip was saved on this phone.";
            } else if (!error) {
                finalMessage = reason + " No completed clip was created.";
            }
        } catch (Exception failedSave) {
            error = true;
            finalMessage = reason + " The unfinished clip could not be saved and was removed. Earlier clips are unchanged.";
        } finally {
            if (!AtlasCaptureStore.deleteTemporary(temporary)) {
                error = true;
                finalMessage = reason + " Capture has stopped, but private temporary-file cleanup failed. Cleanup will retry on the next app process. Earlier clips are unchanged.";
            }
            temporary = null;
        }
        complete = true;
        status(error ? "error" : "stopped", "idle", finalMessage, beganElapsed, beganAtMs, 0L);
        synchronized (STATUS_LOCK) { if (live == this) live = null; }
        main.post(() -> {
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            if (workerThread != null) workerThread.quitSafely();
        });
    }

    private static long measuredDuration(File file) throws Exception {
        MediaMetadataRetriever metadata = new MediaMetadataRetriever();
        try {
            metadata.setDataSource(file.getAbsolutePath());
            String raw = metadata.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            String video = metadata.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO);
            String audio = metadata.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO);
            long duration = raw == null ? 0L : Long.parseLong(raw);
            // Android defines these keys by presence; do not depend on an OEM's string spelling.
            if (video == null || audio != null || duration <= 0L || duration > AtlasCaptureStore.MAX_DURATION_MS)
                throw new IllegalStateException("Recording did not finalize within the session limit");
            return duration;
        } finally { metadata.release(); }
    }

    private long availableBytes() {
        try { return new StatFs(getNoBackupFilesDir().getAbsolutePath()).getAvailableBytes(); }
        catch (RuntimeException unavailable) { return 0L; }
    }

    private int[] captureSize() {
        DisplayManager manager = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        Display display = manager == null ? null : manager.getDisplay(Display.DEFAULT_DISPLAY);
        if (display == null) throw new IllegalStateException("Display unavailable");
        DisplayMetrics metrics = new DisplayMetrics(); display.getRealMetrics(metrics);
        int width = metrics.widthPixels, height = metrics.heightPixels;
        if (width <= 0 || height <= 0) throw new IllegalStateException("Display bounds unavailable");
        double scale = Math.min(1.0, Math.min(1280.0 / Math.max(width, height), 720.0 / Math.min(width, height)));
        width = Math.max(16, ((int) (width * scale) / 16) * 16);
        height = Math.max(16, ((int) (height * scale) / 16) * 16);
        return new int[]{width, height, Math.max(1, metrics.densityDpi)};
    }

    private Notification notification(String text, boolean recording) {
        Intent stop = new Intent(this, AtlasCaptureService.class).setAction(ACTION_STOP);
        PendingIntent stopAction = PendingIntent.getService(this, NOTIFICATION_ID, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.presence_video_busy)
                .setContentTitle("ATLAS screen session").setContentText(text)
                .setOngoing(true).setOnlyAlertOnce(true).setVisibility(Notification.VISIBILITY_PUBLIC)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setStyle(new Notification.BigTextStyle().bigText(text
                        + ". Local video only; no audio. Maximum 10 minutes / 100 MB. Locking the device stops capture."))
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause, "Stop", stopAction).build());
        if (recording) builder.setWhen(beganAtMs).setUsesChronometer(true);
        if (Build.VERSION.SDK_INT >= 31) builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        return builder.build();
    }

    private void updateNotification(String text, boolean recording) {
        main.post(() -> {
            if (complete) return;
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                try { manager.notify(NOTIFICATION_ID, notification(text, recording)); }
                catch (RuntimeException unavailable) { scheduleStop("Recording notification became unavailable.", false); }
            }
        });
    }

    private static void status(String nextState, String nextPhase, String detail,
                               long elapsed, long created, long bytes) {
        synchronized (STATUS_LOCK) {
            state = nextState; phase = nextPhase; message = detail;
            startedElapsed = elapsed; startedAtMs = created; recordedBytes = Math.max(0L, bytes);
        }
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        scheduleStop("ATLAS was closed.", false);
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        if (receiverRegistered) {
            try { unregisterReceiver(screenOff); } catch (RuntimeException ignored) { }
            receiverRegistered = false;
        }
        if (accepted && !complete) scheduleStop("The recording service ended.", false);
        else if (workerThread != null) workerThread.quitSafely();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
