package com.sbh.atlasos;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Locale;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Optional native-only OpenAI transport. No browser network path, tools, redirects,
 * automatic retries, credential persistence or private-file discovery lives here.
 * Each request is bound to its caller's revocable owner/operation gate.
 */
public final class AtlasBrainTransport {
  public static final String DEFAULT_MODEL = "gpt-6-luna";
  static final int MAX_MODEL_BYTES = 64 * 1024;
  static final int MAX_RESPONSE_BYTES = 1024 * 1024;
  static final int MAX_ANSWER_CHARS = 40000;
  private static final int CONNECT_TIMEOUT_MS = 15000;
  private static final int READ_TIMEOUT_MS = 45000;
  private static final long REQUEST_BUDGET_NS = 90L * 1000L * 1000L * 1000L;
  public interface Gate { boolean allowed(); }
  interface ConnectionFactory { HttpsURLConnection open(URL url) throws IOException; }

  public static final class Failure extends Exception {
    public final String code;
    public Failure(String code) { super(message(code)); this.code = code; }
    private static String message(String code) {
      if ("locked".equals(code)) return "Unlock ATLAS and start the request again.";
      if ("cancelled".equals(code)) return "The request was stopped. Data already sent cannot be recalled.";
      if ("busy".equals(code)) return "Another AI request is still running. Stop it or wait for it to finish.";
      if ("timeout".equals(code)) return "The AI service took too long. Check the connection and try again.";
      if ("unauthorized".equals(code)) return "The service did not accept this API key or its access.";
      if ("rate_limited".equals(code)) return "The service limit was reached. Check the API account and try later.";
      if ("service_unavailable".equals(code)) return "The AI service is temporarily unavailable.";
      if ("request_rejected".equals(code)) return "The service rejected this request. Check the model and connection settings.";
      if ("redirect_blocked".equals(code)) return "The service tried to redirect the request. ATLAS did not follow it.";
      if ("response_too_large".equals(code)) return "The service response exceeded the safe size limit.";
      if ("invalid_response".equals(code)) return "The service returned an unreadable or unexpected response.";
      if ("incomplete".equals(code)) return "The service did not complete the answer. Try a shorter request.";
      if ("network".equals(code)) return "The AI service could not be reached. Your local files remain available.";
      return "Check the connection settings and the size of your request.";
    }
  }

  private static final class Request {
    final Gate gate;
    final long started = System.nanoTime();
    volatile boolean cancelled;
    HttpsURLConnection connection;
    Request(Gate gate) { this.gate = gate; }
  }
  private final Object lock = new Object();
  private final ConnectionFactory factory;
  private Request active;

  public AtlasBrainTransport() {
    this(url -> (HttpsURLConnection) url.openConnection());
  }
  AtlasBrainTransport(ConnectionFactory factory) {
    if (factory == null) throw new IllegalArgumentException("connection factory required");
    this.factory = factory;
  }

  public static boolean validModel(String model) {
    if (model == null || model.length() < 1 || model.length() > 80) return false;
    for (int i = 0; i < model.length(); i++) {
      char c = model.charAt(i);
      boolean alpha = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
      boolean digit = c >= '0' && c <= '9';
      if (!(alpha || digit || (i > 0 && (c == '-' || c == '_' || c == '.' || c == ':')))) return false;
    }
    return true;
  }
  public static boolean validKey(String key) {
    if (key == null || key.length() < 4 || key.length() > 1024 || !key.startsWith("sk-")) return false;
    for (int i = 3; i < key.length(); i++) {
      char c = key.charAt(i);
      if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
          (c >= '0' && c <= '9') || c == '-' || c == '_')) return false;
    }
    return true;
  }

  /** An accessible model id is not proof of a completed conversational answer. */
  public void testModel(String key, String model, Gate gate) throws Failure {
    validateCredentials(key, model);
    Request request = begin(gate);
    try {
      String encoded = URLEncoder.encode(model, "UTF-8");
      String body = exchange(request, key, "GET", "/v1/models/" + encoded, null, MAX_MODEL_BYTES);
      JSONObject result = new JSONObject(body);
      if (!"model".equals(result.opt("object")) || !model.equals(result.opt("id")))
        throw new Failure("invalid_response");
      check(request);
    } catch (Failure failure) { throw failure; }
    catch (Exception invalid) { throw interruptedOr(request, "invalid_response"); }
    finally { finish(request); }
  }

  public String answer(String key, String model, String instructions, String input, Gate gate) throws Failure {
    validateCredentials(key, model);
    if (instructions == null || instructions.length() > 12000 ||
        input == null || input.trim().isEmpty() || input.length() > 20000)
      throw new Failure("invalid");
    byte[] payload = null;
    Request request = begin(gate);
    try {
      JSONObject body = new JSONObject().put("model", model).put("store", false)
        .put("max_output_tokens", 1200).put("instructions", instructions).put("input", input);
      if (DEFAULT_MODEL.equals(model))
        body.put("reasoning", new JSONObject().put("effort", "none"));
      payload = encode(body.toString(), MAX_RESPONSE_BYTES);
      String raw = exchange(request, key, "POST", "/v1/responses", payload, MAX_RESPONSE_BYTES);
      JSONObject response = new JSONObject(raw);
      if (!"response".equals(response.opt("object"))) throw new Failure("invalid_response");
      if (response.has("error") && !response.isNull("error")) throw new Failure("request_rejected");
      Object status = response.opt("status");
      if (!"completed".equals(status)) throw new Failure("incomplete");
      JSONArray output = response.optJSONArray("output");
      if (output == null) throw new Failure("invalid_response");
      StringBuilder answer = new StringBuilder();
      for (int i = 0; i < output.length(); i++) {
        check(request);
        JSONObject item = output.optJSONObject(i);
        if (item == null) throw new Failure("invalid_response");
        if (!"message".equals(item.opt("type"))) continue;
        if (!"assistant".equals(item.opt("role"))) continue;
        Object messageStatus = item.opt("status");
        if (messageStatus != null && messageStatus != JSONObject.NULL && !"completed".equals(messageStatus))
          throw new Failure("incomplete");
        JSONArray content = item.optJSONArray("content");
        if (content == null) throw new Failure("invalid_response");
        for (int j = 0; j < content.length(); j++) {
          JSONObject part = content.optJSONObject(j);
          if (part == null) throw new Failure("invalid_response");
          String field;
          if ("output_text".equals(part.opt("type"))) field = "text";
          else if ("refusal".equals(part.opt("type"))) field = "refusal";
          else continue;
          Object value = part.opt(field);
          if (!(value instanceof String)) throw new Failure("invalid_response");
          String text = (String) value;
          if (text.isEmpty()) continue;
          if (answer.length() + text.length() + (answer.length() == 0 ? 0 : 2) > MAX_ANSWER_CHARS)
            throw new Failure("response_too_large");
          if (answer.length() > 0) answer.append("\n\n");
          answer.append(text);
        }
      }
      if (answer.toString().trim().isEmpty()) throw new Failure("invalid_response");
      check(request);
      return answer.toString();
    } catch (Failure failure) { throw failure; }
    catch (Exception invalid) { throw interruptedOr(request, "invalid_response"); }
    finally {
      if (payload != null) Arrays.fill(payload, (byte) 0);
      finish(request);
    }
  }

  /** Retire this request before disconnecting, so a new request may start safely. */
  public void cancel() {
    HttpsURLConnection old = null;
    synchronized (lock) {
      if (active != null) {
        active.cancelled = true;
        old = active.connection;
        active = null;
      }
    }
    disconnect(old);
  }

  private static void validateCredentials(String key, String model) throws Failure {
    if (!validKey(key) || !validModel(model)) throw new Failure("invalid");
  }
  private static boolean allowed(Gate gate) {
    try { return gate != null && gate.allowed(); }
    catch (Exception unavailable) { return false; }
  }
  private Request begin(Gate gate) throws Failure {
    if (!allowed(gate)) throw new Failure("locked");
    synchronized (lock) {
      if (active != null) throw new Failure("busy");
      if (!allowed(gate)) throw new Failure("locked");
      Request next = new Request(gate);
      active = next;
      return next;
    }
  }
  private void check(Request request) throws Failure {
    synchronized (lock) {
      if (request.cancelled || active != request) throw new Failure("cancelled");
    }
    if (!allowed(request.gate)) throw new Failure("locked");
    long elapsed = System.nanoTime() - request.started;
    if (elapsed < 0 || elapsed > REQUEST_BUDGET_NS) throw new Failure("timeout");
  }
  private Failure interruptedOr(Request request, String otherwise) {
    try { check(request); }
    catch (Failure ended) { return ended; }
    return new Failure(otherwise);
  }
  private void finish(Request request) {
    HttpsURLConnection own;
    synchronized (lock) {
      own = request.connection;
      request.connection = null;
      if (active == request) active = null;
    }
    disconnect(own);
  }
  private static void disconnect(HttpsURLConnection connection) {
    if (connection != null) try { connection.disconnect(); } catch (RuntimeException ignored) {}
  }

  private String exchange(Request request, String key, String method, String path,
      byte[] payload, int maxBytes) throws Failure {
    HttpsURLConnection connection = null;
    try {
      check(request);
      // The caller cannot supply an origin, URL, headers, tools or redirect target.
      connection = factory.open(new URL("https://api.openai.com" + path));
      if (connection == null) throw new Failure("network");
      synchronized (lock) {
        if (request.cancelled || active != request) throw new Failure("cancelled");
        request.connection = connection;
      }
      check(request);
      connection.setInstanceFollowRedirects(false);
      connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
      connection.setReadTimeout(READ_TIMEOUT_MS);
      connection.setUseCaches(false);
      connection.setRequestMethod(method);
      connection.setRequestProperty("Accept", "application/json");
      connection.setRequestProperty("Accept-Encoding", "identity");
      connection.setRequestProperty("Authorization", "Bearer " + key);
      connection.setRequestProperty("User-Agent", "ATLAS/0.8");
      if (payload != null) {
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        connection.setFixedLengthStreamingMode(payload.length);
        check(request);
        try (OutputStream out = connection.getOutputStream()) {
          for (int offset = 0; offset < payload.length; offset += 4096) {
            check(request);
            out.write(payload, offset, Math.min(4096, payload.length - offset));
          }
          check(request);
          out.flush();
        }
      }
      check(request);
      int status = connection.getResponseCode();
      check(request);
      if (status >= 300 && status < 400) throw new Failure("redirect_blocked");
      if (status == 401 || status == 403) throw new Failure("unauthorized");
      if (status == 429) throw new Failure("rate_limited");
      if (status >= 500 && status <= 599) throw new Failure("service_unavailable");
      if (status < 200 || status >= 300) throw new Failure("request_rejected");
      String type = connection.getContentType();
      if (type == null || !"application/json".equals(type.split(";", 2)[0].trim().toLowerCase(Locale.ROOT)))
        throw new Failure("invalid_response");
      String encoding = connection.getContentEncoding();
      if (encoding != null && !encoding.trim().isEmpty() && !"identity".equalsIgnoreCase(encoding.trim()))
        throw new Failure("invalid_response");
      if (connection.getContentLengthLong() > maxBytes) throw new Failure("response_too_large");
      check(request);
      try (InputStream in = connection.getInputStream(); ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
        byte[] buffer = new byte[4096];
        for (;;) {
          check(request);
          int count = in.read(buffer, 0, Math.min(buffer.length, maxBytes + 1 - bytes.size()));
          check(request);
          if (count < 0) break;
          if (count == 0) continue;
          if (bytes.size() + count > maxBytes) throw new Failure("response_too_large");
          bytes.write(buffer, 0, count);
        }
        byte[] raw = bytes.toByteArray();
        try {
          String result = StandardCharsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(raw)).toString();
          check(request);
          return result;
        } finally { Arrays.fill(raw, (byte) 0); Arrays.fill(buffer, (byte) 0); }
      }
    } catch (Failure failure) { throw failure; }
    catch (SocketTimeoutException timeout) { throw interruptedOr(request, "timeout"); }
    catch (CharacterCodingException invalid) { throw interruptedOr(request, "invalid_response"); }
    catch (IOException network) { throw interruptedOr(request, "network"); }
    catch (Exception invalid) { throw interruptedOr(request, "invalid_response"); }
    finally {
      // If cancel raced before request.connection assignment, this still closes only
      // this local connection. It can never disconnect a newer request's connection.
      disconnect(connection);
    }
  }
  private static byte[] encode(String value, int limit) throws Failure {
    try {
      ByteBuffer encoded = StandardCharsets.UTF_8.newEncoder()
        .onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
        .encode(CharBuffer.wrap(value));
      if (encoded.remaining() > limit) throw new Failure("invalid");
      byte[] bytes = new byte[encoded.remaining()];
      encoded.get(bytes);
      return bytes;
    } catch (CharacterCodingException invalid) { throw new Failure("invalid"); }
  }
}

