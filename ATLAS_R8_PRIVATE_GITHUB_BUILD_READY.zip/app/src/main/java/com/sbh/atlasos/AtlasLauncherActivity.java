package com.sbh.atlasos;

import android.app.Activity;
import android.app.role.RoleManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.LauncherActivityInfo;
import android.content.pm.LauncherApps;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Process;
import android.os.UserHandle;
import android.os.UserManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * A genuine user-selectable Android HOME activity, separate from the private vault.
 * No background surveillance, read-SMS, default SMS/Dialer role, lock-screen overlay,
 * or custom keyguard. Existing ATLAS MainActivity remains the secured private core.
 * External applications launch as themselves with their usual Android permissions.
 */
public final class AtlasLauncherActivity extends Activity {
    private static final int NIGHT = Color.rgb(9, 8, 20);
    private static final int SURFACE = Color.rgb(26, 23, 47);
    private static final int PURPLE = Color.rgb(160, 113, 249);
    private static final int WHITE = Color.WHITE;
    private static final int MUTED = Color.rgb(181, 180, 199);
    private final ArrayList<AppEntry> all = new ArrayList<>();
    private final ArrayList<AppEntry> filtered = new ArrayList<>();
    private LauncherApps launcherApps;
    private LinearLayout stage;
    private TextView appCount;
    private AppsAdapter appsAdapter;
    private boolean drawerVisible = false;
    private String filter = "";
    private String discoveryError = "";

    private static final class AppEntry {
        final String name;
        final ComponentName component;
        final UserHandle user;
        final boolean primary;
        final LauncherActivityInfo launcherInfo; // null only for PackageManager fallback
        final Drawable fallbackIcon;
        AppEntry(String n, ComponentName c, UserHandle u, boolean p, LauncherActivityInfo info, Drawable icon) {
            name=n;component=c;user=u;primary=p;launcherInfo=info;fallbackIcon=icon;
        }
        String key(){return component.flattenToString()+"|"+user.toString();}
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        // Never use setShowWhenLocked, dismissKeyguard, a device-admin role, or fullscreen flags.
        getWindow().setStatusBarColor(NIGHT);
        getWindow().setNavigationBarColor(NIGHT);
        launcherApps=(LauncherApps)getSystemService(Context.LAUNCHER_APPS_SERVICE);
        collectApps();
        showUniverse();
    }

    @Override public void onResume() {
        super.onResume();
        collectApps();
        if (drawerVisible) refreshResults(); else refreshFavorites();
    }

    private int dp(float value){return Math.round(getResources().getDisplayMetrics().density * value);}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private GradientDrawable surface(int color,int radius){
        GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;
    }
    private TextView text(String value,int size,int color,boolean heavy){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);
        if(heavy)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        t.setIncludeFontPadding(true);return t;
    }
    private Button button(String value){
        Button b=new Button(this);b.setAllCaps(false);b.setText(value);b.setTextSize(15);b.setTextColor(WHITE);
        b.setBackground(surface(SURFACE,16));b.setMinHeight(dp(52));
        b.setPadding(dp(12),dp(7),dp(12),dp(7));return b;
    }
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void gap(LinearLayout parent,int pixels){ View spacer=new View(this);parent.addView(spacer,lp(1,pixels)); }

    private void startShell(){
        LinearLayout outer=vertical();outer.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{Color.rgb(28,15,53),NIGHT,Color.rgb(10,13,30)}));
        outer.setPadding(dp(14),dp(8),dp(14),dp(6));
        setContentView(outer); stage=outer;
        LinearLayout head=horizontal();
        TextView brand=text("△  ATLAS ONE",22,WHITE,true);
        head.addView(brand,new LinearLayout.LayoutParams(0,dp(55),1));
        Button settings=button("⚙");settings.setContentDescription("Android system settings");
        settings.setOnClickListener(v->openSystem(Settings.ACTION_SETTINGS));
        head.addView(settings,lp(58,50));outer.addView(head);
        LinearLayout tabs=horizontal();
        Button universe=button("◎ Universe");Button apps=button("▦ All apps");
        universe.setContentDescription("Open ATLAS Universe launcher home");
        apps.setContentDescription("Open installed Android apps and search");
        universe.setOnClickListener(v->showUniverse());apps.setOnClickListener(v->showApps());
        LinearLayout.LayoutParams tab1=new LinearLayout.LayoutParams(0,dp(54),1);tab1.rightMargin=dp(8);
        tabs.addView(universe,tab1);tabs.addView(apps,new LinearLayout.LayoutParams(0,dp(54),1));
        (drawerVisible?apps:universe).setBackground(surface(Color.rgb(93,51,154),16));
        outer.addView(tabs);gap(outer,10);
    }

    private void showUniverse(){
        drawerVisible=false;
        startShell();
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);
        stage.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout body=vertical();body.setPadding(dp(2),dp(7),dp(2),dp(10));scroll.addView(body);
        TextView eyebrow=text("YOUR REAL ANDROID HOME",12,PURPLE,true);body.addView(eyebrow);
        gap(body,6);
        body.addView(text("Your phone. Your ATLAS.",29,WHITE,true));
        gap(body,8);
        body.addView(text("Universe is your home. Installed Android apps remain real apps, not copies. The private ATLAS vault stays locked until you unlock it.",14,MUTED,false));
        gap(body,18);
        Button openCore=button("◈ Open ATLAS Universe & Private Core");
        openCore.setBackground(surface(Color.rgb(92,44,159),19));
        openCore.setOnClickListener(v->{try{startActivity(new Intent(this,MainActivity.class));}catch(RuntimeException e){tip("ATLAS Core is unavailable");}});
        body.addView(openCore,lp(-1,68));gap(body,14);
        Button access=button("✧ Access Center · Grant and review permissions");
        access.setBackground(surface(Color.rgb(64,44,122),16));
        access.setOnClickListener(v->openAccessCenter());
        body.addView(access,lp(-1,63));gap(body,14);
        body.addView(text("ESSENTIALS",12,PURPLE,true));gap(body,8);
        shortcutPair(body,"Phone","Messages",()->openDialer(),()->openMessaging());
        shortcutPair(body,"Camera","Contacts",()->openCamera(),()->openContacts());
        shortcutPair(body,"All installed apps","Android Settings",()->showApps(),()->openSystem(Settings.ACTION_SETTINGS));
        gap(body,18);
        body.addView(text("PINNED APPS",12,PURPLE,true));gap(body,8);
        TextView note=text("Hold an app in All apps to pin or unpin it. Pins stay on this device.",13,MUTED,false);body.addView(note);
        LinearLayout favorites=vertical();favorites.setTag("favorites_container");body.addView(favorites);
        fillFavorites(favorites);
        gap(body,18);
        body.addView(text("CONTROL YOUR ANDROID HOME",12,PURPLE,true));gap(body,7);
        Button role=button("Choose ATLAS as default Home (system approval)");role.setOnClickListener(v->requestHome());
        body.addView(role,lp(-1,62));gap(body,7);
        Button restore=button("Restore Samsung One UI Home / Default apps");restore.setOnClickListener(v->openSystem(Settings.ACTION_HOME_SETTINGS));
        body.addView(restore,lp(-1,62));gap(body,7);
        Button lock=button("Customize Samsung lock screen & wallpaper");
        lock.setOnClickListener(v->{tip("Samsung's PIN and fingerprint stay active. Choose wallpaper or lock-screen style in Settings.");openSystem(Settings.ACTION_WALLPAPER_SETTINGS);});
        body.addView(lock,lp(-1,62));gap(body,8);
        body.addView(text("Android's secure PIN, fingerprint, calls and emergency functions remain Samsung-controlled. No lock-screen bypass or automatic permissions.",12,MUTED,false));
        attachDock();
    }

    private void shortcutPair(LinearLayout body,String left,String right,Runnable a,Runnable b){
        LinearLayout row=horizontal();Button x=button(left),y=button(right);
        LinearLayout.LayoutParams first=new LinearLayout.LayoutParams(0,dp(62),1);first.rightMargin=dp(8);
        row.addView(x,first);row.addView(y,new LinearLayout.LayoutParams(0,dp(62),1));
        x.setOnClickListener(v->a.run());y.setOnClickListener(v->b.run());
        body.addView(row);gap(body,8);
    }

    private void attachDock(){
        gap(stage,8);LinearLayout dock=horizontal();
        Button phone=button("Call");Button msg=button("Messages");Button apps=button("Apps");
        for(Button b:new Button[]{phone,msg,apps}){
            LinearLayout.LayoutParams param=new LinearLayout.LayoutParams(0,dp(56),1);param.rightMargin=dp(4);dock.addView(b,param);
        }
        phone.setOnClickListener(v->openDialer());msg.setOnClickListener(v->openMessaging());apps.setOnClickListener(v->showApps());
        stage.addView(dock);
    }

    private void showApps(){
        drawerVisible=true;startShell();
        TextView h=text("Installed Android apps",22,WHITE,true);stage.addView(h);gap(stage,4);
        appCount=text("Checking available launcher apps…",13,MUTED,false);stage.addView(appCount);gap(stage,8);
        EditText find=new EditText(this);find.setSingleLine(true);find.setTextColor(WHITE);
        find.setHintTextColor(MUTED);find.setHint("Search installed apps");
        find.setBackground(surface(SURFACE,14));find.setPadding(dp(16),0,dp(16),0);
        find.setText(filter);find.setTextSize(17);
        stage.addView(find,lp(-1,58));gap(stage,8);
        ListView list=new ListView(this);list.setDividerHeight(dp(2));
        list.setBackgroundColor(Color.TRANSPARENT);list.setCacheColorHint(Color.TRANSPARENT);
        appsAdapter=new AppsAdapter();list.setAdapter(appsAdapter);
        list.setOnItemClickListener((parent,view,position,id)->{
            if(position>=0&&position<filtered.size())launch(filtered.get(position));
        });
        list.setOnItemLongClickListener((parent,view,position,id)->{
            if(position>=0&&position<filtered.size()){toggleFavorite(filtered.get(position));return true;}
            return false;
        });
        stage.addView(list,new LinearLayout.LayoutParams(-1,0,1));
        find.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){filter=s.toString();refreshResults();}
            public void afterTextChanged(Editable editable){}
        });
        refreshResults();attachDock();
    }

    private final class AppsAdapter extends BaseAdapter {
        public int getCount(){return filtered.size();}
        public Object getItem(int p){return filtered.get(p);}
        public long getItemId(int p){return p;}
        public View getView(int pos,View reuse,ViewGroup parent){
            AppEntry e=filtered.get(pos);
            LinearLayout row=horizontal();row.setPadding(dp(9),dp(6),dp(9),dp(6));
            ImageView icon=new ImageView(AtlasLauncherActivity.this);
            try{Drawable image=e.launcherInfo!=null?e.launcherInfo.getIcon(0):e.fallbackIcon;
                icon.setImageDrawable(image);}
            catch(RuntimeException ignored){};
            row.addView(icon,lp(43,43));
            LinearLayout nameColumn=vertical();nameColumn.setPadding(dp(13),0,0,0);
            nameColumn.addView(text(e.name,16,WHITE,true));
            boolean favorite=favorites().contains(e.key());
            nameColumn.addView(text((e.primary?"Android app":"Profile app")+(favorite?" · Pinned":"")+" · Hold to pin",12,MUTED,false));
            row.addView(nameColumn,new LinearLayout.LayoutParams(0,dp(63),1));
            row.setContentDescription(e.name+(e.primary?"":" profile")+(favorite?" pinned":""));
            return row;
        }
    }

    private void refreshResults(){
        String q=filter.toLowerCase(Locale.ROOT).trim();filtered.clear();
        for(AppEntry item:all) if(q.length()==0||item.name.toLowerCase(Locale.ROOT).contains(q)
          ||item.component.getPackageName().toLowerCase(Locale.ROOT).contains(q))filtered.add(item);
        if(appsAdapter!=null)appsAdapter.notifyDataSetChanged();
        if(appCount!=null)appCount.setText(filtered.size()+" of "+all.size()+" accessible launchable apps"
            +(discoveryError.length()==0?"":" · "+discoveryError));
    }

    private void collectApps(){
        all.clear();discoveryError="";
        final HashSet<String> seen=new HashSet<>();
        try{
            if(launcherApps!=null){
                List<UserHandle> profiles=launcherApps.getProfiles();
                for(UserHandle user:profiles){
                    try{
                        for(LauncherActivityInfo info:launcherApps.getActivityList(null,user)){
                            ComponentName component=info.getComponentName();
                            if(component==null||component.getClassName().endsWith("AtlasLauncherActivity"))continue;
                            String name=String.valueOf(info.getLabel());
                            if(name.isEmpty())name=component.getPackageName();
                            AppEntry e=new AppEntry(name,component,user,Process.myUserHandle().equals(user),info,null);
                            if(seen.add(e.key()))all.add(e);
                        }
                    }catch(SecurityException blocked){discoveryError="Profile access restricted by Android";}
                    catch(RuntimeException unavailable){discoveryError="One profile is unavailable";}
                }
            }
        }catch(SecurityException restricted){discoveryError="Android limits launcher discovery";}
        catch(RuntimeException failed){discoveryError="Launcher service unavailable";}
        if(all.isEmpty()){
            // Fallback for when HOME has not yet been chosen; only the current profile.
            try {
                Intent query=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> found=getPackageManager().queryIntentActivities(query,0);
                for(ResolveInfo entry:found){
                    if(entry.activityInfo==null||!entry.activityInfo.enabled||!entry.activityInfo.exported)continue;
                    ComponentName c=new ComponentName(entry.activityInfo.packageName,entry.activityInfo.name);
                    String n=String.valueOf(entry.loadLabel(getPackageManager()));
                    AppEntry app=new AppEntry(n,c,Process.myUserHandle(),true,null,entry.loadIcon(getPackageManager()));
                    if(seen.add(app.key()))all.add(app);
                }
            } catch(RuntimeException e){discoveryError="Android app discovery unavailable";}
        }
        final Collator order=Collator.getInstance(Locale.getDefault());
        Collections.sort(all,(a,b)->{int v=order.compare(a.name,b.name);return v!=0?v:a.component.flattenToString().compareTo(b.component.flattenToString());});
    }

    private void launch(AppEntry app){
        try{
            if(launcherApps!=null&&app.launcherInfo!=null){
                launcherApps.startMainActivity(app.component,app.user,null,null);
            }else if(app.primary){
                Intent intent=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                intent.setComponent(app.component).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                startActivity(intent);
            }else {tip("Android has not granted access to this profile");}
        } catch(ActivityNotFoundException missing){tip("App no longer installed. Refresh the list.");collectApps();refreshResults();}
        catch(SecurityException denied){tip("Android blocked this profile or app launch.");}
        catch(RuntimeException error){tip("Unable to open app. You can still use Samsung One UI Home.");}
    }

    private Set<String> favorites(){return new HashSet<>(getSharedPreferences("atlas_launcher_owner",MODE_PRIVATE).getStringSet("favorites",Collections.emptySet()));}
    private void toggleFavorite(AppEntry app){
        Set<String> saved=favorites();boolean added=saved.add(app.key());if(!added)saved.remove(app.key());
        getSharedPreferences("atlas_launcher_owner",MODE_PRIVATE).edit().putStringSet("favorites",saved).apply();
        tip(added?"Pinned to Universe":"Removed from favorites");refreshResults();
    }
    private void refreshFavorites(){ /* Rebuilt whenever Universe opens; no background reads. */ }
    private void fillFavorites(LinearLayout target){
        target.removeAllViews();int displayed=0;Set<String> pinned=favorites();
        for(AppEntry app:all){if(!pinned.contains(app.key()))continue;
            Button b=button(app.name+(app.primary?"":" · Profile"));b.setOnClickListener(v->launch(app));
            target.addView(b,lp(-1,55));gap(target,5);displayed++;if(displayed>=16)break;
        }
        if(displayed==0){TextView empty=text("No apps pinned yet. Your full Android app list is available above.",13,MUTED,false);target.addView(empty);}
    }
    private void openAccessCenter(){
        try{ startActivity(new Intent(this,AtlasAccessCenterActivity.class)); }
        catch(RuntimeException unavailable){tip("Access Center unavailable; open Android Settings → Apps → ATLAS");}
    }
    private void openDialer(){openIntent(new Intent(Intent.ACTION_DIAL),"Phone dialer");}
    private void openMessaging(){
        // Favor the owner's requested Google Messages when it is actually installed.
        // Otherwise open whichever messaging app Android handles; never change SMS role.
        for(AppEntry app:all){
            if(app.primary&&"com.google.android.apps.messaging".equals(app.component.getPackageName())){
                launch(app);return;
            }
        }
        Intent intent=Intent.makeMainSelectorActivity(Intent.ACTION_MAIN,Intent.CATEGORY_APP_MESSAGING);
        openIntent(intent,"Messaging app");
    }
    private void openContacts(){openIntent(new Intent(Intent.ACTION_VIEW,android.provider.ContactsContract.Contacts.CONTENT_URI),"Contacts");}
    private void openCamera(){openIntent(new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),"Camera");}
    private void openIntent(Intent intent,String description){
        try{startActivity(intent);}catch(ActivityNotFoundException noApp){tip(description+" not available. Find its icon in All apps.");}
        catch(SecurityException denied){tip("Android did not allow this action.");}
        catch(RuntimeException failed){tip(description+" unavailable. Use All apps.");}
    }
    private void openSystem(String action){
        try{startActivity(new Intent(action));}
        catch(RuntimeException e){try{startActivity(new Intent(Settings.ACTION_SETTINGS));}catch(RuntimeException ignored){tip("Android Settings unavailable");}}
    }
    private void requestHome(){
        try{
            if(android.os.Build.VERSION.SDK_INT>=29){
                RoleManager roles=(RoleManager)getSystemService(Context.ROLE_SERVICE);
                if(roles!=null&&roles.isRoleAvailable(RoleManager.ROLE_HOME)){
                    if(roles.isRoleHeld(RoleManager.ROLE_HOME)){tip("ATLAS is already the default Home");return;}
                    startActivity(roles.createRequestRoleIntent(RoleManager.ROLE_HOME));return;
                }
            }
        }catch(RuntimeException ignored){}
        // User chooses in Android-owned Settings. We never change Home automatically.
        openSystem(Settings.ACTION_HOME_SETTINGS);
    }
    private void tip(String message){Toast.makeText(this,message,Toast.LENGTH_SHORT).show();}
    @Override public void onBackPressed(){if(drawerVisible){filter="";showUniverse();}else showUniverse();}
}
