package com.sbh.atlasos;

/** Pure-Java limits and path validation for importing the encrypted private seed. */
public final class SeedImportPolicy {
  public static final int MAX_FILES = 5000;
  public static final int MAX_PATH_CHARS = 512;
  public static final long MAX_FILE_BYTES = 128L * 1024L * 1024L;
  public static final long MAX_TOTAL_BYTES = 1024L * 1024L * 1024L;

  private SeedImportPolicy() {}

  public static String safeRelative(String input) {
    if (input == null) return null;
    String p = input.replace('\\', '/');
    while (p.startsWith("/")) p = p.substring(1);
    if (p.isEmpty() || p.length() > MAX_PATH_CHARS || p.matches("^[A-Za-z]:.*")) return null;
    String[] parts = p.split("/", -1);
    for (String part : parts) {
      if (part.isEmpty() || part.equals(".") || part.equals("..") || part.length() > 255) return null;
      for (int i = 0; i < part.length(); i++) {
        char ch = part.charAt(i);
        if (ch == 0 || Character.isISOControl(ch)) return null;
      }
    }
    return p;
  }

  public static boolean declaredSizeAllowed(long declaredBytes) {
    return declaredBytes < 0 || declaredBytes <= MAX_FILE_BYTES;
  }

  public static long remainingBudget(long currentTotalBytes) {
    if (currentTotalBytes < 0 || currentTotalBytes >= MAX_TOTAL_BYTES) return 0;
    return MAX_TOTAL_BYTES - currentTotalBytes;
  }
}
