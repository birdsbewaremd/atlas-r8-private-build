package com.sbh.atlasos;

import java.util.Locale;

/**
 * RATEGUARD1: pure, bounded, fail-closed retry/admission policy for a FUTURE
 * authenticated provider transport. No network, timers, credentials, persistence,
 * escalation, or external actions live here. This is not a ChatGPT-app fix.
 * The caller must re-check the actual native owner session before every attempt.
 */
public final class RequestRecoveryPolicy {
  public enum Action { COMPLETE, RETRY_AFTER, PARK, STOP }
  public static final int MAX_ATTEMPTS = 4;
  public static final long MAX_AUTOMATIC_DELAY_MS = 60_000L;
  public static final long MAX_BACKOFF_MS = 60_000L;
  private RequestRecoveryPolicy() {}

  public static final class Event {
    public final int httpStatus;
    public final String errorCode;
    public final int previousAttempts;
    public final String retryAfterSeconds;
    public final long remainingDeadlineMs;
    public final long jitterMs;
    public final boolean online;
    public final boolean nativeOwnerSessionCurrent;
    public final boolean deviceBoundProofCurrent;
    public final boolean requestIdempotent;
    public final boolean requestReadOnly;
    public final boolean responsePartiallyConsumed;

    public Event(int httpStatus, String errorCode, int previousAttempts,
        String retryAfterSeconds, long remainingDeadlineMs, long jitterMs,
        boolean online, boolean nativeOwnerSessionCurrent,
        boolean deviceBoundProofCurrent, boolean requestIdempotent,
        boolean requestReadOnly, boolean responsePartiallyConsumed) {
      this.httpStatus = httpStatus;
      this.errorCode = errorCode == null ? "" : errorCode.trim().toLowerCase(Locale.ROOT);
      this.previousAttempts = previousAttempts;
      this.retryAfterSeconds = retryAfterSeconds;
      this.remainingDeadlineMs = remainingDeadlineMs;
      this.jitterMs = jitterMs;
      this.online = online;
      this.nativeOwnerSessionCurrent = nativeOwnerSessionCurrent;
      this.deviceBoundProofCurrent = deviceBoundProofCurrent;
      this.requestIdempotent = requestIdempotent;
      this.requestReadOnly = requestReadOnly;
      this.responsePartiallyConsumed = responsePartiallyConsumed;
    }
  }

  public static final class Result {
    public final Action action;
    public final long delayMs;
    public final String reason;
    public final boolean grantsAccess = false;
    private Result(Action action, long delayMs, String reason) {
      this.action = action;
      this.delayMs = delayMs;
      this.reason = reason;
    }
  }

  private static Result result(Action action, long delayMs, String reason) {
    return new Result(action, delayMs, reason);
  }

  /** Returns -1 for absent/invalid Retry-After; 0..MAX_VALUE for integer seconds. */
  static long parseRetryAfterMs(String s) {
    if (s == null || s.isEmpty() || s.length() > 12) return -1L;
    for (int i = 0; i < s.length(); i++) {
      if (s.charAt(i) < '0' || s.charAt(i) > '9') return -1L;
    }
    try {
      long secs = Long.parseLong(s);
      return secs > Long.MAX_VALUE / 1000L ? -1L : secs * 1000L;
    } catch (NumberFormatException ex) { return -1L; }
  }

  /** Optional HTTP-date Retry-After must be parsed by a trusted transport first. */
  public static Result evaluate(Event e) {
    if (e == null || e.previousAttempts < 0 || e.remainingDeadlineMs < 0 ||
        e.jitterMs < 0 || e.jitterMs > 1000L) {
      return result(Action.STOP, 0L, "invalid_event");
    }
    // This policy is only for *future* HTTP transports; no API request is sent here.
    // Even successful remote data may not be released across a changed owner session.
    if (!e.nativeOwnerSessionCurrent || !e.deviceBoundProofCurrent) {
      return result(Action.PARK, 0L, "owner_reauthentication_required");
    }
    if (e.httpStatus >= 200 && e.httpStatus < 300) {
      return result(Action.COMPLETE, 0L, "server_acknowledged");
    }
    if (!e.online) return result(Action.PARK, 0L, "offline_no_automatic_network_retry");
    if (e.responsePartiallyConsumed) {
      return result(Action.STOP, 0L, "partial_response_no_replay");
    }
    if (!e.requestIdempotent || !e.requestReadOnly) {
      return result(Action.STOP, 0L, "side_effect_or_non_idempotent_no_replay");
    }
    if (e.previousAttempts >= MAX_ATTEMPTS) {
      return result(Action.PARK, 0L, "retry_budget_exhausted");
    }
    if (e.httpStatus != 429 && e.httpStatus != 503) {
      return result(Action.STOP, 0L, "not_transient_rate_limit_or_overload");
    }
    if (e.errorCode.contains("quota") || e.errorCode.contains("billing") ||
        e.errorCode.contains("payment") || e.errorCode.contains("hard_limit")) {
      return result(Action.STOP, 0L, "account_or_billing_action_required");
    }
    // Unknown error codes should not trigger repeated traffic.
    if (e.httpStatus == 429 && !(e.errorCode.isEmpty() ||
        e.errorCode.equals("slow_down") || e.errorCode.equals("rate_limit_error"))) {
      return result(Action.PARK, 0L, "unknown_429_error_code");
    }
    if (e.httpStatus == 503 && !(e.errorCode.isEmpty() ||
        e.errorCode.equals("server_is_overloaded") || e.errorCode.equals("service_unavailable"))) {
      return result(Action.PARK, 0L, "unknown_503_error_code");
    }
    long retryAfterMs = parseRetryAfterMs(e.retryAfterSeconds);
    if (e.retryAfterSeconds != null && retryAfterMs < 0L) {
      return result(Action.PARK, 0L, "retry_after_unparsed_review_before_retry");
    }
    long exponentialMs = Math.min(MAX_BACKOFF_MS, 1000L << Math.min(6, e.previousAttempts));
    long delayMs = Math.max(exponentialMs + e.jitterMs, retryAfterMs);
    // Do not violate a server-provided Retry-After to meet an application deadline.
    if (delayMs > MAX_AUTOMATIC_DELAY_MS || delayMs > e.remainingDeadlineMs) {
      return result(Action.PARK, delayMs, "delay_exceeds_automatic_budget");
    }
    return result(Action.RETRY_AFTER, delayMs, "temporary_limit_bounded_retry");
  }
}
