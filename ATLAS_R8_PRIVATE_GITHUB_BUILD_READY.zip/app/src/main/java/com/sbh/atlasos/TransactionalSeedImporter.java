package com.sbh.atlasos;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/**
 * Write into a private staging directory, then publish one NEW import directory.
 * Never writes to an existing vault entry. The writer MUST encrypt before disk.
 * Does not claim directory fsync/power-loss durability or authenticate ZIP provenance.
 */
public final class TransactionalSeedImporter {
  public interface EncryptedWriter {
    long write(InputStream entry, File newFile, long limit) throws Exception;
  }
  public interface Authorization { boolean allowed(); }
  public static final class Result {
    public final int files; public final long bytes; public final String directory;
    Result(int files,long bytes,String directory){this.files=files;this.bytes=bytes;this.directory=directory;}
  }
  private TransactionalSeedImporter() {}

  public static Result importNew(InputStream source, File privateRoot, File vault,
      EncryptedWriter writer, Authorization auth) throws Exception {
    return importWithLimits(source,privateRoot,vault,writer,auth,
      SeedImportPolicy.MAX_FILES, SeedImportPolicy.MAX_FILE_BYTES, SeedImportPolicy.MAX_TOTAL_BYTES);
  }

  // Package-private injectable lower limits exercise the real code without allocating gigabytes.
  static Result importWithLimits(InputStream source,File privateRoot,File vault,
      EncryptedWriter writer,Authorization auth,int maxFiles,long perFile,long maxTotal) throws Exception {
    Objects.requireNonNull(source); Objects.requireNonNull(writer); Objects.requireNonNull(auth);
    if(maxFiles<1||perFile<1||maxTotal<1)throw new IOException("invalid limits");
    if(!auth.allowed())throw new IOException("owner authorization required");
    Path parent=privateRoot.toPath().toAbsolutePath().normalize();
    Path target=vault.toPath().toAbsolutePath().normalize();
    if(Files.isSymbolicLink(parent)||Files.isSymbolicLink(target)
        ||!target.getParent().equals(parent))throw new IOException("unsafe vault root");
    Files.createDirectories(parent);Files.createDirectories(target);
    Path staging=Files.createTempDirectory(parent,".atlas-import-");
    boolean published=false;Path reserved=null;
    try {
      Set<String> names=new HashSet<>();int files=0,entries=0;long total=0;
      try(ZipCompletionGuard archive=new ZipCompletionGuard(new BufferedInputStream(source),
          maxTotal+((long)maxFiles*2+100)*4096+65557)) {
       try(ZipInputStream zip=new ZipInputStream(new FilterInputStream(archive){@Override public void close(){}})) {
        ZipEntry entry;
        while((entry=zip.getNextEntry())!=null) {
          if(!auth.allowed())throw new IOException("owner authorization expired");
          if(++entries > (long)maxFiles*2+100)throw new IOException("too many entries");
          String raw=entry.getName();
          if(raw==null||raw.startsWith("/")||raw.startsWith("\\"))throw new IOException("absolute path");
          if(entry.isDirectory())raw=raw.substring(0,raw.length()-1);
          String relative=SeedImportPolicy.safeRelative(raw);
          if(relative==null)throw new IOException("unsafe seed path");
          // Directory records are validated but are not trusted to create paths.
          if(entry.isDirectory()){if(zip.read()!=-1)throw new IOException("directory contains data");zip.closeEntry();continue;}
          if(++files>maxFiles)throw new IOException("too many files");
          if(!names.add(relative))throw new IOException("duplicate seed entry");
          if(entry.getSize()>perFile)throw new IOException("seed file too large");
          long remaining=maxTotal-total;
          if(remaining<=0)throw new IOException("seed too large");
          Path output=staging.resolve(relative+".atlasenc").normalize();
          if(!output.startsWith(staging))throw new IOException("path escape");
          Files.createDirectories(output.getParent());
          if(Files.exists(output,LinkOption.NOFOLLOW_LINKS))throw new IOException("entry collision");
          long written=writer.write(zip,output.toFile(),Math.min(perFile,remaining));
          if(written<0||written>Math.min(perFile,remaining)||!Files.isRegularFile(output,LinkOption.NOFOLLOW_LINKS))
            throw new IOException("invalid encrypted writer result");
          // Force CRC validation before publishing; a writer may not skip unread bytes.
          if(zip.read()!=-1)throw new IOException("writer did not consume complete entry");
          zip.closeEntry();total+=written;
        }
       }
       archive.finish(entries);
      }
      if(files==0)throw new IOException("empty or invalid seed archive");
      if(!auth.allowed())throw new IOException("owner authorization expired before commit");
      reserved=Files.createTempDirectory(target,"import-");
      Path destination=reserved.resolve("files");
      String name=reserved.getFileName().toString()+"/files";
      // No fallback copy, no REPLACE_EXISTING: unsupported atomic move rejects the import.
      Files.move(staging,destination,StandardCopyOption.ATOMIC_MOVE);
      published=true;
      return new Result(files,total,name);
    } finally {
      if(!published){try{removeStaging(staging);}finally{if(reserved!=null)Files.deleteIfExists(reserved);}}
    }
  }

  private static void removeStaging(Path staging) throws IOException {
    // Only this invocation's random staging tree; no traversal into symlinks.
    Files.walkFileTree(staging,new SimpleFileVisitor<Path>() {
      @Override public FileVisitResult visitFile(Path file,java.nio.file.attribute.BasicFileAttributes a)throws IOException{
        Files.delete(file);return FileVisitResult.CONTINUE;
      }
      @Override public FileVisitResult postVisitDirectory(Path dir,IOException error)throws IOException{
        if(error!=null)throw error;Files.delete(dir);return FileVisitResult.CONTINUE;
      }
    });
  }
}
