package com.sbh.atlasos;

/** Release gate for future third-party model/tool artifacts. No loading occurs here. */
public final class ArtifactTrustPolicy {
  private ArtifactTrustPolicy() {}

  public enum Decision { APPROVE, BLOCK }

  public static final class ArtifactProfile {
    public final boolean sourceKnown;
    public final boolean immutableHashKnown;
    public final boolean licenseKnown;
    public final boolean commercialUseAllowed;
    public final boolean redistributionResolved;
    public final boolean securityScanPassed;
    public final boolean isolatedTestPassed;
    public final boolean serializationRiskResolved;
    public final boolean signaturePresent;
    public final boolean signatureValid;
    public final boolean signerAuthorized;

    public ArtifactProfile(
        boolean sourceKnown,
        boolean immutableHashKnown,
        boolean licenseKnown,
        boolean commercialUseAllowed,
        boolean redistributionResolved,
        boolean securityScanPassed,
        boolean isolatedTestPassed,
        boolean serializationRiskResolved,
        boolean signaturePresent,
        boolean signatureValid,
        boolean signerAuthorized) {
      this.sourceKnown = sourceKnown;
      this.immutableHashKnown = immutableHashKnown;
      this.licenseKnown = licenseKnown;
      this.commercialUseAllowed = commercialUseAllowed;
      this.redistributionResolved = redistributionResolved;
      this.securityScanPassed = securityScanPassed;
      this.isolatedTestPassed = isolatedTestPassed;
      this.serializationRiskResolved = serializationRiskResolved;
      this.signaturePresent = signaturePresent;
      this.signatureValid = signatureValid;
      this.signerAuthorized = signerAuthorized;
    }
  }

  public static Decision decide(ArtifactProfile a) {
    if (a == null) return Decision.BLOCK;
    if (!a.sourceKnown || !a.immutableHashKnown || !a.licenseKnown
        || !a.commercialUseAllowed || !a.redistributionResolved
        || !a.securityScanPassed || !a.isolatedTestPassed
        || !a.serializationRiskResolved) {
      return Decision.BLOCK;
    }
    // A signature is useful only when both cryptographically valid and from an
    // identity authorized for this artifact. Unsigned artifacts are not
    // automatically approved; the other provenance gates still apply.
    if (a.signaturePresent && (!a.signatureValid || !a.signerAuthorized)) return Decision.BLOCK;
    return Decision.APPROVE;
  }
}
