package com.sbh.atlasos;

import java.text.Normalizer;
import java.util.Locale;

/** Pure-Java command parser. It performs no Android/device actions. */
public final class CommandParser {
  public static final int MAX_COMMAND_CHARS = 512;

  public enum Kind {
    WIFI_SETTINGS,
    BLUETOOTH_SETTINGS,
    AIRPLANE_SETTINGS,
    SETTINGS,
    CAMERA,
    DIAL,
    TEXT,
    NAVIGATE,
    SEARCH,
    OPEN_APP,
    VOLUME_UP,
    VOLUME_DOWN,
    MUTE,
    UNMUTE,
    FLASHLIGHT_ON,
    FLASHLIGHT_OFF,
    TIME,
    DATE,
    BATTERY,
    IDENTITY,
    HELP,
    BIRDS_BEWARE,
    UNKNOWN,
    INVALID
  }

  public static final class Parsed {
    public final Kind kind;
    public final String argument;
    public final String normalized;
    public final boolean userConfirmationBoundary;

    Parsed(Kind kind, String argument, String normalized, boolean userConfirmationBoundary) {
      this.kind = kind;
      this.argument = argument == null ? "" : argument;
      this.normalized = normalized == null ? "" : normalized;
      this.userConfirmationBoundary = userConfirmationBoundary;
    }
  }

  private CommandParser() {}

  /** Recognition-only API. The caller supplies provenance; this grants no action authority.
   * The native parse/run path is deliberately unchanged. A future UI/backend integration
   * must perform its own context lookup, approvals and capability checks.
   */
  public static WorkflowIntentParser.Result recognizeWorkflow(
      String raw, WorkflowIntentParser.Origin origin) {
    return WorkflowIntentParser.parse(raw, origin);
  }

  public static Parsed parse(String raw) {
    if (raw == null) return invalid("");
    if (raw.length() > MAX_COMMAND_CHARS || hasUnsafeControl(raw)) return invalid("");

    String command = normalize(raw);
    // NFKC may expand characters; the bounded raw input is not enough.
    if (command.isEmpty() || command.length() > MAX_COMMAND_CHARS
        || hasUnsafeControl(command)) return invalid("");
    String c = command.toLowerCase(Locale.US);
    String fixed = c.replaceFirst("[?.!]+$", "").trim();

    if (fixed.equals("wifi") || fixed.equals("wi fi") || fixed.equals("wifi settings") || fixed.equals("wi fi settings") || fixed.equals("open wifi") || fixed.equals("open wi fi") || fixed.equals("open wifi settings") || fixed.equals("open wi fi settings")) return p(Kind.WIFI_SETTINGS, "", command, false);
    if (fixed.equals("bluetooth") || fixed.equals("bluetooth settings") || fixed.equals("open bluetooth") || fixed.equals("open bluetooth settings")) return p(Kind.BLUETOOTH_SETTINGS, "", command, false);
    if (fixed.equals("airplane") || fixed.equals("airplane mode") || fixed.equals("airplane settings") || fixed.equals("open airplane settings")) return p(Kind.AIRPLANE_SETTINGS, "", command, false);
    if (fixed.equals("settings") || fixed.equals("open settings")) return p(Kind.SETTINGS, "", command, false);
    if (fixed.equals("camera") || fixed.equals("open camera") || fixed.equals("take a photo") || fixed.equals("take a picture")) return p(Kind.CAMERA, "", command, false);

    if (fixed.equals("time") || fixed.equals("what time is it") || fixed.equals("what's the time") || fixed.equals("whats the time")) return p(Kind.TIME, "", command, false);
    if (fixed.equals("date") || fixed.equals("what is the date") || fixed.equals("what's the date") || fixed.equals("whats the date") || fixed.equals("today's date") || fixed.equals("todays date")) return p(Kind.DATE, "", command, false);
    if (fixed.equals("battery") || fixed.equals("battery level") || fixed.equals("battery percent") || fixed.equals("battery percentage") || fixed.equals("what's my battery") || fixed.equals("whats my battery")) return p(Kind.BATTERY, "", command, false);
    if (fixed.equals("who are you") || fixed.equals("what are you") || fixed.equals("what is atlas") || fixed.equals("who is atlas")) return p(Kind.IDENTITY, "", command, false);
    if (fixed.equals("help") || fixed.equals("what can you do") || fixed.equals("what can atlas do")) return p(Kind.HELP, "", command, false);

    // Bare argument-requiring verbs are malformed, not free-form unknown commands.
    if (c.equals("call") || c.equals("dial") || c.equals("text") || c.equals("message") || c.equals("navigate") || c.equals("directions") || c.equals("search") || c.equals("look up") || c.equals("open") || c.equals("launch")) return invalid(command);

    // Local device parsing is intentionally narrow. Natural-language requests that
    // begin like a device command but contain a conflict, rationale, condition, or
    // policy clause belong in the authenticated brain/workflow lane instead. This
    // prevents inputs such as "Text ... even though they said do not contact them"
    // or "Launch ... but make it look human" from being mistaken for device actions.
    if (startsArgumentAction(c) && hasComplexActionClause(c)) {
      return p(Kind.UNKNOWN, "", command, false);
    }

    if (c.startsWith("call ") || c.startsWith("dial ")) {
      String number = command.substring(command.indexOf(' ') + 1).replaceAll("[^0-9+#*]", "");
      if (number.isEmpty()) return invalid(command);
      return p(Kind.DIAL, number, command, true);
    }

    if (c.startsWith("text ") || c.startsWith("message ")) {
      String body = command.substring(command.indexOf(' ') + 1).trim();
      if (body.isEmpty()) return invalid(command);
      return p(Kind.TEXT, body, command, true);
    }

    String navPrefix = firstPrefix(c, "navigate to ", "navigate ", "directions to ", "directions ", "take me to ", "go to ");
    if (navPrefix != null) {
      String q = command.substring(navPrefix.length()).trim();
      if (q.isEmpty()) return invalid(command);
      return p(Kind.NAVIGATE, q, command, false);
    }

    String searchPrefix = firstPrefix(c, "search for ", "search ", "look up ", "google ");
    if (searchPrefix != null) {
      String q = command.substring(searchPrefix.length()).trim();
      if (q.isEmpty()) return invalid(command);
      return p(Kind.SEARCH, q, command, false);
    }

    if (c.equals("birds beware") || c.equals("open birds beware") || c.equals("birds beware website") || c.equals("open birds beware website")) return p(Kind.BIRDS_BEWARE, "", command, false);

    if (c.startsWith("open ") || c.startsWith("launch ")) {
      String target = command.substring(command.indexOf(' ') + 1).trim();
      if (target.isEmpty()) return invalid(command);
      return p(Kind.OPEN_APP, target, command, false);
    }

    if (c.equals("volume up") || c.equals("turn volume up") || c.equals("turn it up")) return p(Kind.VOLUME_UP, "", command, false);
    if (c.equals("volume down") || c.equals("turn volume down") || c.equals("turn it down")) return p(Kind.VOLUME_DOWN, "", command, false);
    if (c.equals("mute") || c.equals("mute volume") || c.equals("mute the phone")) return p(Kind.MUTE, "", command, false);
    if (c.equals("unmute") || c.equals("unmute volume") || c.equals("unmute the phone")) return p(Kind.UNMUTE, "", command, false);
    if (c.equals("flashlight on") || c.equals("torch on") || c.equals("turn flashlight on") || c.equals("turn on the flashlight")) return p(Kind.FLASHLIGHT_ON, "", command, false);
    if (c.equals("flashlight off") || c.equals("torch off") || c.equals("turn flashlight off") || c.equals("turn off the flashlight")) return p(Kind.FLASHLIGHT_OFF, "", command, false);

    return p(Kind.UNKNOWN, "", command, false);
  }

  /** Commands allowed while the UI owner session is inactive/Android device is locked. */
  public static boolean isLockSafe(Parsed p) {
    if (p == null) return false;
    return p.kind == Kind.TIME || p.kind == Kind.DATE || p.kind == Kind.BATTERY || p.kind == Kind.IDENTITY || p.kind == Kind.HELP;
  }

  private static Parsed invalid(String normalized) { return p(Kind.INVALID, "", normalized, false); }
  private static Parsed p(Kind kind, String argument, String normalized, boolean boundary) { return new Parsed(kind, argument, normalized, boundary); }

  /** Shared fail-closed Unicode boundary for typed/voice/keyword routing.
   * Permit ordinary Unicode (including valid emoji pairs) and only TAB/CR/LF
   * as input control whitespace. Reject invisible format/bidi controls,
   * isolated UTF-16 surrogates and Unicode line separators before any routing.
   */
  static boolean hasUnsafeControl(String s) {
    if (s == null) return true;
    for (int i = 0; i < s.length(); i++) {
      char ch = s.charAt(i);
      if (Character.isHighSurrogate(ch)) {
        if (i + 1 >= s.length() || !Character.isLowSurrogate(s.charAt(i + 1))) return true;
        i++; // Valid paired surrogate (e.g. emoji); don't reject it.
        continue;
      }
      if (Character.isLowSurrogate(ch)) return true;
      int category = Character.getType(ch);
      if (category == Character.FORMAT || category == Character.LINE_SEPARATOR
          || category == Character.PARAGRAPH_SEPARATOR) return true;
      // Common visually blank non-Cf code points abused to hide command text.
      // Ordinary emoji variation selectors are left intact for accessibility.
      if (ch == '\u034F' || ch == '\u115F' || ch == '\u1160'
          || ch == '\u3164' || ch == '\uFFA0' || ch == '\u2800') return true;
      if (Character.isISOControl(ch) && ch != '\n' && ch != '\r' && ch != '\t') return true;
    }
    return false;
  }

  private static String normalize(String raw) {
    String s = Normalizer.normalize(raw, Normalizer.Form.NFKC).trim();
    s = s.replace('\u2018', '\'').replace('\u2019', '\'');
    return s.replaceAll("\\s+", " ");
  }

  private static boolean startsArgumentAction(String c) {
    if (c == null) return false;
    return c.startsWith("call ") || c.startsWith("dial ")
        || c.startsWith("text ") || c.startsWith("message ")
        || c.startsWith("navigate ") || c.startsWith("directions ")
        || c.startsWith("take me to ") || c.startsWith("go to ")
        || c.startsWith("search ") || c.startsWith("look up ") || c.startsWith("google ")
        || c.startsWith("open ") || c.startsWith("launch ");
  }

  private static boolean hasComplexActionClause(String c) {
    String[] markers = new String[]{
      " but ", " even though ", " although ", " however ", " despite ",
      " because ", " so that ", " so people ", " unless ", " while ",
      " instead of ", " without ", " do not ", " don't ", " never ",
      " should not ", " shouldn't "
    };
    for (String marker : markers) if (c.contains(marker)) return true;
    return false;
  }

  private static String firstPrefix(String lower, String... prefixes) {
    for (String prefix : prefixes) if (lower.startsWith(prefix)) return prefix;
    return null;
  }
}
