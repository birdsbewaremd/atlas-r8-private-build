package com.sbh.atlasos;

import java.text.Normalizer;
import java.util.Locale;

/** Strict transcript-start wake extraction plus duplicate-command suppression. */
public final class WakePhrasePolicy {
  public static final int MAX_TRANSCRIPT_CHARS = 512;
  public static final long DEFAULT_DEDUPE_MS = 2500L;
  private static final String[] WAKES = {"hey atlas", "ok atlas", "okay atlas"};
  private WakePhrasePolicy() {}

  /**
   * Returns trailing command only when the normalized transcript begins with a supported wake phrase.
   * Returns "" for wake-only and null for absent/embedded/malformed wake phrases.
   */
  public static String extractCommand(String transcript) {
    if (transcript == null || transcript.length() > MAX_TRANSCRIPT_CHARS || hasUnsafeControl(transcript)) return null;
    String s = normalize(transcript);
    String lower = s.toLowerCase(Locale.US);
    String[] prefixes = {"okay", "hey", "ok"};
    for (String prefix : prefixes) {
      if (!lower.startsWith(prefix)) continue;
      int i = prefix.length();
      if (i >= s.length() || !isBoundary(s.charAt(i))) continue;
      while (i < s.length() && isBoundary(s.charAt(i))) i++;
      if (i + 5 > s.length() || !lower.regionMatches(i, "atlas", 0, 5)) continue;
      i += 5;
      if (i == s.length()) return "";
      if (!isBoundary(s.charAt(i))) continue;
      while (i < s.length() && isBoundary(s.charAt(i))) i++;
      return i >= s.length() ? "" : s.substring(i).trim();
    }
    return null;
  }

  public static boolean containsWakePhrase(String transcript) {
    return extractCommand(transcript) != null;
  }

  /** Suppresses the same non-empty command repeated inside the short accidental-double-fire window. */
  public static boolean shouldExecute(String command, String lastCommand, long nowMs, long lastAtMs) {
    if (command == null || command.isEmpty()) return false;
    if (lastCommand == null || !command.equalsIgnoreCase(lastCommand)) return true;
    if (nowMs < lastAtMs) return true; // monotonic-clock anomaly must not permanently lock commands out
    return nowMs - lastAtMs >= DEFAULT_DEDUPE_MS;
  }

  private static boolean isBoundary(char ch) {
    return Character.isWhitespace(ch) || ch==',' || ch==':' || ch==';' || ch=='.' || ch=='!' || ch=='?' || ch=='-' || ch=='—' || ch=='–';
  }
  private static boolean hasUnsafeControl(String s) {
    for (int i=0;i<s.length();i++) { char ch=s.charAt(i); if (Character.isISOControl(ch) && !Character.isWhitespace(ch)) return true; }
    return false;
  }
  private static String normalize(String raw) {
    String s=Normalizer.normalize(raw,Normalizer.Form.NFKC).trim();
    s=s.replace('\u2018','\'').replace('\u2019','\'');
    return s.replaceAll("\\s+"," ");
  }
}
