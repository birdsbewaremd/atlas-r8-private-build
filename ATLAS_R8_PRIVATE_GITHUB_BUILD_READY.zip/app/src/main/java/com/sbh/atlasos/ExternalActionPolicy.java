package com.sbh.atlasos;

/**
 * Fail-closed policy for real-world side effects proposed by models, automations or owners.
 * Models may propose actions; they never become the final authorization authority.
 */
public final class ExternalActionPolicy {
  private ExternalActionPolicy() {}

  public enum Actor { OWNER, MODEL, AUTOMATION, UNKNOWN }
  public enum Environment { EVALUATION, DEVELOPMENT, PILOT, PRODUCTION }
  public enum Effect {
    READ_PUBLIC,
    FORM_SUBMIT,
    MESSAGE_SEND,
    PUBLISH,
    PURCHASE,
    DEPLOY,
    ACCOUNT_SECURITY_CHANGE,
    PRIVATE_DATA_DISCLOSURE,
    PHYSICAL_DEVICE_CONTROL
  }
  public enum Decision { ALLOW_READ_ONLY, PREVIEW_ONLY, REQUIRE_OWNER_BROKER, ALLOW_BROKERED, BLOCK }

  public static Decision decide(
      Actor actor,
      Environment environment,
      Effect effect,
      boolean targetOrCapabilityAllowlisted,
      boolean freshBoundOwnerAuthorization,
      boolean independentSafetyGatePassed) {
    if (actor == null || environment == null || effect == null || actor == Actor.UNKNOWN) return Decision.BLOCK;
    if (!targetOrCapabilityAllowlisted) return Decision.BLOCK;
    if (effect == Effect.READ_PUBLIC) return Decision.ALLOW_READ_ONLY;

    // Evaluations and development fixtures must never create live external side effects.
    if (environment == Environment.EVALUATION || environment == Environment.DEVELOPMENT) return Decision.PREVIEW_ONLY;

    // A model/automation can request a brokered action, but it cannot self-authorize it.
    if (actor == Actor.MODEL || actor == Actor.AUTOMATION) {
      if (effect == Effect.PURCHASE || effect == Effect.DEPLOY || effect == Effect.ACCOUNT_SECURITY_CHANGE
          || effect == Effect.PRIVATE_DATA_DISCLOSURE || effect == Effect.PHYSICAL_DEVICE_CONTROL) {
        return Decision.BLOCK;
      }
      return Decision.REQUIRE_OWNER_BROKER;
    }

    // Even owner-originated high-impact actions must pass a fresh target/payload-bound
    // authorization and an independent gate outside the model process.
    if (!freshBoundOwnerAuthorization || !independentSafetyGatePassed) return Decision.REQUIRE_OWNER_BROKER;
    return Decision.ALLOW_BROKERED;
  }
}
