package com.sbh.atlasos;

/**
 * Pure-Java presentation policy for ATLAS status/voice/visual cues.
 *
 * This layer consumes trusted routing/session facts but never grants execution,
 * changes permissions, authenticates a user, diagnoses emotion, or claims consciousness.
 */
public final class HumanInterfacePolicy {
  public enum ExecutionPhase { IDLE, LISTENING, THINKING, EXECUTING, DONE, BLOCKED, RECOVERING }
  public enum RiskLevel { UNSPECIFIED, LOW, MEDIUM, HIGH, CRITICAL }
  public enum ExpressiveState { CALM, FOCUSED, CURIOUS, SATISFIED, UNCERTAIN, CONCERNED, ALERT, BLOCKED, RECOVERING }

  public static final class SensorState {
    public final boolean known;
    public final boolean microphoneActive;
    public final boolean cameraActive;
    public final boolean neuralSensorActive;

    public SensorState(boolean known, boolean microphoneActive, boolean cameraActive, boolean neuralSensorActive) {
      this.known = known;
      this.microphoneActive = microphoneActive;
      this.cameraActive = cameraActive;
      this.neuralSensorActive = neuralSensorActive;
    }

    public static SensorState unknown() { return new SensorState(false, false, false, false); }
    public static SensorState known(boolean microphone, boolean camera, boolean neural) {
      return new SensorState(true, microphone, camera, neural);
    }
  }

  public static final class Input {
    public final ExecutionPhase phase;
    public final RiskLevel risk;
    public final boolean confidenceKnown;
    public final double confidence;
    public final boolean researchMode;
    public final boolean quietMode;
    public final boolean requiresOwnerApproval;
    public final SensorState sensors;

    public Input(ExecutionPhase phase,
                 RiskLevel risk,
                 boolean confidenceKnown,
                 double confidence,
                 boolean researchMode,
                 boolean quietMode,
                 boolean requiresOwnerApproval,
                 SensorState sensors) {
      this.phase = phase == null ? ExecutionPhase.IDLE : phase;
      this.risk = risk == null ? RiskLevel.UNSPECIFIED : risk;
      this.confidenceKnown = confidenceKnown;
      this.confidence = confidence;
      this.researchMode = researchMode;
      this.quietMode = quietMode;
      this.requiresOwnerApproval = requiresOwnerApproval;
      this.sensors = sensors == null ? SensorState.unknown() : sensors;
      if (confidenceKnown && (confidence < 0.0 || confidence > 1.0)) {
        throw new IllegalArgumentException("confidence must be between 0.0 and 1.0 when known");
      }
    }

    public static Input idle() {
      return new Input(ExecutionPhase.IDLE, RiskLevel.UNSPECIFIED, false, 0.0,
        false, false, false, SensorState.unknown());
    }
  }

  public static final class Output {
    public final ExpressiveState expressiveState;
    public final String primaryStatusMarker;
    public final double speechRate;
    public final double pitchMultiplier;
    public final double energy;
    public final int pauseMs;
    public final String textDensity;
    public final String eyeMotion;
    public final String hapticSignal;
    public final String lightSignal;
    public final String interruptibility;
    public final boolean confirmationRequired;
    public final boolean showProgressAnimation;
    public final String privacyIndicator;
    public final boolean authorityChangeAllowed;
    public final boolean emotionDiagnosisAllowed;
    public final boolean consciousnessClaimAllowed;
    public final String notes;

    Output(ExpressiveState state, Profile profile, boolean confirmationRequired,
           boolean showProgressAnimation, String privacyIndicator) {
      this.expressiveState = state;
      this.primaryStatusMarker = profile.marker;
      this.speechRate = profile.rate;
      this.pitchMultiplier = profile.pitch;
      this.energy = profile.energy;
      this.pauseMs = profile.pauseMs;
      this.textDensity = profile.textDensity;
      this.eyeMotion = profile.eyeMotion;
      this.hapticSignal = profile.hapticSignal;
      this.lightSignal = profile.lightSignal;
      this.interruptibility = profile.interruptibility;
      this.confirmationRequired = confirmationRequired;
      this.showProgressAnimation = showProgressAnimation;
      this.privacyIndicator = privacyIndicator;
      this.authorityChangeAllowed = false;
      this.emotionDiagnosisAllowed = false;
      this.consciousnessClaimAllowed = false;
      this.notes = "Presentation state only: no authority, authentication, diagnosis, or consciousness claim.";
    }
  }

  private static final class Profile {
    final String marker, textDensity, eyeMotion, hapticSignal, lightSignal, interruptibility;
    final double rate, pitch, energy;
    final int pauseMs;
    Profile(String marker, double rate, double pitch, double energy, int pauseMs,
            String textDensity, String eyeMotion, String hapticSignal, String lightSignal,
            String interruptibility) {
      this.marker=marker; this.rate=rate; this.pitch=pitch; this.energy=energy; this.pauseMs=pauseMs;
      this.textDensity=textDensity; this.eyeMotion=eyeMotion; this.hapticSignal=hapticSignal;
      this.lightSignal=lightSignal; this.interruptibility=interruptibility;
    }
    Profile quieted() {
      return new Profile(marker, rate, pitch, Math.min(energy,0.35), pauseMs, textDensity,
        eyeMotion, "urgent".equals(hapticSignal)?hapticSignal:"none", "quiet-"+lightSignal,
        interruptibility);
    }
  }

  private HumanInterfacePolicy() {}

  public static Output render(Input input) {
    if (input == null) input = Input.idle();
    ExpressiveState state = deriveState(input);
    Profile profile = profile(state);
    if (input.quietMode && state != ExpressiveState.ALERT && state != ExpressiveState.CONCERNED) {
      profile = profile.quieted();
    }
    boolean confirmationRequired = input.requiresOwnerApproval
      || input.risk == RiskLevel.HIGH || input.risk == RiskLevel.CRITICAL;
    boolean showProgress = input.phase == ExecutionPhase.EXECUTING;
    return new Output(state, profile, confirmationRequired, showProgress, privacyIndicator(input.sensors));
  }

  /**
   * Bind presentation to the already-authenticated routing result.
   * This method never feeds back into the router and never decides execution eligibility.
   */
  public static Output fromRoute(AuthenticatedInputRouter.Result routed,
                                 boolean localRouterInvoked,
                                 boolean quietMode,
                                 SensorState sensors) {
    if (routed == null || !routed.authenticated) {
      return render(new Input(ExecutionPhase.BLOCKED, RiskLevel.UNSPECIFIED, false, 0.0,
        false, quietMode, false, sensors));
    }
    ExecutionPhase phase;
    switch (routed.route) {
      case LOCKED:
      case INVALID:
        phase = ExecutionPhase.BLOCKED; break;
      case SOURCE_DATA:
        phase = ExecutionPhase.DONE; break;
      case LOCAL_DEVICE:
        phase = localRouterInvoked ? ExecutionPhase.DONE : ExecutionPhase.BLOCKED; break;
      case WORKFLOW_HANDOFF:
      case BRAIN_HANDOFF:
        phase = routed.backendConnected ? ExecutionPhase.THINKING : ExecutionPhase.BLOCKED; break;
      default:
        phase = ExecutionPhase.BLOCKED;
    }
    boolean ownerApproval = routed.constraints.contains("user_confirmation_boundary_required");
    boolean research = routed.commandIds.contains("research") || routed.commandIds.contains("atlas_research");
    return render(new Input(phase, RiskLevel.UNSPECIFIED, false, 0.0,
      research, quietMode, ownerApproval, sensors));
  }

  private static ExpressiveState deriveState(Input input) {
    if (input.phase == ExecutionPhase.BLOCKED) return ExpressiveState.BLOCKED;
    if (input.phase == ExecutionPhase.RECOVERING) return ExpressiveState.RECOVERING;
    if (input.risk == RiskLevel.CRITICAL) return ExpressiveState.ALERT;
    if (input.risk == RiskLevel.HIGH) return ExpressiveState.CONCERNED;
    if (input.confidenceKnown && input.confidence < 0.45) return ExpressiveState.UNCERTAIN;
    if (input.phase == ExecutionPhase.DONE) return ExpressiveState.SATISFIED;
    if (input.phase == ExecutionPhase.EXECUTING) return ExpressiveState.FOCUSED;
    if (input.researchMode && (input.phase == ExecutionPhase.THINKING || input.phase == ExecutionPhase.LISTENING)) {
      return ExpressiveState.CURIOUS;
    }
    if (input.phase == ExecutionPhase.THINKING && input.confidenceKnown && input.confidence < 0.75) {
      return ExpressiveState.UNCERTAIN;
    }
    return ExpressiveState.CALM;
  }

  private static String privacyIndicator(SensorState sensors) {
    if (sensors == null || !sensors.known) return "UNKNOWN";
    StringBuilder active = new StringBuilder();
    if (sensors.microphoneActive) active.append("MIC");
    if (sensors.cameraActive) append(active,"CAMERA");
    if (sensors.neuralSensorActive) append(active,"NEURAL-SENSOR");
    return active.length()==0 ? "OFF" : "ACTIVE:"+active;
  }

  private static void append(StringBuilder value,String item) {
    if (value.length()>0) value.append('+');
    value.append(item);
  }

  private static Profile profile(ExpressiveState state) {
    switch (state) {
      case FOCUSED:return new Profile("🧠",1.04,0.99,0.52,130,"compact","narrow-focus","none","task-active","normal");
      case CURIOUS:return new Profile("🔎",1.02,1.01,0.50,160,"balanced","explore-scan","none","research-active","normal");
      case SATISFIED:return new Profile("✅",1.00,1.00,0.48,150,"compact","brief-confirm-then-neutral","confirm","verified-done","normal");
      case UNCERTAIN:return new Profile("?",0.95,0.99,0.38,260,"explanatory","subtle-uncertainty","none","uncertain","normal");
      case CONCERNED:return new Profile("🛡️",0.96,0.98,0.45,240,"compact","attention-hold","caution","caution","elevated");
      case ALERT:return new Profile("⚠️",0.92,0.97,0.60,280,"minimal","high-salience-alert","urgent","urgent","high-priority");
      case BLOCKED:return new Profile("🟡",0.96,0.99,0.42,220,"compact","stopped-locked","waiting","blocked","normal");
      case RECOVERING:return new Profile("↻",0.98,0.99,0.46,200,"compact","recovery-cycle","recovery","recovering","normal");
      case CALM:
      default:return new Profile("•",1.00,1.00,0.45,180,"balanced","steady-neutral","none","steady-status","normal");
    }
  }
}
