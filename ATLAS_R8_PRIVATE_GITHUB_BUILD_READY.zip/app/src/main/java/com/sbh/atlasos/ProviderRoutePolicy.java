package com.sbh.atlasos;

/**
 * Deterministic privacy/data-route gate for future model providers.
 *
 * This class does not call a provider and grants no execution authority.
 * Unknown sensitive-data routes fail closed.
 */
public final class ProviderRoutePolicy {
  private ProviderRoutePolicy() {}

  public enum DataClass {
    PUBLIC,
    BUSINESS_INTERNAL,
    CUSTOMER_PRIVATE,
    PERSONAL_PRIVATE,
    HEALTH_LEGAL_FINANCIAL,
    SECRET
  }

  public enum TrainingUse {
    NO_BY_DEFAULT,
    OPTED_OUT,
    OPTED_IN,
    LOCAL_ONLY,
    UNKNOWN
  }

  public enum RouteStatus {
    APPROVED,
    APPROVED_MINIMIZED_ONLY,
    BLOCKED,
    QUARANTINED,
    OUTDATED,
    UNKNOWN
  }

  public enum Decision {
    ALLOW,
    MINIMIZE_ONLY,
    BLOCK
  }

  public static final class RouteProfile {
    public final String routeId;
    public final String deploymentMode;
    public final boolean external;
    public final RouteStatus status;
    public final TrainingUse trainingUse;
    public final boolean retentionKnown;
    public final boolean statefulBehaviorKnown;
    public final boolean policyCurrent;

    public RouteProfile(
        String routeId,
        String deploymentMode,
        boolean external,
        RouteStatus status,
        TrainingUse trainingUse,
        boolean retentionKnown,
        boolean statefulBehaviorKnown,
        boolean policyCurrent) {
      this.routeId = routeId == null ? "" : routeId.trim();
      this.deploymentMode = deploymentMode == null ? "" : deploymentMode.trim();
      this.external = external;
      this.status = status == null ? RouteStatus.UNKNOWN : status;
      this.trainingUse = trainingUse == null ? TrainingUse.UNKNOWN : trainingUse;
      this.retentionKnown = retentionKnown;
      this.statefulBehaviorKnown = statefulBehaviorKnown;
      this.policyCurrent = policyCurrent;
    }
  }

  public static Decision decide(DataClass dataClass, RouteProfile route) {
    if (dataClass == null || route == null || route.routeId.isEmpty()) return Decision.BLOCK;
    if (dataClass == DataClass.SECRET) return Decision.BLOCK;

    if (!route.policyCurrent) return Decision.BLOCK;
    if (route.status == RouteStatus.BLOCKED
        || route.status == RouteStatus.QUARANTINED
        || route.status == RouteStatus.OUTDATED
        || route.status == RouteStatus.UNKNOWN) {
      return Decision.BLOCK;
    }

    // Local-only processing still must use an approved, current route record.
    if (!route.external) {
      return route.status == RouteStatus.APPROVED_MINIMIZED_ONLY
          ? Decision.MINIMIZE_ONLY : Decision.ALLOW;
    }

    if (route.deploymentMode.isEmpty()) return Decision.BLOCK;

    boolean sensitive = dataClass == DataClass.CUSTOMER_PRIVATE
        || dataClass == DataClass.PERSONAL_PRIVATE
        || dataClass == DataClass.HEALTH_LEGAL_FINANCIAL;

    if (sensitive) {
      if (route.trainingUse == TrainingUse.UNKNOWN || route.trainingUse == TrainingUse.OPTED_IN) {
        return Decision.BLOCK;
      }
      if (!route.retentionKnown || !route.statefulBehaviorKnown) return Decision.BLOCK;
    }

    if (route.status == RouteStatus.APPROVED_MINIMIZED_ONLY) return Decision.MINIMIZE_ONLY;

    // Business-internal material sent to an explicitly opted-in training route
    // is allowed only after minimization. Private classes were already blocked.
    if (dataClass == DataClass.BUSINESS_INTERNAL && route.trainingUse == TrainingUse.OPTED_IN) {
      return Decision.MINIMIZE_ONLY;
    }

    return Decision.ALLOW;
  }
}
