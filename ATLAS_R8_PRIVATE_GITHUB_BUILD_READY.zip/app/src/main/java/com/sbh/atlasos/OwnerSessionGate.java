package com.sbh.atlasos;

import android.app.KeyguardManager;
import android.content.Context;
import android.os.SystemClock;

/** Fail-closed process-local owner session. No voice/JS claim is authentication. */
public final class OwnerSessionGate {
  private static final long DEFAULT_WINDOW_MS = 15L * 60L * 1000L;
  private static long activeWindowMs = DEFAULT_WINDOW_MS;
  private static long resumeDeadlineElapsed;
  private static boolean suspended;
  private static long activeUntilElapsed, lastElapsed;
  private static long generation = 1L;
  private static boolean foreground;
  private OwnerSessionGate() {}

  /** Activity lifecycle owns this state; returning to foreground never logs in. */
  public static synchronized void setForeground(boolean value) {
    if (!value) { foreground = false; clear(); return; }
    long now = SystemClock.elapsedRealtime();
    if (suspended && (now < lastElapsed || now >= resumeDeadlineElapsed)) clear();
    foreground = true; suspended = false; resumeDeadlineElapsed = 0L;
  }
  public static synchronized boolean isForeground() { return foreground; }

  /** Explicitly chosen idle timeout, never infinite; caller must authenticate first. */
  public static synchronized boolean setIdleTimeoutSeconds(int seconds) {
    if (seconds != 300 && seconds != 900 && seconds != 1800) return false;
    activeWindowMs = 1000L * seconds;
    if (foreground && activeUntilElapsed > 0L) {
      long now = SystemClock.elapsedRealtime();
      if (now >= activeUntilElapsed || now < lastElapsed) clear();
      else { lastElapsed = now; activeUntilElapsed = now + activeWindowMs; }
    }
    return true;
  }

  /** Paused Android activities cannot access owner data. Optional bounded return
   * retains only proof of login; queued operations are invalidated by generation.
   * A screen-off receiver in MainActivity revokes even this return window. */
  public static synchronized void suspend(int graceSeconds) {
    if (!foreground) return;
    long now = SystemClock.elapsedRealtime();
    if (graceSeconds <= 0 || graceSeconds > 120 || now < lastElapsed || activeUntilElapsed <= now) {
      foreground = false; clear(); return;
    }
    foreground = false;
    suspended = true;
    resumeDeadlineElapsed = Math.min(activeUntilElapsed, now + graceSeconds * 1000L);
    generation = generation == Long.MAX_VALUE ? 1L : generation + 1L;
  }
  public static synchronized boolean hasSuspendedSession() {
    long now = SystemClock.elapsedRealtime();
    return !foreground && suspended && now < resumeDeadlineElapsed && now >= lastElapsed;
  }

  public static synchronized void setActive(boolean active) {
    clear();
    if (active && foreground) {
      lastElapsed = SystemClock.elapsedRealtime();
      activeUntilElapsed = lastElapsed + activeWindowMs;
    }
  }

  public static synchronized void touch() {
    long now = SystemClock.elapsedRealtime();
    if (!foreground) return;
    if (now < lastElapsed || activeUntilElapsed <= now) { clear(); return; }
    lastElapsed = now;
    activeUntilElapsed = now + activeWindowMs;
  }

  public static synchronized boolean isActive(Context context) {
    long now = SystemClock.elapsedRealtime();
    if (!foreground) return false;
    if (now < lastElapsed || activeUntilElapsed <= now) { clear(); return false; }
    try {
      if (context == null) { clear(); return false; }
      KeyguardManager km = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);
      if (km == null || km.isDeviceLocked()) { clear(); return false; }
    } catch (Exception unavailable) { clear(); return false; }
    lastElapsed = now;
    return true;
  }
  /** Bind deferred work to this login, not just to whichever login is active later. */
  public static synchronized long capture(Context context) {
    return isActive(context) ? generation : 0L;
  }
  public static synchronized boolean isCurrent(Context context, long captured) {
    return captured != 0L && isActive(context) && captured == generation;
  }
  public static synchronized void clear() {
    activeUntilElapsed = 0L; lastElapsed = 0L; suspended = false; resumeDeadlineElapsed = 0L;
    generation = generation == Long.MAX_VALUE ? 1L : generation + 1L;
  }
}
