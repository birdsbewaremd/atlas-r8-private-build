package com.sbh.atlasos;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Handler;
import android.os.Looper;
import android.text.InputFilter;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;

/** Optional native-only AI connection. The WebView never receives a credential. */
public final class AtlasBrainController {
  public static final String PRIVATE_RECORD="brainConnection";
  public interface Host {
    long capture();
    boolean current(long session);
    void emit(long session,String detail);
    String readText(long session,String relativePath)throws Exception;
  }
  private static final class Config {
    String key,model;boolean enabled;long revision;
  }
  private static final class Problem extends Exception {
    Problem(String message){super(message);}
  }
  private final Activity activity;
  private final OwnerRecordStore store;
  private final Host host;
  private final AtlasBrainTransport transport=new AtlasBrainTransport();
  private final Handler ui=new Handler(Looper.getMainLooper());
  // Operation changes occur on the Activity thread. Workers can only observe them.
  private volatile long operation=0L;
  private volatile boolean busy=false;
  private volatile long verifiedRevision=-1L,lastCheckedAt=0L;
  private AlertDialog dialog;
  private EditText secretInput;
  private Runnable expiryCheck;

  public AtlasBrainController(Activity activity,OwnerRecordStore store,Host host){
    this.activity=activity;this.store=store;this.host=host;
  }
  private boolean current(long session){return host.current(session);}
  private boolean active(long session,long request){return busy&&request==operation&&current(session);}
  private OwnerRecordStore.Access access(long session,long request){return ()->active(session,request);}
  private void post(long session,long request,Runnable action){
    ui.post(()->{if(active(session,request))action.run();});
  }
  private Config config(OwnerRecordStore.Access access)throws Problem {
    OwnerRecordStore.Result result=store.read(PRIVATE_RECORD,access);
    if(!"ok".equals(result.status))throw new Problem(storageMessage(result.status));
    Config c=new Config();c.revision=result.revision;c.model=AtlasBrainTransport.DEFAULT_MODEL;
    if(result.value==null){if(result.revision!=0)throw new Problem("Saved connection could not be verified. It was kept unchanged.");return c;}
    try{
      JSONObject p=new JSONObject(result.value);
      if(p.length()!=4||!(p.opt("schema") instanceof Number)||p.optDouble("schema",0)!=1
        ||!(p.opt("key") instanceof String)||!(p.opt("model") instanceof String)||!(p.opt("enabled") instanceof Boolean))
        throw new IllegalArgumentException();
      c.key=(String)p.get("key");c.model=(String)p.get("model");c.enabled=(Boolean)p.get("enabled");
      if(!AtlasBrainTransport.validKey(c.key)||!AtlasBrainTransport.validModel(c.model))throw new IllegalArgumentException();
      return c;
    }catch(Exception invalid){throw new Problem("Saved connection could not be verified. It was kept unchanged.");}
  }
  private static String storageMessage(String status){
    if("locked".equals(status))return "Unlock ATLAS and try again.";
    if("conflict".equals(status))return "The saved connection changed. Reopen this screen before trying again.";
    if("corrupt".equals(status))return "The saved record could not be verified. It was kept unchanged.";
    return "Private storage is unavailable. Your saved records were kept unchanged.";
  }
  private long write(Config c,long session,long request)throws Exception {
    JSONObject data=new JSONObject().put("schema",1).put("key",c.key).put("model",c.model).put("enabled",c.enabled);
    OwnerRecordStore.Result result=store.write(PRIVATE_RECORD,data.toString(),c.revision,access(session,request));
    if(!"ok".equals(result.status))throw new Problem(storageMessage(result.status));
    return result.revision;
  }

  /** Safe status only: never the key, preference text or provider response body. */
  public String status(){
    long session=host.capture();
    if(session==0)return "{\"status\":\"locked\",\"configured\":false,\"enabled\":false,\"verified\":false,\"busy\":false}";
    try{
      Config c=config(()->current(session));
      if(!current(session))return "{\"status\":\"locked\"}";
      return new JSONObject().put("status","ok").put("configured",c.key!=null).put("enabled",c.key!=null&&c.enabled)
        .put("verified",c.enabled&&c.key!=null&&verifiedRevision==c.revision&&lastCheckedAt>0)
        .put("busy",busy).put("model",c.model).put("lastCheckedAt",lastCheckedAt).toString();
    }catch(Exception unavailable){return "{\"status\":\"unavailable\",\"configured\":false,\"enabled\":false,\"verified\":false,\"busy\":false}";}
  }
  private long begin(long session,String kind){
    if(!current(session))return 0;
    if(busy){emit(session,kind,"error",null,"Finish or cancel the current connection step first.");return 0;}
    busy=true;long request=++operation;
    expiryCheck=new Runnable(){public void run(){
      if(request!=operation||!busy)return;
      if(!current(session)){cancelInternal();return;}
      ui.postDelayed(this,1000L);
    }};
    ui.postDelayed(expiryCheck,1000L);
    return request;
  }
  private void emit(long session,String kind,String status,String text,String message){
    if(!current(session))return;
    try{
      JSONObject event=new JSONObject().put("kind",kind).put("status",status);
      if(text!=null)event.put("text",text);
      if(message!=null)event.put("message",message);
      host.emit(session,event.toString());
    }catch(Exception ignored){}
  }
  private void finish(long session,long request,String kind,String status,String text,String message){
    ui.post(()->{
      if(!active(session,request))return;
      busy=false;removeWatch();clearDialog();
      emit(session,kind,status,text,message);
    });
  }
  private void failed(long session,long request,String kind,Exception error){
    String message=error instanceof Problem||error instanceof AtlasBrainTransport.Failure
      ?error.getMessage():"This step could not finish. Your saved files and connection were kept unchanged.";
    finish(session,request,kind,"error",null,message);
  }
  private void removeWatch(){if(expiryCheck!=null){ui.removeCallbacks(expiryCheck);expiryCheck=null;}}
  private void clearDialog(){
    if(secretInput!=null){secretInput.setText("");secretInput=null;}
    AlertDialog old=dialog;dialog=null;
    if(old!=null){try{old.dismiss();}catch(RuntimeException ignored){}}
  }
  private void cancelInternal(){
    operation++;busy=false;removeWatch();transport.cancel();clearDialog();
  }
  /** Lifecycle cancellation is silent and cannot make a later login inherit a result. */
  public void suspend(){
    if(Looper.myLooper()==Looper.getMainLooper())cancelInternal();else ui.post(this::cancelInternal);
  }
  public void cancel(){
    final long session=host.capture();
    ui.post(()->{
      boolean wasBusy=busy;cancelInternal();
      if(wasBusy&&current(session))emit(session,"cancel","cancelled",null,"Request stopped. Text already transmitted cannot be recalled.");
    });
  }
  private LinearLayout box(){
    LinearLayout box=new LinearLayout(activity);box.setOrientation(LinearLayout.VERTICAL);
    int p=Math.round(20*activity.getResources().getDisplayMetrics().density);box.setPadding(p,p,p,p);
    box.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
    box.setFilterTouchesWhenObscured(true);
    return box;
  }
  private TextView text(LinearLayout box,String content){
    TextView view=new TextView(activity);view.setText(content);view.setTextSize(16);view.setPadding(0,8,0,12);
    view.setTextIsSelectable(false);box.addView(view,new LinearLayout.LayoutParams(-1,-2));return view;
  }
  private AlertDialog show(long session,long request,String kind,String title,LinearLayout content,String positive,Runnable action){
    if(!active(session,request))return null;
    ScrollView scroll=new ScrollView(activity);scroll.addView(content);
    AlertDialog shown=new AlertDialog.Builder(activity).setTitle(title).setView(scroll)
      .setPositiveButton(positive,null)
      .setNegativeButton("Cancel",(d,w)->finish(session,request,kind,"cancelled",null,"Cancelled. Nothing was sent or changed."))
      .create();
    shown.setCanceledOnTouchOutside(false);
    shown.setOnCancelListener(d->finish(session,request,kind,"cancelled",null,"Cancelled. Nothing was sent or changed."));
    shown.setOnDismissListener(d->{
      if(dialog==shown){dialog=null;if(secretInput!=null){secretInput.setText("");secretInput=null;}}
    });
    dialog=shown;shown.show();
    if(shown.getWindow()!=null){
      shown.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
      shown.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }
    shown.getButton(AlertDialog.BUTTON_POSITIVE).setFilterTouchesWhenObscured(true);
    shown.getButton(AlertDialog.BUTTON_NEGATIVE).setFilterTouchesWhenObscured(true);
    shown.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(active(session,request))action.run();else cancelInternal();});
    return shown;
  }

  public void configure(){
    final long session=host.capture();
    ui.post(()->{
      long request=begin(session,"configure");if(request==0)return;
      new Thread(()->{
        try{
          Config c=config(access(session,request));
          post(session,request,()->configureDialog(session,request,c));
        }catch(Exception error){failed(session,request,"configure",error);}
      },"atlas-brain-config-load").start();
    });
  }
  private void configureDialog(long session,long request,Config c){
    LinearLayout content=box();
    text(content,"Optional online answers from OpenAI. Your ChatGPT subscription and exported chats do not connect an API account. "
      +"Use your own API key from a funded API project. API answers are billed by OpenAI. "
      +"The key stays in ATLAS's encrypted private storage; saving it sends nothing. "
      +"This personal test build does not include an account setup or billing service.");
    text(content,c.key==null?"API key":"API key — leave empty to keep the saved key");
    EditText key=new EditText(activity);secretInput=key;
    key.setSaveEnabled(false);key.setFilterTouchesWhenObscured(true);
    key.setSingleLine(true);key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
    key.setFilters(new InputFilter[]{new InputFilter.LengthFilter(1024)});
    key.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
    key.setImeOptions(android.view.inputmethod.EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);
    content.addView(key,new LinearLayout.LayoutParams(-1,-2));
    text(content,"Model (advanced)");
    EditText model=new EditText(activity);model.setSingleLine(true);model.setText(c.model);
    model.setFilters(new InputFilter[]{new InputFilter.LengthFilter(80)});
    model.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
    content.addView(model,new LinearLayout.LayoutParams(-1,-2));
    TextView feedback=text(content,"Saving enables this connection for requests you approve. Test it next. Files are never sent automatically.");
    show(session,request,"configure","Connect Atlas Brain",content,"Save connection",()->{
      String entered=key.getText().toString().trim(),chosen=model.getText().toString().trim();
      String kept=entered.isEmpty()?c.key:entered;
      if(!AtlasBrainTransport.validKey(kept)){feedback.setText("Enter an OpenAI API key beginning with sk-. Do not use a ChatGPT password.");return;}
      if(!AtlasBrainTransport.validModel(chosen)){feedback.setText("Use a model ID with letters, numbers, dots, underscores or hyphens (up to 80 characters).");return;}
      c.key=kept;c.model=chosen;c.enabled=true;
      clearDialog();
      new Thread(()->{
        try{
          write(c,session,request);
          post(session,request,()->{verifiedRevision=-1;lastCheckedAt=0;finish(session,request,"configure","ok",null,"Connection saved on this phone. Tap Test connection next. No files were sent.");});
        }catch(Exception error){failed(session,request,"configure",error);}
      },"atlas-brain-config-save").start();
    });
  }
  public void test(){
    final long session=host.capture();
    ui.post(()->{
      long request=begin(session,"test");if(request==0)return;
      new Thread(()->{
        try{
          Config c=ready(session,request);
          post(session,request,()->{
            LinearLayout content=box();
            text(content,"Check access to "+c.model+" at api.openai.com using your saved key? "
              +"This sends the model ID and your API credential. It sends no question, preferences or files and does not request a generated answer. "
              +"A successful check confirms model access at that moment; billing, rate limits or a later request can still fail.");
            show(session,request,"test","Test connection",content,"Check access",()->{
              clearDialog();verifiedRevision=-1;lastCheckedAt=0;
              new Thread(()->{
                try{
                  transport.testModel(c.key,c.model,()->active(session,request));
                  post(session,request,()->{verifiedRevision=c.revision;lastCheckedAt=System.currentTimeMillis();finish(session,request,"test","ok",null,"Model access check passed. You can now ask a question after reviewing its text.");});
                }catch(Exception error){failed(session,request,"test",error);}
              },"atlas-brain-test").start();
            });
          });
        }catch(Exception error){failed(session,request,"test",error);}
      },"atlas-brain-test-prepare").start();
    });
  }
  private Config ready(long session,long request)throws Problem {
    Config c=config(access(session,request));
    if(c.key==null)throw new Problem("Save your optional API connection first. Local files work without it.");
    if(!c.enabled)throw new Problem("This connection is paused. Open setup to enable the saved connection again.");
    return c;
  }
  public void ask(String question,String relativeFile){
    final long session=host.capture();
    ui.post(()->{
      long request=begin(session,"ask");if(request==0)return;
      if(!AtlasBrainProfile.validText(question,4000)||question.trim().isEmpty()
        ||(relativeFile!=null&&!AtlasBrainProfile.validText(relativeFile,512))){
        finish(session,request,"ask","error",null,"Enter a question of up to 4,000 characters and choose at most one supported text file.");return;
      }
      new Thread(()->{
        try{
          Config c=ready(session,request);
          OwnerRecordStore.Result saved=store.read("assistantProfile",access(session,request));
          if(!"ok".equals(saved.status))throw new Problem(storageMessage(saved.status));
          String instructions;
          try{instructions=AtlasBrainProfile.instructions(saved.value);}
          catch(Exception invalid){throw new Problem("Your saved preferences could not be verified. They were kept unchanged. Review How ATLAS helps me before sending.");}
          String input="Owner question:\n"+question.trim();
          if(relativeFile!=null&&!relativeFile.isEmpty()){
            String reference;
            try{reference=host.readText(session,relativeFile);}
            catch(Exception unavailable){throw new Problem("The selected file cannot be read for this request. Choose a supported text file up to 256 KiB, or ask without attaching it.");}
            String excerpt=AtlasBrainProfile.excerpt(reference,12000);
            input+="\n\nOwner-selected reference file: "+relativeFile+"\n"
              +(reference.length()>excerpt.length()?"Only the first "+excerpt.length()+" characters are included.\n":"The complete text is included.\n")
              +"BEGIN UNTRUSTED REFERENCE\n"+excerpt+"\nEND UNTRUSTED REFERENCE";
          }
          final String approvedInput=input,approvedInstructions=instructions;
          post(session,request,()->askDialog(session,request,c,approvedInstructions,approvedInput));
        }catch(Exception error){failed(session,request,"ask",error);}
      },"atlas-brain-question-prepare").start();
    });
  }
  private void askDialog(long session,long request,Config c,String instructions,String input){
    LinearLayout content=box();
    text(content,"Send the text shown below to OpenAI using "+c.model+"? This can incur API charges. "
      +"No other files, images, screen content or past turns are attached. The request sets store:false, but this does not mean zero retention; OpenAI's provider policies still apply. "
      +"An answer cannot control your phone or run actions.");
    text(content,"Instructions and saved preferences being sent:");
    TextView instructionView=text(content,instructions);instructionView.setTextSize(14);
    text(content,"Question and selected reference being sent:");
    TextView inputView=text(content,input);inputView.setTextSize(14);
    show(session,request,"ask","Review before sending",content,"Send approved text",()->{
      clearDialog();
      new Thread(()->{
        try{
          String answer=transport.answer(c.key,c.model,instructions,input,()->active(session,request));
          finish(session,request,"ask","ok",answer,"AI answer. Review it before using it. This turn is not stored as conversation history.");
        }catch(Exception error){failed(session,request,"ask",error);}
      },"atlas-brain-answer").start();
    });
  }
  /** Pause retains the encrypted key so this action does not silently delete data. */
  public void disconnect(){
    final long session=host.capture();
    ui.post(()->{
      long request=begin(session,"disconnect");if(request==0)return;
      new Thread(()->{
        try{
          Config c=config(access(session,request));
          if(c.key==null){finish(session,request,"disconnect","ok",null,"No online connection is configured.");return;}
          post(session,request,()->{
            LinearLayout content=box();
            text(content,"Pause online answers? Your encrypted key will stay on this phone. "
              +"Your local files, preferences and other ATLAS tools stay available. Open connection setup to enable it again.");
            show(session,request,"disconnect","Pause connection",content,"Pause connection",()->{
              clearDialog();c.enabled=false;
              new Thread(()->{
                try{
                  write(c,session,request);
                  post(session,request,()->{verifiedRevision=-1;lastCheckedAt=0;finish(session,request,"disconnect","ok",null,"Connection paused. Your encrypted key and local files are retained.");});
                }catch(Exception error){failed(session,request,"disconnect",error);}
              },"atlas-brain-pause").start();
            });
          });
        }catch(Exception error){failed(session,request,"disconnect",error);}
      },"atlas-brain-pause-prepare").start();
    });
  }
}
