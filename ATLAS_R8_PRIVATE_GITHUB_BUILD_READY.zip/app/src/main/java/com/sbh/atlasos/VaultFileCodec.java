package com.sbh.atlasos;

import java.io.*;
import java.nio.file.*;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * ATL1 AES-GCM file codec. Production and host tests execute the same codec.
 * Encryption gets its nonce from the provider, as Android Keystore requires.
 * Reads return no plaintext until doFinal authenticates the complete message.
 * This is not encrypted browser storage, a backup format, or path authentication.
 */
public final class VaultFileCodec {
  public interface Authorization { boolean allowed(); }
  public static final int TEXT_LIMIT = 1024 * 1024;
  public static final int IMAGE_LIMIT = 8 * 1024 * 1024;
  private static final int TAG_BYTES = 16;
  private static final int BUFFER_BYTES = 65536;
  private static final byte[] MAGIC = {'A','T','L','1'};

  public static final class SizeLimitException extends IOException {
    public SizeLimitException() { super("vault read/write size limit exceeded"); }
  }
  private VaultFileCodec() {}

  private static void authorized(Authorization auth) throws IOException {
    if (!auth.allowed()) throw new IOException("owner session ended");
  }

  /**
   * Creates one new encrypted file; never truncates or removes an existing file.
   * Caller owns the input stream. Only a file created by this call is cleaned on failure.
   * The import transaction owns publication; this method does not promise power-loss durability.
   */
  public static long encryptNew(InputStream input, File destination, SecretKey key,
      long maxBytes, Authorization auth) throws Exception {
    Objects.requireNonNull(input); Objects.requireNonNull(destination);
    Objects.requireNonNull(key); Objects.requireNonNull(auth);
    if (maxBytes < 0 || maxBytes > SeedImportPolicy.MAX_FILE_BYTES)
      throw new IllegalArgumentException("invalid encryption limit");
    authorized(auth);
    Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
    // Do not supply GCMParameterSpec/IV here. Keep randomized encryption REQUIRED.
    cipher.init(Cipher.ENCRYPT_MODE, key);
    byte[] iv = cipher.getIV();
    if (iv == null || iv.length != 12)
      throw new GeneralSecurityException("unsupported provider IV length");
    GCMParameterSpec parameters = cipher.getParameters().getParameterSpec(GCMParameterSpec.class);
    if (parameters.getTLen() != TAG_BYTES * 8)
      throw new GeneralSecurityException("unsupported provider authentication tag");
    Path path = destination.toPath();
    boolean created = false;
    byte[] buffer = new byte[BUFFER_BYTES];
    try {
      OutputStream raw = Files.newOutputStream(path, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
      created = true;
      try (OutputStream output = raw) {
        output.write(MAGIC); output.write(iv.length); output.write(iv);
        long total = 0;
        while (true) {
          authorized(auth);
          int n = input.read(buffer);
          if (n < 0) break;
          // A broken provider stream must not turn into a busy-loop or silent truncation.
          if (n == 0) {
            int one = input.read();
            if (one < 0) break;
            buffer[0] = (byte) one; n = 1;
          }
          if (n > maxBytes - total) throw new SizeLimitException();
          total += n;
          byte[] encrypted = cipher.update(buffer, 0, n);
          if (encrypted != null) output.write(encrypted);
        }
        authorized(auth);
        output.write(cipher.doFinal()); // Do not hide finalization errors in a stream wrapper.
        output.flush();
        authorized(auth);
        return total;
      }
    } catch (Exception error) {
      if (created) {
        try { Files.deleteIfExists(path); }
        catch (IOException cleanup) { error.addSuppressed(cleanup); }
      }
      throw error;
    } finally {
      Arrays.fill(buffer, (byte) 0); // Best effort; no claim of complete memory erasure.
    }
  }

  /** Reads at most maxBytes of authenticated plaintext. Caller owns the input stream. */
  public static byte[] decrypt(InputStream input, SecretKey key, int maxBytes,
      Authorization auth) throws Exception {
    Objects.requireNonNull(input); Objects.requireNonNull(key); Objects.requireNonNull(auth);
    if (maxBytes < 0 || maxBytes > IMAGE_LIMIT)
      throw new IllegalArgumentException("invalid bridge read limit");
    authorized(auth);
    DataInputStream header = new DataInputStream(input);
    byte[] magic = new byte[MAGIC.length]; header.readFully(magic);
    if (!Arrays.equals(magic, MAGIC)) throw new IOException("bad vault file");
    int ivLength = header.readUnsignedByte();
    // Preserve the previously documented ATL1 read range; new writes always use 12.
    if (ivLength < 12 || ivLength > 32) throw new IOException("bad vault IV length");
    byte[] iv = new byte[ivLength]; header.readFully(iv);
    byte[] encrypted = readBounded(input, maxBytes + TAG_BYTES, auth);
    if (encrypted.length < TAG_BYTES) throw new EOFException("missing authentication tag");
    Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
    cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(TAG_BYTES * 8, iv));
    byte[] plaintext = null;
    try {
      authorized(auth);
      plaintext = cipher.doFinal(encrypted); // AEADBadTagException is propagated, not swallowed.
      if (plaintext.length > maxBytes) throw new SizeLimitException();
      authorized(auth);
      byte[] result = plaintext; plaintext = null;
      return result;
    } finally {
      Arrays.fill(encrypted, (byte) 0);
      if (plaintext != null) Arrays.fill(plaintext, (byte) 0);
    }
  }

  private static byte[] readBounded(InputStream input, int limit, Authorization auth)
      throws IOException {
    ByteArrayOutputStream output = new ByteArrayOutputStream(Math.min(4096, limit));
    byte[] buffer = new byte[Math.min(BUFFER_BYTES, limit + 1)];
    int total = 0;
    while (true) {
      authorized(auth);
      // Read at most one byte beyond the limit to reject an oversized stream early.
      int n = input.read(buffer, 0, Math.min(buffer.length, limit - total + 1));
      if (n < 0) break;
      if (n == 0) {
        int one = input.read();
        if (one < 0) break;
        buffer[0] = (byte) one; n = 1;
      }
      if (n > limit - total) throw new SizeLimitException();
      output.write(buffer, 0, n); total += n;
    }
    authorized(auth);
    return output.toByteArray();
  }
}
