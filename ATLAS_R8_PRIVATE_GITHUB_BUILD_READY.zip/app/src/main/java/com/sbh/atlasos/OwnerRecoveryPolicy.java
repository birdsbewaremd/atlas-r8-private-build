package com.sbh.atlasos;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;

/** Offline recovery code policy. No network, persistence, or Android authority here. */
public final class OwnerRecoveryPolicy {
  public static final int CODE_BYTES = 32;
  public static final long FLOW_WINDOW_MS = 5L * 60L * 1000L;
  private OwnerRecoveryPolicy() {}

  public static boolean pinPairMatches(String pin, String confirmation) {
    return OwnerPinPolicy.validPin(pin) && OwnerPinPolicy.validPin(confirmation)
        && MessageDigest.isEqual(pin.getBytes(StandardCharsets.US_ASCII),
            confirmation.getBytes(StandardCharsets.US_ASCII));
  }

  public static boolean flowValid(long started, long now) {
    return started >= 0 && now >= started && now - started < FLOW_WINDOW_MS;
  }

  public static String newCode(SecureRandom random) {
    if (random == null) throw new IllegalArgumentException("random required");
    byte[] bytes = new byte[CODE_BYTES]; random.nextBytes(bytes);
    char[] hex = "0123456789ABCDEF".toCharArray();
    StringBuilder out = new StringBuilder(79);
    for (int i = 0; i < bytes.length; i++) {
      if (i > 0 && i % 2 == 0) out.append('-');
      out.append(hex[(bytes[i] & 255) >>> 4]).append(hex[bytes[i] & 15]);
    }
    java.util.Arrays.fill(bytes, (byte) 0);
    return out.toString();
  }

  public static String normalize(String raw) {
    if (raw == null || raw.length() > 128) return null;
    StringBuilder out = new StringBuilder(64);
    for (int i = 0; i < raw.length(); i++) {
      char c = raw.charAt(i);
      if (c == '-' || c == ' ') continue;
      if (c >= 'a' && c <= 'f') c = (char) (c - 'a' + 'A');
      if (!((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F'))) return null;
      out.append(c);
    }
    return out.length() == 64 ? out.toString() : null;
  }

  public static byte[] digest(String code, byte[] salt) throws GeneralSecurityException {
    String normalized = normalize(code);
    if (normalized == null || salt == null || salt.length != OwnerPinPolicy.SALT_BYTES)
      throw new GeneralSecurityException("invalid recovery material");
    MessageDigest md = MessageDigest.getInstance("SHA-256");
    md.update("ATLAS_OWNER_RECOVERY_V1\0".getBytes(StandardCharsets.US_ASCII));
    md.update(salt);
    return md.digest(normalized.getBytes(StandardCharsets.US_ASCII));
  }

  public static boolean matches(String code, byte[] salt, byte[] expected) {
    if (expected == null || expected.length != 32) return false;
    try { return MessageDigest.isEqual(expected, digest(code, salt)); }
    catch (GeneralSecurityException e) { return false; }
  }
}
