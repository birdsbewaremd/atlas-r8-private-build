# ATLAS OS Release Protocol — Preservation + 10-Pass Review
Every release must preserve accepted functionality unless explicitly superseded.
1. Preservation: compare prior accepted startup, setup, lock, home, apps, settings, permissions, owner/delegate boundaries.
2. Visual: inspect clipping, overlap, wrapping, crop, safe areas, spacing, hierarchy, contrast.
3. Interaction: every visible control has press/selected/loading/success/failure/disabled or honest unavailable state.
4. Responsive: phone/tablet, portrait/landscape, keyboard open, large text, reduced motion.
5. Persistence: reload preserves intended profile/settings/reorder/tasks/notes without leaking private data.
6. Permissions: allow/deny/retry for camera/microphone and truthful Native-required boundaries.
7. Security: owner/delegate isolation, no secrets in client/logs/prompts, sensitive modules fail closed.
8. Failure: offline, stale service worker, missing asset, denied permission, interrupted action, empty state.
9. Regression: defects previously found by Shaun become permanent checks; no silent feature removal.
10. Release truth: CODED != STATIC VERIFIED != RUNTIME VERIFIED != DEPLOYED != PRODUCTION VERIFIED.
Do not ship merely because syntax passes. If runtime/visual testing is blocked, say so and do not claim publish-ready.
