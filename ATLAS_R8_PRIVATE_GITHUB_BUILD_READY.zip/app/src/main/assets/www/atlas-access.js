/* ATLAS ACCESS CENTER · owner-directed, source-only integration.
   A guided control panel, never blanket permission or silent activation.
   Android/owner MUST approve roles/permissions independently. */
(()=>{'use strict';
 const items=[
  {id:'home',group:'Core',label:'Make ATLAS the Home app',detail:'Choose ATLAS as the default Home app in Android Settings; you can restore Samsung Home.',mode:'system',arg:'home',scope:'Android role — user confirmation'},
  {id:'assistant',group:'Core',label:'Default voice assistant',detail:'Ask Android to review the Assistant role. Wake-word listening is separate and remains off until you activate it.',mode:'assistant',scope:'Android role — user confirmation'},
  {id:'voice',group:'Core',label:'Voice and wake controls',detail:'Open the existing Voice Studio. Microphone use requires Android permission; no ambient archive is collected by this button.',mode:'route',arg:'voice',scope:'Owner-initiated mic session'},
  {id:'files',group:'Data',label:'Choose files and archives',detail:'Open Library Transfer. Android’s system picker grants access only to the documents you select.',mode:'route',arg:'library-transfer',scope:'Selected files only'},
  {id:'camera',group:'Core',label:'Camera / eyes',detail:'Open visible Camera. The system decides camera permission. No 24/7 dual-camera feed is activated.',mode:'route',arg:'camera',scope:'Visible camera session'},
  {id:'notifications',group:'System',label:'Notifications',detail:'Review ATLAS notifications using Android Settings. Returning here is not proof of any change.',mode:'system',arg:'notifications',scope:'Android notification settings'},
  {id:'apps',group:'System',label:'Android app settings',detail:'Inspect permission grants and restrictions in Android Settings. ATLAS cannot grant them for you.',mode:'system',arg:'apps',scope:'Android settings'},
  {id:'accessibility',group:'Unavailable',label:'Accessibility service / screen control',detail:'No ATLAS Accessibility service is implemented. Android cannot grant nonexistent service access.',mode:'unavailable',scope:'Not built — no permission request'},
  {id:'devices',group:'System',label:'Device and app insights',detail:'Inspect available device insight features; Android limits third-party app and activity visibility.',mode:'route',arg:'devices',scope:'App-specific and supported'},
  {id:'account',group:'Data',label:'Accounts and exports',detail:'Open the official export/import guidance. Provider sign-in remains separate; no passwords stored here.',mode:'route',arg:'start',scope:'User-selected official exports'},
  {id:'unlock',group:'Advanced',label:'Owner security / recovery',detail:'Open current ATLAS security settings. A seamless biometric grace session is not yet implemented.',mode:'route',arg:'settings',scope:'Existing PIN controls only'},
  {id:'background_camera',group:'Unavailable',label:'Hidden 24/7 camera access',detail:'Not supported or offered. No covert camera capture or lock-screen bypass.',mode:'unavailable',scope:'Unsupported'},
  {id:'all_files',group:'Unavailable',label:'Unrestricted access to every app',detail:'Android isolates app-private data; ATLAS cannot grant itself access to every other app or account.',mode:'unavailable',scope:'Unsupported'}
 ];
 let ctx=null,focus='all',guided=-1;
 const supported=()=>items.filter(x=>x.mode!=='unavailable');
 const $=(s)=>document.querySelector('.atlasAccess '+s);
 const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
 const owner=()=>!!ctx&&(!ctx.native?.available?.()||ctx.native.call('ownerSessionActive')===true);
 const native=()=>!!ctx?.native?.available?.();
 const say=(s)=>{const el=$('#accessResult');if(el)el.textContent=s;};
 function row(it){return `<article class="ax-card ${it.mode==='unavailable'?'ax-disabled':''} ${supported()[guided]?.id===it.id?'ax-guided-current':''}">
  <div class="ax-head"><div><span class="ax-scope">${escape(it.scope)}</span><h3>${escape(it.label)}</h3></div><span class="ax-state">${it.mode==='unavailable'?'UNAVAILABLE':'REVIEW'}</span></div>
  <p>${escape(it.detail)}</p>${it.mode==='unavailable'?'':`<button data-access="${escape(it.id)}" type="button" class="ax-action">${it.mode==='route'?'Open ATLAS feature':it.mode==='assistant'?'Request Android role':'Open Android settings'} <span aria-hidden="true">↗</span></button>`}
 </article>`;}
 function render(){if(!ctx)return false;
  const title='ATLAS Access Center';
  const filters=['all','Core','Data','System','Advanced','Unavailable'];
  ctx.frame(title,`<section class="atlasAccess" aria-label="ATLAS Access Center"><header class="ax-hero"><p class="ax-eyebrow">OWNER PRIVATE · S20 ULTRA</p><h1>Unlock what <em>Android allows.</em></h1><p>One place to review supported capabilities. Android grants each protected permission separately—nothing is silently turned on.</p>
  <div class="ax-heroactions"><button type="button" id="accessNative" class="ax-primary">Open Native Android Access Setup</button><button type="button" id="accessReviewAll">Review all supported features</button><button type="button" id="accessStatus">Check live status</button></div></header>
  ${guided>=0?`<div class="ax-guidebar" aria-label="Guided permission review"><b>Step ${guided+1} / ${supported().length} — ${escape(supported()[guided]?.label||'Complete')}</b><small>Tap the relevant button below. Android decides permission approval. Then review the next step.</small><div class="ax-guidenav"><button id="axPrev" ${guided===0?'disabled':''}>Previous</button><button id="axNext">${guided===supported().length-1?'Finish review':'Next step'}</button><button id="axExit">Exit guide</button></div></div>`:''}
  <section class="ax-notice"><strong>Always your choice.</strong> These controls open Android or an existing ATLAS destination. A request or opened Settings page does <b>not</b> prove a permission was granted. Locked/private information stays protected.</section>
  <section class="ax-filters" aria-label="Permission categories">${filters.map(f=>`<button type="button" data-group="${escape(f)}" aria-pressed="${focus===f}">${escape(f==='all'?'All':f)}</button>`).join('')}</section>
  <div class="ax-grid" id="accessList">${items.filter(it=>focus==='all'||it.group===focus).map(row).join('')}</div>
  <div class="ax-safeties"><h2>Immediate control</h2><p>Stop Hey ATLAS separately from Android’s microphone/camera switches. For other access, open app settings and revoke grants. Stop never pretends to wipe recordings already saved.</p><div class="ax-inline"><button id="accessStopWake" type="button">Stop Hey ATLAS</button><button id="accessRevoke" type="button">Review / revoke permissions</button></div></div>
  <p class="ax-result" id="accessResult" role="status" aria-live="polite">Status: setup not checked. No access was changed on opening this page.</p>
  <p class="ax-foot">Source-built preview · no universal Allow All · no covert recording, device management or provider account access. Existing data and settings unchanged.</p></section>`, 'atlasAccessView');
  document.querySelectorAll('.atlasAccess [data-access]').forEach(b=>b.addEventListener('click',()=>action(b.dataset.access)));
  document.querySelectorAll('.atlasAccess [data-group]').forEach(b=>b.addEventListener('click',()=>{focus=b.dataset.group;render()}));
  $('#accessNative').addEventListener('click',()=>{
    if(!native()){say('A compiled Android ATLAS app is required. This is a source-only preview.');return;}
    if(!owner()){say('Unlock ATLAS owner access first.');return;}
    ctx.native.call('openAccessCenter');say('Native Android Access Center requested. Android controls permission grants and role changes.');
  });
  $('#accessReviewAll').addEventListener('click',()=>{focus='all';guided=0;render();say('Guided review opened. Select each action explicitly; no permissions are granted automatically.')});
  $('#axPrev')?.addEventListener('click',()=>{guided=Math.max(0,guided-1);focus='all';render()});
  $('#axNext')?.addEventListener('click',()=>{guided=guided>=supported().length-1?-1:guided+1;focus='all';render();if(guided<0)say('Review finished. Check Android Settings for actual permission status.')});
  $('#axExit')?.addEventListener('click',()=>{guided=-1;render();say('Guided review closed. No permissions were granted by the guide.')});
  $('#accessStatus').addEventListener('click',()=>{
    if(!native()){say('Browser preview: Android permission status unavailable, no permissions granted by this preview.');return;}
    if(!owner()){say('Unlock your ATLAS owner session before reviewing permissions.');return;}
    try{
      const state=JSON.parse(ctx.native.call('accessStatusJson')||'{}');
      if(state.status==='locked'){say('Owner session locked.');return;}
      let allowed=0,review=0;
      document.querySelectorAll('.atlasAccess [data-access]').forEach(b=>{
        const id=b.dataset.access;const key=({voice:'microphone',apps:'app_settings'})[id]||id;const card=b.closest('.ax-card');const badge=card?.querySelector('.ax-state');
        if(!badge||typeof state[key]!=='string')return;
        badge.textContent=state[key];if(state[key]==='ALLOWED')allowed++;else if(state[key]==='REVIEW')review++;
      });
      say('Android reports '+allowed+' allowed and '+review+' reviewable visible items. Other features are system settings, per-file grants or not built. No changes made.');
    }catch(e){say('Live permission reading unavailable. Open the native Access Center or Android App Settings.');}
  });
  $('#accessStopWake').addEventListener('click',()=>{if(!native()){say('Native Android build required. No listener controlled from browser preview.');return;}if(!owner()){say('Owner unlock required for this action.');return;}ctx.native.call('stopHeyAtlas');say('Stop request submitted to native ATLAS. Verify microphone access in Android settings if necessary.')});
  $('#accessRevoke').addEventListener('click',()=>action('apps'));
  return true;
 }
 function action(id){if(!owner()){say('ATLAS owner unlock required. Nothing was changed.');return false;}const item=items.find(it=>it.id===id);if(!item||item.mode==='unavailable'){say('Unsupported capability; nothing changed.');return false;}
  if(item.mode==='route'){say('Opening '+item.label+'. No permission was granted by this screen.');ctx.open?.(item.arg);return true;}
  if(!native()){say('This action requires a native Android install. Browser preview cannot request '+item.label+'.');return false;}
  if(item.mode==='assistant'){ctx.native.call('requestAssistantRole');say('Android Assistant role review requested. Only Android can confirm if selected.');return true;}
  if(item.mode==='system'){ctx.native.call('openSystemPanel',item.arg);say('Android settings request opened for '+item.label+'. Return to ATLAS after reviewing; approval is not assumed.');return true;}
  return false;
 }
 function open(context){ctx=context;focus='all';guided=-1;return render();}
 window.ATLASAccessCenter=Object.freeze({open,render,items:()=>items.map(({id,group,label,mode})=>({id,group,label,mode}))});
})();
