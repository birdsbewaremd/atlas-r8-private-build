/* ATLAS Owner View Bridge · additive, source-only · 2026-10-24
 * ATLAS Home appearance is separate from Android ROLE_HOME.
 * No permissions or external destinations are changed without an owner tap.
 * No authentication bypass, no auto-switch of Android launcher. */
(()=>{'use strict';
  const STORAGE='atlas.home.mode';
  const VALID=['universe','apps'];
  let ctx=null;
  const esc=s=>String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  function mode(){return localStorage.getItem(STORAGE)==='classic'?'apps':'universe'}
  function owner(){try{return !!ctx&&ctx.owner()===true}catch{return false}}
  function render(){
    const selected=mode();
    return `<nav class="atlasModeBar" aria-label="Choose the ATLAS view. Android system Home is separate."><span class="atmbTitle">ATLAS view</span><div class="atmbButtons" role="group" aria-label="Appearance inside ATLAS"><button type="button" data-at-mode="universe" aria-label="Show futuristic Universe inside ATLAS" aria-pressed="${selected==='universe'}">◎ Universe</button><button type="button" data-at-mode="apps" aria-label="Show familiar Apps layout inside ATLAS" aria-pressed="${selected==='apps'}">▦ Apps</button></div><button type="button" data-at-home-role aria-label="Open Android system Home-app Settings. No Home selection changes automatically." title="Android system Home is separate; opens Settings only">⌂ Android Home</button></nav>`;
  }
  function set(next){
    if(!VALID.includes(next)||!owner())return false;
    // Do not interrupt unsaved fields silently; only input edits trigger this warning.
    const form=document.querySelector('#app .appview');
    if(form&&form.dataset.atDirty==='1'&&typeof window.confirm==='function'&&!window.confirm('Leave this screen? Unsaved input may be lost.'))return false;
    const desired=next==='apps'?'classic':'universe';
    localStorage.setItem(STORAGE,desired);
    ctx.home();
    return mode()===next;
  }
  function role(){
    if(!owner())return false;
    // Android role is not controlled by this preference. Android owns the dialog.
    if(!ctx.native?.available?.()){
      ctx.toast?.('Choose Home app from Android Settings on your phone.');return false;
    }
    const result=ctx.native.call('openSystemPanel','home');
    // JNI void methods return undefined; this is a request, NOT proof of change.
    ctx.toast?.('Android Home selection requested; no selection changed by ATLAS.');
    return result!==false;
  }
  function bindButtons(root=document){
    if(!owner())return false;
    root.querySelectorAll('[data-at-mode]').forEach(button=>{
      button.addEventListener('click',()=>set(button.dataset.atMode));
    });
    root.querySelectorAll('[data-at-home-role]').forEach(b=>b.addEventListener('click',role));
    return true;
  }
  function bind(options){ctx=options;return true}
  function status(){return {mode:mode(),owner:owner(),androidHome:'Independent Android setting',native:!!ctx?.native?.available?.()}}
  window.ATLASModeBridge=Object.freeze({bind,render,mode,set,bindButtons,role,status});
})();