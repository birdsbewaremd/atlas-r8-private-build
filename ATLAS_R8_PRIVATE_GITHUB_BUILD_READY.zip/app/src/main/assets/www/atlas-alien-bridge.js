/* Exact original Alien Mode V1 archived locally, opened in a restricted iframe.
   Owner-action only. No native bridge, external account connection or auto-camera. */
(()=>{'use strict';
 let ctx;
 function open(environment){ctx=environment;const contents=`<section class="ag-alien" aria-label="ATLAS Alien Mode archived experiment"><p class="ag-eyebrow">ATLAS Ω · OWNER-PRIVATE · RECOVERED OCT 24</p><h1>ALIEN MODE <em>V1</em></h1><p>The original cosmic, music and creative-thinking experiment is preserved here in a local isolated viewer. No camera, microphone, location or external account is started by ATLAS.</p><div class="ag-alien-actions"><button id="alienEnter" type="button">Open original cosmic cockpit</button><button id="alienEarth" type="button">Back to ATLAS Home</button></div><p id="alienStatus" role="status">Original archived source. Browser storage/notes inside the sandbox may not be available; export your work before leaving.</p><div id="alienStage"></div><p class="ag-foot">No medical claim or permission to drive while impaired. Stop, pause or exit at any time.</p></section>`;
  ctx.frame?.('ATLAS Alien Mode',contents,'atlasAlienBridgeView');
  const root=document.querySelector('.ag-alien');if(!root)return false;
  root.querySelector('#alienEnter').addEventListener('click',()=>{if(root.querySelector('iframe')){root.querySelector('iframe').focus();return;}const iframe=document.createElement('iframe');iframe.className='ag-alien-iframe';iframe.title='ATLAS Alien Mode V1 original offline HTML';iframe.setAttribute('sandbox','allow-scripts allow-forms allow-downloads');iframe.setAttribute('referrerpolicy','no-referrer');iframe.setAttribute('loading','eager');iframe.src='./atlas-legacy/alien-mode-2026-10-24.html';root.querySelector('#alienStage').append(iframe);root.querySelector('#alienStatus').textContent='Archived original opened in a restricted viewer. No ATLAS native permissions or sensitive accounts were granted.';});
  root.querySelector('#alienEarth').addEventListener('click',()=>ctx.home?.());
  return true;
 }
 window.ATLASAlien=Object.freeze({open});
})();
