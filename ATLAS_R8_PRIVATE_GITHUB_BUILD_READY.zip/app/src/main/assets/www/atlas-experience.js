/* ATLAS Ω App Galaxy / Command Lens, 2026-10-24.
   Improves navigation of existing owner-gated apps; adds no device permissions.
   NOT an alternative system launcher or externally connected assistant. */
(()=>{'use strict';
 const storeKey='atlas.experience.pins.v1', recentKey='atlas.experience.recent.v1';
 const safeRead=(key,def)=>{try{const x=JSON.parse(localStorage.getItem(key)||'null');return Array.isArray(x)?x:def}catch{return def}};
 const safeWrite=(key,arr)=>{try{localStorage.setItem(key,JSON.stringify(arr))}catch{}};
 const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const META={
  god:['ATLAS Master Chat','Core','One owner-gated command conversation'],
  atlas:['ATLAS AI','Core','Local command console; connected AI must be authorized'],
  stats:['Character & Stats','Life','AURA, LEVEL ONE RPG and sourced capability records'],
  tasks:['Missions','Work','Manage the current local task list'],
  projects:['ATLAS Builder','Work','Saved plans and projects'],
  goals:['Goals','Life','Track goals and actual next actions'],
  notes:['ATLAS Notes','Life','Owner-controlled notes'],
  files:['ATLAS Drive','Files','Selected local files; no cloud drive synchronization'],
  'library-transfer':['Library Transfer','Files','Import files you selected from supported exports'],
  memory:['ATLAS Mind','Life','Existing preserved source and memory view'],
  shaunos:['Shaun OS','Core','Private second-brain source collection'],
  games:['Game Lab','Worlds','Recovered original chess, estate, FPS and adventure games'],
  currency:['Currency Lab','Worlds','A1V / ATC / AXU research — not real money'],
  recovered:['All Recovered','Worlds','Historical source pointers, not installed apps'],
  pilot:['ATLAS Pilot','System','One-tap phone controls, Hey ATLAS, settings and Home mode'],
  voice:['Voice Studio','Creative','Speech settings; cloned voice unverified'],
  camera:['ATLAS Vision','Creative','User-invoked visible camera session'],
  photos:['ATLAS Gallery','Creative','Photos and project art'],
  store:['ATLAS Shopping','Work','Discover, wishlist, owned inventory, project parts, manual order journal and planning cart'],
  browser:['ATLAS Browser','Files','Local bookmarks and web handoffs, not a full browser engine'],
  messages:['Messages','Connect','Android messages handoff'],
  phone:['Phone','Connect','Android dialer handoff'],
  contacts:['Contacts','Connect','Selected local/Android contact workflows'],
  mail:['Mail','Connect','Owner draft record; not live signed-in Gmail'],
  calendar:['Calendar','Work','Local planning and schedule records'],
  maps:['ATLAS Maps','Connect','Android maps handoff'],
  learning:['ATLAS School','Worlds','Lessons, research and preserved source reading'],
  evolution:['ATLAS Evolution','Worlds','From footsteps and carrier pigeons to AI; communications, medicine, clothing, industry and future research'],
  access:['Access Center','System','One guided review of actual Android permission pathways'],
  settings:['Settings','System','Appearance, accessibility, owner and app controls'],
  storage:['Storage','System','Storage information and files'],
  devices:['ATLAS Connect','System','Supported device and app insights'],
  commands:['ATLAS Terminal','System','Existing bounded local commands, not a system shell'],
  sentinel:['ATLAS Secure','System','Existing owner privacy and security review'],
  robotics:['Robotics','Worlds','Existing robotics concepts and plans'],
  businesses:['Birds Beware & Business','Work','Existing business workflows and archives'],
  lab:['Feature Lab','Worlds','Current staged feature and engineering registry'],
  calculator:['Calculator','Work','Arithmetic tool'],
  'safefor':['Safe For Later','Life','Owner-selected deferred project notes'],
  'alien':['ALIEN MODE','Creative','Recovered October 24 cosmic lab; isolated local original'],
  'start':['Add My Files','Files','Owner-authorized import and first-use guide']
 };
 const EXTRA=[['library-transfer','T','Files','private'],['alien','✧','Creative','private'],['start','+','Files','private']];
 const FUTURE=[
  ['ATLAS AR','Worlds','Augmented reality studio research; hardware support not verified','devices'],
  ['ATLAS Car','Connect','Vehicle diagnostics and compatible sensors require hardware','devices'],
  ['ATLAS Home','Connect','Future opt-in smart-home integrations','devices'],
  ['ATLAS Flight','Worlds','Flight and aerospace concepts, not a simulator pilot tool','learning'],
  ['ATLAS Meet','Connect','Conferencing and account integrations not implemented','contacts'],
  ['ATLAS Translate','Worlds','Language-learning prototype; universal translation not built','learning'],
  ['ATLAS OS Independent','System','Future OS roadmap, not a current Android replacement','projects']
 ];
 const TERMS={atlas:'chat ai gpt assistant siri brain',god:'chat god director',currency:'wallet coin barter value tokens money atc a1v axu',store:'shopping shop inventory gear products orders wishlist cart bill of materials bom parts supplies price budget procurement owned equipment',files:'drive vault documents cloud storage',learning:'learn school teach books education translate',evolution:'evolution history timeline pigeon doves walking mail letters telegraph phone electronics email sms text message medicine clothes clothing invention future past chronology',photos:'gallery media images pictures',camera:'vision eyes photos picture',notes:'notepad diary memory',projects:'builder forge studio develop code',games:'chess wordcraft game lab fps play',alien:'cosmic alien high mode creative relax',devices:'connect computer car home bluetooth wifi',messages:'messaging texts sms',pilot:'pilot voice command phone settings wifi bluetooth volume home classic universe wake listening stop hey atlas voice access',access:'permission allow all security access center',stats:'iq rpg gideon aura character special fallout',browser:'browser web internet',tasks:'automate missions todos',library_transfer:'archive export chatgpt import'};
 const groups=['All','Core','Work','Files','Life','Creative','Worlds','Connect','System'];
 let ctx=null, filter='All',query='', overlay=null, lastFocus=null, view='all', hint='';
 const OWNER=()=>{try{return !!ctx && sessionStorage.getItem('atlas.role')==='owner' && (!ctx.native?.available?.()||ctx.native.call('ownerSessionActive')===true)}catch{return false}};
 function catalog(){const seed=window.ATLASAppDirectory||[];const seen=new Set();const rows=[];
  for(const a of [...seed,...EXTRA]){const [id,n,icon,state]=a;if(seen.has(id))continue;seen.add(id);const [name,group,desc]=META[id]||[n,'System','Existing ATLAS route; full native device acceptance not verified'];rows.push({id,name,group,desc,icon:icon||'◇',status:id==='alien'?'ARCHIVED LOCAL':['currency','cash','bank'].includes(id)?'RESEARCH / GATED':'APP ROUTE',planned:false});}
  for(const [name,group,desc,related] of FUTURE)rows.push({id:'concept:'+name,name,group,desc,related,icon:'⊕',status:'CONCEPT ONLY',planned:true});
  return rows;
 }
 const pins=()=>safeRead(storeKey,['atlas','stats','games','files','library-transfer']).filter(x=>typeof x==='string').slice(0,12);
 const recents=()=>safeRead(recentKey,[]).filter(x=>typeof x==='string').slice(0,8);
 function track(id){if(!OWNER())return;if(typeof id!=='string'||!catalog().some(x=>x.id===id&&!x.planned))return;safeWrite(recentKey,[id,...recents().filter(x=>x!==id)].slice(0,8));}
 function togglePin(id){if(!OWNER()||id.startsWith('concept:'))return;const a=pins(),b=a.includes(id)?a.filter(x=>x!==id):[...a,id];safeWrite(storeKey,b.slice(0,12));hint=a.includes(id)?'Removed from pinned apps.':'Pinned for quick access.';renderGalaxy();}
 const route=(id)=>{if(!OWNER()){close();return false;}const item=catalog().find(x=>x.id===id);if(!item){hint='That app is not available in this build.';updateHint();return false;}
  if(item.planned){hint=`${item.name} is an archived concept, not an installed app. Open its related research if useful.`;updateHint();return false;}
  track(id);close();ctx.open?.(id);return true;};
 function icon(id){const img={atlas:'./assets/gallery/orbit-monogram.webp',stats:'./assets/gallery/better-you.webp',files:'./assets/gallery/sovereign-control.webp',games:'./assets/gallery/wordcraft.webp','alien':'./assets/gallery/future-world.webp',learning:'./assets/gallery/blue-mist.webp',projects:'./assets/gallery/ecosystem-command.webp',store:'./assets/gallery/orbit-cover.webp'}[id];return img?`<span class="ag-art" style="background-image:url('${img}')" aria-hidden="true"></span>`:`<span class="ag-sigil" aria-hidden="true">${esc((catalog().find(x=>x.id===id)?.icon)||'△')}</span>`;}
 const tbtn=(item,compact=false)=>`<article class="ag-item ${compact?'compact':''}${item.planned?' planned':''}" data-id="${esc(item.id)}"><button class="ag-launch" data-ag-open="${esc(item.id)}" ${item.planned?'aria-label="Read concept status for '+esc(item.name)+'"':''}>${icon(item.id)}<span class="ag-copy"><strong>${esc(item.name)}</strong><small>${esc(item.desc)}</small><em>${esc(item.status)}</em></span><span class="ag-arrow" aria-hidden="true">↗</span></button>${item.planned?'':`<button class="ag-pin" data-ag-pin="${esc(item.id)}" aria-label="${pins().includes(item.id)?'Unpin':'Pin'} ${esc(item.name)}" aria-pressed="${pins().includes(item.id)}">${pins().includes(item.id)?'✦':'☆'}</button>`}</article>`;
 function matching(rows,word=query,category=filter){const q=word.trim().toLowerCase().split(/\s+/).filter(Boolean);return rows.filter(a=>(category==='All'||a.group===category)&&q.every(t=>(a.name+' '+a.desc+' '+a.group+' '+a.status+' '+(TERMS[a.id]||'')).toLowerCase().includes(t)));}
 function updateHint(){const e=document.querySelector('#ag-status')||overlay?.querySelector('#ag-lens-status');if(e)e.textContent=hint;}
 function renderGalaxy(){if(!OWNER())return false;
  const all=catalog(),shown=matching(all),most=all.filter(x=>pins().includes(x.id)&&!x.planned),recent=all.filter(x=>recents().includes(x.id)&&!x.planned);
  const art=`<div class="ag-skyart" role="img" aria-label="Original ATLAS orbital architecture artwork"></div>`;
  const html=`<section class="atlasGalaxy" aria-label="ATLAS App Galaxy"><div class="ag-hero">${art}<div class="ag-hero-copy"><span class="ag-eyebrow">ATLAS Ω · ONE INTELLIGENCE / MANY WORLDS</span><h1>Your whole world.<br><em>One gesture away.</em></h1><p>Apps, games, research, projects and tools—without hunting through a phone grid.</p><div class="ag-hero-cta"><button id="agAsk" type="button">◈ Ask ATLAS</button><button id="agResume" type="button">↗ Continue</button></div></div></div>
    <div class="ag-search"><label for="agFind">Search your ATLAS universe</label><div><span aria-hidden="true">⌕</span><input id="agFind" type="search" value="${esc(query)}" placeholder="Search apps, goals, files, worlds…" autocomplete="off" spellcheck="false"/><button id="agClear" type="button" aria-label="Clear search">×</button></div></div>
    <div class="ag-links"><button data-ag-quick="stats">Character</button><button data-ag-quick="games">Games</button><button data-ag-quick="files">Files</button><button data-ag-quick="store">Shopping</button><button data-ag-quick="alien">Alien Mode</button><button data-ag-quick="access">Access</button></div>
    ${!query&&filter==='All'?`<section class="ag-section"><div class="ag-heading"><h2>Your shortcuts</h2><span>Tap ★ to pin</span></div><div class="ag-row" id="agPinned">${most.map(x=>tbtn(x,true)).join('')||'<p>No pinned apps</p>'}</div></section>${recent.length?`<section class="ag-section"><div class="ag-heading"><h2>Recently used</h2><span>Only destinations, not activity recordings</span></div><div class="ag-row">${recent.slice(0,4).map(x=>tbtn(x,true)).join('')}</div></section>`:''}`:''}
    <section class="ag-section"><div class="ag-heading"><h2>Explore everything</h2><span id="agCount">${shown.length} entries · routes vs concepts labeled</span></div><div class="ag-filters" role="group" aria-label="App categories">${groups.map(g=>`<button type="button" data-ag-group="${g}" aria-pressed="${filter===g}">${g}</button>`).join('')}</div><div class="ag-results" id="agResults">${shown.map(x=>tbtn(x)).join('')||'<p>No matching ATLAS entries. Try a different word or category.</p>'}</div></section>
    <div class="ag-status" id="ag-status" role="status" aria-live="polite">${esc(hint||'Existing routes are not verified physical-device installations. Concepts are labeled.')}</div><p class="ag-foot">All original source and project records remain in Shaun OS. 68 historical module folders are separate pointers, not bundled working apps.</p></section>`;
  ctx.frame?.('ATLAS App Galaxy',html,'atlasGalaxyView');
  const root=document.querySelector('.atlasGalaxy');if(!root)return false;
  root.querySelector('#agFind').addEventListener('input',e=>{query=e.target.value.slice(0,140);renderList(root)});
  root.querySelector('#agClear').addEventListener('click',()=>{query='';renderList(root);root.querySelector('#agFind').focus()});
  root.querySelector('#agAsk').addEventListener('click',()=>route('atlas'));
  root.querySelector('#agResume').addEventListener('click',()=>{const r=recents()[0];if(r)route(r);else route('start')});
  root.querySelectorAll('[data-ag-group]').forEach(b=>b.addEventListener('click',()=>{filter=b.dataset.agGroup;renderList(root)}));
  root.querySelectorAll('[data-ag-quick]').forEach(b=>b.addEventListener('click',()=>route(b.dataset.agQuick)));
  bindResults(root);return true;
 }
 function renderList(root){const list=root.querySelector('#agResults');if(!list)return;const data=matching(catalog());list.innerHTML=data.map(x=>tbtn(x)).join('')||'<p>No matching ATLAS entries. Try another keyword.</p>';root.querySelector('#agCount').textContent=`${data.length} entries · routes vs concepts labeled`;root.querySelectorAll('[data-ag-group]').forEach(x=>x.setAttribute('aria-pressed',String(x.dataset.agGroup===filter)));const inp=root.querySelector('#agFind');if(inp&&inp.value!==query)inp.value=query;bindResults(root);}
 function bindResults(root){root.querySelectorAll('[data-ag-open]').forEach(b=>b.addEventListener('click',()=>{const id=b.dataset.agOpen;if(id.startsWith('concept:')){const item=catalog().find(x=>x.id===id);hint=item?`${item.name} is a concept. ${item.desc} Open ${catalog().find(x=>x.id===item.related)?.name||'a related module'} for current research.`:'Concept not available.';updateHint();return;}route(id)}));root.querySelectorAll('[data-ag-pin]').forEach(b=>b.addEventListener('click',()=>{togglePin(b.dataset.agPin)}));}
 function makeLens(){if(!OWNER())return false;if(overlay)close();lastFocus=document.activeElement;query='';filter='All';overlay=document.createElement('div');overlay.className='ag-lens-veil';overlay.innerHTML=`<section role="dialog" aria-modal="true" aria-label="ATLAS Command Lens" class="ag-lens"><div class="ag-lens-head"><span>△ ATLAS <b>LENS</b><small>One search across available destinations</small></span><button id="agLensClose" aria-label="Close lens" type="button">×</button></div><label for="agLensQuery">What do you want to open?</label><div class="ag-lens-input"><span aria-hidden="true">⌕</span><input type="search" id="agLensQuery" placeholder="Games, files, stats, assistant…" autocomplete="off" spellcheck="false"></div><div class="ag-lens-options"><button data-ag-option="all" aria-pressed="true">All</button><button data-ag-option="pinned" aria-pressed="false">Pinned</button><button data-ag-option="recent" aria-pressed="false">Recent</button></div><div class="ag-lens-results" id="agLensResults"></div><p id="ag-lens-status" role="status">${esc('Owner-gated local destinations. No permission was changed.')}</p></section>`;document.body.appendChild(overlay);view='all';overlay.addEventListener('click',e=>{if(e.target===overlay)close()});overlay.querySelector('#agLensClose').onclick=close;overlay.querySelector('#agLensQuery').addEventListener('input',e=>{query=e.target.value.slice(0,140);paintLens()});overlay.querySelectorAll('[data-ag-option]').forEach(b=>b.addEventListener('click',()=>{view=b.dataset.agOption;paintLens()}));paintLens();overlay.querySelector('#agLensQuery').focus();return true;}
 function paintLens(){if(!overlay)return;const data=matching(catalog(),'');const use=view==='pinned'?data.filter(x=>pins().includes(x.id)):view==='recent'?data.filter(x=>recents().includes(x.id)):data;const q=query.trim().toLowerCase().split(/\s+/).filter(Boolean);const rows=use.filter(x=>q.every(t=>(x.name+' '+x.desc+' '+x.group+' '+(TERMS[x.id]||'')).toLowerCase().includes(t))).slice(0,35);overlay.querySelector('#agLensResults').innerHTML=rows.map(x=>`<button type="button" data-ag-lens-open="${esc(x.id)}" class="ag-lens-entry"><span class="ag-lens-glyph">${x.id==='alien'?'✧':esc(x.icon||'◈')}</span><span><b>${esc(x.name)}</b><small>${esc(x.status)} · ${esc(x.group)}</small></span><span aria-hidden="true">↗</span></button>`).join('')||'<p>No matching destinations in this build.</p>';overlay.querySelectorAll('[data-ag-lens-open]').forEach(b=>b.addEventListener('click',()=>{const id=b.dataset.agLensOpen;if(id.startsWith('concept:')){hint='This is a concept, not an installed feature.';overlay.querySelector('#ag-lens-status').textContent=hint;return;}route(id)}));overlay.querySelectorAll('[data-ag-option]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.agOption===view)));}
 function close(){if(!overlay)return false;overlay.remove();overlay=null;lastFocus?.focus?.();return true;}
 function bindFrame(){const nav=document.querySelector('#app>.appview>.nav');if(!nav||nav.querySelector('.ag-global-open'))return;const btn=document.createElement('button');btn.type='button';btn.className='ag-global-open';btn.setAttribute('aria-label','Find any ATLAS app');btn.title='ATLAS Lens';btn.textContent='⌕';nav.insertBefore(btn,nav.lastElementChild);btn.onclick=makeLens;}
 function open(context){ctx=context;query='';filter='All';hint='';return renderGalaxy();}
 function init(context){ctx=context;return true;}
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&overlay){close();e.preventDefault();e.stopImmediatePropagation();return;}if((e.key==='k'&&(e.ctrlKey||e.metaKey)||e.key==='/'&&!['INPUT','TEXTAREA'].includes(document.activeElement?.tagName))&&!e.altKey&&!e.shiftKey&&!e.repeat&&OWNER()){e.preventDefault();makeLens();}});
 window.ATLASExperience=Object.freeze({open,init,bindFrame,lens:makeLens,close,back:()=>!!overlay&&close(),track,apps:catalog,pins,recents});
})();
