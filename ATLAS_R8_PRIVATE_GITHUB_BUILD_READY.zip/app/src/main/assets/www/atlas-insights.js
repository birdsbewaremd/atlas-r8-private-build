/* Owner-controlled, local device insights. No input text, keys or clipboard data are read. */
(()=>{'use strict';
const METRICS_KEY='activityMetrics',PREVIEW_KEY='atlas.activity.preview.v1',MAX_DAYS=31,MAX_COUNT=10000000;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const number=v=>typeof v==='number'&&Number.isFinite(v);
const json=(raw,fallback={status:'unavailable'})=>{try{const v=typeof raw==='string'?JSON.parse(raw):raw;return v&&typeof v==='object'?v:fallback}catch{return fallback}};
const dateKey=(d=new Date())=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const count=n=>number(n)?Math.round(n).toLocaleString():'—';
const clock=t=>number(t)&&t>0?new Date(t).toLocaleTimeString([],{hour:'numeric',minute:'2-digit'}):'Unknown time';
const stamp=t=>number(t)&&t>0?new Date(t).toLocaleString([],{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}):'Time unavailable';
const duration=ms=>{if(!number(ms)||ms<0)return 'Unavailable';if(ms===0)return '0 min';if(ms<60000)return '<1 min';const m=Math.floor(ms/60000);return m>=60?`${Math.floor(m/60)}h ${m%60}m`:`${m} min`};
const bytes=n=>number(n)&&n>=0?(n>=1048576?(n/1048576).toFixed(1)+' MiB':Math.round(n/1024)+' KiB'):'Unavailable';
const icons={battery:'<rect x="4" y="7" width="15" height="10" rx="2"/><path d="M22 10v4M8 10v4m4-4v4m4-4v4"/>',usage:'<rect x="6" y="2" width="12" height="20" rx="3"/><path d="M10 18h4M10 7h4m-4 4h4"/>',typing:'<rect x="2" y="5" width="20" height="14" rx="3"/><path d="M6 9h.01M10 9h.01M14 9h.01M18 9h.01M6 12h.01M10 12h.01M14 12h.01M18 12h.01M8 15h8"/>',record:'<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/>',refresh:'<path d="M20 7v5h-5M4 17v-5h5M6 6a8 8 0 0 1 13 3M5 15a8 8 0 0 0 13 3"/>',shield:'<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"/>',bolt:'<path d="m13 2-8 12h6l-1 8 9-13h-6z"/>',play:'<path d="m9 5 10 7-10 7z"/>',pause:'<path d="M9 5v14M15 5v14"/>'};
const icon=name=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name]||icons.shield}</svg>`;
let bridge=null,env=null,view='',tab='all',viewTimer=null,suspended=null,device=null,usage=null,capture=null;
let metrics=null,revision=0,dirty=false,metricsError='',attempted=false,trackingInput=false,flushTimer=null,lastEdit=0,lastDay='',runtimePaused=false,observer=null,lifecycleQueued=false;
const native=()=>{try{return !!bridge?.available?.()}catch{return false}};
const call=(name,...args)=>{try{return bridge?.call?.(name,...args)}catch{return null}};
const supports=name=>{try{return native()&&(bridge?.has?.(name)===true||typeof window.ATLASNative?.[name]==='function')}catch{return false}};
function ownerActive(includeHidden=false){try{return (includeHidden||!document.hidden)&&sessionStorage.getItem('atlas.role')==='owner'&&(!native()||call('ownerSessionActive')===true)}catch{return false}}
const $=s=>document.querySelector('.atlasInsights '+s);
function notify(message,error=false){const node=$('#insightsNotice');if(node){node.textContent=message;node.dataset.error=String(error)}else env?.toast?.(message)}
function request(payload){return json(call('ownerRecordsRequest',JSON.stringify(payload)))}
function validMetrics(value){
 if(!value||value.schema!==1||typeof value.enabled!=='boolean'||!Array.isArray(value.days)||value.days.length>MAX_DAYS||Object.keys(value).some(k=>!['schema','enabled','days'].includes(k)))return false;
 const seen=new Set();return value.days.every(d=>{if(!d||typeof d.day!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(d.day)||dateKey(new Date(d.day+'T12:00:00'))!==d.day||seen.has(d.day)||Object.keys(d).some(k=>!['day','edits','insertions','deletions','bursts'].includes(k)))return false;seen.add(d.day);return ['edits','insertions','deletions','bursts'].every(k=>Number.isSafeInteger(d[k])&&d[k]>=0&&d[k]<=MAX_COUNT)&&d.edits===d.insertions+d.deletions&&d.bursts<=d.edits});
}
function metricError(code){return ({locked:'Unlock ATLAS to read your saved summary.',conflict:'The saved summary changed elsewhere. Counting is paused. Reload the saved summary to continue.',corrupt:'The saved summary could not be verified. Counting is paused and the record is preserved.',invalid:'The summary could not be saved within its limits. Counting is paused.',unavailable:'Storage did not confirm this operation. Counting is paused; the previous saved summary is preserved.'})[code]||'The saved summary is unavailable. Counting is paused.'}
function loadMetrics(){
 if(!ownerActive()||attempted)return !!metrics;attempted=true;let r;
 if(native())r=request({op:'read',key:METRICS_KEY});else try{r={status:'ok',revision:0,value:sessionStorage.getItem(PREVIEW_KEY)}}catch{r={status:'unavailable'}}
 if(r.status!=='ok'||!Number.isSafeInteger(r.revision)||r.revision<0){metricsError=metricError(r.status);return false}
 const next=r.value===null?{schema:1,enabled:false,days:[]}:json(r.value,null);
 if(!validMetrics(next)){metricsError=metricError('corrupt');return false}metrics=next;revision=r.revision;metricsError='';dirty=false;return true;
}
function detachInput(){if(trackingInput)document.removeEventListener('input',onInput,true);trackingInput=false;document.removeEventListener('focusout',flushOnBlur,true);clearTimeout(flushTimer);flushTimer=null;lastEdit=0;lastDay=''}
function saveMetrics(next,allowHidden=false){
 if(!ownerActive(allowHidden)||!next||metricsError)return false;
 if(!validMetrics(next)){metricsError=metricError('invalid');detachInput();return false}
 const text=JSON.stringify(next);if(new TextEncoder().encode(text).length>32768){metricsError=metricError('invalid');detachInput();return false}
 if(native()){const r=request({op:'write',key:METRICS_KEY,value:text,expectedRevision:revision});if(r.status!=='ok'||!Number.isSafeInteger(r.revision)||r.revision<=revision){metricsError=metricError(r.status);detachInput();return false}revision=r.revision}
 else try{sessionStorage.setItem(PREVIEW_KEY,text)}catch{metricsError='Preview storage could not save this summary. Counting is paused.';detachInput();return false}
 metrics=next;dirty=false;return true;
}
function flush(allowHidden=false){clearTimeout(flushTimer);flushTimer=null;if(!dirty)return true;const ok=saveMetrics(metrics,allowHidden);if(!ok&&metricsError&&view==='activity')updateTyping();return ok}
function flushOnBlur(){if(dirty)flush()}
function safeField(el){
 if(!(el instanceof HTMLTextAreaElement||el instanceof HTMLInputElement)||el.disabled||el.readOnly||!el.closest('.content'))return false;
 if(el.closest('[data-sensitive], [data-atlas-metrics="off"], .lock, .setup, .securityView, .keypad'))return false;
 const type=String(el.type||'').toLowerCase(),mode=String(el.inputMode||'').toLowerCase();
 if(['password','tel','number','email'].includes(type)||['numeric','decimal','tel'].includes(mode))return false;
 const metadata=[el.id,el.name,el.getAttribute('autocomplete'),el.getAttribute('aria-label'),el.getAttribute('placeholder')].filter(Boolean).join(' ');
 if(/password|passwd|passcode|\bpin\b|pin(?:input|code|field|\d|$|[\s_-])|one.?time|otp|recovery|secret|token|credential|security|credit|card|cvv|cvc|bank|routing|iban|ssn|social.?security/i.test(metadata))return false;
 const heading=el.closest('.appview')?.querySelector('.nav h2')?.textContent||'';
 if(/security|password|recovery|credential|\bpin\b|banking|payment/i.test(heading))return false;
 if(el instanceof HTMLTextAreaElement)return true;
 if(type!=='search')return false;
 return el.getAttribute('data-atlas-metrics-safe')==='true'||(el.id==='dailySearch'&&!!el.closest('.atlasDaily'))||(['readerQuery','featureSearch'].includes(el.id)&&!!el.closest('.atlasTransfer'));
}
function onInput(event){
 if(!event.isTrusted||!trackingInput||!metrics?.enabled||runtimePaused||metricsError)return;
 if(!ownerActive()){pause();return}if(!safeField(event.target))return;
 // Deliberately inspect only inputType. Never read value, data, key, clipboard or selection text.
 const type=typeof event.inputType==='string'?event.inputType:'';
 const kind=type.startsWith('delete')?'deletions':type.startsWith('insert')?'insertions':null;if(!kind)return;
 const now=Date.now(),today=dateKey(),cutoff=new Date();cutoff.setDate(cutoff.getDate()-MAX_DAYS+1);const oldest=dateKey(cutoff);
 metrics.days=metrics.days.filter(d=>d.day>=oldest&&d.day<=today).sort((a,b)=>a.day.localeCompare(b.day));
 let row=metrics.days.find(d=>d.day===today);if(!row){row={day:today,edits:0,insertions:0,deletions:0,bursts:0};metrics.days.push(row);metrics.days=metrics.days.slice(-MAX_DAYS)}
 if(row.edits>=MAX_COUNT)return;row.edits++;row[kind]++;if(!lastEdit||now-lastEdit>10000||today!==lastDay)row.bursts++;lastEdit=now;lastDay=today;dirty=true;
 // A fixed maximum delay bounds the unsaved batch, even during continuous input.
 if(!flushTimer)flushTimer=setTimeout(()=>flush(),2000);
}
function syncInput(){
 const permitted=ownerActive()&&!!metrics?.enabled&&!metricsError&&!runtimePaused;
 if(permitted&&!trackingInput){document.addEventListener('input',onInput,true);document.addEventListener('focusout',flushOnBlur,true);trackingInput=true}
 else if(!permitted&&trackingInput)detachInput();
}
function pause(){flush(true);detachInput();metrics=null;revision=0;dirty=false;attempted=false;metricsError=''}
function checkLifecycle(){
 lifecycleQueued=false;
 if(!ownerActive()){if(metrics||trackingInput)pause();return}
 if(!attempted)loadMetrics();syncInput();
}
function queueLifecycle(){if(lifecycleQueued)return;lifecycleQueued=true;queueMicrotask(checkLifecycle)}
function init(options={}){
 if(options.native)bridge=options.native;
 if(!observer&&document.body){observer=new MutationObserver(queueLifecycle);observer.observe(document.getElementById('app')||document.body,{childList:true,subtree:true})}
 checkLifecycle();return true;
}
function setTyping(enabled){
 if(!ownerActive())return;if(!metrics&&!loadMetrics()){updateTyping();return}
 if(!enabled){runtimePaused=true;detachInput()}
 if(metricsError){updateTyping();return}
 const next={...metrics,enabled};
 if(saveMetrics(next)){runtimePaused=!enabled;syncInput();notify(enabled?'Typing counts are on for allowed ATLAS fields. Only daily totals are saved.':'Typing counts paused. Your saved daily totals are kept.')}else notify(metricsError,true);
 updateTyping();
}
function reloadMetrics(){detachInput();metrics=null;dirty=false;revision=0;attempted=false;metricsError='';loadMetrics();syncInput();updateTyping();notify(metricsError||'Saved summary reloaded.',!!metricsError)}
function frame(title,body){
 if(!ownerActive()||!env)return false;
 env.frame(title,`<section class="atlasInsights" data-insights="${view}"><div class="insightsMode"><span class="insightsDot"></span>${native()?'OWNER VIEW · ON THIS PHONE':'BROWSER PREVIEW · THIS TAB ONLY'}</div><p id="insightsNotice" class="insightsNotice" role="status" aria-live="polite"></p>${body}<footer class="insightsFoot">${icon('shield')}<span>Owner control · ATLAS can make mistakes.</span></footer></section>`,'insightsView');
 const button=document.getElementById('back');if(button)button.onclick=back;window.ATLASUI?.setBack?.(back);return true;
}
function refreshButton(label,id){return `<button id="${id}" class="insightsIconButton" aria-label="${label}">${icon('refresh')}</button>`}
function unavailable(title,text){return `<div class="insightsEmpty"><span class="insightsEmptyIcon">${icon('shield')}</span><h3>${esc(title)}</h3><p>${esc(text)}</p></div>`}
function statusText(status,kind){return status==='locked'?'Unlock ATLAS to read this information.':status==='corrupt'?'Saved history could not be verified. It has been preserved; no empty record replaces it.':status==='blocked'?'The phone blocked this reading. Review its permissions, then refresh.':!native()?`${kind} needs the installed Android app. This preview does not invent phone readings.`:`The phone did not provide ${kind.toLowerCase()}. Try Refresh while ATLAS is unlocked.`}
function devices(){
 frame('Devices',`<header class="insightsHeader"><div><span class="insightsEyebrow">DEVICE INSIGHTS</span><h1>Your phone.<br>A clearer view.</h1><p>Live battery status and history you control.</p></div>${refreshButton('Refresh device readings','deviceRefresh')}</header><div id="deviceLive"></div><section class="insightsCard insightsHistory"><div class="insightsSectionHead"><div><span class="insightsEyebrow">MEASURED OVER TIME</span><h2>Battery history</h2></div><span id="historyBadge" class="insightsBadge">Not loaded</span></div><div id="batteryChart"></div><div id="batteryTrend"></div><p id="samplingNote" class="insightsHint"></p><button id="historyToggle" class="insightsPrimary" disabled>Loading history status</button><p class="insightsFine">Start or stop collection here. Pausing keeps the history already saved on this phone.</p></section>`);
 $('#deviceRefresh').onclick=()=>refreshDevice(true);$('#historyToggle').onclick=toggleHistory;refreshDevice();
}
function normalizeSamples(snapshot){
 if(!Array.isArray(snapshot.samples))return [];
 return snapshot.samples.slice(-2048).filter(s=>s&&number(s.atMs)&&s.atMs>0&&s.atMs<=Date.now()+300000&&number(s.level)&&s.level>=0&&s.level<=100);
}
function plugName(plug){return ({none:'Unplugged',ac:'Wall power',usb:'USB power',wireless:'Wireless power',dock:'Dock power',unknown:'Unknown connection'})[plug]||'Unavailable'}
function refreshDevice(manual=false){
 if(view!=='devices'||!ownerActive()||!$('#deviceLive'))return;
 device=native()?json(call('insightsSnapshot')):{status:'preview'};
 const ok=device.status==='ok',battery=ok&&device.battery&&typeof device.battery==='object'?device.battery:{},level=number(battery.level)&&battery.level>=0&&battery.level<=100?battery.level:null;
 const connected=['ac','usb','wireless','dock'].includes(battery.plug),chargingKnown=battery.chargingKnown!==false&&typeof battery.charging==='boolean',charging=connected&&chargingKnown&&battery.charging===true,chargeText=!chargingKnown?'Status unavailable':charging?'Charging':connected?'Power connected':battery.plug==='none'?'On battery':'Reading unavailable';
 const circumference=2*Math.PI*64;
 $('#deviceLive').innerHTML=`<section class="insightsBattery ${connected?'is-connected':''} ${charging?'is-charging':''}" aria-label="Live battery"><div class="insightsBatteryTop"><span>${icon('battery')} Live battery</span><span class="insightsBadge ${connected?'is-cyan':''}">${esc(chargeText)}</span></div><div class="insightsRingWrap"><svg class="insightsRing" viewBox="0 0 160 160" aria-hidden="true"><circle class="insightsRingTrack" cx="80" cy="80" r="64"/><circle class="insightsRingValue" cx="80" cy="80" r="64" stroke-dasharray="${circumference}" stroke-dashoffset="${circumference*(1-(level??0)/100)}"/></svg><div class="insightsBatteryNumber"><strong>${level===null?'—':Math.round(level)}${level===null?'':'<span>%</span>'}</strong><small>${connected?icon('bolt'):''}${esc(chargeText)}</small></div></div><p class="insightsReadingTime">${ok?`Read at ${esc(clock(device.atMs||Date.now()))}`:esc(statusText(device.status,'Battery readings'))}</p><dl class="insightsBatteryFacts"><div><dt>Connection</dt><dd>${esc(plugName(battery.plug))}</dd></div><div><dt>Temperature</dt><dd>${number(battery.temperatureC)?battery.temperatureC.toFixed(1)+'°C':'—'}</dd></div><div><dt>Voltage</dt><dd>${number(battery.voltageMv)?(battery.voltageMv/1000).toFixed(2)+' V':'—'}</dd></div></dl></section>`;
 const historyBlocked=ok&&['error','corrupt','unavailable','blocked'].includes(device.historyStatus),samples=ok&&!historyBlocked?normalizeSamples(device):[],tracking=ok&&!historyBlocked&&device.tracking===true;
 $('#historyBadge').textContent=historyBlocked?'History blocked':ok?(tracking?'Collecting':'Paused'):native()?'Unavailable':'Native app only';$('#historyBadge').classList.toggle('is-cyan',tracking);
 $('#batteryChart').innerHTML=historyBlocked?unavailable('Saved history could not be read.','Collection is paused and existing encrypted history is preserved. Retry after unlocking; no empty history is substituted.'):!ok?unavailable('History not available',statusText(device.status,'Battery history')):samples.length?batteryChart(samples,device.sampling||{}):unavailable(tracking?'Your history has started.':'Your history starts here.',tracking?'The first readings will appear as the phone provides them. No line is drawn before there are actual samples.':'Turn on battery history to keep a bounded record of measured levels on this phone.');
 const trend=ok&&!historyBlocked?device.trend:null;
 if(trend&&['ok','ready','observed'].includes(trend.status)&&number(trend.ratePerHour)&&number(trend.observedMinutes)&&trend.observedMinutes>0){const value=trend.ratePerHour;$('#batteryTrend').innerHTML=`<div class="insightsTrend"><span>Observed change</span><strong>${value>0?'+':value<0?'−':''}${Math.abs(value).toFixed(1)}<small> percentage points / hour</small></strong><p>Across ${Math.round(trend.observedMinutes)} observed minutes. This is a measured trend, not time remaining.</p></div>`}
 else $('#batteryTrend').innerHTML=`<div class="insightsTrend"><span>Observed change</span><strong class="insightsPending">${ok?'More continuous readings needed':'Not available'}</strong><p>${ok?'A rate appears after enough readings with a consistent power state. No remaining-life estimate is invented.':'A rate needs readable, time-stamped battery history.'}</p></div>`;
 const sampling=ok&&device.sampling?device.sampling:{};
 $('#samplingNote').textContent=typeof sampling.note==='string'?sampling.note:'Collection follows available phone readings. Blank spans in the chart mean there was a gap in observation.';
 const toggle=$('#historyToggle');toggle.disabled=!ok||historyBlocked;toggle.textContent=historyBlocked?'History unavailable':tracking?'Pause battery history':'Start battery history';toggle.classList.toggle('insightsSecondary',tracking);
 if(manual)notify(ok?'Device readings refreshed.':statusText(device.status,'Battery readings'),!ok);
}
function batteryChart(samples,sampling){
 const W=300,H=150,L=30,R=10,T=10,B=26,plotW=W-L-R,plotH=H-T-B;
 const min=Math.min(...samples.map(s=>s.atMs)),max=Math.max(...samples.map(s=>s.atMs)),span=max-min;
 const gap=(number(sampling.maxGapMinutes)?sampling.maxGapMinutes:45)*60000;
 const x=s=>L+(span?(s.atMs-min)/span:0.5)*plotW,y=s=>T+(100-s.level)/100*plotH;
 const segments=[];let segment=[],prior=null,gaps=0;
 samples.forEach(s=>{const discontinuity=prior&&(s.atMs<=prior.atMs||s.atMs-prior.atMs>gap||String(s.segment??s.session??'')!==String(prior.segment??prior.session??''));if(discontinuity){segments.push(segment);segment=[];gaps++}segment.push(s);prior=s});if(segment.length)segments.push(segment);
 const paths=segments.filter(s=>s.length>1).map(s=>`<polyline points="${s.map(p=>`${x(p).toFixed(1)},${y(p).toFixed(1)}`).join(' ')}"/>`).join('');
 const points=samples.map(s=>`<circle cx="${x(s).toFixed(1)}" cy="${y(s).toFixed(1)}" r="${samples.length>80?1.2:2.5}"><title>${esc(stamp(s.atMs))} · ${Math.round(s.level)}% · ${esc(plugName(s.plug))}</title></circle>`).join('');
 return `<figure class="insightsChart"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Battery level history: ${samples.length} actual samples, ${gaps} observation gaps. First ${Math.round(samples[0].level)} percent, latest ${Math.round(samples[samples.length-1].level)} percent."><g class="insightsChartGrid">${[0,50,100].map(n=>`<line x1="${L}" x2="${W-R}" y1="${T+(100-n)/100*plotH}" y2="${T+(100-n)/100*plotH}"/><text x="${L-7}" y="${T+(100-n)/100*plotH+3}" text-anchor="end">${n}</text>`).join('')}</g><g class="insightsChartLines">${paths}</g><g class="insightsChartDots">${points}</g></svg><figcaption><time>${esc(span>86400000?stamp(min):clock(min))}</time><time>${esc(span>86400000?stamp(max):clock(max))}</time></figcaption><p class="insightsChartKey"><span></span>${samples.length.toLocaleString()} actual ${samples.length===1?'sample':'samples'}${gaps?` · ${gaps} ${gaps===1?'gap':'gaps'}`:''} · battery %</p></figure>`;
}
function toggleHistory(){
 if(!ownerActive()||!native()||device?.status!=='ok')return;
 const enable=device.tracking!==true;call('insightsSetTracking',enable);notify(enable?'Review the phone dialog to start battery history.':'Pause requested. Saved readings are kept; the status updates when the phone confirms.');
 setTimeout(()=>{if(view==='devices')refreshDevice()},700);
}
function activity(){
 frame('Activity',`<header class="insightsHeader"><div><span class="insightsEyebrow">YOUR ACTIVITY</span><h1>Your day.<br>Your choice.</h1><p>See only what you choose to measure.</p></div><span class="insightsHeaderMark">${icon('usage')}</span></header><div class="insightsTabs" role="tablist" aria-label="Activity sections">${[['all','All'],['usage','Screen time'],['typing','Typing'],['recordings','Recordings']].map(([id,label])=>`<button id="insightsTab-${id}" role="tab" aria-selected="${tab===id}" aria-controls="activityPanels" tabindex="${tab===id?'0':'-1'}" data-tab="${id}">${label}</button>`).join('')}</div><div id="activityPanels" role="tabpanel" aria-labelledby="insightsTab-${tab}" tabindex="0"><section class="insightsCard" data-panel="usage"><div class="insightsSectionHead"><div class="insightsSectionLabel"><span class="insightsSectionIcon">${icon('usage')}</span><h2>Screen time</h2></div><span class="insightsBadge">On request</span></div><div id="usageBody"></div><button id="usageLoad" class="insightsPrimary" ${native()?'':'disabled'}>Load today's usage</button><div id="usageSettingsArea"></div><p class="insightsFine">A one-time Android foreground estimate. App names and durations stay in this view and clear when you leave or lock ATLAS.</p></section><section class="insightsCard" data-panel="typing"><div class="insightsSectionHead"><div class="insightsSectionLabel"><span class="insightsSectionIcon is-purple">${icon('typing')}</span><h2>Typing in ATLAS</h2></div><span id="typingBadge" class="insightsBadge">Off</span></div><div id="typingBody"></div><div id="typingActions"></div><details class="insightsDetails"><summary>What these counts mean</summary><p>Only totals for input edits, deletion actions and typing bursts in allowed ATLAS text fields are counted. A new burst starts after 10 seconds without an edit. One edit is an input event; it is not a word or character count.</p><p>The tracker never reads or saves field text, character keys, clipboard contents, passwords, PINs or one-time codes. Security screens and numeric, phone, password and email inputs are excluded. It does not observe typing in other apps.</p><p>${native()?'Daily totals are saved to encrypted owner records on this phone.':'Preview totals use this tab’s session storage, without native encryption.'} Up to 31 days are retained. Counting pauses while ATLAS is hidden or locked and follows your saved preference after owner unlock.</p></details></section><section class="insightsCard insightsCaptureCard" data-panel="recordings"><div class="insightsSectionHead"><div class="insightsSectionLabel"><span class="insightsSectionIcon is-rose">${icon('record')}</span><h2>Screen sessions</h2></div><span id="captureBadge" class="insightsBadge">Opt-in</span></div><div id="captureBody"></div><div id="captureActions"></div><p class="insightsFine">Android asks you to choose what to capture. A visible session stops on lock, after 10 minutes or at 100 MiB. No audio is recorded. Start each session yourself.</p><div id="captureList"></div></section></div>`);
 document.querySelectorAll('.atlasInsights [data-tab]').forEach(button=>{button.onclick=()=>selectTab(button.dataset.tab);button.onkeydown=event=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;event.preventDefault();const ids=['all','usage','typing','recordings'],index=ids.indexOf(tab),next=event.key==='Home'?0:event.key==='End'?3:(index+(event.key==='ArrowRight'?1:3))%4;selectTab(ids[next]);$('#insightsTab-'+ids[next])?.focus()}});
 $('#usageLoad').onclick=loadUsage;drawUsage();updateTyping();refreshCapture();selectTab(tab);
}
function selectTab(next){
 if(!['all','usage','typing','recordings'].includes(next))return;tab=next;
 document.querySelectorAll('.atlasInsights [data-tab]').forEach(button=>{const chosen=button.dataset.tab===tab;button.setAttribute('aria-selected',String(chosen));button.tabIndex=chosen?0:-1});
 document.querySelectorAll('.atlasInsights [data-panel]').forEach(panel=>panel.hidden=tab!=='all'&&panel.dataset.panel!==tab);
 $('#activityPanels')?.setAttribute('aria-labelledby','insightsTab-'+tab);
}
function permissionRequired(result){return ['permission_required','permission_denied','denied','usage_access_required','not_granted','permission'].includes(result?.status)||result?.permissionGranted===false}
function drawUsage(){
 if(!$('#usageBody'))return;const body=$('#usageBody'),settings=$('#usageSettingsArea');settings.replaceChildren();
 if(!usage){body.innerHTML=`<div class="insightsMetricHero"><strong>—<small> today</small></strong><p>${native()?'Your app-usage report has not been read. Tap below when you want to see it.':'Phone app usage is available in the installed Android app. No device data is connected to this preview.'}</p></div>`;return}
 if(usage.status!=='ok'){
  body.innerHTML=unavailable(permissionRequired(usage)?'Usage Access is off.':'Usage is unavailable.',permissionRequired(usage)?'You can allow Android’s Usage Access for an app-name and foreground-time estimate. This is optional.':statusText(usage.status,'App usage'));
  if(permissionRequired(usage)&&native()){settings.innerHTML='<div class="insightsPermission"><p>This opens Android Settings after confirmation. If you enable ATLAS Usage Access, return here, unlock and tap Load again.</p><button id="usageSettings" class="insightsSecondary">Open Android Usage Access</button></div>';$('#usageSettings').onclick=()=>{if(!ownerActive())return;call('insightsUsageSettings');notify('Android Usage Access settings requested. Confirm before leaving ATLAS.')}}return;
 }
 const apps=Array.isArray(usage.apps)?usage.apps.filter(a=>a&&typeof a.packageName==='string'&&number(a.foregroundMs)&&a.foregroundMs>0).slice(0,200).sort((a,b)=>b.foregroundMs-a.foregroundMs):[];
 const total=number(usage.totalForegroundMs)&&usage.totalForegroundMs>=0?usage.totalForegroundMs:apps.reduce((sum,a)=>sum+a.foregroundMs,0);
 const from=usage.fromAtMs??usage.startMs??usage.range?.fromAtMs,to=usage.toAtMs??usage.endMs??usage.atMs;
 body.innerHTML=`<div class="insightsMetricHero"><strong>${esc(duration(total))}</strong><p>Estimated foreground time today${number(from)?` · from ${esc(clock(from))}`:''}</p><span class="insightsReadStamp">Read at ${esc(clock(to||Date.now()))} · ${apps.length} ${apps.length===1?'app':'apps'}</span></div>${apps.length?`<ol class="insightsUsageList">${apps.map(a=>{const label=typeof a.label==='string'&&a.label.trim()?a.label:a.packageName;return `<li><div class="insightsAppInitial" aria-hidden="true">${esc(Array.from(label.trim())[0]||'·')}</div><div class="insightsAppDetail"><div><b>${esc(label)}</b><span>${esc(duration(a.foregroundMs))}</span></div><small>${esc(a.packageName)}</small><div class="insightsUsageBar" aria-hidden="true"><i style="width:${Math.max(0,Math.min(100,total>0?a.foregroundMs/total*100:0)).toFixed(2)}%"></i></div></div></li>`}).join('')}</ol>`:unavailable('No foreground time returned.','Android returned no readable foreground intervals for today. This does not prove the phone was unused.')}<p class="insightsHint">Android event availability and overlapping app activity can affect these estimates. This report does not read app screens, messages or logins.</p>`;
 $('#usageLoad').textContent="Reload today's usage";
}
function loadUsage(){
 if(!native()||!ownerActive()||view!=='activity')return;
 usage=json(call('insightsUsageToday'));drawUsage();notify(usage.status==='ok'?'Today’s usage loaded for this view.':permissionRequired(usage)?'Usage Access has not been granted. You can keep it off.':'Usage could not be read.',usage.status!=='ok'&&!permissionRequired(usage));
}
function updateTyping(){
 if(!$('#typingBody'))return;if(!attempted&&ownerActive())loadMetrics();
 const running=!!metrics?.enabled&&!runtimePaused&&!metricsError&&trackingInput;
 $('#typingBadge').textContent=metricsError?'Paused':running?'Counting':'Off';$('#typingBadge').classList.toggle('is-cyan',running);
 if(!metrics||metricsError){$('#typingBody').innerHTML=unavailable('Saved summary unavailable.',metricsError||'Unlock ATLAS to read this summary.');$('#typingActions').innerHTML='<button id="typingReload" class="insightsSecondary">Reload saved summary</button>';$('#typingReload').onclick=reloadMetrics;return}
 const today=metrics.days.find(d=>d.day===dateKey()),days=metrics.days.slice().sort((a,b)=>b.day.localeCompare(a.day)).slice(0,7);
 $('#typingBody').innerHTML=`<p class="insightsCardIntro">${running?'Counting only allowed inputs while you use ATLAS.':metrics.days.length?'Your saved totals are kept. Turn counts on when you choose.':'Optional daily totals for your typing inside ATLAS.'}</p><dl class="insightsTypingStats"><div><dt>Input edits</dt><dd>${today?count(today.edits):'—'}</dd></div><div><dt>Bursts</dt><dd>${today?count(today.bursts):'—'}</dd></div><div><dt>Deletions</dt><dd>${today?count(today.deletions):'—'}</dd></div></dl><p class="insightsHint">${today?'Today · totals since you enabled counting.':'No input edits have been collected today.'} ${native()?'Encrypted on this phone.':'Preview · this tab session only.'}</p>${days.length?`<details class="insightsDetails insightsDayHistory"><summary>Recent daily totals</summary><div class="insightsTableWrap"><table><caption>Up to 7 most recent collected days</caption><thead><tr><th scope="col">Day</th><th scope="col">Edits</th><th scope="col">Bursts</th><th scope="col">Deletes</th></tr></thead><tbody>${days.map(d=>`<tr><th scope="row">${esc(new Date(d.day+'T12:00:00').toLocaleDateString([],{month:'short',day:'numeric'}))}</th><td>${count(d.edits)}</td><td>${count(d.bursts)}</td><td>${count(d.deletions)}</td></tr>`).join('')}</tbody></table></div></details>`:''}`;
 $('#typingActions').innerHTML=`<button id="typingToggle" class="${running?'insightsSecondary':'insightsPrimary'}">${running?'Pause typing counts':metrics.days.length?'Resume typing counts':'Turn on typing counts'}</button>`;
 $('#typingToggle').onclick=()=>setTyping(!running);
}
function refreshCapture(){
 if(view!=='activity'||!ownerActive()||!$('#captureBody'))return;
 const next=native()?json(call('captureStatus')):{status:'preview'};
 // Refresh only this read-only section; never replace the page or an input field.
 if(capture&&JSON.stringify(capture)===JSON.stringify(next))return;capture=next;
 const focusId=document.activeElement?.id?.startsWith('capture')?document.activeElement.id:null;
 const running=next.running===true||next.state==='running',known=['running','stopped','error'].includes(next.state)&&['idle','preparing','recording','finalizing'].includes(next.phase)&&typeof next.busy==='boolean',pending=next.busy===true||['starting','consent','pending','requesting','preparing','finalizing'].includes(next.phase),historyOK=next.historyStatus==='ok',historyBlocked=next.historyStatus==='error';
 const retry=known&&next.state==='error'&&next.busy===false&&next.phase==='idle'&&historyOK,canStart=known&&!pending&&next.phase==='idle'&&historyOK&&(next.state==='stopped'||retry);
 $('#captureBadge').textContent=running?'Recording':next.phase==='finalizing'?'Saving':pending?'Preparing':retry?'Needs attention':canStart?'Ready':native()?'Unavailable':'Native app only';$('#captureBadge').classList.toggle('is-recording',running);
 const message=typeof next.message==='string'&&next.message?next.message:'';
 $('#captureBody').innerHTML=running?`<div class="insightsRecordingLive"><div class="insightsRecordingDot"></div><div><strong>Recording now</strong><p>${number(next.remainingDurationMs)?duration(next.remainingDurationMs)+' remaining':'Session active'}${number(next.remainingBytes)?' · '+bytes(next.remainingBytes)+' available':''}</p></div></div>`:known?`<div class="insightsMetricHero insightsCaptureIntro"><strong>${icon('record')}</strong><h3>${next.phase==='finalizing'?'Saving your session.':pending?'Preparing your session.':retry?'The last session did not complete.':'Keep a visible screen session.'}</h3><p>${esc(message||'Start a session when there is something you want to keep. Android asks for permission every time.')}</p></div>`:unavailable('Screen capture is not connected.',native()?statusText(next.status,'Screen recording'):'Use the installed Android app to start an explicitly approved screen session.');
 $('#captureActions').innerHTML=running?'<button id="captureStop" class="insightsStop">Stop screen session</button>':`<button id="captureStart" class="insightsPrimary" ${!native()||!canStart?'disabled':''}>${next.phase==='finalizing'?'Saving session':pending?'Preparing session':retry?'Try a new session':'Start screen session'}</button>${native()&&(!known||historyBlocked)?'<button id="captureStatusRefresh" class="insightsSecondary">Refresh session status</button>':''}`;
 if($('#captureStop'))$('#captureStop').onclick=()=>{if(!ownerActive())return;call('captureStop');notify('Stop requested. The session status will update when the phone confirms it.');setTimeout(refreshCapture,400)};
 if($('#captureStart'))$('#captureStart').onclick=()=>{if(!ownerActive())return;call('captureStart');notify('Choose the screen to share in Android’s confirmation. The session has not started until Android confirms it.');setTimeout(refreshCapture,500)};
 const recordings=historyOK&&Array.isArray(next.recordings)?next.recordings.filter(r=>r&&typeof r.id==='string'&&r.id.length<=200&&number(r.createdAtMs)&&number(r.durationMs)&&number(r.bytes)).slice(0,100):[];
 $('#captureList').innerHTML=historyBlocked?`<div class="insightsSavedHeading"><h3>Saved sessions</h3><button id="captureRefresh" class="insightsTextButton">Refresh</button></div>${unavailable('Saved sessions could not be read.',typeof next.historyMessage==='string'?next.historyMessage:'Existing recordings are preserved. Their history could not be verified; this is not an empty library.')}`:historyOK?`<div class="insightsSavedHeading"><h3>Saved sessions</h3><button id="captureRefresh" class="insightsTextButton">Refresh</button></div>${recordings.length?`<ol class="insightsRecordingList">${recordings.map(r=>`<li><div><b>${esc(stamp(r.createdAtMs))}</b><small>${esc(duration(r.durationMs))} · ${esc(bytes(r.bytes))} · no audio</small></div><div class="insightsClipActions"><button data-recording-id="${esc(r.id)}" class="insightsPlay" aria-label="Play screen session from ${esc(stamp(r.createdAtMs))}">${icon('play')}</button>${supports('captureDelete')?`<button data-delete-recording="${esc(r.id)}" class="insightsTextButton" aria-label="Remove screen session from ${esc(stamp(r.createdAtMs))}">Remove</button>`:''}</div></li>`).join('')}</ol>`:'<p class="insightsHint">No saved screen sessions were returned.</p>'}`:'';
 if(historyOK&&number(next.unreadableCount)&&next.unreadableCount>0)$('#captureList').insertAdjacentHTML('beforeend',`<p class="insightsHint">${count(next.unreadableCount)} saved ${next.unreadableCount===1?'file could':'files could'} not be verified and ${next.unreadableCount===1?'is':'are'} preserved. This is not an empty recording archive.</p>`);
 if(number(next.archiveBytes)&&number(next.archiveLimitBytes))$('#captureList').insertAdjacentHTML('beforeend',`<p class="insightsHint">Recording storage: ${esc(bytes(next.archiveBytes))} / ${esc(bytes(next.archiveLimitBytes))}. Existing clips are not automatically removed.</p>`);
 if($('#captureRefresh'))$('#captureRefresh').onclick=()=>{capture=null;refreshCapture()};
 if($('#captureStatusRefresh'))$('#captureStatusRefresh').onclick=()=>{capture=null;refreshCapture()};
 document.querySelectorAll('.atlasInsights [data-recording-id]').forEach(button=>button.onclick=()=>{if(!ownerActive())return;call('capturePlay',button.dataset.recordingId);notify('Playback requested for the selected saved session.')});
 document.querySelectorAll('.atlasInsights [data-delete-recording]').forEach(button=>button.onclick=()=>{if(!ownerActive())return;call('captureDelete',button.dataset.deleteRecording);notify('Review the phone confirmation to remove only the selected screen session.');setTimeout(()=>{capture=null;refreshCapture()},700)});
 if(focusId)$('#'+focusId)?.focus({preventScroll:true});
}
function startViewTimer(){clearInterval(viewTimer);viewTimer=setInterval(()=>{if(!ownerActive()){dispose();return}if(view==='devices')refreshDevice();else if(view==='activity')refreshCapture()},view==='devices'?15000:5000)}
function dispose(){clearInterval(viewTimer);viewTimer=null;env=null;view='';device=null;usage=null;capture=null;tab='all'}
function back(){if(!env)return false;const home=env.home;dispose();home?.();return true}
function open(kind,options){
 if(!['devices','activity'].includes(kind))return false;dispose();env=options;view=kind;suspended=null;init({native:options.native});
 if(!ownerActive()){options.toast?.('Unlock ATLAS owner access first.');dispose();return false}
 if(kind==='devices')devices();else activity();startViewTimer();return true;
}
window.addEventListener('atlas-insights-updated',()=>{if(view==='devices')refreshDevice();else if(view==='activity')refreshCapture()});
window.addEventListener('atlas-capture-updated',()=>{if(view==='activity'){capture=null;refreshCapture()}});
window.addEventListener('atlas-owner-unlocked',checkLifecycle);
window.addEventListener('atlas-owner-locked',()=>{suspended=null;pause();const shell=document.querySelector('.atlasInsights');if(shell)shell.replaceChildren();dispose()});
document.addEventListener('visibilitychange',()=>{
 if(document.hidden){pause();if(env&&view){suspended={kind:view,options:env};const shell=document.querySelector('.atlasInsights');if(shell){shell.replaceChildren();const p=document.createElement('p');p.className='insightsHint';p.textContent='This private view is paused while ATLAS is hidden.';shell.appendChild(p)}dispose()}}
 else{checkLifecycle();const previous=suspended;suspended=null;if(previous&&document.querySelector('.atlasInsights')&&ownerActive())open(previous.kind,previous.options)}
});
window.ATLASInsights=Object.freeze({init,open,back,dispose,pause});
})();
