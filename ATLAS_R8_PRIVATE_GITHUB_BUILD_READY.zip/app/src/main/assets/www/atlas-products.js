window.ATLAS_PRODUCTS = [
  {
    "id": "one-founder",
    "title": "ATLAS ONE · Founder",
    "category": "Devices",
    "description": "Original front, rear and side design study with the blue action key and proposed rear display. The gallery also preserves the physical-controls study. Hardware remains unbuilt. Additional recovered gallery boards preserve earlier ATLAS ONE industrial designs and human-use concepts; their differences are design iterations, not configurable manufactured hardware.",
    "images": [
      "./assets/products/one-founder.webp",
      "./assets/products/one-controls.webp",
      "./assets/products/recovered/one-perspective.webp",
      "./assets/products/recovered/one-standard.webp",
      "./assets/products/recovered/one-future.webp",
      "./assets/products/recovered/one-human.webp"
    ],
    "status": "concept",
    "variants": [
      "Original concept"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Original concept artwork. Prices, dates, performance and readiness statements printed inside earlier art are historical proposals, not verified specifications or current offers."
  },
  {
    "id": "one-public",
    "title": "ATLAS ONE · Public",
    "category": "Devices",
    "description": "Recovered public-edition concept, preserved as a separate design version. Its old $599 target is unvalidated and is not used as a cart price.",
    "images": [
      "./assets/products/one-public.webp"
    ],
    "status": "concept",
    "variants": [
      "Original concept"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Original concept artwork. Prices, dates, performance and readiness statements printed inside earlier art are historical proposals, not verified specifications or current offers."
  },
  {
    "id": "one-government",
    "title": "ATLAS ONE · Government",
    "category": "Devices",
    "description": "Recovered agency-oriented concept. No government approval, certification or security qualification is established. Its old $1,799 target is not a current quote.",
    "images": [
      "./assets/products/one-government.webp"
    ],
    "status": "concept",
    "variants": [
      "Original concept"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Original concept artwork. Prices, dates, performance and readiness statements printed inside earlier art are historical proposals, not verified specifications or current offers."
  },
  {
    "id": "apex-s",
    "title": "ATLAS APEX S",
    "category": "Devices",
    "description": "Rugged, portless handset proposal with depth and thermal sensor goals. The recovered blueprint is a design reference; components and performance have not been validated.",
    "images": [
      "./assets/products/apex-s.webp"
    ],
    "status": "concept",
    "variants": [
      "Original concept"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Original concept artwork. Prices, dates, performance and readiness statements printed inside earlier art are historical proposals, not verified specifications or current offers."
  },
  {
    "id": "gt-e",
    "title": "ATLAS GT-E",
    "category": "Vehicles",
    "description": "Original electric hypercar design study in deep violet, including front, rear and cockpit views. No running vehicle, production specification or sale price is claimed.",
    "images": [
      "./assets/products/gt-e.webp"
    ],
    "status": "concept",
    "variants": [
      "Violet design study"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "contentId": "gt-e",
    "artNotice": "Original concept artwork. Prices, dates, performance and readiness statements printed inside earlier art are historical proposals, not verified specifications or current offers."
  },
  {
    "id": "atlas-robot",
    "title": "ATLAS Robot",
    "category": "Robotics",
    "description": "Recovered robotics-lab concept for an owner-directed assistant body. The artwork represents the vision; this phone app has not connected to or controlled a physical robot.",
    "images": [
      "./assets/products/robot.webp"
    ],
    "status": "concept",
    "variants": [
      "Original concept"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Original concept artwork. Prices, dates, performance and readiness statements printed inside earlier art are historical proposals, not verified specifications or current offers."
  },
  {
    "id": "body-system",
    "title": "ATLAS Body System",
    "category": "Clothing",
    "description": "The original technology-apparel family: ZERO base layer, SHIELD protection modules, CLIMATE weather concepts and NEURAL optional sensing. Preserved adult full-body design boards include front, side and back studies. This is distinct from SHIFTWEAVE technical outerwear. Materials and functions remain untested.",
    "images": [
      "./assets/products/body-system.webp",
      "./assets/products/exoskin.webp",
      "./assets/products/recovered/canonical-seven.webp"
    ],
    "status": "concept",
    "variants": [
      "ZERO concept",
      "SHIELD concept",
      "CLIMATE concept",
      "NEURAL concept"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Original concept artwork. Prices, dates, performance and readiness statements printed inside earlier art are historical proposals, not verified specifications or current offers."
  },
  {
    "id": "ecosystem",
    "title": "ATLAS accessories",
    "category": "Accessories",
    "description": "Recovered ecosystem board includes glasses, earbuds, ring, pendant, dock and modular accessories. Each selection refers to the shared original board; separate variant photography has not been recovered.",
    "images": [
      "./assets/products/ecosystem.webp",
      "./assets/products/recovered/ecosystem-reference.webp"
    ],
    "status": "concept",
    "variants": [
      "Glasses concept",
      "Earbuds concept",
      "Ring concept",
      "Pendant concept",
      "Dock concept"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Original concept artwork. Prices, dates, performance and readiness statements printed inside earlier art are historical proposals, not verified specifications or current offers."
  },
  {
    "id": "quiet-pod",
    "title": "ATLAS Quiet Pod",
    "category": "Accessories",
    "description": "Preserved CAD enclosure preview for the Quiet Pod project. A model image is available; physical fabrication, fit and electronics remain unverified.",
    "images": [
      "./assets/products/quiet-pod.webp"
    ],
    "status": "concept",
    "variants": [
      "Original concept"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Original concept artwork. Prices, dates, performance and readiness statements printed inside earlier art are historical proposals, not verified specifications or current offers."
  },
  {
    "id": "mobile-tech-lab",
    "title": "ATLAS Mobile Tech Lab",
    "category": "Tools",
    "description": "Recovered modular-parts CAD preview for the portable tool and electronics workspace. Treat as a prototype design, pending print, fit and field tests.",
    "images": [
      "./assets/products/tech-lab.webp"
    ],
    "status": "concept",
    "variants": [
      "Original concept"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Original concept artwork. Prices, dates, performance and readiness statements printed inside earlier art are historical proposals, not verified specifications or current offers."
  },
  {
    "id": "birds-beware",
    "title": "Birds Beware services",
    "category": "Services",
    "description": "Your exterior-services brand, with its recovered original logo. Window cleaning, washing, landscaping and cleanup are represented in the artwork. Prepare a local service plan; availability and any job quote require your review.",
    "images": [
      "./assets/products/birds-beware.webp"
    ],
    "status": "service planning",
    "variants": [
      "Window cleaning",
      "Exterior washing",
      "Landscaping",
      "Cleanup"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Recovered brand artwork. No job booking is transmitted by this prototype."
  },
  {
    "id": "hampton-legacy",
    "title": "Hampton Legacy",
    "category": "Projects",
    "description": "Recovered luxury brand board for the wider business, people and innovation project. This is a project reference, not equity, an investment offer or a manufactured item.",
    "images": [
      "./assets/products/hampton-legacy.webp"
    ],
    "status": "project reference",
    "variants": [
      "Original concept"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Recovered brand board. Contact and promotional text inside original artwork has not been reverified."
  },
  {
    "id": "future-finder",
    "title": "ATLAS Future Finder",
    "category": "Digital",
    "description": "Offline research and scenario-planning project. Preserved modules are already in this build; projections are scenarios, not predictions or time travel.",
    "images": [
      "./assets/products/future-finder.webp"
    ],
    "status": "prototype",
    "variants": [
      "Offline research prototype"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "contentId": "feature-record",
    "artNotice": "Recovered interface image; screen depicts a labelled simulation."
  },
  {
    "id": "echo-divide",
    "title": "ATLAS · Echo Divide",
    "category": "Books",
    "description": "Original science-fiction manuscript through Chapter 13, recovered as an editable draft. Read the actual bundled text offline. It is distinct from the Living Codex religious/philosophical project.",
    "images": [
      "./assets/products/echo-divide.svg"
    ],
    "status": "manuscript draft",
    "variants": [
      "Book One draft"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "contentId": "echo-divide",
    "artNotice": "New typography-only title card. The manuscript is recovered original text."
  },
  {
    "id": "living-codex",
    "title": "ATLAS Living Codex",
    "category": "Books",
    "description": "Your original religion and philosophy writing project. The recovered phone feature record retains this goal. A complete canonical Living Codex manuscript was not available in this source set.",
    "images": [
      "./assets/products/living-codex.svg"
    ],
    "status": "writing project",
    "variants": [
      "Living document project"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "contentId": "feature-record",
    "artNotice": "Typography-only project card. No complete manuscript is implied."
  },
  {
    "id": "shiftweave",
    "title": "ATLAS SHIFTWEAVE",
    "category": "Clothing",
    "description": "Repairable technical outerwear with modular pockets, tailored seams and an optional removable sensor puck. FIELD, GUARD, SENSE and ADAPT remain proposed subsystems. Shared original boards preserve the black technical garment and believable textile direction.",
    "images": [
      "./assets/products/recovered/systems-board.webp",
      "./assets/products/recovered/canonical-seven.webp"
    ],
    "status": "concept",
    "variants": [
      "FIELD concept",
      "GUARD concept",
      "SENSE concept",
      "ADAPT concept"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Shared recovered concept board. The collection card focuses on this project’s panel; the gallery preserves the complete original. Printed capabilities and performance are design proposals, not measured results. No manufacturing, stock or sale price is established.",
    "cardCrop": {
      "source": "./assets/products/recovered/systems-board.webp",
      "x": 0,
      "y": 0,
      "w": 37.8,
      "h": 54.2,
      "aspect": 1.115
    }
  },
  {
    "id": "atlas-core",
    "title": "ATLAS CORE",
    "category": "Devices",
    "description": "Owner-directed phone and Quiet Pod concept, with dark cyan controls, a physical input accessory and a clear Stop action. The historical hardware concept is separate from this app’s tested functions. No ATLAS phone or pod has been fabricated or certified.",
    "images": [
      "./assets/products/recovered/systems-board.webp",
      "./assets/products/recovered/canonical-seven.webp"
    ],
    "status": "concept",
    "variants": [
      "PHONE concept",
      "QUIET POD concept",
      "OWNER UI concept"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Shared recovered concept board. The collection card focuses on this project’s panel; the gallery preserves the complete original. Printed capabilities and performance are design proposals, not measured results. No manufacturing, stock or sale price is established.",
    "cardCrop": {
      "source": "./assets/products/recovered/systems-board.webp",
      "x": 37.8,
      "y": 0,
      "w": 32.8,
      "h": 54.2,
      "aspect": 0.967
    }
  },
  {
    "id": "atlas-vision",
    "title": "ATLAS VISION",
    "category": "Accessories",
    "description": "Assistive eyewear research concept for real-world scene cues. The shared original panel preserves human-scale glasses and minimal overlays. Recognition confidence, translation, optics, battery and weight shown in the art have not been validated.",
    "images": [
      "./assets/products/recovered/canonical-seven.webp"
    ],
    "status": "concept",
    "variants": [
      "OPTICS concept",
      "PERCEPTION concept",
      "PRIVACY concept"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Shared recovered concept board. The collection card focuses on this project’s panel; the gallery preserves the complete original. Printed capabilities and performance are design proposals, not measured results. No manufacturing, stock or sale price is established.",
    "cardCrop": {
      "source": "./assets/products/recovered/canonical-seven.webp",
      "x": 0,
      "y": 30.8,
      "w": 53.0,
      "h": 20.5,
      "aspect": 1.455
    }
  },
  {
    "id": "computational-brain",
    "title": "ATLAS Computational Brain",
    "category": "Digital",
    "description": "The second-brain architecture project: input, permission rules, model, memory, evidence and output. Original glowing-brain imagery is an artistic metaphor. This collection does not imply that a live model, private model weights or independent AGI are installed.",
    "images": [
      "./assets/products/recovered/systems-board.webp",
      "./assets/products/recovered/canonical-seven.webp"
    ],
    "status": "concept",
    "variants": [
      "Software architecture reference"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Shared recovered concept board. The collection card focuses on this project’s panel; the gallery preserves the complete original. Printed capabilities and performance are design proposals, not measured results. No manufacturing, stock or sale price is established.",
    "cardCrop": {
      "source": "./assets/products/recovered/systems-board.webp",
      "x": 0,
      "y": 54.2,
      "w": 47.8,
      "h": 45.8,
      "aspect": 1.668
    }
  },
  {
    "id": "atlas-life",
    "title": "ATLAS LIFE",
    "category": "Research",
    "description": "Species-by-species observation and annotation concept for animal signals and behavior. The original cat, bird, whale and insect panels describe a research direction. This is not a validated animal-language translator.",
    "images": [
      "./assets/products/recovered/systems-board.webp",
      "./assets/products/recovered/canonical-seven.webp"
    ],
    "status": "concept",
    "variants": [
      "OBSERVE concept",
      "ANNOTATE concept",
      "CONTEXT concept",
      "HYPOTHESIS concept",
      "REPLICATION concept"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Shared recovered concept board. The collection card focuses on this project’s panel; the gallery preserves the complete original. Printed capabilities and performance are design proposals, not measured results. No manufacturing, stock or sale price is established.",
    "cardCrop": {
      "source": "./assets/products/recovered/systems-board.webp",
      "x": 47.8,
      "y": 54.2,
      "w": 52.2,
      "h": 45.8,
      "aspect": 1.822
    }
  },
  {
    "id": "shaun-os-system",
    "title": "ATLAS Ecosystem / Shaun OS",
    "category": "Digital",
    "description": "One offline-first owner hub connecting projects, learning, research, media and records. This original ecosystem board records the wider design vision. Availability of each phone feature is reported separately in the current build guide.",
    "images": [
      "./assets/products/recovered/canonical-seven.webp",
      "./assets/products/recovered/one-future.webp"
    ],
    "status": "concept",
    "variants": [
      "Owner hub concept"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Shared recovered concept board. The collection card focuses on this project’s panel; the gallery preserves the complete original. Printed capabilities and performance are design proposals, not measured results. No manufacturing, stock or sale price is established.",
    "cardCrop": {
      "source": "./assets/products/recovered/canonical-seven.webp",
      "x": 0,
      "y": 72.6,
      "w": 100,
      "h": 21.9,
      "aspect": 2.57
    }
  },
  {
    "id": "ryl-01",
    "title": "ATLAS RYL-01 companion",
    "category": "Collectibles",
    "description": "Recovered character and mascot boards preserve the original drawing, colors, expressions and product applications. Plush, figurine, sticker, keychain and digital companion are design variants; these images do not establish a manufactured product or inventory.",
    "images": [
      "./assets/products/recovered/ryl-01.webp",
      "./assets/products/recovered/mascot-current.webp"
    ],
    "status": "concept",
    "variants": [
      "Plush concept",
      "Figurine concept",
      "Sticker concept",
      "Keychain concept",
      "Digital companion concept"
    ],
    "price": null,
    "priceKind": "unpriced",
    "currency": "USD",
    "artNotice": "Recovered mascot concept art and original drawing references. Proposed physical products and the digital companion are not shown as manufactured or complete software."
  }
];
