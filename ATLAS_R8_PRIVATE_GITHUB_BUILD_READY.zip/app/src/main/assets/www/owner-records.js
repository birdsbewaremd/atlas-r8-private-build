/* Encrypted native records UI. No plaintext browser persistence or network calls. */
(()=>{'use strict';
const MAX_BYTES=256*1024;
const titles={notes:'Notes',tasks:'Tasks',mailDrafts:'Mail',bookmarks:'Browser'};
const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const plain=(v,max)=>typeof v==='string'&&v.length<=max;
const id=()=>crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);
function httpsUrl(raw){try{if(!plain(raw,2048)||/[\u0000-\u0020\u007f]/.test(raw))return null;const u=new URL(raw);return u.protocol==='https:'&&!u.username&&!u.password&&u.hostname?u.href:null}catch{return null}}
function valid(key,value){
 if(!value||typeof value!=='object'||Array.isArray(value)||value.schema!==1)return false;
 if(key==='notes')return plain(value.text,180000);
 if(!Array.isArray(value.items)||value.items.length>500)return false;
 const ids=new Set();return value.items.every(x=>{
  if(!x||!plain(x.id,100)||!x.id||ids.has(x.id))return false;ids.add(x.id);
  if(key==='tasks')return plain(x.text,2000)&&typeof x.done==='boolean';
  if(key==='mailDrafts')return plain(x.to,1000)&&plain(x.subject,1000)&&plain(x.body,180000)&&plain(x.updatedAt,50);
  return plain(x.title,240)&&!!httpsUrl(x.url);
 });
}
function mount(host,key,env){
 let alive=true,record=null,revision=0,blocked=false,currentDraft=null,dirty=false;
 const $=s=>host.querySelector(s),$$=s=>Array.from(host.querySelectorAll(s));
 const active=()=>alive&&host.isConnected&&env.isOwner();
 const locked=()=>{if(!alive)return;dispose();env.onLocked()};
 function clearForm(){host.querySelectorAll('input,textarea').forEach(x=>x.value='')}
 function dispose(){alive=false;record=null;currentDraft=null;dirty=false;clearForm();host.replaceChildren()}
 function status(text,kind='info'){const el=$('#recordStatus');if(el){el.textContent=text;el.dataset.state=kind}}
 function request(data){
  if(!active()){locked();return {status:'locked'}}
  if(!env.nativeAPI||typeof env.nativeAPI.ownerRecordsRequest!=='function')return {status:'unavailable'};
  let result;try{result=JSON.parse(env.nativeAPI.ownerRecordsRequest(JSON.stringify(data))||'{}')}catch{return {status:'unavailable'}}
  if(!active()||result.status==='locked'){locked();return {status:'locked'}}
  return result;
 }
 function failText(code){return ({locked:'Locked. Unlock ATLAS to continue.',corrupt:'Saved data could not be verified. Nothing was replaced. Keep this installation for recovery.',conflict:'This record changed elsewhere. Your edit was not saved. Keep a copy, then reopen the app screen to load the latest record.',invalid:'This change could not be accepted. Nothing was saved.',unavailable:'Encrypted storage is unavailable. Nothing was saved.'})[code]||'Storage could not confirm this operation. Nothing was saved.'}
 function errorScreen(code){
  blocked=true;record=null;
  host.innerHTML=`<div class="pageTitle"><h1>${titles[key]}</h1><p>Private records · native encrypted storage</p></div><div class="card"><b>RECORDS UNAVAILABLE</b><p id="recordStatus" role="status">${escape(failText(code))}</p><p>No empty record will overwrite saved data.</p></div>`;
 }
 function commit(next){
  if(blocked||!record||!active()){if(!active())locked();return false}
  let value;try{value=JSON.stringify(next)}catch{status('Unable to encode this change. Nothing was saved.','error');return false}
  if(!valid(key,next)||new TextEncoder().encode(value).length>MAX_BYTES){status('This record is too large or invalid. Nothing was saved. Shorten it before retrying.','error');return false}
  const response=request({op:'write',key,value,expectedRevision:revision});
  if(!alive)return false;
  if(response.status!=='ok'||!Number.isSafeInteger(response.revision)||response.revision<=revision){
   if(response.status==='conflict'||response.status==='corrupt')blocked=true;
   status(failText(response.status),'error');return false;
  }
  record=next;revision=response.revision;dirty=false;return true;
 }
 const sharedNotice='<p class="recordNotice">Saved records stay encrypted on this phone after lock. Unsaved edits clear when you leave or lock. Uninstalling, clearing app data or losing this phone can lose these records; portable backup is not yet available.</p>';
 const statusBox=()=>`<p id="recordStatus" class="recordStatus" role="status" aria-live="polite" data-state="info">${revision>0?'Loaded from encrypted phone storage.':'No saved record yet. Save changes to keep them.'}</p>`;
 function notes(){
  host.innerHTML=`<div class="pageTitle"><h1>Notes</h1><p>Private writing · saved on this phone</p></div>${sharedNotice}<label class="recordLabel" for="noteArea">Your note</label><textarea id="noteArea" class="noteArea" maxlength="180000" placeholder="Start writing…" autocomplete="off" spellcheck="false">${escape(record.text)}</textarea><div class="recordActions"><button id="noteSave" class="pill">Save note</button></div>${statusBox()}`;
  $('#noteArea').oninput=()=>{dirty=true;status('Unsaved changes — tap Save note before leaving.','unsaved')};
  $('#noteSave').onclick=()=>{const next={schema:1,text:$('#noteArea').value};if(commit(next))status('Saved encrypted on this phone.','saved')};
 }
 function tasks(message,pending=''){
  host.innerHTML=`<div class="pageTitle"><h1>Tasks</h1><p>Private tasks · saved after each change</p></div>${sharedNotice}<label class="recordLabel" for="taskin">New task</label><div class="askbox"><input id="taskin" maxlength="2000" placeholder="What is the next step?" autocomplete="off"><button id="taskadd" aria-label="Add task">＋</button></div>${statusBox()}<div class="listGroup recordList">${record.items.length?record.items.map((x,i)=>`<button class="listRow" data-ti="${i}" aria-pressed="${x.done}"><span>${x.done?'✓':'○'}</span><b class="${x.done?'recordDone':''}">${escape(x.text)}</b></button>`).join(''):'<div class="empty"><h2>No saved tasks</h2><p>Add the next move.</p></div>'}</div>`;
  if(message)status(message,'saved');
  if(pending){$('#taskin').value=pending;dirty=true;status('Task updated. New task is still unsaved — tap ＋ to add it.','unsaved')}
  $('#taskadd').onclick=()=>{const text=$('#taskin').value.trim();if(!text)return status('Write a task first.');const next={schema:1,items:[{id:id(),text,done:false},...record.items]};if(commit(next))tasks('Task saved encrypted on this phone.')};
  $('#taskin').oninput=()=>{dirty=!!$('#taskin').value;status(dirty?'Task not added yet — tap ＋ to save.':'Loaded from encrypted phone storage.',dirty?'unsaved':'info')};
  $$('[data-ti]').forEach(button=>button.onclick=()=>{const index=Number(button.dataset.ti),next={schema:1,items:record.items.map((x,i)=>i===index?{...x,done:!x.done}:{...x})};const pending=$('#taskin').value;if(commit(next))tasks('Task updated and saved.',pending)});
 }
 function draftFields(){return {to:$('#draftTo').value,subject:$('#draftSubject').value,body:$('#draftBody').value}}
 function mail(message){
  const draft=currentDraft?record.items.find(x=>x.id===currentDraft):null;
  host.innerHTML=`<div class="pageTitle"><h1>Mail</h1><p>Local drafts · mailbox disconnected</p></div><div class="card"><b>DISCONNECTED</b><p>No email account is connected. This screen saves private drafts only. It cannot read an inbox, send email, or attach files yet.</p></div>${sharedNotice}<div class="recordActions"><button id="draftNew" class="pill">New draft</button></div><label class="recordLabel" for="draftTo">To (draft only)</label><input id="draftTo" class="recordInput" maxlength="1000" autocomplete="off" inputmode="email" value="${escape(draft?.to||'')}"><label class="recordLabel" for="draftSubject">Subject</label><input id="draftSubject" class="recordInput" maxlength="1000" autocomplete="off" value="${escape(draft?.subject||'')}"><label class="recordLabel" for="draftBody">Message</label><textarea id="draftBody" class="recordText" maxlength="180000" autocomplete="off" spellcheck="false" placeholder="Write an email draft…">${escape(draft?.body||'')}</textarea><div class="recordActions"><button id="draftSave" class="pill">Save draft</button></div>${statusBox()}<h2 class="recordHeading">Saved drafts</h2><div class="listGroup recordList">${record.items.length?record.items.map((x,i)=>`<button class="listRow" data-draft="${i}"><span><b>${escape(x.subject||'Untitled draft')}</b><small>${escape(x.to||'No recipient yet')}</small></span><span>›</span></button>`).join(''):'<div class="empty">No saved drafts yet.</div>'}</div>`;
  if(message)status(message,'saved');
  ['#draftTo','#draftSubject','#draftBody'].forEach(sel=>$(sel).oninput=()=>{dirty=true;status('Unsaved draft — tap Save draft before leaving.','unsaved')});
  $('#draftNew').onclick=()=>{if(dirty)return status('Save this draft before starting another.','unsaved');currentDraft=null;mail()};
  $('#draftSave').onclick=()=>{const values=draftFields();if(!values.to.trim()&&!values.subject.trim()&&!values.body.trim())return status('Write something before saving a draft.');const draftId=currentDraft||id(),saved={id:draftId,...values,updatedAt:new Date().toISOString()},items=record.items.some(x=>x.id===draftId)?record.items.map(x=>x.id===draftId?saved:x):[saved,...record.items];if(commit({schema:1,items})){currentDraft=draftId;mail('Draft saved encrypted. No email was sent.')}};
  $$('[data-draft]').forEach(button=>button.onclick=()=>{if(dirty)return status('Save this draft before opening another.','unsaved');currentDraft=record.items[Number(button.dataset.draft)].id;mail()});
 }
 function bookmarks(message){
  host.innerHTML=`<div class="pageTitle"><h1>Browser</h1><p>Saved links · external browser or app handoff</p></div><div class="card"><b>PARTIAL</b><p>Save and search HTTPS bookmarks offline. Opening a link asks for approval in Android and uses your existing browser or a matching app. ATLAS does not yet provide web tabs, page history, downloads or an embedded web engine.</p></div>${sharedNotice}<label class="recordLabel" for="bookmarkTitle">Bookmark title</label><input id="bookmarkTitle" class="recordInput" maxlength="240" autocomplete="off" placeholder="Name this link"><label class="recordLabel" for="bookmarkUrl">HTTPS address</label><input id="bookmarkUrl" class="recordInput" maxlength="2048" type="url" autocomplete="off" placeholder="https://example.com"><div class="recordActions"><button id="bookmarkSave" class="pill">Save bookmark</button></div>${statusBox()}<label class="recordLabel" for="bookmarkSearch">Search saved links</label><input id="bookmarkSearch" class="recordInput" autocomplete="off" placeholder="Title or website"><div id="bookmarkRows" class="listGroup recordList"></div>`;
  if(message)status(message,'saved');
  function rows(){const term=$('#bookmarkSearch').value.toLowerCase().trim();$('#bookmarkRows').innerHTML=record.items.map((x,i)=>({x,i})).filter(({x})=>!term||[x.title,x.url].join(' ').toLowerCase().includes(term)).map(({x,i})=>`<div class="listRow recordBookmark"><span><b>${escape(x.title)}</b><small>${escape(x.url)}</small></span><button class="pill" data-bookmark="${i}">Open</button></div>`).join('')||'<div class="empty">No matching saved links.</div>';$$('[data-bookmark]').forEach(button=>button.onclick=()=>{if(!active())return locked();const x=record.items[Number(button.dataset.bookmark)];if(!httpsUrl(x.url))return status('This address is not a valid HTTPS bookmark.','error');if(typeof env.nativeAPI.openBookmarkedUrl!=='function')return status('Confirmed browser handoff is unavailable in this build. Nothing opened.','error');env.nativeAPI.openBookmarkedUrl(x.url);status('Requested Android confirmation. The link has not been marked as opened.','info')})}
  $('#bookmarkSearch').oninput=rows;
  ['#bookmarkTitle','#bookmarkUrl'].forEach(sel=>$(sel).oninput=()=>{dirty=true;status('Unsaved link — tap Save bookmark.','unsaved')});
  $('#bookmarkSave').onclick=()=>{const title=$('#bookmarkTitle').value.trim(),url=httpsUrl($('#bookmarkUrl').value.trim());if(!title||!url)return status('Add a title and a valid HTTPS address without a username or password.','error');if(record.items.some(x=>x.url===url))return status('That address is already saved.');if(commit({schema:1,items:[{id:id(),title,url},...record.items]}))bookmarks('Bookmark saved encrypted on this phone.')};rows();
 }
 if(!Object.hasOwn(titles,key)){errorScreen('invalid');return dispose}
 if(!active()){locked();return dispose}
 if(!env.nativeAPI||typeof env.nativeAPI.ownerRecordsRequest!=='function'){
  host.innerHTML=`<div class="pageTitle"><h1>${titles[key]}</h1><p>Native installation required</p></div><div class="card"><b>NOT CONNECTED</b><p>Encrypted private records require the updated Android app. This browser preview will not save private notes, tasks, email drafts or bookmarks in browser storage.</p></div>`;return dispose;
 }
 const loaded=request({op:'read',key});
 if(!alive)return dispose;
 if(loaded.status!=='ok'||!Number.isSafeInteger(loaded.revision)||loaded.revision<0){errorScreen(loaded.status);return dispose}
 try{record=loaded.value===null?(key==='notes'?{schema:1,text:''}:{schema:1,items:[]}):JSON.parse(loaded.value);if(!valid(key,record))throw Error('invalid record');revision=loaded.revision}catch{errorScreen('corrupt');return dispose}
 if(key==='notes')notes();else if(key==='tasks')tasks();else if(key==='mailDrafts')mail();else bookmarks();
 return dispose;
}
window.AtlasOwnerRecords=Object.freeze({mount});
})();
