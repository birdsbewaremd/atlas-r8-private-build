/* Offline transfer, source reader and owner-maintained device test record. */
(()=>{'use strict';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>crypto.randomUUID?.()||Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);
let env=null,view='',returnView='transfer',record=null,revision=0,blocked=false,filter='',category='',selected=null;
const native=()=>!!env?.native?.available();
const call=(name,...args)=>env?.native?.call(name,...args);
const active=()=>!!env&&sessionStorage.getItem('atlas.role')==='owner'&&(!native()||!!call('ownerSessionActive'));
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const safeJSON=(s,fallback)=>{try{return JSON.parse(s)}catch{return fallback}};
function notice(){return native()?'Saved test notes stay encrypted on this phone.':'Browser preview: test notes last for this tab only.'}
function status(text){let el=$('#transferStatus');if(el)el.textContent=text;else env?.toast?.(text)}
function valid(r){return r&&r.schema===1&&Array.isArray(r.items)&&r.items.length<=500&&r.items.every(x=>x&&typeof x.id==='string'&&x.id.length<160&&typeof x.kind==='string'&&typeof x.title==='string'&&x.title.length<=500&&typeof x.notes==='string'&&x.notes.length<=16000)}
function loadRecord(){
 if(record)return true;if(!active())return false;
 if(!native()){const raw=sessionStorage.getItem('atlas.lab.preview.v1');record=raw?safeJSON(raw,null):{schema:1,items:[]};if(!valid(record)){blocked=true;record=null;return false}return true}
 const r=safeJSON(call('ownerRecordsRequest',JSON.stringify({op:'read',key:'lab'}))||'{}',{});
 if(r.status==='absent'||(r.status==='ok'&&r.revision===0&&r.value===null)){record={schema:1,items:[]};revision=0;return true}
 if(r.status!=='ok'||!Number.isSafeInteger(r.revision)){blocked=true;return false}
 const d=safeJSON(r.value,null);if(!valid(d)){blocked=true;return false}record=d;revision=r.revision;return true;
}
function saveItem(item){
 if(!active()||blocked||!loadRecord()){status('Saved data could not be verified. Nothing was replaced.');return false}
 const next={schema:1,items:[...record.items.filter(x=>x.id!==item.id),item]};
 if(!valid(next)||new TextEncoder().encode(JSON.stringify(next)).length>256*1024){status('This record is full. Keep a copy of your notes before adding more.');return false}
 if(native()){
  const r=safeJSON(call('ownerRecordsRequest',JSON.stringify({op:'write',key:'lab',value:JSON.stringify(next),expectedRevision:revision}))||'{}',{});
  if(r.status!=='ok'||!Number.isSafeInteger(r.revision)||r.revision<=revision){if(['corrupt','conflict'].includes(r.status))blocked=true;status('Save not confirmed ('+(r.status||'unavailable')+'). Your previous data was preserved.');return false}revision=r.revision;
 }else{try{sessionStorage.setItem('atlas.lab.preview.v1',JSON.stringify(next))}catch{status('Preview storage is full. Nothing was saved.');return false}}
 record=next;return true;
}
function draw(title,body,cls='transferView'){
 if(!active())return false;
 env.frame(title,`<div class="transferShell atlasTransfer">${body}<p id="transferStatus" role="status" aria-live="polite"></p><p class="transferFooter">Owner control · ATLAS can make mistakes.</p></div>`,cls);
 const back=$('#back');if(back)back.onclick=()=>{if(!api.back())env?.home()};window.ATLASUI?.setBack?.(back?.onclick);return true;
}
function openRoute(id){if(window.ATLASUI?.open)window.ATLASUI.open(id);else if(id==='files')call('openAtlasOne');else status('Use Home to open '+id+'.')}
function importReport(){
 const r=safeJSON(call('importStatus')||'{}',{});
 if(!r.status||r.status==='idle')return 'No import receipt yet. Your archive has not been transferred just by installing the app.';
 if(r.status==='saved')return `Saved ${r.files||0} original files (${formatBytes(r.bytes||0)}). ${r.conversations||0} conversations, ${r.messages||0} text messages and ${r.searchFiles||0} readable chunks indexed. ${r.nonTextParts||0} non-text parts reported separately.`;
 if(r.status==='saved_raw')return `Original files saved encrypted. Search indexing is pending: ${r.reason||r.indexStatus||'review the archive format'}. Keep the original ZIP.`;
 if(r.status==='rejected')return 'Import was not completed: '+(r.reason||'see native message')+'. Existing saved data was preserved.';
 return 'Import status: '+r.status+'. Keep ATLAS open while it completes.';
}
function formatBytes(n){return n>1024*1024?(n/1024/1024).toFixed(1)+' MiB':Math.round(n/1024)+' KiB'}
function transfer(){
 view='transfer';
 const docs=window.ATLAS_DOCUMENTS||[],products=window.ATLAS_PRODUCTS||[],features=window.ATLAS_FEATURES||[];
 draw('Transfer & content',`<div class="transferIntro"><span class="transferEyebrow">YOUR WORK, TOGETHER</span><h1>Bring your history.</h1><p>${products.length} recovered projects, ${docs.length} full source documents and ${features.length} requirement entries are bundled. The original offline modules remain available.</p></div>
 <section class="transferCard"><h2>ChatGPT → ATLAS</h2><ol><li>In ChatGPT: <b>Settings → Data controls → Export Data</b>.</li><li>Download the ZIP when the export message arrives.</li><li>Tap <b>Import ChatGPT ZIP</b> below and choose that file.</li></ol><button class="transferPrimary" id="importChats">Import ChatGPT ZIP</button><p class="transferHint">Export preparation can take up to 7 days. The download link expires after 24 hours. Full account history has not been fetched by this app.</p><details><summary>What transfers and limits</summary><p>The native importer keeps supported ZIP members encrypted in the vault and creates readable text chunks from a supported conversations.json. It preserves your original ZIP. Images and builds can be retained as original files; importing them does not install or run them. Text search does not perform image OCR.</p><p>Current limits: 1 GiB unpacked per archive, 128 MiB per file and 5,000 files. Text indexing is bounded separately. Larger archives need splitting on a computer; a rejected or partially indexed archive is reported explicitly. Free phone storage is still required.</p><p>The account export may not contain every separate build or library artifact. Import your saved project ZIPs separately. Retain a backup outside the phone: device-bound encryption alone is not portable recovery.</p><p>Official guide: <span class="transferURL">https://help.openai.com/en/articles/7260999-exporting-your-chatgpt-history-and-data</span></p></details></section>
 <section class="transferCard"><h2>Files, builds and originals</h2><div class="transferActions"><button id="importZip">Import project ZIP</button><button id="importFile">Import text file</button><button id="openFiles">Open encrypted Files</button><button id="refreshImport">Refresh import status</button></div><p id="importReceipt" role="status">${esc(native()?importReport():'Archive import is available in the Android app. This browser preview cannot access its encrypted vault.')}</p></section>
 <section class="transferCard"><h2>Already on this build</h2><div class="transferDocList">${docs.map(d=>`<button data-read="${esc(d.id)}"><b>${esc(d.title)}</b><small>${esc(d.kind)}</small></button>`).join('')}</div></section>
 <section class="transferCard"><h2>Make it yours</h2><p>Settings changes your identity, wallpaper, sounds and Home layout. Shopping lets you edit your catalog and choose its images. Feature Lab keeps tests, bugs and improvement ideas.</p><div class="transferActions"><button id="customize">Customize</button><button id="testLab">Feature Lab</button></div></section>`);
 $('#importChats').onclick=()=>native()?call('importChatGPTArchive'):status('Open the installed Android app to choose and encrypt your ZIP.');
 $('#importZip').onclick=()=>native()?call('importSeedZip'):status('ZIP transfer needs the native Android vault.');
 $('#importFile').onclick=()=>native()?call('importLocalDocument'):status('Document import needs the native Android vault.');
 $('#openFiles').onclick=()=>openRoute('files');$('#refreshImport').onclick=()=>$('#importReceipt').textContent=native()?importReport():'No native vault connected.';
 $$('[data-read]').forEach(b=>b.onclick=()=>read(b.dataset.read,env,'transfer'));
 $('#customize').onclick=()=>openRoute('settings');$('#testLab').onclick=lab;
}
function read(id,environment,from){
 if(environment)env=environment;if(!active())return false;
 const d=(window.ATLAS_DOCUMENTS||[]).find(x=>x.id===id);if(!d)return false;
 returnView=from||'transfer';view='reader';
 draw(d.title,`<div class="transferReaderHead"><span class="transferEyebrow">${esc(d.kind)}</span><h1>${esc(d.title)}</h1><label>Find in this document<input id="readerQuery" type="search" placeholder="Word or phrase"></label><p id="readerFound" role="status"></p></div><div id="readerText" class="transferReader"></div><details><summary>Original and integrity</summary><p>${esc(d.filename)}</p><p class="transferHash">SHA-256 ${esc(d.sha256)}</p><p>Bundled text was recovered from this original. Original wording is retained.</p></details>`,'transferReaderView');
 $('#readerText').textContent=d.text;
 $('#readerQuery').oninput=e=>{let q=e.target.value.trim();const h=$('#readerText');h.replaceChildren();if(!q){h.textContent=d.text;$('#readerFound').textContent='';return}const original=d.text,lower=original.toLowerCase(),needle=q.toLowerCase();let pos=0,n=0,next;while((next=lower.indexOf(needle,pos))!==-1&&n<1000){h.append(document.createTextNode(original.slice(pos,next)));let m=document.createElement('mark');m.textContent=original.slice(next,next+q.length);h.append(m);pos=next+q.length;n++}h.append(document.createTextNode(original.slice(pos)));$('#readerFound').textContent=n+' matching passages'+(n===1000?' (display capped)':'');};return true;
}
function lab(){
 view='lab';selected=null;loadRecord();
 draw('Feature Lab',`<div class="transferIntro"><span class="transferEyebrow">TEST · RECORD · IMPROVE</span><h1>Your phone, under test.</h1><p>${(window.ATLAS_FEATURES||[]).length} saved requirement entries, including current additions and overlapping historical proposals. Route labels suggest a related tool. They do not certify that the full requirement works; hardware needs its own physical test.</p></div><div class="transferActions"><button id="labIssues">Bugs & ideas</button><button id="labDiagnostics">This device</button><button id="labSources">Full source record</button><button id="labRelease">What changed in 0.7.0</button></div><label>Search every recovered requirement<input id="featureSearch" type="search" placeholder="FM, voice, cooling, backup…" value="${esc(filter)}"></label><label>Section<select id="featureCategory"><option value="">All sections</option>${[...new Set((window.ATLAS_FEATURES||[]).map(f=>f.category))].map(c=>`<option${category===c?' selected':''}>${esc(c)}</option>`).join('')}</select></label><p id="featureCount" class="transferHint"></p><div id="featureList" class="featureList"></div><p class="transferHint">${esc(notice())}</p>`,'featureLabView');
 $('#featureSearch').oninput=e=>{filter=e.target.value;listFeatures()};$('#featureCategory').onchange=e=>{category=e.target.value;listFeatures()};
 $('#labIssues').onclick=issues;$('#labDiagnostics').onclick=diagnostics;$('#labSources').onclick=()=>read('feature-record',env,'lab');$('#labRelease').onclick=()=>read('release-070',env,'lab');listFeatures();
}
function listFeatures(){
 const matches=(window.ATLAS_FEATURES||[]).filter(f=>(!category||f.category===category)&&(!filter||(f.title+' '+f.detail+' '+f.category).toLowerCase().includes(filter.toLowerCase())));
 $('#featureCount').textContent=matches.length+' matching entries';
 $('#featureList').innerHTML=matches.slice(0,100).map(f=>{let t=record?.items.find(x=>x.id==='test:'+f.id);return `<button class="featureRow" data-feature="${f.id}"><span class="featureRoute">${esc(f.status)}</span><b>${esc(f.title)}</b><small>${esc(t?'Your result: '+t.result:'No phone test recorded')}</small></button>`}).join('')+(matches.length>100?'<p>Showing the first 100. Narrow the search to see other entries.</p>':'');
 $$('[data-feature]').forEach(b=>b.onclick=()=>feature(b.dataset.feature));
}
function feature(id){
 const f=(window.ATLAS_FEATURES||[]).find(x=>x.id===id);if(!f)return;view='feature';selected=f;
 const prior=record?.items.find(x=>x.id==='test:'+id);const simulation=/warm|cool|heat|temperature|thermal|lidar|sensor|radar/i.test(f.title);
 draw('Test requirement',`<span class="transferEyebrow">${esc(f.category)}</span><h1>${esc(f.title)}</h1><section class="transferCard"><b>Current route: ${esc(f.status)}</b><p>${esc(f.detail||'Recovered owner or design requirement. Read the full record for historical context.')}</p><p>Source: ${esc(f.source)}, line ${f.sourceLine}.</p>${f.target!=='lab'?'<button id="tryRoute">Open related tool</button>':''}${simulation?'<button id="trySimulation">Try display-only simulation</button>':''}</section><section class="transferCard"><h2>Record a real test</h2><p>Describe what you tried, what you expected and what you observed. Mark a pass only for the behavior you actually checked. Hardware requires the relevant physical component and measured evidence.</p><label>Result<select id="testResult">${['Not tested','Pass on my phone','Fail on my phone','Blocked'].map(x=>`<option${prior?.result===x?' selected':''}>${x}</option>`).join('')}</select></label><label>Evidence / next fix<textarea id="testNotes" rows="5" maxlength="16000" placeholder="Steps, observed result, screenshot filename, next action">${esc(prior?.notes||'')}</textarea></label><button class="transferPrimary" id="saveTest">Save test result</button><p>${esc(notice())}</p></section>`,'featureLabView');
 if($('#tryRoute'))$('#tryRoute').onclick=()=>openRoute(f.target);if($('#trySimulation'))$('#trySimulation').onclick=()=>simulate(f);
 $('#saveTest').onclick=()=>{if(saveItem({id:'test:'+id,kind:'test',title:f.title.slice(0,500),notes:$('#testNotes').value,result:$('#testResult').value,updatedAt:new Date().toISOString()}))status('Test result saved. This is your recorded evidence, not automatic certification.');};
}
function simulate(f){
 view='simulation';selected=f;draw('Display simulation',`<span class="transferEyebrow">SIMULATED INPUT</span><h1>${esc(f.title)}</h1><p>Try how a sensor value could affect the interface. This screen reads no sensor and controls no heater, cooler, radio or other hardware.</p><div class="sensorPreview" id="sensorPreview"><span>TEST VALUE</span><strong id="simValue">50</strong><span>DISPLAY ONLY</span></div><label>Simulated input<input id="simInput" type="range" min="0" max="100" value="50"></label><p>This tests interface feedback only. It cannot pass the physical-feature requirement.</p><button id="simDone">Return to test record</button>`,'featureLabView');
 $('#simInput').oninput=e=>{let v=Number(e.target.value);$('#simValue').textContent=v;$('#sensorPreview').style.setProperty('--sensor-color',`hsl(${240-v*2.4} 70% 65%)`)};$('#simDone').onclick=()=>feature(f.id);
}
function issues(){
 view='issues';loadRecord();const list=record?.items.filter(x=>x.kind==='bug'||x.kind==='idea')||[];
 draw('Bugs & improvements',`<div class="transferIntro"><span class="transferEyebrow">OWNER-DIRECTED IMPROVEMENT</span><h1>Keep the next fix.</h1><p>Change your layout and catalog in the app. Record software fixes here, then use the reviewable report for the next source update. This build does not silently rewrite, install or run new code.</p></div><section class="transferCard"><label>Type<select id="issueKind"><option value="bug">Bug / failure</option><option value="idea">Improvement idea</option></select></label><label>Title<input id="issueTitle" maxlength="300" placeholder="What needs to change?"></label><label>Steps and expected result<textarea id="issueNotes" rows="5" maxlength="16000" placeholder="Where it happened, how to repeat it, what should happen"></textarea></label><button class="transferPrimary" id="saveIssue">Save improvement</button></section><section class="transferCard"><h2>${list.length} saved items</h2>${list.map(x=>`<details><summary>${esc(x.title)}</summary><p>${esc(x.notes)}</p><small>${esc(x.updatedAt||'')}</small></details>`).join('')||'<p>Your improvement record starts empty.</p>'}<button id="makeReport">Create reviewable report</button><p>${esc(notice())}</p></section>`,'featureLabView');
 $('#saveIssue').onclick=()=>{const title=$('#issueTitle').value.trim();if(!title){status('Enter a title first.');return}if(saveItem({id:uid(),kind:$('#issueKind').value,title,notes:$('#issueNotes').value,updatedAt:new Date().toISOString()})){issues();status('Saved for the next improvement cycle.')}};$('#makeReport').onclick=report;
}
function diagnosticData(){return {app:'ATLAS Preview 0.7.0',measuredAt:new Date().toISOString(),environment:native()?'native Android bridge':'browser preview',viewport:{width:innerWidth,height:innerHeight,visualWidth:visualViewport?.width||innerWidth,visualHeight:visualViewport?.height||innerHeight,dpr:devicePixelRatio},native:native()?safeJSON(call('viewportInfo')||'{}',{}):null,device:native()?safeJSON(call('deviceStatus')||'{}',{}):null,loadedProducts:(window.ATLAS_PRODUCTS||[]).length,recoveredEntries:(window.ATLAS_FEATURES||[]).length,localAI:'No inference model bundled',portablePrivateBackup:'Not implemented; preserve installation and original archives'}}
function diagnostics(){view='diagnostics';const d=diagnosticData();draw('This build & device',`<h1>Measured here.</h1><p>This report reads viewport and available native status. It is not a phone-performance benchmark.</p><pre class="diagnosticText">${esc(JSON.stringify(d,null,2))}</pre><button id="diagRefresh">Measure again</button><button id="diagReport">Create reviewable report</button>`,'featureLabView');$('#diagRefresh').onclick=diagnostics;$('#diagReport').onclick=report;}
function report(){view='report';loadRecord();const data={diagnostics:diagnosticData(),ownerReportedTestsAndIdeas:record?.items||[],scope:'Manually reviewed report. No automatic send or update. Test claims are owner-recorded.'};draw('Review improvement report',`<h1>Ready to review.</h1><p>This text includes the test notes and ideas you chose to record. Review it before copying into a chat. Nothing is sent automatically.</p><textarea id="reviewReport" rows="18" readonly></textarea><button id="selectReport">Select report text</button>`,'featureLabView');$('#reviewReport').value=JSON.stringify(data,null,2);$('#selectReport').onclick=()=>{$('#reviewReport').focus();$('#reviewReport').select();status('Text selected. Use your phone’s Copy action.');};}
function dispose(){env=null;record=null;revision=0;blocked=false;selected=null;view='';}
const api={open(id,e){if(!['transfer','lab'].includes(id))return false;env=e;record=null;blocked=false;revision=0;if(!active())return false;id==='transfer'?transfer():lab();return true},read,back(){if(!env||!active())return false;if(view==='reader'){if(typeof env.onReaderBack==='function'){const cb=env.onReaderBack;dispose();cb();return true}returnView==='lab'?lab():transfer();return true}if(view==='simulation'&&selected){feature(selected.id);return true}if(['feature','issues','diagnostics','report'].includes(view)){lab();return true}return false},dispose};
window.ATLASTransfer=api;
window.addEventListener('atlas-import-status',()=>{if(view==='transfer'&&active()&&$('#importReceipt'))$('#importReceipt').textContent=importReport()});
window.addEventListener('atlas-owner-locked',dispose);
document.addEventListener('visibilitychange',()=>{if(document.hidden&&native())dispose()});
})();
