/* ATLAS PILOT 0.1 · owner-initiated voice, Android panels, safer Home modes.
   Uses ONLY pre-existing source-verified Android native bridge calls.
   Does not create background or accessibility privileges, recordings or account grants. */
(()=>{'use strict';
let ctx=null, active=false, voiceListener=null,commandListener=null;
const $=id=>document.getElementById(id);
const H=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const mode=()=>localStorage.getItem('atlas.home.mode')==='classic'?'apps':'universe';
const alive=()=>!!ctx && active && sessionStorage.getItem('atlas.role')==='owner' && (!ctx.native?.available?.()||ctx.native.call('ownerSessionActive')===true);
const hasNative=()=>!!ctx?.native?.available?.();
function say(message){const e=$('pilotStatus');if(e)e.textContent=message;}
const SETTINGS=[
 ['wifi','Wi-Fi','wifi'],['bluetooth','Bluetooth','bt'],['brightness','Display','display'],['volume','Volume','volume'],
 ['battery','Battery','battery'],['notifications','Notifications','notifications'],['apps','App permissions','apps'],
 ['home','Default Home','home'],['accessibility','Accessibility','accessibility']
];
const DESTS=[['atlas','Ask ATLAS','Chat and local commands'],['games','Games','Chess and original worlds'],['store','Shopping','Gear, parts and orders'],['files','My files','Open selected documents'],['stats','My stats','Character and ATLAS capability'],['camera','Camera','Visible owner-invoked camera'],['library-transfer','Import files','Selected ChatGPT archives'],['access','Access Center','Review supported permissions']];
function setMode(next){if(!alive())return say('Unlock ATLAS first.');
 if(window.ATLASModeBridge?.set?.(next))return;
 if(next==='universe')localStorage.removeItem('atlas.home.mode');else localStorage.setItem('atlas.home.mode','classic');
 ctx.home();
}
function settingsPanel(key){if(!alive())return say('Unlock ATLAS first.');if(!hasNative())return say('Requires the Android ATLAS app. This preview cannot change phone settings.');
 if(!SETTINGS.some(x=>x[0]===key))return say('Unknown settings destination.');
 const param=SETTINGS.find(x=>x[0]===key)[2];const ret=ctx.native.call('openSystemPanel',param);
 say('Requested Android '+SETTINGS.find(x=>x[0]===key)[1]+' settings. Only Android can confirm or change settings.');return ret;
}
function route(to){if(!alive())return say('Unlock ATLAS first.');
 if(!DESTS.some(x=>x[0]===to)&&!['voice','commands','settings','pilot'].includes(to))return say('This route is unavailable.');
 ctx.open(to);
}
function refresh(){if(!active||!$('pilotWakeStatus'))return;
 const state=hasNative()?ctx.native.call('heyAtlasEnabled'):null;
 $('pilotWakeStatus').textContent=!hasNative()?'NATIVE REQUIRED':state===true?'REQUESTED / ENABLED BY NATIVE':'OFF / NOT CONFIRMED';
 $('pilotNativeState').textContent=hasNative()?'ATLAS NATIVE':'BROWSER PREVIEW';
 const current=mode();document.querySelectorAll('.pilot-switch button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.pilotMode===current)));
}
function wake(on){if(!alive())return say('Unlock ATLAS first.');if(!hasNative())return say('Native Android required. This browser preview cannot activate a microphone.');
 const current=ctx.native.call('heyAtlasEnabled')===true;
 if(on&&current)return say('Native wake preference is already enabled. This is not proof of screen-off recognition.');
 if(!on&&!current){ctx.native.call('stopHeyAtlas');refresh();return say('Stop sent to native wake service.');}
 ctx.native.call(on?'startHeyAtlas':'stopHeyAtlas');
 say(on?'Hey ATLAS request sent. Android may ask for microphone permission. Service availability and screen-off behavior remain unverified.':'Wake service stop requested.');
 setTimeout(refresh,500);
}
function stop(){// STOP is allowed even as a locked user; it can only reduce sensing.
 if(hasNative())for(const m of ['stopListening','stopHeyAtlas','stopSpeaking'])ctx.native.call(m);
 say(hasNative()?'Stop requests sent for ATLAS native speech, one-shot recognition and wake. Android Voice Access is separate.':'No native listening or speech is active in this browser preview.');
 refresh();
}
function listen(){if(!alive())return say('Unlock ATLAS first.');if(!hasNative())return say('One-shot microphone recognition needs the Android ATLAS app; typed local navigation still works here.');
 say('Requesting ONE spoken command using Android speech recognition. This does not activate 24/7 recording.');ctx.native.call('listenOnce');
}
function assistant(){if(!alive())return say('Unlock ATLAS first.');if(!hasNative())return say('Android assistant role requires native ATLAS.');ctx.native.call('requestAssistantRole');say('Android Assistant role review requested. Your selection is required.');}
const EXTRA_PHONE_ACTIONS=[
  ['battery','Battery level','battery level'],
  ['torch-on','Flashlight on','turn on the flashlight'],
  ['torch-off','Flashlight off','turn off the flashlight'],
  ['volume-up','Volume +','volume up'],
  ['volume-down','Volume −','volume down']
];
function extraPhoneAction(key){
  if(!alive())return say('Unlock ATLAS first.');
  const row=EXTRA_PHONE_ACTIONS.find(x=>x[0]===key);
  if(!row)return say('Unknown control. Nothing changed.');
  if(!hasNative())return say('This action requires native ATLAS Android. Nothing changed.');
  const raw=ctx.native.call('routeTextInput',row[2]);
  let detail='';try{const parsed=JSON.parse(raw||'{}');detail=String(parsed.localResult||parsed.outcome||parsed.route||parsed.statusLine||'No verified result').slice(0,140)}catch{detail='Native result unavailable';}
  say(row[1]+' — '+detail+'. Native response; no blanket permission changed.');
}
const COMMANDS=[
 [/\b(stop|cancel)(?:\s+(?:all|listening|speech|wake))?\b/i,'stop'],
 [/\b(universe|cosmic|futuristic)\b/i,'mode:universe'],
 [/\b(classic|phone\s*style|app\s*mode|app\s*screen)\b/i,'mode:apps'],
 [/\b(wi-?fi|wireless\s+network)\b/i,'setting:wifi'],
 [/\bbluetooth\b/i,'setting:bluetooth'],
 [/\b(brightness|display)\b/i,'setting:brightness'],
 [/\bvolume\b/i,'setting:volume'],
 [/\bnotifications?\b/i,'setting:notifications'],
 [/\b(battery|power\s+saver)\b/i,'setting:battery'],
 [/\b(accessibility|voice\s+access)\b/i,'setting:accessibility'],
 [/\bpermissions?\b/i,'route:access'],
 [/\b(camera|take a photo)\b/i,'route:camera'],
 [/\b(games?|chess)\b/i,'route:games'],
 [/\b(shopping|wish\s*list|parts|orders)\b/i,'route:store'],
 [/\b(stats|levels|rpg)\b/i,'route:stats'],
 [/\b(files|archive|documents)\b/i,'route:files'],
 [/\b(import|chatgpt\s+export)\b/i,'route:library-transfer'],
 [/\b(assistant|talk|chat)\b/i,'route:atlas']
];
function classify(s){const q=String(s||'').trim().slice(0,180);if(!q)return null;
 let cleaned=q.replace(/^(?:hey\s+)?atlas\b[\s,:-]*/i,'').trim();
 if(!cleaned)return null;
 if(/\b(allow|grant|enable|give|turn\s+on)\s+(?:me\s+)?(?:all|every|everything|unrestricted|full)\b/i.test(cleaned))return 'denied';
 for(const [rx,action] of COMMANDS)if(rx.test(cleaned))return action;
 return 'unknown';
}
function run(s){if(!alive())return say('Unlock ATLAS first.');const action=classify(s);if(!action)return say('Try “Atlas, open Wi-Fi”, “Atlas, games”, or “Atlas, switch to Universe”.');
 if(action==='denied')return say('Android does not have a universal Allow All action. Review each permission in ATLAS Access Center; no access was changed.');
 if(action==='unknown')return say('No verified local shortcut matched. Open ATLAS Chat for broader requests; no device setting was changed.');
 if(action==='stop')return stop();const [kind,arg]=action.split(':');
 if(kind==='mode')return setMode(arg);if(kind==='setting')return settingsPanel(arg);if(kind==='route')return route(arg);
}
function view(){const state=hasNative()?ctx.native.call('heyAtlasEnabled'):null;
 const press=mode();return `<section class="pilot" aria-label="ATLAS Pilot voice and device controls">
 <header class="pilot-hero"><span class="pilot-kicker">ATLAS Ω · OWNER CONTROL</span><h1>One voice.<br><em>Real controls.</em></h1><p>Open apps and supported Android settings without hunting through menus. No automatic permission grants, background recording or hidden phone changes.</p><div class="pilot-signal"><span aria-hidden="true" class="pilot-dot"></span><span id="pilotNativeState">${hasNative()?'ATLAS NATIVE':'BROWSER PREVIEW'}</span><span id="pilotWakeStatus">${!hasNative()?'NATIVE REQUIRED':state?'REQUESTED / ENABLED BY NATIVE':'OFF / NOT CONFIRMED'}</span></div></header>
 <section class="pilot-main"><h2>Talk to ATLAS</h2><p>Tap once to speak. The Android recognizer decides whether voice recognition is available. Voice Access in your screenshots is a separate Google service.</p><div class="pilot-mainbuttons"><button type="button" id="pilotTalk" class="pilot-talk">◉ Talk now</button><button type="button" id="pilotStop" class="pilot-stop">■ STOP ALL ATLAS AUDIO</button></div><label for="pilotText">Or type a short local command</label><div class="pilot-input"><input type="text" maxlength="180" id="pilotText" placeholder="Atlas, open Wi-Fi" autocapitalize="none" autocomplete="off"><button id="pilotRun" type="button">Run ↗</button></div><div class="pilot-samples">${['Atlas, open Wi-Fi','Atlas, games','Atlas, classic apps','Atlas, universe'].map(s=>`<button type="button" data-pilot-example="${H(s)}">${H(s)}</button>`).join('')}</div>
 <p id="pilotStatus" role="status" aria-live="polite">Ready. No microphone or permission changed by opening this screen.</p></section>
 <section class="pilot-section"><header><h2>Change your ATLAS view</h2><small>One tap, same applications and private records</small></header><div class="pilot-switch" role="group" aria-label="ATLAS Home appearance"><button type="button" data-pilot-mode="universe" aria-pressed="${press==='universe'}">△ Universe</button><button type="button" data-pilot-mode="apps" aria-pressed="${press==='apps'}">▦ Classic apps</button></div><p class="pilot-note">This changes ATLAS's Home appearance only. To change Android's default Home app, open the Home settings below.</p></section>
 <section class="pilot-section"><header><h2>Your Android controls</h2><small>All settings open through Android itself</small></header><div class="pilot-grid">${SETTINGS.map(([id,label])=>`<button type="button" data-pilot-setting="${id}"><span class="pilot-glyph">${id==='wifi'?'⌁':id==='bluetooth'?'ᛒ':id==='home'?'⌂':id==='notifications'?'◌':'⚙'}</span><strong>${H(label)}</strong><small>Open settings ↗</small></button>`).join('')}</div></section>
 <section class="pilot-section" aria-label="Manual device quick actions"><header><h2>Device quick actions</h2><small>Reconciled from the earlier Voice Controls branch · Owner tap required</small></header><div class="pilot-row">${EXTRA_PHONE_ACTIONS.map(([id,label])=>`<button type="button" data-pilot-extra="${id}">${H(label)}</button>`).join('')}</div><p>Each action uses the existing authenticated native local command parser. The status is not proof a peripheral actually changed unless Android reports success.</p></section>
 <section class="pilot-section"><header><h2>Open an ATLAS app</h2> <section class="pilot-section"><header><h2>Open an ATLAS app</h2><small>Existing, owner-gated destinations</small></header><div class="pilot-apps">${DESTS.map(([id,label,desc])=>`<button type="button" data-pilot-open="${id}"><b>${H(label)}</b><small>${H(desc)}</small><span aria-hidden="true">↗</span></button>`).join('')}</div></section>
 <section class="pilot-section pilot-listen"><h2>Hey ATLAS · Opt-in foreground listener</h2><p>Native ATLAS currently supports an opt-in <b>“Hey Atlas”</b> phrase while its supported wake service is running. Bare “Atlas” with the screen off and reliable 24/7 operation are <b>not verified or implemented</b>.</p><div class="pilot-row"><button type="button" id="pilotWakeOn">Start Hey ATLAS</button><button type="button" id="pilotWakeOff">Stop listener</button><button type="button" id="pilotAssistant">Assistant role</button></div><p>Starting may request microphone permission. No raw ambient recording archive is enabled by this screen. Android privacy indicators and restrictions remain active.</p></section>
 <section class="pilot-section"><h2>Voice Access · Google is separate</h2><p>Your screenshots show Google Voice Access. Its accessibility shortcut is already enabled; an unassigned <b>physical activation key</b> is optional and does not control ATLAS's wake word. Google Voice Access can navigate your phone while activated.</p><div class="pilot-row"><button id="pilotVoiceHelp" type="button">Android accessibility settings ↗</button><button id="pilotAccess" type="button">Review ATLAS access</button></div></section>
 <footer class="pilot-footer">Owner control · No Allow All bypass · Stop must always be available · ATLAS can make mistakes.</footer></section>`;
}
function dispose(){if(voiceListener)window.removeEventListener('atlas-voice',voiceListener);if(commandListener)window.removeEventListener('atlas-command-result',commandListener);voiceListener=commandListener=null;active=false;ctx=null;}
function open(context){dispose();ctx=context;active=true;ctx.frame('ATLAS Pilot',view(),'atlasPilotView');
 $('pilotRun')?.addEventListener('click',()=>run($('pilotText')?.value));
 $('pilotText')?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();run($('pilotText').value)}});
 document.querySelectorAll('[data-pilot-example]').forEach(b=>b.addEventListener('click',()=>{if($('pilotText'))$('pilotText').value=b.dataset.pilotExample;run(b.dataset.pilotExample)}));
 $('pilotTalk')?.addEventListener('click',listen);$('pilotStop')?.addEventListener('click',stop);
 document.querySelectorAll('[data-pilot-mode]').forEach(b=>b.addEventListener('click',()=>setMode(b.dataset.pilotMode)));
 document.querySelectorAll('[data-pilot-extra]').forEach(b=>b.addEventListener('click',()=>extraPhoneAction(b.dataset.pilotExtra)));
 document.querySelectorAll('[data-pilot-setting]').forEach(b=>b.addEventListener('click',()=>settingsPanel(b.dataset.pilotSetting)));
 document.querySelectorAll('[data-pilot-open]').forEach(b=>b.addEventListener('click',()=>route(b.dataset.pilotOpen)));
 $('pilotWakeOn')?.addEventListener('click',()=>wake(true));$('pilotWakeOff')?.addEventListener('click',()=>wake(false));$('pilotAssistant')?.addEventListener('click',assistant);
 $('pilotVoiceHelp')?.addEventListener('click',()=>settingsPanel('accessibility'));
 $('pilotAccess')?.addEventListener('click',()=>route('access'));
 voiceListener=e=>{if(!active||!alive())return;const d=e.detail||{};say('ATLAS voice: '+String(d.state||'state unavailable')+(d.state==='RESULT'&&d.text?' · '+String(d.text).slice(0,150):''));};
 commandListener=e=>{if(!active||!alive())return;const d=e.detail||{};say('Native command result: '+String(d.outcome||d.localResult||d.statusLine||'received').slice(0,220));};
 window.addEventListener('atlas-voice',voiceListener);window.addEventListener('atlas-command-result',commandListener);
 refresh();return true;
}
window.ATLASPilot=Object.freeze({open,dispose,classify,devices:()=>SETTINGS.map(([id,label])=>({id,label}))});
})();
