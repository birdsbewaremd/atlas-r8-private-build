/* A clear owner-only route to files, response preferences and an optional AI connection. */
(() => {
  'use strict';
  const PROFILE_KEY = 'assistantProfile';
  const PREVIEW_KEY = 'atlas.assistantProfile.preview.v1';
  const PENDING_KEY = 'atlas.start.pendingImport';
  const STYLES = ['short', 'balanced', 'detailed'];
  const SYMBOLS = {
    file: '<path d="M5 3h9l5 5v13H5zM14 3v6h5M8 13h8M8 17h6"/>',
    profile: '<circle cx="12" cy="8" r="4"/><path d="M4 22v-3c0-8 16-8 16 0v3M18 5l2 2 3-4"/>',
    brain: '<path d="M12 4c-4-5-10 1-7 5-5 3-2 10 2 9 0 5 5 5 5 1V4Zm0 0c4-5 10 1 7 5 5 3 2 10-2 9 0 5-5 5-5 1M7 9l3 2m7-2-3 2M7 16l3-2m7 2-3-2"/>',
    search: '<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6"/>',
    arrow: '<path d="m9 5 7 7-7 7"/>',
    shield: '<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"/>'
  };
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const icon = name => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (SYMBOLS[name] || SYMBOLS.arrow) + '</svg>';
  let env = null, page = '', profile = null, revision = 0, blocked = '', fileDispose = null;
  let pendingBrain = false, lastBrainText = '', lastBrainMessage = '', brainDraft = '', selectedBrainFile = '', attachRecords = [];
  const $ = selector => document.querySelector('.atlasStart ' + selector);
  const native = () => !!env?.native?.available?.();
  function call(name, ...args) {
    if (!active()) return null;
    try { return env?.native?.call?.(name, ...args); } catch { return null; }
  }
  function active() {
    if (!env || document.hidden || sessionStorage.getItem('atlas.role') !== 'owner') return false;
    if (!native()) return true;
    try { return env.native.call('ownerSessionActive') === true; } catch { return false; }
  }
  function parsed(value, fallback = null) {
    if (typeof value !== 'string' || value.length > 100000) return fallback;
    try { return JSON.parse(value); } catch { return fallback; }
  }
  function validProfile(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value) || value.schema !== 1) return false;
    const exact = ['schema','displayName','responseStyle','priorities','instructions'];
    if (Object.keys(value).some(key => !exact.includes(key))) return false;
    return typeof value.displayName === 'string' && value.displayName.length <= 80 &&
      STYLES.includes(value.responseStyle) &&
      typeof value.priorities === 'string' && value.priorities.length <= 2000 &&
      typeof value.instructions === 'string' && value.instructions.length <= 4000;
  }
  function initialProfile() {
    let name = '';
    try { name = JSON.parse(localStorage.getItem('atlas.profile.owner') || '{}').name || ''; } catch {}
    return {schema:1,displayName:typeof name === 'string' ? name.slice(0,80) : '',responseStyle:'short',priorities:'',instructions:''};
  }
  function loadProfile() {
    if (!active()) return false;
    if (profile) return true;
    blocked = ''; revision = 0;
    if (!native()) {
      let raw;
      try { raw = sessionStorage.getItem(PREVIEW_KEY); } catch { blocked = 'unavailable'; return false; }
      const value = raw === null ? initialProfile() : parsed(raw);
      if (!validProfile(value)) { blocked = 'corrupt'; return false; }
      profile = value; return true;
    }
    const response = parsed(call('ownerRecordsRequest', JSON.stringify({op:'read',key:PROFILE_KEY})), {});
    if (!active()) return false;
    if (response.status === 'absent' || (response.status === 'ok' && response.revision === 0 && response.value === null)) {
      profile = initialProfile(); return true;
    }
    if (response.status !== 'ok' || !Number.isSafeInteger(response.revision) || response.revision < 0) {
      blocked = response.status || 'unavailable'; return false;
    }
    const value = parsed(response.value);
    if (!validProfile(value)) { blocked = 'corrupt'; return false; }
    profile = value; revision = response.revision; return true;
  }
  function failure(code) {
    return ({
      locked:'Unlock ATLAS to continue.',
      corrupt:'Your saved preferences could not be verified. They were kept unchanged.',
      conflict:'Your preferences changed elsewhere. This edit was not saved. Keep your text, then reopen this screen.',
      invalid:'Check the length and values before saving.',
      unavailable:'Private storage is unavailable. Nothing was saved.'
    })[code] || 'ATLAS could not confirm the save. Your previous preferences were kept.';
  }
  function notify(text, state='info') {
    const target = $('#startStatus');
    if (target) { target.textContent = text; target.dataset.state = state; }
    else env?.toast?.(text);
  }
  function clearFileSearch() {
    if (fileDispose) fileDispose();
    fileDispose = null;
  }
  function draw(title, body) {
    if (!active()) return false;
    clearFileSearch();
    env.frame(title, '<section class="atlasStart" data-start-page="' + esc(page) + '">' + body +
      '<p class="startStatus" id="startStatus" role="status" aria-live="polite"></p>' +
      '<p class="startFooter">Owner control · ATLAS can make mistakes.</p></section>', 'startView');
    const backButton = document.getElementById('back');
    if (backButton) backButton.onclick = () => { if (!back()) env?.home?.(); };
    window.ATLASUI?.setBack?.(() => { if (!back()) env?.home?.(); });
    return true;
  }
  function route(id) {
    if (active()) window.ATLASUI?.open?.(id);
  }
  function brainState() {
    if (!native()) return {status:'preview',configured:false,enabled:false,verified:false,busy:false};
    const value = parsed(call('brainStatus'), {});
    if (value.status === 'locked') return {status:'locked',configured:false,enabled:false,verified:false,busy:false};
    return {
      ...value,
      status: value.status === 'ok' ? 'ok' : 'unavailable',
      configured:value.configured === true,
      enabled:value.enabled === true,
      verified:value.verified === true,
      busy:value.busy === true
    };
  }
  function brainLabel(state) {
    if (!native()) return 'Android setup available in the app';
    if (state.status === 'locked') return 'Unlock required';
    if (state.status === 'unavailable') return 'Connection settings could not be read';
    if (state.busy || pendingBrain) return 'Request in progress';
    if (!state.configured) return 'Not connected';
    if (!state.enabled) return 'Paused · your saved connection is retained';
    return state.verified ? 'Last connection check passed' : 'Saved · needs a connection check';
  }
  function leaveBrain() {
    if (page !== 'brain') return;
    if (active() && native() && (pendingBrain || brainState().busy)) call('brainCancel');
    pendingBrain=false;lastBrainText='';lastBrainMessage='';selectedBrainFile='';attachRecords=[];
  }
  function hub() {
    leaveBrain();
    page = 'start'; loadProfile();
    const state = brainState();
    const subtitle = profile?.displayName ? 'A simpler start, ' + profile.displayName + '.' : 'Three clear steps. Your work stays yours.';
    if (!draw('My ATLAS',
      '<header class="startHero"><span class="startEyebrow">YOUR PRIVATE SECOND BRAIN</span><h1>Make ATLAS yours.</h1><p>' + esc(subtitle) + '</p></header>' +
      '<div class="startSteps">' +
      '<button class="startStep" id="startFiles"><span class="startStepIcon">' + icon('file') + '</span><span><small>01 · YOUR INFORMATION</small><b>Add my files</b><em>Bring in notes, ChatGPT history or project ZIPs.</em></span>' + icon('arrow') + '</button>' +
      '<button class="startStep" id="startProfile"><span class="startStepIcon violet">' + icon('profile') + '</span><span><small>02 · YOUR PREFERENCES</small><b>How ATLAS helps me</b><em>' + esc(blocked ? 'Saved preferences need attention.' : revision > 0 ? 'Your response style and priorities are saved.' : 'Set your priorities and preferred replies.') + '</em></span>' + icon('arrow') + '</button>' +
      '<button class="startStep" id="startBrain"><span class="startStepIcon blue">' + icon('brain') + '</span><span><small>03 · OPTIONAL ONLINE AI</small><b>Connect Atlas Brain</b><em>' + esc(brainLabel(state)) + '</em></span>' + icon('arrow') + '</button></div>' +
      '<button class="startQuiet" id="startSearch">' + icon('search') + '<span>Search my files</span></button>' +
      '<p class="startPrivacy">' + icon('shield') + '<span>Files stay on your phone. Adding a file does not upload it to an AI service.</span></p>')) return;
    $('#startFiles').onclick = files;
    $('#startProfile').onclick = preferences;
    $('#startBrain').onclick = brain;
    $('#startSearch').onclick = () => searchFiles();
  }
  function pendingImport() {
    try {
      const value = sessionStorage.getItem(PENDING_KEY);
      return ['text','chatgpt','project'].includes(value) ? value : '';
    } catch { return ''; }
  }
  function rememberImport(kind) {
    try { sessionStorage.setItem(PENDING_KEY, kind); } catch {}
  }
  function importSummary() {
    if (!native()) return 'Choose files in the installed Android app. This preview has no access to its encrypted files.';
    const report = parsed(call('importStatus'), {});
    if (!report.status || report.status === 'idle') {
      return pendingImport() ? 'After choosing a file, return and unlock ATLAS. Confirm the import, then open Search my files to check the saved result.' : 'No archive import has been recorded yet. Choose a file above to begin.';
    }
    if (report.status === 'importing') return 'ATLAS is importing your selected file. Keep it open, then check this receipt.';
    if (report.status === 'saved' && report.kind === 'document') return report.searchFiles > 0 ? 'Your last selected document was saved on this phone. Open Search my files to find and read it.' : 'Your last selected document was saved on this phone. Find it by filename; ATLAS could not confirm that it can read the text.';
    if (report.status === 'saved') {
      const files = Number.isSafeInteger(report.files) && report.files >= 0 ? report.files : 0;
      const conversations = Number.isSafeInteger(report.conversations) && report.conversations >= 0 ? report.conversations : 0;
      const chunks = Number.isSafeInteger(report.searchFiles) && report.searchFiles >= 0 ? report.searchFiles : 0;
      return 'Last archive: ' + files + ' files saved. ' + conversations + ' conversations and ' + chunks + ' readable text chunks indexed. Open Search my files to review them.';
    }
    if (report.status === 'saved_raw') return 'The last archive’s originals were saved. Its text index is not ready or fully supported. Search filenames and keep the original ZIP.';
    if (report.status === 'rejected') return 'The last file was not imported: ' + String(report.reason || 'review the Android message').slice(0,300) + '. Your previous files were kept.';
    if (report.status === 'locked') return 'Unlock ATLAS to check the import.';
    return 'Import status: ' + String(report.status).slice(0,80) + '. Keep ATLAS open while the import finishes.';
  }
  function chooseImport(kind) {
    if (!active()) return;
    if (!native()) { notify('Open the installed ATLAS app, then use Add my files to choose a file from your phone.'); return; }
    rememberImport(kind);
    notify('Android will open your files. Choose one, return and unlock ATLAS, then confirm the import.');
    const method = kind === 'text' ? 'importLocalDocument' : kind === 'chatgpt' ? 'importChatGPTArchive' : 'importSeedZip';
    call(method);
  }
  function files() {
    leaveBrain();
    page = 'files';
    if (!draw('Add my files',
      '<header class="startHero"><span class="startEyebrow">START WITH ONE FILE</span><h1>What are you adding?</h1><p>Tap a type, then choose the file in Android.</p></header>' +
      '<div class="startChoices">' +
      '<button class="startChoice" id="addText">' + icon('file') + '<span><b>A text document</b><small>Notes or information · TXT, MD, JSON or CSV</small></span>' + icon('arrow') + '</button>' +
      '<button class="startChoice" id="addChats">' + icon('brain') + '<span><b>My ChatGPT history</b><small>Choose the downloaded ChatGPT export ZIP</small></span>' + icon('arrow') + '</button>' +
      '<button class="startChoice" id="addProject">' + icon('file') + '<span><b>A project or archive</b><small>A ZIP of saved work, images or builds</small></span>' + icon('arrow') + '</button></div>' +
      '<section class="startReceipt"><h2>After you choose</h2><p>Return to ATLAS, unlock and confirm. Your original file stays where it is.</p><p id="startImportReceipt" role="status">' + esc(importSummary()) + '</p><div class="startButtonRow"><button class="startPrimary" id="reviewMyFiles">Search my files</button><button class="startSecondary" id="refreshMyImport">Check status</button></div></section>' +
      '<details class="startDetails"><summary>I don’t have my ChatGPT ZIP yet</summary><ol><li>Open ChatGPT Settings.</li><li>Open Data controls, choose Export Data and confirm. Some versions continue in your browser.</li><li>Download the export ZIP when it is ready.</li><li>Return here and tap My ChatGPT history.</li></ol><p>Saved app builds and separately downloaded artwork may need their own project ZIP. An export does not connect your ChatGPT account to ATLAS.</p></details>' +
      '<details class="startDetails"><summary>What can ATLAS read?</summary><p>Supported text documents can be searched locally. ChatGPT archives can add readable conversation text when their format is supported. Images, PDFs, audio and builds inside a project ZIP can be kept as originals, but they are not automatically read, transcribed, run or installed.</p><p>One text document can be up to 8 MiB. ZIP imports have separate file and space limits; a rejected or partial import is reported. Keep a copy outside this phone: portable encrypted backup is still being developed.</p><p>Files provide reference material. Set how ATLAS should respond in How ATLAS helps me.</p><div class="startButtonRow"><button id="filesPreferences">Set my preferences</button><button id="productPhotos">Add a product photo</button></div></details>' +
      '<button class="startQuiet" id="fromLibrary">' + icon('file') + '<span>Get saved ChatGPT Library files</span></button>' + '<button class="startQuiet" id="pasteNote">' + icon('file') + '<span>Just paste a quick note</span></button>')) return;
    $('#addText').onclick = () => chooseImport('text');
    $('#addChats').onclick = () => chooseImport('chatgpt');
    $('#addProject').onclick = () => chooseImport('project');
    $('#reviewMyFiles').onclick = () => searchFiles();
    $('#refreshMyImport').onclick = () => { $('#startImportReceipt').textContent = importSummary(); notify('Showing the latest available import report.'); };
    $('#filesPreferences').onclick = preferences;
    $('#productPhotos').onclick = () => route('store');
    $('#fromLibrary').onclick = () => route('library-transfer');
    $('#pasteNote').onclick = () => route('notes');
  }
  function searchFiles(query='') {
    leaveBrain();
    page = 'search';
    if (!draw('Search my files', '<div id="startFileSearch"></div>')) return;
    const host = $('#startFileSearch');
    if (!native()) {
      host.innerHTML = '<header class="startHero"><h1>Your files stay on your phone.</h1><p>Open the installed Android app to search its private files.</p></header><button class="startPrimary" id="bundledSearch">Search the bundled ATLAS projects</button><button class="startSecondary" id="backToAddFiles">How to add files</button>';
      $('#bundledSearch').onclick = () => route('askshaun');
      $('#backToAddFiles').onclick = files; return;
    }
    if (!window.AtlasFileSearch) { host.textContent = 'File search is unavailable in this build. Your saved files were not changed.'; return; }
    fileDispose = window.AtlasFileSearch.mount(host, {
      ownerSessionActive:active,
      listVaultForSearch:() => call('listVaultForSearch'),
      readVaultTextForSearch:path => call('readVaultTextForSearch',path),
      importSeedZip:() => files()
    });
    const heading = host.querySelector('h1'), intro = heading?.nextElementSibling;
    if (heading) heading.textContent = 'Search my files.';
    if (intro) intro.textContent = 'Find filenames and supported text on this phone. Each result points to its saved source.';
    const input = host.querySelector('#vaultQuery');
    if (input) { input.placeholder = 'Try a project, person or topic'; input.value = String(query).slice(0,256); }
    const include = host.querySelector('#vaultScanText');
    if (include) include.checked = true;
    const add = host.querySelector('#vaultImport');
    if (add) { add.textContent = 'Add files'; add.onclick = files; }
    if (query) host.querySelector('form')?.requestSubmit();
  }
  function preferences() {
    leaveBrain();
    page = 'profile';
    profile = null;
    const loaded = loadProfile();
    if (!loaded) {
      draw('How ATLAS helps me', '<header class="startHero"><h1>Your saved preferences need attention.</h1><p>' + esc(failure(blocked)) + '</p></header><p class="startNotice">No empty profile will replace your saved information. Keep this installation for recovery.</p>');
      return;
    }
    if (!draw('How ATLAS helps me',
      '<header class="startHero"><span class="startEyebrow">YOUR VOICE · YOUR PRIORITIES</span><h1>Tell ATLAS what helps.</h1><p>Save your preferences once. Edit them whenever your needs change.</p></header>' +
      '<form class="startProfileForm" id="startProfileForm">' +
      '<label for="profileName">What should ATLAS call you?<input id="profileName" maxlength="80" autocomplete="off" value="' + esc(profile.displayName) + '" placeholder="Your name"></label>' +
      '<fieldset class="startStyle"><legend>How much detail?</legend>' +
      STYLES.map(style => '<label><input type="radio" name="responseStyle" value="' + style + '"' + (profile.responseStyle===style?' checked':'') + '><span>' + ({short:'Short & clear',balanced:'Balanced',detailed:'Go deeper'})[style] + '</span></label>').join('') + '</fieldset>' +
      '<label for="profilePriorities">What matters most right now?<textarea id="profilePriorities" rows="3" maxlength="2000" placeholder="Your priorities, projects and current focus">' + esc(profile.priorities) + '</textarea></label>' +
      '<details class="startDetails"' + (profile.instructions ? ' open' : '') + '><summary>More instructions for ATLAS</summary><label for="profileInstructions">How should ATLAS help?<textarea id="profileInstructions" rows="4" maxlength="4000" placeholder="For example: Give me the next useful action. Be honest when something is not connected.">' + esc(profile.instructions) + '</textarea></label><p>These are your instructions. Text inside imported files stays reference material and does not change these preferences by itself.</p></details>' +
      '<button type="submit" class="startPrimary" id="saveMyPreferences">Save my preferences</button></form>' +
      '<p class="startNotice">' + (native() ? 'Saved preferences are encrypted on this phone. When you ask online, the Android confirmation shows the question and saved preferences before sending. Other files are not included automatically.' : 'Browser preview: preferences last for this tab only. Use the Android app for encrypted phone storage.') + '</p>')) return;
    $('#startProfileForm').onsubmit = event => {
      event.preventDefault();
      if (!active() || blocked) return notify(failure(blocked || 'locked'),'error');
      const next = {schema:1,displayName:$('#profileName').value.trim(),responseStyle:$('#startProfileForm input[name="responseStyle"]:checked')?.value,
        priorities:$('#profilePriorities').value.trim(),instructions:$('#profileInstructions').value.trim()};
      if (!validProfile(next)) return notify(failure('invalid'),'error');
      if (native()) {
        const result = parsed(call('ownerRecordsRequest', JSON.stringify({op:'write',key:PROFILE_KEY,value:JSON.stringify(next),expectedRevision:revision})), {});
        if (!active()) return;
        if (result.status !== 'ok' || !Number.isSafeInteger(result.revision) || result.revision <= revision) {
          if (['corrupt','conflict'].includes(result.status)) blocked = result.status;
          return notify(failure(result.status),'error');
        }
        revision = result.revision;
      } else {
        try { sessionStorage.setItem(PREVIEW_KEY,JSON.stringify(next)); } catch { return notify(failure('unavailable'),'error'); }
      }
      profile = next;
      notify(native() ? 'Your preferences are saved on this phone.' : 'Saved for this preview tab session.','saved');
    };
  }
  function brain() {
    page = 'brain';
    const state = brainState();
    if (!draw('Connect Atlas Brain',
      '<header class="startHero"><span class="startEyebrow">ONE PLACE TO CONNECT</span><h1>Your Atlas Brain.</h1><p>Keep your files local. Add online AI when you want it.</p></header>' +
      '<section class="startConnection"><div class="startConnectionTitle"><span class="startStepIcon">' + icon('brain') + '</span><div><h2>Online AI</h2><p id="brainConnectionLabel">' + esc(brainLabel(state)) + '</p></div><span class="startStatusDot' + (state.verified&&state.enabled?' verified':'') + '"></span></div>' +
      '<p class="startNotice" id="brainModel">' + esc(state.configured && typeof state.model === 'string' ? 'Model: ' + state.model.slice(0,120) : 'Connect with your OpenAI API key. Enter it privately in the Android dialog.') + '</p>' +
      '<div class="startButtonRow"><button class="startPrimary" id="connectMyBrain">' + (state.configured?'Connection settings':'Connect AI') + '</button><button class="startSecondary" id="testMyBrain"' + (state.configured?'':' disabled') + '>Test connection</button></div>' +
      '<button class="startQuiet" id="refreshMyBrain">Refresh status</button>' +
      '<details class="startDetails"><summary>What do I need?</summary><ol><li>In your OpenAI API account, create a key for your project and check its billing and usage limits.</li><li>Tap Connect AI and enter the key in the private Android dialog.</li><li>Tap Test connection to check access to the chosen model.</li><li>Write a question, then review and approve it in Android.</li></ol><p>An OpenAI API account and key are separate from signing into the ChatGPT app. API usage may cost money. ATLAS has not created an account, bought credit or connected a service for you.</p><p>The key is entered in Android, not in this page or a chat. A connection test checks model access; it does not generate an answer or prove every request will succeed.</p><p>Each online question is shown for your approval before sending. Imported files are not automatically sent. Your saved preferences can be included only as shown in that approval.</p>' +
      '<button class="startSecondary" id="disconnectMyBrain"' + (state.configured&&state.enabled?'':' disabled') + '>Pause online AI</button><p>Pausing keeps your encrypted connection settings. It does not delete the saved key.</p></details></section>' +
      '<form class="startAsk" id="brainAskForm"><label for="brainQuestion">Ask Atlas Brain<textarea id="brainQuestion" rows="3" maxlength="4000" autocomplete="off" placeholder="What do you want help with?">' + esc(brainDraft) + '</textarea></label>' +
      '<details class="startDetails startAttachment" id="brainAttachment"><summary>Attach one saved text file (optional)</summary><p>The Android approval shows the selected excerpt before it leaves your phone. Other files stay local.</p><p id="brainSelectedFile"></p><button type="button" class="startSecondary" id="chooseBrainFile">Choose from my files</button><button type="button" class="startQuiet" id="clearBrainFile"' + (selectedBrainFile?'':' hidden') + '>Remove attachment</button><div id="brainAttachmentPicker" hidden><label for="brainFileQuery">Find a saved text file<input id="brainFileQuery" type="search" maxlength="200" placeholder="File or folder name"></label><p id="brainFileStatus" role="status"></p><div id="brainFileChoices"></div></div></details>' +
      '<button class="startPrimary" id="askMyBrain" type="submit"' + (state.configured&&state.enabled?'':' disabled') + '>Review & send online</button><button class="startSecondary" id="stopMyBrain" type="button"' + ((pendingBrain||state.busy)?'':' hidden') + '>Stop request</button></form>' +
      '<section class="startAnswer" id="brainAnswerSection"' + (lastBrainText?'':' hidden') + '><h2>Atlas Brain reply</h2><div id="brainAnswer" class="startAnswerText"></div><p>AI can make mistakes. Check important claims against your original sources.</p></section>' +
      '<section class="startLocal"><span class="startLocalBadge">AVAILABLE OFFLINE</span><h2>Your information is still useful.</h2><p>Search your imported text, keep notes and set your response preferences without connecting online AI.</p><div class="startButtonRow"><button id="brainLocalFiles">Search my files</button><button id="brainMyPreferences">My preferences</button></div></section>')) return;
    $('#brainAnswer').textContent = lastBrainText;
    if (lastBrainMessage) notify(lastBrainMessage);
    $('#connectMyBrain').onclick = () => brainAction('configure');
    $('#testMyBrain').onclick = () => brainAction('test');
    $('#disconnectMyBrain').onclick = () => brainAction('disconnect');
    $('#refreshMyBrain').onclick = () => { pendingBrain = brainState().busy; brain(); };
    $('#brainQuestion').oninput = event => { brainDraft = event.target.value; };
    $('#brainAskForm').onsubmit = event => { event.preventDefault(); brainDraft = $('#brainQuestion').value; brainAction('ask',brainDraft.trim()); };
    $('#chooseBrainFile').onclick = loadAttachments;
    $('#clearBrainFile').onclick = () => { selectedBrainFile=''; attachmentLabel(); };
    $('#brainFileQuery').oninput = renderAttachments;
    attachmentLabel();
    $('#stopMyBrain').onclick = () => brainAction('cancel');
    $('#brainLocalFiles').onclick = () => searchFiles();
    $('#brainMyPreferences').onclick = preferences;
    refreshBusy(state.busy || pendingBrain,state);
  }
  function attachmentLabel() {
    const label=$('#brainSelectedFile'),clear=$('#clearBrainFile');
    if(label)label.textContent=selectedBrainFile ? 'Selected: '+selectedBrainFile : 'No file attached.';
    if(clear)clear.hidden=!selectedBrainFile;
  }
  function loadAttachments() {
    if(!active())return;
    if(!native()){notify('Choose saved private files in the installed Android app.');return;}
    const picker=$('#brainAttachmentPicker');if(picker)picker.hidden=false;
    const status=$('#brainFileStatus');if(status)status.textContent='Reading saved filenames…';
    attachRecords=[];
    const raw=call('listVaultForSearch');
    const listing=typeof raw==='string'&&raw.length<=12*1024*1024?(()=>{try{return JSON.parse(raw)}catch{return null}})():null;
    if(!active())return;
    if(!listing||listing.status!=='ok'||!Array.isArray(listing.paths)){if(status)status.textContent='Saved filenames could not be read. Nothing was attached.';return;}
    const safe=window.AtlasFileSearch?.safePath;
    if(typeof safe!=='function'){if(status)status.textContent='File validation is unavailable. Nothing was attached.';return;}
    attachRecords=[...new Set(listing.paths.slice(0,5000).filter(path=>safe(path)&&/\.(txt|md|json|jsonl|csv|tsv|log|yaml|yml)$/i.test(path)))];
    if(status)status.dataset.partial=listing.truncated||listing.paths.length>5000?'true':'false';
    renderAttachments();
  }
  function renderAttachments() {
    if(!active()||page!=='brain')return;
    const list=$('#brainFileChoices'),status=$('#brainFileStatus');if(!list||!status)return;
    const query=($('#brainFileQuery')?.value||'').trim().toLowerCase();
    const matches=attachRecords.filter(path=>path.toLowerCase().includes(query));
    list.replaceChildren();
    for(const path of matches.slice(0,50)){
      const button=document.createElement('button');button.type='button';button.className='startFileChoice';
      button.textContent=path;button.onclick=()=>{if(!active())return;selectedBrainFile=path;attachmentLabel();$('#brainAttachmentPicker').hidden=true;notify('One file selected. Review its excerpt in Android before sending.');};
      list.append(button);
    }
    status.textContent=matches.length?matches.length+' matching text files. Showing '+Math.min(matches.length,50)+'.'+(status.dataset.partial==='true'?' This file list is partial.':''):'No matching supported text files. Add a text document first.';
  }
  function refreshBusy(busy, state=brainState()) {
    if (page !== 'brain') return;
    busy = busy || state.busy;
    for (const id of ['connectMyBrain','testMyBrain','askMyBrain','disconnectMyBrain']) {
      const element = $('#'+id);
      if (element) element.disabled = busy || (['testMyBrain','askMyBrain','disconnectMyBrain'].includes(id) && (!state.configured || !state.enabled));
    }
    const stop = $('#stopMyBrain'); if (stop) stop.hidden = !busy;
    const form = $('#brainAskForm'); if (form) form.setAttribute('aria-busy',busy?'true':'false');
  }
  function brainAction(kind, text='') {
    if (!active()) return;
    if (!native()) { notify('Use Connect Atlas Brain in the installed Android app. This browser preview does not store keys or contact an AI service.'); return; }
    if (kind === 'ask' && (!text || text.length > 4000)) { notify('Write a question of up to 4,000 characters first.'); return; }
    if (pendingBrain && kind !== 'cancel') return;
    const names = {configure:'brainConfigure',test:'brainTest',ask:'brainAsk',disconnect:'brainDisconnect',cancel:'brainCancel'};
    if (kind === 'ask') { lastBrainText=''; const result=$('#brainAnswer'); if(result)result.textContent=''; const section=$('#brainAnswerSection'); if(section)section.hidden=true; }
    pendingBrain = kind !== 'cancel'; refreshBusy(pendingBrain);
    lastBrainMessage = kind === 'cancel' ? 'Stopping the current request…' : kind === 'configure' ? 'Complete the connection settings in Android.' : kind === 'disconnect' ? 'Confirm the connection change in Android.' : 'Review the Android confirmation. Nothing is sent before you approve.';
    notify(lastBrainMessage);
    const raw = kind === 'ask' ? call(names[kind],text,selectedBrainFile) : call(names[kind]);
    const response = parsed(raw);
    if (response && !['pending','queued','awaiting_confirmation','started','ok'].includes(response.status)) {
      pendingBrain=false;refreshBusy(false);notify(resultMessage(response),'error');
    }
    if (kind === 'cancel') { pendingBrain=false; refreshBusy(false); }
  }
  function resultMessage(result) {
    const known = {
      cancelled:'The request was cancelled.',
      not_configured:'Connect AI first, then test the connection.',
      locked:'Unlock ATLAS to continue.',
      unavailable:'This connection is unavailable. Your files are still available locally.',
      offline:'No network connection. Your local files and tools still work.',
      unauthorized:'The service did not accept this key. Check Connection settings.',
      quota:'The service reported a usage or credit limit. Check your API account.',
      timeout:'The request timed out. Your local work was kept.',
      error:'The AI request did not complete. Check the connection and try again.'
    };
    if (typeof result.message === 'string' && result.message.length <= 1500) return result.message;
    return known[result.status] || (result.status === 'ok' ? 'The operation completed.' : 'The service could not confirm this operation.');
  }
  function onBrainResult(event) {
    if (!active() || page !== 'brain' || !document.querySelector('.atlasStart')) return;
    const result = typeof event.detail === 'string' ? parsed(event.detail,{}) : event.detail || {};
    if (typeof result !== 'object' || Array.isArray(result)) return;
    pendingBrain=false;
    lastBrainMessage=resultMessage(result);
    if (result.kind === 'ask' && result.status === 'ok' && typeof result.text === 'string') {
      lastBrainText=result.text.slice(0,40000);
      const target=$('#brainAnswer'),section=$('#brainAnswerSection');
      if(target)target.textContent=lastBrainText;
      if(section)section.hidden=false;
    }
    const state=brainState(),label=$('#brainConnectionLabel');
    if(label)label.textContent=brainLabel(state);
    const dot=$('.startStatusDot'); if(dot)dot.classList.toggle('verified',state.verified&&state.enabled);
    const settings=$('#connectMyBrain');if(settings)settings.textContent=state.configured?'Connection settings':'Connect AI';
    const model=$('#brainModel');if(model)model.textContent=state.configured&&typeof state.model==='string'?'Model: '+state.model.slice(0,120):'Connect with your OpenAI API key. Enter it privately in the Android dialog.';
    refreshBusy(state.busy,state);notify(lastBrainMessage,result.status==='ok'?'saved':'info');
  }
  function onImport(event) {
    if (!active() || page !== 'files') return;
    const target=$('#startImportReceipt');if(target)target.textContent=importSummary();
    if (event.type === 'atlas-document-import') notify('Document import finished. Search my files to confirm its saved contents.');
  }
  function erasePrivate() {
    clearFileSearch();
    const host=document.querySelector('.atlasStart');
    if(host){host.querySelectorAll('input,textarea').forEach(x=>x.value='');host.replaceChildren();}
    profile=null;revision=0;blocked='';lastBrainText='';lastBrainMessage='';brainDraft='';selectedBrainFile='';attachRecords=[];pendingBrain=false;
  }
  function dispose() {
    leaveBrain();erasePrivate();env=null;page='';
  }
  function back() {
    if (!env || !document.querySelector('.atlasStart')) return false;
    if (!active()) { dispose(); return false; }
    if (page==='start') { const home=env.home;dispose();home?.();return true; }
    hub();return true;
  }
  function open(id, options) {
    dispose();env=options;
    if(!active()){dispose();return false;}
    if(id==='brain')brain();else hub();
    return true;
  }
  window.addEventListener('atlas-brain-result',onBrainResult);
  window.addEventListener('atlas-import-status',onImport);
  window.addEventListener('atlas-native-import',onImport);
  window.addEventListener('atlas-document-import',onImport);
  window.addEventListener('atlas-owner-locked',dispose);
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&env)dispose();});
  window.ATLASStart=Object.freeze({open,back,dispose});
})();
