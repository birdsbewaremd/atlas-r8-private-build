/* ATLAS Home gestures. Own only the launcher and panel handles; app content keeps native scrolling. */
(()=>{'use strict';
let env=null,abort=null,pointer=null,hold=null,moveFrame=0,settleFrame=0,ghost=null,target=null,edgeAt=0,consumedUntil=0;
const touches=new Set(),panels=new Map(),animations=new Map();
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const reduced=()=>document.documentElement.classList.contains('reduceMotion')||matchMedia('(prefers-reduced-motion: reduce)').matches;
function suppress(){consumedUntil=Date.now()+250;env?.suppress?.(250);}
function clearHold(){clearTimeout(hold);hold=null;}
function release(p){try{if(p?.capture?.hasPointerCapture(p.id))p.capture.releasePointerCapture(p.id);}catch{}}
function cleanGhost(){ghost?.remove();ghost=null;target?.classList.remove('layoutTarget');target=null;env?.root.querySelectorAll('.layoutDragging').forEach(x=>x.classList.remove('layoutDragging'));}
function stopSettle(){cancelAnimationFrame(settleFrame);settleFrame=0;}
function finishRail(c,page){if(!c?.rail.isConnected)return;c.rail.style.scrollSnapType='';c.rail.style.scrollBehavior='';c.root.classList.remove('homeMoving');c.onPage?.(page);}
function goToPage(page,animate=true){
 if(!env)return;const c=env,rail=c.rail,width=rail.clientWidth;page=clamp(Math.round(page),0,c.pageCount-1);stopSettle();
 const from=rail.scrollLeft,to=page*width;rail.style.scrollSnapType='none';rail.style.scrollBehavior='auto';
 if(!animate||reduced()||Math.abs(to-from)<1){rail.scrollLeft=to;finishRail(c,page);return;}
 c.root.classList.add('homeMoving');const began=performance.now(),duration=180;
 const tick=now=>{if(c!==env||!rail.isConnected)return;const t=clamp((now-began)/duration,0,1),ease=1-Math.pow(1-t,3);rail.scrollLeft=from+(to-from)*ease;if(t<1)settleFrame=requestAnimationFrame(tick);else{settleFrame=0;rail.scrollLeft=to;finishRail(c,page);}};
 settleFrame=requestAnimationFrame(tick);
}
function stopPanelAnimation(node){const a=animations.get(node);if(a){a.cancel();animations.delete(node);}}
function panelAt(node,y){node.style.transform=`translate3d(0,${Math.round(y)}px,0)`;}
function settlePanel(node,y,close){
 if(!node?.isConnected)return;stopPanelAnimation(node);node.classList.add('panelMoving');delete node.dataset.gesturePreview;
 const done=()=>{animations.delete(node);node.classList.remove('panelMoving');node.style.transform='';if(close)close();};
 if(reduced()||!node.animate){panelAt(node,y);done();return;}
 const from=node.style.transform||'translate3d(0,0,0)',a=node.animate([{transform:from},{transform:`translate3d(0,${y}px,0)`}],{duration:180,easing:'cubic-bezier(.2,.7,.2,1)',fill:'forwards'});
 animations.set(node,a);a.onfinish=()=>{done();a.cancel();};
}
function editing(){
 if(!env)return;env.onEdit();env.root.classList.add('edit');const search=env.root.querySelector('#spotlight');if(search)search.hidden=true;
 if(!env.root.querySelector('.layoutTools')){const bar=document.createElement('div');bar.className='layoutTools';bar.innerHTML='<button type="button" class="layoutUndo">Undo move</button><button type="button" class="layoutDone">Done</button>';search?.parentNode.insertBefore(bar,search);bar.querySelector('.layoutDone').onclick=()=>env?.onDone();bar.querySelector('.layoutUndo').onclick=()=>env?.onUndo();}
 const undo=env.root.querySelector('.layoutUndo');if(undo)undo.disabled=!env.canUndo();
}
function capture(p){try{p.capture=env.root;p.capture.setPointerCapture(p.id);}catch{}}
function begin(){
 if(!pointer?.element?.isConnected||!env||touches.size>1)return;const p=pointer;p.dragging=true;clearHold();stopSettle();capture(p);suppress();editing();
 const rect=p.element.getBoundingClientRect();ghost=p.element.cloneNode(true);ghost.removeAttribute('data-app');ghost.removeAttribute('id');ghost.setAttribute('aria-hidden','true');ghost.className='app layoutGhost';ghost.style.width=rect.width+'px';ghost.style.height=rect.height+'px';document.body.appendChild(ghost);p.element.classList.add('layoutDragging');renderMove(p);env.announce('Drag to a new place or into the dock.');
}
function renderMove(p){
 if(!env||!p)return;
 if(p.dragging&&ghost){
  // Hit-test before style writes. The rail bounds are cached at gesture start.
  const hit=document.elementFromPoint(p.x,p.y)?.closest('.homeGrid [data-app],.dock [data-app]'),next=hit&&env.root.contains(hit)?hit:null;
  if(next!==target){target?.classList.remove('layoutTarget');target=next;target?.classList.add('layoutTarget');}
  ghost.style.transform=`translate3d(${Math.round(p.x)}px,${Math.round(p.y)}px,0) translate(-50%,-54%) scale(1.12)`;
  const now=performance.now();if(p.y>=p.rect.top&&p.y<=p.rect.bottom&&now-edgeAt>700&&(p.x<p.rect.left+36||p.x>p.rect.right-36)){edgeAt=now;goToPage(Math.round(env.rail.scrollLeft/p.width)+(p.x<p.rect.left+36?-1:1),false);}
 }else if(p.axis==='x')env.rail.scrollLeft=clamp(p.left-(p.x-p.sx),0,(env.pageCount-1)*p.width);
 else if(p.axis==='y'&&p.panel){const distance=Math.max(0,(p.y-p.sy)*p.direction);panelAt(p.panel,p.direction*(Math.min(distance,p.height)-p.height));}
}
function queueMove(){if(!moveFrame)moveFrame=requestAnimationFrame(()=>{moveFrame=0;renderMove(pointer);});}
function cancelGesture(settle=true){
 const p=pointer;pointer=null;clearHold();cancelAnimationFrame(moveFrame);moveFrame=0;release(p);cleanGhost();
 if(!p)return;if(p.axis||p.dragging)suppress();
 if(p.panel){stopPanelAnimation(p.panel);env?.closePanel?.(p.panel.id);}
 if(p.axis==='x'&&settle)goToPage(p.page,true);else if(env)env.root.classList.remove('homeMoving');
}
function dispose(){
 cancelGesture(false);stopSettle();abort?.abort();abort=null;for(const id of [...panels.keys()])detachPanel(id);for(const [node] of animations)stopPanelAnimation(node);touches.clear();env=null;
}
function bind(config){
 dispose();env=config;abort=new AbortController();const opt={signal:abort.signal};goToPage(config.initialPage||0,false);if(env.isEditing())editing();
 document.addEventListener('pointerdown',e=>{if(e.isPrimary&&!pointer){consumedUntil=0;env?.suppress?.(0);}if(e.pointerType==='touch'){touches.add(e.pointerId);if(touches.size>1)cancelGesture();}},{...opt,capture:true});
 env.root.querySelectorAll('.homeGrid [data-app],.dock [data-app]').forEach(el=>{el.draggable=false;el.oncontextmenu=e=>{e.preventDefault();if(!pointer?.axis&&!pointer?.dragging)editing();};});
 env.root.addEventListener('pointerdown',e=>{
  if(e.button!==0||!e.isPrimary||touches.size>1||env.hasOverlay?.())return;
  const el=e.target.closest('.homeGrid [data-app],.dock [data-app]'),inRail=env.rail.contains(e.target);if(!el&&!inRail)return;
  cancelGesture(false);stopSettle();const width=env.rail.clientWidth,rect=env.rail.getBoundingClientRect();
  pointer={id:e.pointerId,element:el,app:el?.dataset.app,inRail,x:e.clientX,y:e.clientY,sx:e.clientX,sy:e.clientY,lx:e.clientX,ly:e.clientY,at:performance.now(),vx:0,vy:0,left:env.rail.scrollLeft,width,rect,page:Math.round(env.rail.scrollLeft/Math.max(1,width)),axis:null,dragging:false};
  if(el)hold=setTimeout(begin,env.isEditing()?120:450);
 },opt);
 document.addEventListener('pointermove',e=>{
  const p=pointer;if(!p||e.pointerId!==p.id||!env)return;const now=performance.now(),dt=Math.max(1,now-p.at);p.vx=(e.clientX-p.lx)/dt;p.vy=(e.clientY-p.ly)/dt;p.lx=p.x=e.clientX;p.ly=p.y=e.clientY;p.at=now;
  const dx=p.x-p.sx,dy=p.y-p.sy;if(!p.dragging&&!p.axis&&Math.hypot(dx,dy)>10){clearHold();if(!p.inRail){suppress();return;}p.axis=Math.abs(dx)>Math.abs(dy)?'x':'y';capture(p);suppress();
   if(p.axis==='x'){env.rail.style.scrollSnapType='none';env.rail.style.scrollBehavior='auto';env.root.classList.add('homeMoving');}
   else{p.direction=dy>0?1:-1;p.panel=env.openPanel?.(dy>0?'controls':'apps');if(p.panel){p.height=p.panel.getBoundingClientRect().height;p.panel.dataset.gesturePreview='true';p.panel.classList.add('panelMoving');panelAt(p.panel,-p.direction*p.height);}}
  }
  if(p.dragging||p.axis){if(e.cancelable)e.preventDefault();queueMove();}
 },{...opt,passive:false});
 document.addEventListener('pointerup',e=>{
  touches.delete(e.pointerId);const p=pointer;if(!p||p.id!==e.pointerId||!env)return;const c=env;p.x=e.clientX;p.y=e.clientY;cancelAnimationFrame(moveFrame);moveFrame=0;renderMove(p);pointer=null;clearHold();release(p);
  if(p.dragging){const dest=target?.dataset.app,isDock=!!target?.closest('.dock');suppress();cleanGhost();if(dest)c.onDrop(p.app,dest,isDock);else c.announce('No move saved. Drop onto an app or dock slot.');return;}
  if(p.axis==='x'){suppress();const dx=p.x-p.sx,fast=performance.now()-p.at<100&&Math.abs(p.vx)>.45,commit=Math.abs(dx)>Math.min(80,p.width*.22)||(Math.abs(dx)>20&&fast);goToPage(p.page+(commit?(dx<0?1:-1):0),true);}
  if(p.axis==='y'&&p.panel){suppress();const distance=(p.y-p.sy)*p.direction,fast=performance.now()-p.at<100&&p.vy*p.direction>.45,commit=distance>64||(distance>20&&fast);settlePanel(p.panel,commit?0:-p.direction*p.height,commit?null:()=>c.closePanel?.(p.panel.id));}
 },opt);
 document.addEventListener('pointercancel',e=>{touches.delete(e.pointerId);if(pointer?.id===e.pointerId)cancelGesture();},opt);
 env.root.addEventListener('lostpointercapture',e=>{if(e.target===env?.root&&pointer?.id===e.pointerId)cancelGesture();},opt);
 document.addEventListener('click',e=>{if(ghost||Date.now()<consumedUntil){e.preventDefault();e.stopImmediatePropagation();consumedUntil=0;}},{...opt,capture:true});
 env.rail.addEventListener('keydown',e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();goToPage(Math.round(env.rail.scrollLeft/env.rail.clientWidth)+(e.key==='ArrowRight'?1:-1));}},opt);
}
function detachPanel(id){const entry=panels.get(id);if(!entry)return;entry.abort.abort();cancelAnimationFrame(entry.frame);stopPanelAnimation(entry.node);panels.delete(id);}
function bindPanel(node,{direction,onClose}){
 if(!node)return;detachPanel(node.id);const handle=node.querySelector('.panelDragHandle');if(!handle)return;const entry={node,abort:new AbortController(),frame:0,p:null,active:new Set()};panels.set(node.id,entry);const opt={signal:entry.abort.signal};
 document.addEventListener('pointerdown',e=>{if(e.pointerType!=='touch')return;entry.active.add(e.pointerId);if(entry.active.size>1&&entry.p){entry.p=null;cancelAnimationFrame(entry.frame);entry.frame=0;settlePanel(node,0);}},{...opt,capture:true});
 document.addEventListener('pointerup',e=>entry.active.delete(e.pointerId),opt);document.addEventListener('pointercancel',e=>entry.active.delete(e.pointerId),opt);
 handle.onclick=()=>{if(!entry.p&&Date.now()>=consumedUntil)onClose();};
 handle.addEventListener('pointerdown',e=>{if(!e.isPrimary||e.button!==0||entry.active.size>1)return;stopPanelAnimation(node);entry.p={id:e.pointerId,sy:e.clientY,y:e.clientY,height:node.getBoundingClientRect().height};try{handle.setPointerCapture(e.pointerId);}catch{}},opt);
 handle.addEventListener('pointermove',e=>{const p=entry.p;if(!p||p.id!==e.pointerId)return;p.y=e.clientY;if(Math.abs(p.y-p.sy)<6)return;if(e.cancelable)e.preventDefault();node.classList.add('panelMoving');if(!entry.frame)entry.frame=requestAnimationFrame(()=>{entry.frame=0;if(entry.p)panelAt(node,direction*Math.max(0,(entry.p.y-entry.p.sy)*direction));});},{...opt,passive:false});
 const finish=(e,cancel)=>{const p=entry.p;if(!p||p.id!==e.pointerId)return;entry.p=null;cancelAnimationFrame(entry.frame);entry.frame=0;const distance=(e.clientY-p.sy)*direction;if(Math.abs(distance)<6){node.style.transform='';node.classList.remove('panelMoving');return;}suppress();settlePanel(node,!cancel&&distance>64?direction*p.height:0,!cancel&&distance>64?onClose:null);};
 handle.addEventListener('pointerup',e=>finish(e,false),opt);handle.addEventListener('pointercancel',e=>finish(e,true),opt);
}
window.ATLASLayout=Object.freeze({bind,dispose,goToPage,bindPanel,detachPanel,busy:()=>!!pointer||!!settleFrame,consumedGesture:()=>!!pointer?.dragging||Date.now()<consumedUntil});
})();
