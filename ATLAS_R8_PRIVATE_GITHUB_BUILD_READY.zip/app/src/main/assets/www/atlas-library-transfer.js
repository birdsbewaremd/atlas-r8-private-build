/* ATLAS Library Transfer v0.1 — deliberate first-party downloads and explicit local imports.
 * No ChatGPT credentials, scraping, background service, cookies or silent file downloads.
 * ChatGPT Library bulk selection happens in the owner's separate authenticated browser.
 * The APK's existing selected ZIP/document import remains bounded. */
(() => { 'use strict';
  const LIBRARY_URL='https://chatgpt.com/library';
  const PORTAL_URL='https://privacy.openai.com/';
  const KB_URL='https://help.openai.com/en/articles/20001052-using-library-to-manage-files-in-chatgpt';
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const $=s=>document.querySelector('.atlasLibraryTransfer '+s);
  let context=null, previousImport='',pendingKind='';
  const native=()=>!!context?.native?.available?.();
  const authorized=()=>!!context&&sessionStorage.getItem('atlas.role')==='owner'&&(!native()||context.native.call('ownerSessionActive')===true);
  const call=(method,...args)=>authorized()?context.native.call(method,...args):null;
  const safeParse=raw=>{try{if(typeof raw!=='string'||raw.length>20000)return null;return JSON.parse(raw)}catch{return null}};
  const gib=bytes=>Number.isFinite(bytes)&&bytes>=0?(bytes/1073741824).toFixed(2)+' GiB':'unknown';
  function storage(){
    if(!native())return {status:'preview'};
    const response=safeParse(call('storageStatus'));
    return response&&response.status==='ok'&&Number.isFinite(response.availableBytes)&&Number.isFinite(response.totalBytes)?response:{status:'unavailable'};
  }
  function report(){
    if(!native())return {status:'preview'};
    const response=safeParse(call('importStatus'));
    return response&&typeof response.status==='string'?response:{status:'unavailable'};
  }
  function receiptText(r){
    if(r.status==='preview')return 'Browser demonstration — no Android imports exist in this preview.';
    if(r.status==='idle')return 'No native import receipt recorded yet; 0 verified downloaded files cannot be inferred.';
    if(r.status==='importing')return 'The selected import is processing. Do not close ATLAS before confirming the native receipt.';
    if(r.status==='locked')return 'Unlock ATLAS to read the native import status.';
    if(r.status==='rejected')return 'Last attempt REJECTED: '+String(r.reason||'Unsupported/oversized input').slice(0,120)+'. Earlier files remain unchanged.';
    if(r.status==='saved_raw')return 'RAW-ONLY: the last selected archive was stored, but searchable contents were not fully verified.';
    if(r.status==='saved'){
      const files=Number.isSafeInteger(r.files)&&r.files>=0?r.files:null;
      const chats=Number.isSafeInteger(r.conversations)&&r.conversations>=0?r.conversations:null;
      const indexed=Number.isSafeInteger(r.searchFiles)&&r.searchFiles>=0?r.searchFiles:null;
      return 'Native last-import receipt: SAVED'+(files!==null?' · '+files+' files':'')+(chats!==null?' · '+chats+' conversations':'')+(indexed!==null?' · '+indexed+' searchable chunks':'')+'. This does not confirm the whole cloud Library.';
    }
    return 'Native last import: '+String(r.status).slice(0,50)+'. Coverage of cloud Library is UNKNOWN.';
  }
  function status(message,isError=false){const el=$('#libraryActionStatus');if(el){el.textContent=message;el.dataset.severity=isError?'error':'info';}}
  async function copyUrl(url){
    if(!authorized())return false;
    try {if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(url);return true;}}catch{}
    let box=null;
    try{
      box=document.createElement('textarea');box.value=url;box.setAttribute('readonly','');box.style.cssText='position:fixed;top:3px;left:3px;width:1px;height:1px;opacity:0';document.body.appendChild(box);box.select();
      return document.execCommand?.('copy')===true;
    }catch{return false;}finally{box?.remove()}
  }
  async function browser(){
    if(!authorized())return;
    if(!native()){
      window.open?.(LIBRARY_URL,'_blank','noopener,noreferrer');
      status('Opened the official Library in a separate browser tab. Select saved files there; ATLAS did not download them.');
      return;
    }
    const copied=await copyUrl(LIBRARY_URL);
    if(!authorized())return;
    if(!copied){
      status('Clipboard unavailable. Long-press the address shown below and copy it, then open it in your browser. No files were downloaded.',true);return;
    }
    status('Official Library address copied. Opening your browser; paste the address and select Download. Nothing has transferred yet.');
    call('openNativeApp','browser');
  }
  async function copyOnly(url){if(await copyUrl(url)){status('Public address copied. Open in your own authenticated browser. No account data was sent by ATLAS.');}
    else status('Could not copy automatically. Long-press the printed address below and copy it.',true);}
  function importChosen(method,kind){
    if(!authorized())return;
    if(!native()){status('This preview cannot access Android downloads. Use the built ATLAS app to choose a saved file. No import started.',true);return;}
    pendingKind=kind;
    status('Android file picker requested for '+kind+'. Choose a file YOU downloaded. Return, unlock ATLAS, review native confirmation, then refresh the receipt.');
    call(method);
  }
  function updateStorage(){const s=storage();const el=$('#librarySpace');if(!el)return;
    if(s.status==='ok'){
      el.textContent=gib(s.availableBytes)+' phone storage free · '+gib(s.totalBytes)+' total · '+gib(s.vaultEncryptedBytes)+' encrypted ATLAS vault files. Cloud storage is separate.';
      const note=$('#libraryCapacityNote');if(note)note.textContent=s.availableBytes<80*1073741824?'The phone currently reports less than 80 GiB free. The full ~77 GB cloud estimate may not fit; use smaller batches or a separate approved storage device.':'Available bytes are not proof an all-Library transfer will fit; budget for temporary ZIP and indexing overhead.';
    }else{
      el.textContent='Phone space UNKNOWN ('+(s.status==='preview'?'browser preview':'native query unavailable')+'). Cloud storage screenshot is not a phone-space reading.';
      const note=$('#libraryCapacityNote');if(note)note.textContent='Check storage on the actual device before selecting large downloads.';
    }
  }
  function refresh(){if(!authorized())return;const r=report();const result=$('#libraryImportReceipt');if(result){result.textContent=receiptText(r);result.dataset.state=r.status==='saved'?'saved':r.status==='rejected'?'rejected':'unknown';}updateStorage();}
  function render(){if(!authorized())return false;
    const html=`<section class="atlasLibraryTransfer" aria-label="ATLAS Library download center">
      <header class="libraryHero"><span class="libraryEyebrow">ATLAS Ω · OWNER CONTROL · CLOUD TO LOCAL</span><h1>Download your <em>Library.</em></h1><p>Get saved ChatGPT files in batches, then import only the files you select into this ATLAS phone vault. Your cloud Library and downloaded phone files are different copies.</p><div class="librarySnapshot">Screenshot checkpoint: <strong>77 / 100 GB used</strong> · ~23 GB cloud space remaining. <small>Owner screenshot, NOT live storage measurement or confirmed download progress.</small></div></header>
      <section class="libraryStep" aria-labelledby="libraryDownloadHead"><span class="libraryNumber">01</span><div class="libraryBody"><h2 id="libraryDownloadHead">Download Library files</h2><p>On the official ChatGPT website, choose one or more files in Library and tap <strong>Download</strong>. Repeat in smaller batches. The whole Library is <strong>not</strong> available through an ATLAS one-tap account API.</p>
        <button type="button" id="libraryGo" class="libraryAction">Open Library in my browser ↗</button>
        <button type="button" id="libraryCopy" class="libraryOther">Copy Library address</button>
        <p id="libraryAddress" class="libraryAddress">${esc(LIBRARY_URL)}</p>
        <small class="libraryFine">The browser is outside ATLAS. Sign in only on the official site; never paste credentials into ATLAS.</small></div></section>
      <section class="libraryStep" aria-labelledby="libraryChatHead"><span class="libraryNumber">02</span><div class="libraryBody"><h2 id="libraryChatHead">Request the separate chat-history export</h2><p>ChatGPT Settings → Data controls → Export data. Wait for the official email/SMS, then download the ZIP. The account export is not proof every Library file is included.</p><button type="button" id="libraryPrivacy" class="libraryOther">Copy official Privacy Portal address</button><p class="libraryAddress">${esc(PORTAL_URL)}</p><small class="libraryFine">Some files from locked chats or temporary chats may not appear in Library exports. This screen cannot override access controls.</small></div></section>
      <section class="libraryStep" aria-labelledby="libraryImportHead"><span class="libraryNumber">03</span><div class="libraryBody"><h2 id="libraryImportHead">Import files already downloaded</h2><p>Choose a local ZIP or export. Android opens its own picker and ATLAS requires owner confirmation. Existing native import limits remain active.</p>
       <button type="button" id="libraryImportZip" class="libraryAction">Import downloaded Library ZIP</button>
       <button type="button" id="libraryImportChats" class="libraryOther">Import ChatGPT export ZIP</button>
       <button type="button" id="libraryImportText" class="libraryOther">Import a small text document</button>
       <small class="libraryFine">Archive imports are bounded. Single text document limit: 8 MiB. Multi-gigabyte whole-Library transfer is NOT supported by this candidate. Nothing is deleted or synced automatically.</small></div></section>
      <section class="libraryStep" aria-labelledby="libraryVerifyHead"><span class="libraryNumber">04</span><div class="libraryBody"><h2 id="libraryVerifyHead">Verify what ATLAS actually saved</h2><p id="libraryImportReceipt" class="libraryReceipt" role="status" aria-live="polite"></p><p id="librarySpace" class="libraryCapacity"></p><p id="libraryCapacityNote" class="libraryFine"></p>
       <button type="button" id="libraryRefresh" class="libraryAction">Check native receipt & space</button>
       <button type="button" id="librarySearch" class="libraryOther">Search imported files</button>
       <small class="libraryFine">One last-import receipt is not a cumulative 77 GB completeness audit. For a full archive we still need per-batch manifests, byte-level verification and portable encrypted backups.</small></div></section>
      <p class="libraryActionStatus" id="libraryActionStatus" role="status" aria-live="polite"></p>
      <p class="libraryBottom">Source: official <span>ChatGPT Library</span> and <span>Data Export</span> documentation. Local-only presentation; no background worker or automatic account access. ATLAS can make mistakes.</p>
    </section>`;
    context.frame('Download Library',html,'atlasLibraryView');
    $('#libraryGo').onclick=browser;
    $('#libraryCopy').onclick=()=>copyOnly(LIBRARY_URL);
    $('#libraryPrivacy').onclick=()=>copyOnly(PORTAL_URL);
    $('#libraryImportZip').onclick=()=>importChosen('importSeedZip','Library ZIP');
    $('#libraryImportChats').onclick=()=>importChosen('importChatGPTArchive','ChatGPT export ZIP');
    $('#libraryImportText').onclick=()=>importChosen('importLocalDocument','text document');
    $('#libraryRefresh').onclick=()=>{refresh();status('Checked the available native receipt, not a remote ChatGPT sync.')};
    $('#librarySearch').onclick=()=>context?.open?.('files');
    refresh();return true;
  }
  function open(env){context=env;return render()}
  window.ATLASLibraryTransfer=Object.freeze({open,urls:Object.freeze({library:LIBRARY_URL,portal:PORTAL_URL,help:KB_URL}),refresh});
})();
