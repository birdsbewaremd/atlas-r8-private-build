/* R7: real Android installed applications in the existing ATLAS app drawer.
 * Runs only in the owner-unlocked ATLAS WebView; calls existing native bridge.
 * Separate native AtlasLauncherActivity remains accessible without ATLAS PIN.
 */
(()=>{'use strict';
  const html=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const allowedIcon=s=>/^data:image\/png;base64,[A-Za-z0-9+/]{1,180000}={0,2}$/.test(s||'');
  let live=null;
  function attach({root,native}){
    if(live)live.dispose();
    const rail=root.querySelector('#libRail'), count=root.querySelector('#libCount'),
      search=root.querySelector('#libQ'), dots=root.querySelector('#libDots');
    if(!rail||!count||!search||!dots)return false;
    const tabs=document.createElement('nav');tabs.className='atlasAndroidTabs';tabs.setAttribute('aria-label','ATLAS tools or real Android applications');
    tabs.innerHTML='<button type="button" data-real-tab="atlas" aria-pressed="true">ATLAS tools</button><button type="button" data-real-tab="phone" aria-pressed="false">Installed phone apps</button>';
    rail.parentNode.insertBefore(tabs,rail);
    const wrap=document.createElement('section');wrap.id='atlasAndroidApps';wrap.className='atlasRealApps';wrap.hidden=true;
    wrap.innerHTML='<p class="atlasRealState" role="status">Choose Installed phone apps to discover Android launchable applications.</p><div class="atlasRealGrid"></div>';
    rail.parentNode.insertBefore(wrap,rail.nextSibling);
    const state=wrap.querySelector('.atlasRealState'),grid=wrap.querySelector('.atlasRealGrid');
    let mode='atlas', rows=[],loaded=false,disposed=false;
    const nativeAvailable=()=>!!native?.available?.();
    function load(){
      if(loaded)return;loaded=true;
      if(!nativeAvailable()){state.textContent='Android apps appear after this project is installed as a native Android application. Browser previews cannot read installed apps.';return;}
      try{
        const list=JSON.parse(native.call('installedApps')||'[]');
        if(!Array.isArray(list))throw Error('Android app list unavailable');
        const seen=new Set();
        rows=list.filter(r=>{
          if(!r||typeof r.id!=='string'||typeof r.label!=='string'||r.id.length>512||r.label.length>120||seen.has(r.id))return false;
          seen.add(r.id);return true;
        }).sort((a,b)=>a.label.localeCompare(b.label));
        state.textContent=rows.length?`${rows.length} Android app shortcuts found on this profile. Tap to open the actual app. Work-profile apps are available in the native launcher when Android permits.`:'No Android app shortcuts returned. Verify ATLAS owner unlock and Android launcher permissions.';
      }catch(error){state.textContent='Android app discovery failed. Native app remains available through your normal Android home.';}
    }
    function refresh(){
      if(disposed||mode!=='phone')return;
      const q=(search.value||'').trim().toLocaleLowerCase();
      const filtered=rows.filter(r=>r.label.toLocaleLowerCase().includes(q)||String(r.packageName||'').toLocaleLowerCase().includes(q));
      grid.innerHTML=filtered.length?filtered.map(r=>`<button type="button" class="atlasRealApp" data-native-id="${html(r.id)}" aria-label="Open installed Android app ${html(r.label)}">${allowedIcon(r.icon)?`<img src="${r.icon}" loading="lazy" alt="">`:'<span class="atlasRealFallback" aria-hidden="true">▣</span>'}<span>${html(r.label)}</span></button>`).join(''):'<p class="atlasRealEmpty">No matching installed apps.</p>';
      count.textContent=`${filtered.length} Android apps`;
    }
    function switchTab(to){
      mode=to==='phone'?'phone':'atlas';
      const isPhone=mode==='phone';
      rail.hidden=isPhone;dots.hidden=isPhone;wrap.hidden=!isPhone;
      tabs.querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.realTab===mode)));
      if(isPhone){load();refresh();}
      else{count.textContent='ATLAS tools';}
    }
    const onTabs=e=>{const btn=e.target.closest('[data-real-tab]');if(btn) switchTab(btn.dataset.realTab)};
    const onGrid=e=>{const btn=e.target.closest('[data-native-id]');if(!btn)return;
      if(!nativeAvailable())return;
      // Native revalidates exact Launcher component and owner session before opening.
      native.call('openInstalledApp',btn.dataset.nativeId);
    };
    const onSearch=()=>{if(mode==='phone')refresh()};
    tabs.addEventListener('click',onTabs);grid.addEventListener('click',onGrid);search.addEventListener('input',onSearch);
    live={dispose(){disposed=true;tabs.removeEventListener('click',onTabs);grid.removeEventListener('click',onGrid);search.removeEventListener('input',onSearch);tabs.remove();wrap.remove();}};
    return true;
  }
  window.ATLASInstalledDrawer=Object.freeze({attach});
})();
