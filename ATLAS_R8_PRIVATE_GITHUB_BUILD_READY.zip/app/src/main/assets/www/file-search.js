/* Owner-only, read-only Files search. No network or persistent search index. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.AtlasFileSearch=api;
})(typeof window!=='undefined'?window:null,function(){
  'use strict';
  const LIMITS=Object.freeze({files:5000,scanFiles:120,scanChars:4*1024*1024,textChars:262144,previewChars:30000,results:200,queryChars:256});
  const TEXT=new Set(['txt','md','json','jsonl','csv','tsv','log','yaml','yml']);
  const STOP=new Set(['show','me','the','a','an','all','my','please','find','for','about','what','which','where','is','are','in','of','and']);
  const ALIAS={clients:'client',customers:'client',customer:'client',quotes:'estimate',quote:'estimate',estimates:'estimate',invoices:'invoice',photos:'photo',pictures:'photo',picture:'photo',images:'photo',image:'photo',files:'file',documents:'document'};
  function tokens(value){return String(value||'').slice(0,1000000).normalize('NFKC').toLowerCase().match(/[\p{L}\p{N}]+/gu)?.flatMap(x=>x==='birdsbeware'||x==='bbes'?['birds','beware']:[x])||[];}
  function terms(value){return [...new Set(tokens(String(value||'').slice(0,LIMITS.queryChars)).filter(x=>!STOP.has(x)).map(x=>ALIAS[x]||x))];}
  function safePath(value){return typeof value==='string'&&value.length>0&&value.length<=2048&&!/[\\:\u0000-\u001f\u007f]/.test(value)&&value.split('/').every(x=>x&&x!=='.'&&x!=='..'&&!x.startsWith('.'));}
  function ext(path){const n=path.split('/').pop();return n.includes('.')?n.split('.').pop().toLowerCase():'';}
  function category(path){
    const e=ext(path), words=tokens(path).join(' ');
    if(/\bbirds\b|birdsbeware|\bbbes\b/.test(words))return 'Birds Beware';
    if(['png','jpg','jpeg','webp','gif','heic'].includes(e))return 'Images';
    if(TEXT.has(e)||['pdf','doc','docx','xls','xlsx'].includes(e))return 'Documents';
    if(['mp3','m4a','wav','mp4','mov'].includes(e))return 'Audio / video';
    if(['java','py','js','css','html','zip','apk'].includes(e))return 'Software / archives';
    return 'Other';
  }
  function manifest(raw){
    if(!raw||raw.status!=='ok'||!Array.isArray(raw.paths))throw new Error(raw?.status==='locked'?'locked':'unreadable');
    const seen=new Set(), records=[];let skipped=Number.isSafeInteger(raw.skipped)?Math.max(0,raw.skipped):0;
    for(const path of raw.paths.slice(0,LIMITS.files)){
      if(!safePath(path)){skipped++;continue;}if(seen.has(path))continue;seen.add(path);
      records.push({path,name:path.split('/').pop(),category:category(path),text:TEXT.has(ext(path))});
    }
    return {records,skipped,truncated:raw.truncated===true||raw.paths.length>LIMITS.files};
  }
  function match(path,text,query){
    const q=Array.isArray(query)?query:terms(query);
    if(!q.length)return true;
    const hay=new Set(tokens(path+' '+text).map(x=>ALIAS[x]||x));
    return q.every(x=>hay.has(x));
  }
  function excerpt(text,query){
    const lines=String(text).split('\n'),q=terms(query);let idx=lines.findIndex(x=>q.some(t=>tokens(x).map(w=>ALIAS[w]||w).includes(t)));
    if(idx<0)idx=0;return {line:idx+1,text:lines[idx].slice(0,300)};
  }
  function mount(host,native){
    let alive=true,epoch=0,records=[],listingPartial=false,listingSkipped=0;
    function active(){try{return alive&&native?.ownerSessionActive()===true;}catch(_){return false;}}
    function node(tag,text,klass){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(klass)e.className=klass;return e;}
    const heading=node('h1','Files');host.append(heading,node('p','Search imported vault filenames, or scan supported text. Results cite the source; they do not infer payments or other facts.'));
    const form=node('form');form.setAttribute('role','search');
    const input=node('input');input.type='search';input.id='vaultQuery';input.maxLength=LIMITS.queryChars;input.placeholder='Birds Beware clients';input.setAttribute('aria-label','Search imported files');
    const group=node('select');group.id='vaultCategory';group.setAttribute('aria-label','File category');
    ['All files','Birds Beware','Images','Documents','Audio / video','Software / archives','Other'].forEach(x=>{const o=node('option',x);o.value=x;group.append(o);});
    const label=node('label'),include=node('input');include.type='checkbox';include.id='vaultScanText';label.append(include,document.createTextNode(' Include supported text (bounded scan)'));
    const search=node('button','Search');search.type='submit';search.id='vaultSearch';const refresh=node('button','Refresh');refresh.type='button';refresh.id='vaultRefresh';
    const importer=node('button','Import ZIP');importer.type='button';importer.id='vaultImport';
    form.append(input,group,label,search,refresh,importer);host.append(form);
    const status=node('p','Checking owner access…');status.id='vaultSearchStatus';status.setAttribute('role','status');
    const results=node('div');results.id='vaultResults';const preview=node('section');preview.id='vaultPreview';preview.setAttribute('aria-label','Source preview');
    host.append(status,results,preview);
    function erase(){records=[];results.replaceChildren();preview.replaceChildren();input.value='';include.checked=false;}
    function locked(){epoch++;erase();status.textContent='Locked. Unlock ATLAS to read imported files.';for(const control of form.elements)control.disabled=true;}
    async function call(method,...args){if(!active())throw new Error('locked');if(typeof native[method]!=='function')throw new Error('unavailable');const raw=await Promise.resolve(native[method](...args));if(!active())throw new Error('locked');if(typeof raw!=='string'||raw.length>12*1024*1024)throw new Error('unreadable');try{return JSON.parse(raw);}catch(_){throw new Error('unreadable');}}
    function boundary(){return listingPartial?' Partial manifest: the native listing limit was reached.':'';}
    function report(error){if(!alive)return;if(!active()||error.message==='locked'){locked();return;}status.textContent=error.message==='unavailable'?'Native search is unavailable. This screen needs the matching Android candidate.':'Unable to read the vault. No empty-vault or complete-search claim is made.';}
    async function show(record){
      const run=++epoch;preview.replaceChildren();if(!active()){locked();return;}
      preview.append(node('h2',record.name),node('p',record.path,'sourcePath'));
      if(!record.text){preview.append(node('p','Filename indexed. Content preview is not supported for this file type; no file was opened or executed.'));return;}
      try{
        const response=await call('readVaultTextForSearch',record.path);if(!alive||run!==epoch)return;
        if(response.status==='locked'){locked();return;}
        if(response.status!=='ok'||typeof response.text!=='string'||response.text.length>LIMITS.textChars){preview.append(node('p',response.status==='too_large'?'Text exceeds the 256 KiB native limit. No partial plaintext was returned.':'Content unavailable or unsupported. The original file was not changed.'));return;}
        preview.append(node('pre',response.text.slice(0,LIMITS.previewChars)));
        if(response.text.length>LIMITS.previewChars)preview.append(node('p','Preview shortened to 30,000 characters. The source is unchanged.'));
      }catch(error){if(alive&&run===epoch)report(error);}
    }
    function render(rows){results.replaceChildren();for(const row of rows.slice(0,LIMITS.results)){
      const button=node('button',undefined,'fileSearchResult');button.type='button';button.append(node('strong',row.record.name),node('span',row.record.path,'sourcePath'),node('span',row.record.category));
      if(row.hit)button.append(node('span','Line '+row.hit.line+': '+row.hit.text,'sourceExcerpt'));
      button.addEventListener('click',()=>show(row.record));results.append(button);
    }}
    async function runSearch(){
      const run=++epoch;preview.replaceChildren();results.replaceChildren();if(!active()){locked();return;}
      const query=input.value,q=terms(query),scanning=include.checked&&q.length>0;
      const selected=records.filter(x=>group.value==='All files'||x.category===group.value);
      const hits=new Map();for(const record of selected)if(match(record.path,'',q))hits.set(record.path,{record});
      let scanned=0,chars=0,skipped=0,scanPartial=false;status.textContent=scanning?'Scanning bounded text locally…':'Searching filenames…';
      if(scanning){
        const candidates=selected.filter(x=>x.text);
        for(let i=0;i<candidates.length;i++){
          if(scanned>=LIMITS.scanFiles||chars>=LIMITS.scanChars){scanPartial=true;break;}
          const record=candidates[i];scanned++;
          try{
            const response=await call('readVaultTextForSearch',record.path);if(!alive||run!==epoch)return;
            if(response.status==='locked'){locked();return;}
            if(response.status!=='ok'||typeof response.text!=='string'||response.text.length>LIMITS.textChars){skipped++;continue;}
            if(chars+response.text.length>LIMITS.scanChars){scanPartial=true;break;}
            chars+=response.text.length;
            if(match(record.path,response.text,q))hits.set(record.path,{record,hit:excerpt(response.text,query)});
          }catch(error){if(!alive||run!==epoch)return;if(error.message==='locked'||error.message==='unavailable'){report(error);return;}skipped++;}
          await new Promise(resolve=>setTimeout(resolve,0));if(!alive||run!==epoch)return;
        }
      }
      if(!active()){locked();return;}if(run!==epoch)return;
      const rows=[...hits.values()].sort((a,b)=>a.record.path.localeCompare(b.record.path));render(rows);
      status.textContent=`${rows.length} matching file(s); showing ${Math.min(rows.length,LIMITS.results)}. ${records.length} filenames indexed.`+
        (scanning?` Text scan: ${scanned} supported files attempted; ${skipped} unavailable; ${scanPartial?'partial, limit reached':'bounded scan finished'}.`:' Filenames only.')+
        ` ${selected.filter(x=>!x.text).length} files in this category have no text-content support.`+boundary()+
        (listingSkipped?` ${listingSkipped} unsafe or unreadable entries excluded.`:'');
    }
    async function load(){
      const run=++epoch;records=[];results.replaceChildren();preview.replaceChildren();if(!active()){locked();return;}
      status.textContent='Reading authenticated vault manifest…';
      try{const value=await call('listVaultForSearch');if(!alive||run!==epoch)return;const data=manifest(value);records=data.records;listingPartial=data.truncated;listingSkipped=data.skipped;await runSearch();}catch(error){if(alive&&run===epoch)report(error);}
    }
    function dispose(){if(!alive)return;alive=false;epoch++;erase();host.replaceChildren();clearInterval(timer);window.removeEventListener('atlas-owner-locked',onLock);window.removeEventListener('atlas-native-import',onImport);document.removeEventListener('visibilitychange',onHidden);}
    function onLock(){if(alive)locked();}
    function onHidden(){if(document.hidden)onLock();}
    function onImport(){if(active())load();}
    form.onsubmit=e=>{e.preventDefault();runSearch();};group.onchange=runSearch;refresh.onclick=load;
    importer.onclick=()=>{if(!active()){locked();return;}if(typeof native.importSeedZip==='function')native.importSeedZip();else status.textContent='Native ZIP import is unavailable.';};
    window.addEventListener('atlas-owner-locked',onLock);window.addEventListener('atlas-native-import',onImport);document.addEventListener('visibilitychange',onHidden);
    const timer=setInterval(()=>{if(alive&&!active())locked();},1000);
    load();return dispose;
  }
  return Object.freeze({LIMITS,tokens,terms,safePath,ext,category,manifest,match,excerpt,mount});
});
