/* ATLAS Command Universe: source-only, owner-private visual shell on existing 0.8.0 app.
 * No new permissions, network requests, background actions or automatic account sync.
 * All actual application actions are routed into the existing owner-gated shell. */
(() => { 'use strict';
  const $=(s,r=document)=>r.querySelector(s);
  const WORLD_DATA=[
    {id:'mercury',name:'Mercury',type:'Terrestrial',detail:'Sun-facing world with extreme temperature swings and a tenuous exosphere.',challenge:'Thermal cycling, solar exposure, dust.',paint:'mercury'},
    {id:'venus',name:'Venus',type:'Terrestrial',detail:'Dense carbon-dioxide atmosphere; exceptionally hot and high-pressure surface.',challenge:'Heat, pressure, and corrosive cloud chemistry.',paint:'venus'},
    {id:'earth',name:'Earth',type:'Terrestrial',detail:'Only confirmed inhabited planet; oceans, ecosystems and active geology.',challenge:'Ecological sustainability and measured environmental change.',paint:'earth'},
    {id:'mars',name:'Mars',type:'Terrestrial',detail:'Cold, thin atmosphere; robotic missions have explored its surface.',challenge:'Radiation, thin air, dust, distance.',paint:'mars'},
    {id:'jupiter',name:'Jupiter',type:'Gas giant',detail:'Large gas giant with powerful atmospheric storms and many moons.',challenge:'Radiation, winds, increasing pressure, no ordinary solid surface.',paint:'jupiter'},
    {id:'saturn',name:'Saturn',type:'Gas giant',detail:'Gas giant known for its rings and varied moons.',challenge:'Distance, low solar flux, demanding orbital conditions.',paint:'saturn'},
    {id:'uranus',name:'Uranus',type:'Ice giant',detail:'Distant ice giant with a highly tilted rotational axis.',challenge:'Deep cold and very long communications lag.',paint:'uranus'},
    {id:'neptune',name:'Neptune',type:'Ice giant',detail:'Distant blue ice giant with intense atmospheric winds.',challenge:'Distance, low sunlight, extreme cold.',paint:'neptune'}
  ];
  const SOURCE = 'Oct 12 Planetary Future Finder · historical offline research snapshot';
  const escapeHTML=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let page='home', ctx=null, lastWorld='earth', lastWorldFilter='', lastHomeScroll=0;
  const BUTTON = (action,label,extra='')=>`<button type="button" data-omega="${action}" ${extra}>${label}</button>`;
  const ICON={chat:'◈',worlds:'◎',projects:'⌘',files:'▣',learning:'✧',businesses:'◇',store:'◉',atlas:'△',settings:'⚙',memory:'∞',tasks:'✓',voice:'♫',pilot:'◉',start:'+',stats:'◇',galaxy:'⌗',alien:'✧',evolution:'⌁'};
  const node=(action,title,eyebrow,icon)=>`<button type="button" class="omega-node omega-${action}" data-omega="${action}" aria-label="Open ${escapeHTML(title)}"><b aria-hidden="true">${icon}</b><span>${escapeHTML(title)}</span><small>${escapeHTML(eyebrow)}</small></button>`;
  const chooseStatus=()=> ctx?.native?.available?.() ? 'NATIVE OWNER SESSION' : 'BROWSER PREVIEW';
  function header(){return `<header class="omega-head"><span class="omega-identity"><span class="omega-logo" aria-hidden="true">△</span><span><b>ATLAS <em>Ω</em></b><small>COMMAND UNIVERSE</small></span></span><span class="omega-connection" aria-label="Connection status">${escapeHTML(chooseStatus())}</span>${BUTTON('lens','⌕','class="omega-headbtn" aria-label="Search all ATLAS apps"')}${BUTTON('controls','⚙','class="omega-headbtn" aria-label="Quick controls"')}</header>`}
  function footer(){return `<nav class="omega-navigation" aria-label="ATLAS destinations">${[['atlas','◈','Chat'],['home','◎','Universe'],['tasks','◇','Missions'],['files','▣','Vault'],['apps','⌗','All apps']].map(([id,ic,l])=>`<button type="button" data-omega="${id}" ${page==='home'&&id==='home'?'aria-current="page"':''}><span aria-hidden="true">${ic}</span><small>${l}</small></button>`).join('')}</nav><small class="omega-footnote">Owner-controlled prototype · Status is not proof of background work</small>`}
  function home(){
    const recent = ctx?.recent;
    const resume = recent?.[0] ? `<button class="omega-resume" data-omega="resume"><span>CONTINUE</span> ${escapeHTML(recent[1])} <b aria-hidden="true">↗</b></button>` : `<button class="omega-resume" data-omega="start"><span>SET UP</span> Add my files & preferences <b aria-hidden="true">↗</b></button>`;
    return `<div class="omega-intro"><div><span class="omega-overline">YOUR WORLD · ONE SYSTEM</span><h1>Welcome to <em>ATLAS.</em></h1></div><button type="button" class="omega-small" data-omega="classic">Classic apps <span aria-hidden="true">↗</span></button></div>
      <section class="omega-cosmos" aria-label="Explore six real ATLAS destinations">
        <div class="omega-cosmos-halo" aria-hidden="true"></div><div class="omega-orbit omega-orbit-one" aria-hidden="true"></div><div class="omega-orbit omega-orbit-two" aria-hidden="true"></div>
        <button type="button" class="omega-center" data-omega="atlas" aria-label="Open ATLAS Chat and commands"><span class="omega-core-image" aria-hidden="true"></span><span class="omega-center-title">ATLAS CORE</span><small>OPEN ATLAS CHAT</small></button>
        ${node('evolution','Evolution','History & inventions','⌁')}
        ${node('projects','Builds','Your projects','⌘')}
        ${node('files','Vault','Local archive','▣')}
        ${node('worlds','Worlds','Planets & future','◎')}
        ${node('businesses','Business','Birds Beware & more','◇')}
        ${node('store','Concepts','Devices & designs','◈')}
      </section>
      <section class="omega-commandline" aria-label="Ask ATLAS"><label for="omegaAsk">ATLAS COMMAND</label><div><input id="omegaAsk" type="text" spellcheck="true" autocomplete="off" placeholder="Ask ATLAS or enter a command…" aria-label="Question or command for ATLAS" maxlength="1000"><button type="submit" data-omega="ask" aria-label="Open in ATLAS commands">↗</button></div><small>Uses the existing owner-gated ATLAS command surface. Online requests require separate approval.</small></section>
      <div class="omega-ribbon"><span>LOCAL FILES: <b>OPEN TO VERIFY</b></span><span>ONLINE BRAIN: <b>NOT ASSUMED</b></span></div>
      <section class="omega-section"><div class="omega-sectionhead"><h2>Continue your mission</h2><button type="button" data-omega="tasks">Open tasks ↗</button></div><div class="omega-actiongrid">${resume}<button class="omega-resume" data-omega="stats"><span>CHARACTER & INTELLIGENCE</span> LEVEL ONE · AURA · Verified capabilities <b aria-hidden="true">↗</b></button><button class="omega-resume" data-omega="library-transfer"><span>YOUR LIBRARY</span> Download & import saved files <b aria-hidden="true">↗</b></button><button class="omega-resume" data-omega="playlist"><span>MEDIA & LEARNING</span> ATLAS YouTube playlist <b aria-hidden="true">↗</b></button><button class="omega-resume" data-omega="games"><span>GAME WORLD</span> Chess · Estate · FPS · Wordcraft <b aria-hidden="true">↗</b></button><button class="omega-resume" data-omega="currency"><span>VALUE LAB</span> A1V · ATC · AXU (research only) <b aria-hidden="true">↗</b></button><button class="omega-resume" data-omega="evolution"><span>EVOLUTION OF EVERYTHING</span> Footsteps · pigeons · texts · medicine · clothing <b aria-hidden="true">↗</b></button><button class="omega-resume" data-omega="recovered"><span>RECOVERED WORK</span> Search archived app modules <b aria-hidden="true">↗</b></button></div></section>
      <section class="omega-section omega-quick"><div class="omega-sectionhead"><h2>Quick access</h2></div><div class="omega-quickrow">${[['pilot','Voice & Phone'],['galaxy','All Apps'],['evolution','Evolution'],['alien','Alien Mode'],['stats','Stats'],['memory','Memory'],['voice','Voice'],['access','Access'],['settings','Settings'],['start','Add files']].map(([id,label])=>`<button data-omega="${id}" type="button"><b aria-hidden="true">${ICON[id]}</b><span>${label}</span></button>`).join('')}</div></section>`;
  }
  function worlds(){
    return `<section class="omega-detailhead"><span class="omega-overline">FUTURE FINDER · OFFLINE RESEARCH</span><h1>Explore the <em>worlds.</em></h1><p>Eight planets, selected facts and environmental barriers. This research view is not live mission telemetry or real planetary travel.</p></section>
      <label class="omega-worldfilter">Search worlds<input id="omegaWorldSearch" value="${escapeHTML(lastWorldFilter)}" placeholder="Search planet or type…" autocomplete="off" aria-label="Search worlds"></label><div id="omega-world-cards" class="omega-worldcards"></div><section id="omega-world-detail" aria-live="polite" class="omega-worlddetail"></section><p class="omega-source">${escapeHTML(SOURCE)}. For updated missions and science, visit <a href="https://science.nasa.gov/solar-system/" target="_blank" rel="noopener noreferrer">NASA Solar System Science</a> when online.</p>`;
  }
  function playlist(){
    return `<section class="omega-detailhead"><span class="omega-overline">MEDIA · PERSONAL LEARNING</span><h1>ATLAS <em>playlist.</em></h1><p>The saved master playlist and channel links are available. No YouTube account connection, writeback, transcript indexing or video-count verification is claimed by this screen.</p></section>
      <div class="omega-playcard"><h2>ATLAS ∞ — Everything / Anything / Nothing</h2><p>One master library of videos and research topics.</p><div class="omega-playactions"><button type="button" data-omega="youtubePlaylist">Open master playlist ↗</button><button type="button" data-omega="youtubeChannel">Open channel ↗</button></div><small>Status: links provided by owner; live contents unknown until authorized account retrieval.</small></div>
      <div class="omega-playcard"><h2>Keep learning offline</h2><p>Use Learning and Files for already saved material. Importing metadata is not proof a video was watched or downloaded.</p><div class="omega-playactions"><button type="button" data-omega="learning">Learning</button><button type="button" data-omega="files">My files</button></div></div>`;
  }
  function renderWorldCards(){const holder=$('#omega-world-cards');if(!holder)return;const q=lastWorldFilter.toLowerCase().trim();const items=WORLD_DATA.filter(w=>[w.name,w.type,w.detail,w.challenge].join(' ').toLowerCase().includes(q));holder.innerHTML=items.length?items.map(w=>`<button type="button" class="omega-world ${w.id===lastWorld?'selected':''}" data-world="${w.id}" aria-pressed="${w.id===lastWorld}"><span class="omega-planet ${w.paint}" aria-hidden="true"></span><b>${w.name}</b><small>${w.type}</small></button>`).join(''):'<p>No matching worlds in the saved eight-planet index.</p>';holder.querySelectorAll('[data-world]').forEach(b=>b.onclick=()=>{lastWorld=b.dataset.world;renderWorldCards()});renderWorldDetail()}
  function renderWorldDetail(){const place=$('#omega-world-detail');if(!place)return;const w=WORLD_DATA.find(x=>x.id===lastWorld)||WORLD_DATA[2];place.innerHTML=`<span class="omega-overline">SELECTED WORLD · RESEARCH SNAPSHOT</span><h2>${escapeHTML(w.name)}</h2><p>${escapeHTML(w.detail)}</p><h3>Engineering barriers</h3><p>${escapeHTML(w.challenge)}</p><button type="button" data-omega="projects">Open invention projects ↗</button>`;place.querySelector('[data-omega="projects"]').onclick=()=>ctx?.open('projects')}
  function external(link){if(ctx?.native?.available?.()){ctx.native.call('openUrl',link)}else if(typeof window.open==='function'){window.open(link,'_blank','noopener,noreferrer')}}
  function go(action){
    if(page==='home'&&$('#omega-main'))lastHomeScroll=$('#omega-main').scrollTop;
    if(action==='home'||action==='worlds'||action==='playlist'){page=action;render(ctx);return;}
    if(action==='classic'){page='home';if(window.ATLASModeBridge?.set?.('apps'))return;ctx?.switchClassic?.();return;}
    if(action==='apps'){ctx?.allApps?.();return;}
    if(action==='lens'){window.ATLASExperience?.lens?.();return;}
    if(action==='galaxy'){ctx?.open?.('galaxy');return;}
    if(action==='controls'){ctx?.control?.();return;}
    if(action==='resume'){if(ctx?.recent?.[0])ctx.open(ctx.recent[0]);else ctx.open('start');return;}
    if(action==='ask'){const input=$('#omegaAsk');ctx?.ask?.(input?.value?.trim()||'');return;}
    if(action==='youtubePlaylist'){external('https://www.youtube.com/playlist?list=PLFJtW3uU13jM');return;}
    if(action==='youtubeChannel'){external('https://www.youtube.com/@shaunreviewstech2618');return;}
    if(['pilot','library-transfer','god','files','projects','businesses','store','learning','start','memory','voice','settings','tasks','atlas','games','currency','recovered','access','stats','alien','evolution'].includes(action)){ctx?.open(action);return;}
  }
  function render(context){if(context)ctx=context;if(!ctx?.root)return;
    const root=ctx.root;
    root.innerHTML=`<div class="omega-universe"><div class="omega-atmosphere" aria-hidden="true"></div>${header()}${window.ATLASModeBridge?.render?.()||''}<main class="omega-scroll" id="omega-main">${page==='home'?home():page==='worlds'?worlds():playlist()}</main>${footer()}</div>`;
    window.ATLASModeBridge?.bindButtons?.(root);
    root.querySelectorAll('[data-omega]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.omega)));
    const input=$('#omegaAsk'); if(input)input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();go('ask')}});
    if(page==='home'&&$('#omega-main'))$('#omega-main').scrollTop=lastHomeScroll;
    const filter=$('#omegaWorldSearch');if(filter){filter.addEventListener('input',e=>{lastWorldFilter=String(e.target.value).slice(0,100);renderWorldCards()});renderWorldCards()}
  }
  function back(){if(!$('.omega-universe')||page==='home')return false;page='home';render();return true;}
  function reset(){page='home';}
  window.ATLASUniverse=Object.freeze({render,back,reset,worlds:()=>WORLD_DATA.map(x=>x.name)});
})();
