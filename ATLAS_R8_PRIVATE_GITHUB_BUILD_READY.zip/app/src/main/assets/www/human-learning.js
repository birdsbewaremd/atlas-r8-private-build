/* Owner-only native learning screen. No localStorage, network, background profiling, or execution. */
(function(root){'use strict';
  let disposeCurrent=()=>{};
  const messages={OWNER_UNLOCK_REQUIRED:'Unlock ATLAS to use your learning profile.',NO_PROFILE:'No learning profile exists. Nothing has been saved.',CONSENT_REQUIRED:'Personalization is off. Your existing record remains available for inspection or deletion.',REVISION_CONFLICT:'The record changed. Refresh before trying again; nothing was overwritten.',CONFIRMATION_REQUIRED:'Confirm deletion first.',STORAGE_UNAVAILABLE:'Storage could not be verified. Refresh before retrying; no successful save is claimed.',INVALID_INPUT:'That input was not accepted.',ATTEMPT_LIMIT:'The practice record limit was reached. Existing records were preserved.',EVIDENCE_REQUIRED:'A completed or staged claim needs an evidence reference.'};
  function dispose(){disposeCurrent();disposeCurrent=()=>{};}
  function mount({host,request,sessionActive,onLock,speak}){
    dispose();let profile=null,alive=true,busy=false,lesson=null,pendingAttempt=null,seq=0;
    const by=id=>host.querySelector('#'+id);
    const text=(id,s)=>{const el=by(id);if(el)el.textContent=s||'';};
    const stamp=()=>({generation:profile.generation,revision:profile.revision});
    const preferences=()=>({detail:by('hl-detail').value,examples:by('hl-examples').checked,practice:by('hl-practice').value});
    function clearPrivate(){profile=null;lesson=null;pendingAttempt=null;seq++;host.replaceChildren();}
    function revokeView(){if(!alive)return;clearPrivate();const p=document.createElement('p');p.textContent='Learning view locked. Reopen it after unlocking ATLAS.';host.appendChild(p);dispose();onLock();}
    async function call(q){
      if(!alive||!host.isConnected)throw Error('VIEW_CLOSED');
      if(!sessionActive()){revokeView();throw Error('OWNER_UNLOCK_REQUIRED');}
      const epoch=seq;let raw=await request(JSON.stringify(q));
      if(!alive||!host.isConnected||epoch!==seq)throw Error('VIEW_CLOSED');
      if(!sessionActive()){revokeView();throw Error('OWNER_UNLOCK_REQUIRED');}
      let result;try{result=typeof raw==='string'?JSON.parse(raw):raw;}catch{throw Error('STORAGE_UNAVAILABLE');}
      if(!result||result.ok!==true){const code=result&&result.error||'STORAGE_UNAVAILABLE';if(code==='OWNER_UNLOCK_REQUIRED')revokeView();throw Error(code);}
      return result.data;
    }
    async function act(fn){if(busy||!alive)return;busy=true;disable(true);try{await fn();}catch(e){if(alive&&e.message!=='VIEW_CLOSED'){text('hl-status',messages[e.message]||'The action could not be verified. Refresh before retrying.');if(e.message==='REVISION_CONFLICT'||e.message==='STORAGE_UNAVAILABLE')text('hl-progress','');}}finally{busy=false;disable(false);}}
    function disable(flag){host.querySelectorAll('button').forEach(b=>{b.disabled=flag;});}
    function base(){host.innerHTML=`
      <section class="hl-intro"><span class="nativeReq">OWNER LEARNING · LOCAL CANDIDATE</span><h1>Make it clear.<br>Then make it useful.</h1><p>Choose how ATLAS explains things. Practice is optional. This screen does not connect the general AI backend.</p></section>
      <p id="hl-status" role="status" aria-live="polite" class="hl-status"></p>
      <section class="card"><h2>Your communication preferences</h2><p id="hl-consent-state"></p>
        <label class="hl-row" for="hl-detail">Detail <select id="hl-detail"><option value="brief">Brief</option><option value="standard">Standard</option><option value="detailed">Detailed</option></select></label>
        <label class="hl-row"><span>Include a useful example</span><input type="checkbox" id="hl-examples" checked></label>
        <label class="hl-row" for="hl-practice">Practice <select id="hl-practice"><option value="optional">Optional</option><option value="off">Off</option></select></label>
        <label class="hl-check" id="hl-optin-row"><input type="checkbox" id="hl-optin"> I agree to save these preferences and exercise results on this device.</label>
        <div class="hl-actions"><button id="hl-save" class="pill">Enable and save</button><button id="hl-refresh" class="pill">Refresh</button><button id="hl-consent" class="pill" hidden>Turn personalization off</button></div>
        <p class="muted">Off by default. No private Shaun OS import, inferred personality, diagnosis, shared learner profile, or automatic cloud sync. Native encryption protects this new record at rest; the rest of the app has separate limits.</p></section>
      <section id="hl-preview-card" class="card" hidden><h2>Reply format</h2><p class="muted">Synthetic status example—not a claim that your app is deployed.</p><pre id="hl-preview" class="hl-pre"></pre><button id="hl-read" class="pill">Read example aloud</button><p class="muted">Uses your configured Android speech engine; its handling of text is separate.</p></section>
      <section id="hl-lesson-card" class="card" hidden><h2>Explain → try → correct</h2><label for="hl-lesson">Practice topic</label><select id="hl-lesson"><option value="job-contribution-v1">Cash versus job contribution</option><option value="deployment-evidence-v1">Source versus deployment</option></select>
        <label class="hl-check"><input type="checkbox" id="hl-urgent"> Urgent: explanation only</label>
        <h3 id="hl-goal"></h3><p id="hl-explain"></p><p id="hl-example"></p>
        <div id="hl-practice-area"><label id="hl-question" for="hl-answer"></label><input id="hl-answer" maxlength="120" autocomplete="off" placeholder="Your answer"><label class="hl-check"><input type="checkbox" id="hl-assisted" checked> I used help or the worked explanation</label><button id="hl-submit" class="pill">Check my answer</button></div>
        <p id="hl-feedback" role="status" aria-live="polite"></p><p id="hl-progress" class="muted"></p></section>
      <section id="hl-controls" class="card" hidden><h2>Your record, your controls</h2><div class="hl-actions"><button id="hl-export" class="pill">Export preview</button><button id="hl-hide-export" class="pill" hidden>Hide preview</button></div><p class="muted">Profile-only JSON is shown here. Nothing is sent or written to an external file.</p><textarea id="hl-export-text" aria-label="Profile-only export preview" readonly hidden spellcheck="false"></textarea>
        <label class="hl-check"><input type="checkbox" id="hl-delete-confirm"> Delete this device's active learning record. Exported copies and backups are not erased.</label><button id="hl-delete" class="pill hl-danger">Delete learning record</button></section>`;
      by('hl-save').onclick=()=>act(async()=>{
        if(!profile){if(!by('hl-optin').checked){text('hl-status','Check the consent box first. Nothing was saved.');return;}profile=await call({op:'create',consent:true,preferences:preferences()});}
        else {if(!profile.consent_active){text('hl-status','Turn personalization on before changing preferences.');return;}profile=await call({op:'update',...stamp(),preferences:preferences()});}
        pendingAttempt=null;await show('Saved on this device. Your communication preferences are ready.');
      });
      by('hl-refresh').onclick=()=>act(load);
      by('hl-consent').onclick=()=>act(async()=>{profile=await call({op:'consent',...stamp(),active:!profile.consent_active});pendingAttempt=null;await show(profile.consent_active?'Personalization is on again.':'Personalization is off. The existing record was not deleted.');});
      by('hl-lesson').onchange=()=>act(loadLesson);by('hl-urgent').onchange=()=>act(loadLesson);
      by('hl-submit').onclick=()=>act(async()=>{
        if(!lesson||!lesson.practice)return;
        const answer=by('hl-answer').value.trim();if(!answer){text('hl-feedback','Enter an answer first.');return;}
        const spec={lesson_id:lesson.lesson_id,answer,assisted:by('hl-assisted').checked};
        const signature=JSON.stringify(spec);
        // Preserve the same ID on uncertain retries. Changed answers get a new ID.
        if(!pendingAttempt||pendingAttempt.signature!==signature)pendingAttempt={id:uuid(),signature,stamp:stamp()};
        const result=await call({op:'submit',...pendingAttempt.stamp,attempt_id:pendingAttempt.id,...spec});profile=result.profile;
        text('hl-feedback',result.feedback);await progress();
      });
      by('hl-export').onclick=()=>act(async()=>{const data=await call({op:'export'});by('hl-export-text').value=JSON.stringify(data.profile,null,2);by('hl-export-text').hidden=false;by('hl-hide-export').hidden=false;text('hl-status','Export preview opened. No file or message was sent.');});
      by('hl-hide-export').onclick=()=>{by('hl-export-text').value='';by('hl-export-text').hidden=true;by('hl-hide-export').hidden=true;};
      by('hl-delete').onclick=()=>act(async()=>{
        if(!by('hl-delete-confirm').checked){text('hl-status','Confirm deletion first. Nothing was deleted.');return;}
        await call({op:'delete',...stamp(),confirmed:true});profile=null;pendingAttempt=null;lesson=null;await show('Deleted this device’s active learning record. Exported copies and backups were not erased.');
      });
      by('hl-read').onclick=()=>act(async()=>{await call({op:'progress'});speak(by('hl-preview').textContent);text('hl-status','Speech requested from the device. Playback is not yet verified.');});
    }
    function uuid(){if(root.crypto&&root.crypto.randomUUID)return root.crypto.randomUUID();const b=new Uint8Array(16);root.crypto.getRandomValues(b);b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;const x=Array.from(b,v=>v.toString(16).padStart(2,'0')).join('');return `${x.slice(0,8)}-${x.slice(8,12)}-${x.slice(12,16)}-${x.slice(16,20)}-${x.slice(20)}`;}
    async function load(){try{profile=await call({op:'inspect'});}catch(e){if(e.message!=='NO_PROFILE')throw e;profile=null;}pendingAttempt=null;await show(profile?'Loaded this device’s learning record.':'No learning profile exists. Nothing has been saved.');}
    async function show(message){
      if(!alive)return;base();text('hl-status',message);
      const exists=!!profile,active=exists&&profile.consent_active;
      by('hl-optin-row').hidden=exists;by('hl-controls').hidden=!exists;by('hl-consent').hidden=!exists;
      by('hl-preview-card').hidden=!active;by('hl-lesson-card').hidden=!active;
      text('hl-consent-state',exists?`Personalization ${active?'on':'off'} · revision ${profile.revision} · sharing disabled`:'Personalization off · no saved record');
      by('hl-save').textContent=exists?'Save preferences':'Enable and save';by('hl-consent').textContent=active?'Turn personalization off':'Turn personalization on';
      if(exists){by('hl-detail').value=profile.preferences.detail;by('hl-examples').checked=profile.preferences.examples;by('hl-practice').value=profile.preferences.practice;}
      if(active){
        const update={status:'staged',outcome:'The source checks passed',next_action:'Test the app on the phone',evidence_refs:['Synthetic example: local source-test receipt'],details:['Source tests check code behavior.','An installable APK is a separate step.','Your real-world learning outcomes have not been measured.'],blockers:['No phone-install result in this example.'],warnings:['Do not describe source-tested code as deployed.'],deadline:null};
        const response=await call({op:'render',update});text('hl-preview',response.text);await loadLesson();
      }
    }
    async function loadLesson(){
      pendingAttempt=null;lesson=await call({op:'lesson',lesson_id:by('hl-lesson').value,urgent:by('hl-urgent').checked});
      text('hl-goal',lesson.goal);text('hl-explain',lesson.explain);text('hl-example',lesson.example);text('hl-question',lesson.practice);
      by('hl-practice-area').hidden=!lesson.practice;by('hl-answer').value='';text('hl-feedback','');await progress();
    }
    async function progress(){const p=await call({op:'progress'});text('hl-progress',`${p.correct} correct out of ${p.attempts} recorded attempts. Independence, retention, and mastery are not established.`);}
    const hidden=()=>{if(document.hidden)revokeView();};
    const observer=new MutationObserver(()=>{if(!host.isConnected)dispose();});observer.observe(document.body,{childList:true,subtree:true});
    const timer=setInterval(()=>{if(!host.isConnected){dispose();return;}if(!sessionActive())revokeView();},500);
    root.addEventListener('atlas-learning-locked',revokeView);document.addEventListener('visibilitychange',hidden);
    disposeCurrent=()=>{alive=false;seq++;profile=null;lesson=null;pendingAttempt=null;clearInterval(timer);observer.disconnect();root.removeEventListener('atlas-learning-locked',revokeView);document.removeEventListener('visibilitychange',hidden);};
    act(load);
  }
  root.AtlasLearning=Object.freeze({mount,dispose});
})(window);
