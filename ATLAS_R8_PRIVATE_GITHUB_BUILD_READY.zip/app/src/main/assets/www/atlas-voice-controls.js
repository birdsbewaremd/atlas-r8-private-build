/* ATLAS Ω Voice & Controls V1 — explicit owner action only.
 * Source-only; reuses verified 0.8.x native handlers, grants NO permissions.
 * Voice Access by Google is NOT the ATLAS wake word. No screen-off hotword claim. */
(()=>{'use strict';
  let host=null, listener=null, ctx=null;
  const $=(q)=>document.querySelector(q);
  const esc=(v)=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const safeParse=(s)=>{try{const v=JSON.parse(s);return v&&typeof v==='object'&&!Array.isArray(v)?v:{}}catch{return {}}};
  const isNative=()=>!!ctx?.native?.available?.();
  const owner=()=>!!ctx?.ownerActive?.();
  const permitted=()=>isNative()&&owner();
  const out=(message)=>{const el=$('#atvc-result');if(el)el.textContent=String(message||'');};
  const bridge=(name,...args)=>{
    if(!permitted()){out(isNative()?'Unlock ATLAS before using device controls.':'Device controls require ATLAS Native.');return null;}
    return ctx.native.call(name,...args);
  };
  const refresh=()=>{
    if(!$('#atvc-root'))return;
    const active=permitted();
    const wake=active&&!!ctx.native.call('heyAtlasEnabled');
    const power=active?safeParse(ctx.native.call('deviceStatus')):{};
    const label=$('#atvc-mode-status');if(label)label.textContent=isNative()?(active?'NATIVE · OWNER UNLOCKED':'NATIVE · LOCKED'):'BROWSER DEMO';
    const st=$('#atvc-wake-state');if(st)st.textContent=active?(wake?'Wake requested · foreground only':'Wake not enabled'):'Native owner session required';
    const b=$('#atvc-wake');if(b){b.textContent=wake?'Stop Hey ATLAS':'Start Hey ATLAS';b.disabled=!active;}
    const p=$('#atvc-battery');if(p)p.textContent=Number.isFinite(power.battery)&&power.battery>=0&&power.battery<=100?power.battery+'%':'Not available';
    const s=$('#atvc-phone-status');if(s)s.textContent=active?`${power.model?String(power.model).slice(0,45)+' · ':''}${typeof power.charging==='boolean'?(power.charging?'Charging · ':'Not charging · '):''}${power.network||'Network unknown'}`:'No device data read';
    document.querySelectorAll('#atvc-root [data-native]').forEach(b=>{b.disabled=!active});
  };
  const stop=()=>{
    if(!isNative()){out('Browser preview only. No ATLAS native microphone is available.');return;}
    // STOP can only decrease sensing. Keep accessible even if the owner session times out.
    for(const name of ['stopListening','stopSpeaking','stopHeyAtlas'])ctx.native.call(name);
    out('Stop requested for ATLAS wake, speech recognition and speaking. Check the Android microphone indicator.');
    refresh();
  };
  const route=(id)=>{
    if(!owner()){out('Unlock ATLAS before switching views.');return;}
    if(id==='universe'||id==='classic'){
      const next=id==='classic'?'apps':'universe';
      if(window.ATLASModeBridge?.set?.(next))return;
      out('View switch not available; open the ATLAS view selector.');return;
    }
    ctx.open(id);
  };
  function open(context){
    dispose();ctx=context;
    const active=permitted();
    ctx.frame('Voice & Controls',`<main class="atvc" id="atvc-root" aria-label="ATLAS Voice and phone controls">
      <header class="atvc-hero"><div class="atvc-eyebrow">ATLAS Ω · OWNER CONTROL</div><div class="atvc-orb" aria-hidden="true">△</div><h1>Speak. Tap.<br><em>Take control.</em></h1><p>One place for the real ATLAS voice features and supported phone controls.</p><div class="atvc-chip" id="atvc-mode-status">${active?'NATIVE · OWNER UNLOCKED':'BROWSER DEMO'}</div></header>
      <nav class="atvc-layout" aria-label="ATLAS layout switching"><button type="button" data-nav="universe">◈ <span>Universe</span></button><button type="button" data-nav="classic">▦ <span>Apps layout</span></button><button type="button" data-nav="galaxy">⌕ <span>All apps</span></button></nav>
      <section class="atvc-panel" aria-label="Voice commands"><div class="atvc-section"><h2>Talk with ATLAS</h2><span class="atvc-dot">ON DEMAND</span></div><p>Say “ATLAS” in the app only when native recognition is available. This is not a continuous system hotword.</p>
        <div class="atvc-primary"><button id="atvc-talk" data-native>◖ <b>Talk now</b></button><button id="atvc-command">⌘ <b>Type / command</b></button></div>
        <p class="atvc-live" id="atvc-voice-state" role="status" aria-live="polite">${esc(context.voiceState?.()||'READY')}</p>
        <div class="atvc-actions"><button id="atvc-wake" data-native>Start Hey ATLAS</button><button id="atvc-stop" class="atvc-stop">■ STOP ALL</button></div><small id="atvc-wake-state">Foreground only · no audio saved</small>
      </section>
      <section class="atvc-panel"><div class="atvc-section"><h2>Your phone</h2><span class="atvc-dot">OWNER TAP</span></div>
        <div class="atvc-batterycard"><div><span>BATTERY</span><strong id="atvc-battery">—</strong></div><small id="atvc-phone-status">Read on refresh</small><button id="atvc-refresh" data-native>Refresh</button></div>
        <div class="atvc-tiles"><button data-native data-command="flashlight on"><b>◈</b>Flash on</button><button data-native data-command="flashlight off"><b>◇</b>Flash off</button><button data-native data-command="volume up"><b>＋</b>Volume up</button><button data-native data-command="volume down"><b>−</b>Volume down</button><button data-native data-panel="wifi"><b>⌁</b>Wi-Fi settings</button><button data-native data-panel="bt"><b>⌘</b>Bluetooth</button><button data-native data-panel="battery"><b>◷</b>Battery settings</button><button data-native data-panel="home"><b>⌂</b>Home app settings</button></div>
      </section>
      <section class="atvc-panel"><h2>Voice setup · not the same service</h2><p><strong>Google Voice Access</strong> controls Android by spoken navigation commands. <strong>Hey ATLAS</strong> uses a separate opt-in ATLAS foreground listener. The screenshots you shared are Google Voice Access settings.</p><div class="atvc-actions"><button id="atvc-accessibility" data-native>Android Voice Access settings</button><button id="atvc-assistant" data-native>Choose ATLAS Assistant</button><button id="atvc-permissions">ATLAS Access Center</button></div><p class="atvc-note">Google Voice Access's “No key assigned” only refers to an optional physical key/switch. The accessibility shortcut can work without one.</p></section>
      <section class="atvc-panel atvc-privacy"><h2>Real limits & privacy</h2><p>ATLAS wake recognition in this build is <b>foreground-only</b> and stops when the app leaves the screen. It does not enable 24/7 locked-screen monitoring. Android requires consent and supported permissions; microphone and camera are never enabled automatically. External speech services may process audio depending on their own settings.</p></section>
      <p id="atvc-result" class="atvc-feedback" role="status" aria-live="polite">${active?'Ready for your command. Nothing starts automatically.':'Browser preview only. No phone actions are available here.'}</p>
    </main>`);
    host=$('#atvc-root');
    host.querySelectorAll('[data-nav]').forEach(b=>b.onclick=()=>route(b.dataset.nav));
    $('#atvc-command').onclick=()=>route('atlas');
    $('#atvc-talk').onclick=()=>{if(!permitted())return out('ATLAS Native and owner unlock are required.');ctx.listenOnce?.();out('One-shot voice request started; watch Android microphone indicator.');};
    $('#atvc-wake').onclick=()=>{
      if(!permitted())return out('Unlock ATLAS Native first.');
      const armed=!!ctx.native.call('heyAtlasEnabled');bridge(armed?'stopHeyAtlas':'startHeyAtlas');
      out(armed?'Stop requested; check voice status.':'Start requested; approve Android microphone access if prompted. Foreground only.');
      // Readback is separate from the request; never claim enabled until native confirms.
      refresh();
    };
    $('#atvc-stop').onclick=stop;
    $('#atvc-refresh').onclick=()=>{refresh();out(permitted()?'Native device status read where available.':'Native owner session required; no device information read.');};
    host.querySelectorAll('[data-command]').forEach(b=>b.onclick=()=>{
      const reply=bridge('runCommand',b.dataset.command);if(reply!==null)out('Native response: '+String(reply).slice(0,110));
    });
    host.querySelectorAll('[data-panel]').forEach(b=>b.onclick=()=>{bridge('openSystemPanel',b.dataset.panel);out('Android Settings requested. Any change requires your action.');});
    $('#atvc-accessibility').onclick=()=>{bridge('openSystemPanel','accessibility');out('Android Accessibility settings requested; ATLAS did not change permissions.');};
    $('#atvc-assistant').onclick=()=>{bridge('requestAssistantRole');out('Android Assistant choice requested; confirm in Android Settings if offered.');};
    $('#atvc-permissions').onclick=()=>route('access');
    listener=e=>{if(!$('#atvc-root'))return;const s=String(e?.detail?.state||'READY');const el=$('#atvc-voice-state');if(el)el.textContent=s;};
    window.addEventListener('atlas-voice',listener);
    refresh();
  }
  function dispose(){if(listener){window.removeEventListener('atlas-voice',listener);listener=null;}ctx=null;host=null;}
  window.ATLASVoiceControls=Object.freeze({open,dispose});
})();
