/* Source-of-truth paths are owner Library references, not local executable modules. */
const LIBRARY_BUILD_NAMES = [
 'ATLAS_ALL_SIDES_V1_PRIVATE_2026-10-11','ATLAS_CHAT_FAILSAFE_V1_2026-10-12','ATLAS_CHAT_VISUAL_COMPANION_V1_2026-10-12','ATLAS_EVERYWHERE_SENSING_V0_1_2026-10-12',
 'ATLAS_FUTURE_FORGE_V1_5_1_NO_OVERLAP_2026-10-11','ATLAS_FUTURE_FORGE_V1_5_2026-10-11','ATLAS_GENESIS_GOD_ONE_TAP_V7_2026-10-12','ATLAS_HUMAN_FIRST_V4_1_2026-10-11',
 'ATLAS_MASTER_UI_V3_3_2026-10-11','ATLAS_MOBILE_TECH_LAB_V1_2026-10-12','ATLAS_OMEGA_GOD_GUARD_V3_1_2026-10-12','ATLAS_OMEGA_GOD_ONE_TAP_V4_2026-10-12',
 'ATLAS_OMEGA_OFFLINE_DUCKY_V3_2_2026-10-12','ATLAS_ONE_CONTROL_FIX_V0_5_2026-10-12','ATLAS_ONE_FIELD_HQ_V0_6_2026-10-12','ATLAS_OS_CONTINUITY_V1_7_2026-10-11',
 'ATLAS_SENTINEL_SECURITY_V1_1_2026-10-11','ATLAS_SENTINEL_SECURITY_V1_2026-10-11','ATLAS_SENTINEL_UNBLOCK_V1_2_2026-10-11','ATLAS_SHIELD_SECURITY_V1_2026-10-12'
];
const LIBRARY_MODULE_NAMES = [
 'ATLAS_APEX_GOVSHIELD_V0_2_2026-10-12','ATLAS_APEX_UNIVERSAL_HARDWARE_V0_1_2026-10-12','ATLAS_ARGUE_ANDROID_HANDOFF_V1_2_2026-10-12','ATLAS_ARGUE_MODE_2026-10-12',
 'ATLAS_ARGUE_OMNIGENESIS_V1_1_2026-10-12','ATLAS_COMMANDMENT_XI_SOVEREIGN_CREATION_V1_2026-10-12','ATLAS_ECHO_GOD_V1_2026-10-12','ATLAS_G56_TECH_BRAIN_DIAG_LANGUAGE_V1_2_2026-10-12',
 'ATLAS_GEN1_COMMAND_FORGE_V0_1_2026-10-12','ATLAS_GIDEON_PLUS_V1_2026-10-12','ATLAS_LIFE_OS_V1_2026-10-12','ATLAS_LIMIT_FORGE_V1_2026-10-12',
 'ATLAS_MISSION_HORIZON_V1_2026-10-12','ATLAS_MISSION_HORIZON_V2_SBH_INNOVATIONS_2026-10-12','ATLAS_OCT13_ROBOT_LANGUAGE_MISSION_V1_2026-10-12','ATLAS_OMNISCOPE_UNIVERSAL_PERSPECTIVES_V1_2026-10-12',
 'ATLAS_POWER_LOOP_V1_2026-10-12','ATLAS_QUIET_MODE_V1_2026-10-12','ATLAS_QUIT_MODE_V1_2026-10-12','ATLAS_SCHOOL_FUTURE_FINDER_V1_2026-10-12','ATLAS_SIGNAL_MUSIC_V1_2026-10-12',
 'ATLAS_THERMAL_SHIELD_G56_2_2026-10-12'
];
const BUNDLED = [
 {id:'omega',name:'ATLAS OMEGA · GOD One-Tap V4',source:'ATLAS_OMEGA_GOD_ONE_TAP_V4_2026-10-12',path:'modules/ATLAS_OMEGA_GOD_ONE_TAP_V4_2026-10-12.html',kind:'HQ',sourceKind:'existing HTML, unmodified'},
 {id:'limit',name:'ATLAS LIMIT FORGE V1',source:'ATLAS_LIMIT_FORGE_V1_2026-10-12',path:'modules/ATLAS_LIMIT_FORGE_OPEN_V1.html',kind:'Forge',sourceKind:'existing HTML, unmodified'},
 {id:'gen1',name:'ATLAS GEN1 Command Forge V0.1',source:'ATLAS_GEN1_COMMAND_FORGE_V0_1_2026-10-12',path:'modules/ATLAS_GEN1_COMMAND_FORGE_V0_1.html',kind:'Governance',sourceKind:'existing HTML extracted byte-for-byte from owner ZIP'},
 {id:'field',name:'ATLAS ONE · Field HQ V0.6',source:'ATLAS_ONE_FIELD_HQ_V0_6_2026-10-12',path:'modules/ATLAS_ONE_FIELD_HQ_V0_6_OFFLINE.html',kind:'Field',sourceKind:'existing HTML, unmodified'}
];
const REFERENCE_ONLY = [...LIBRARY_BUILD_NAMES.map(name=>({name,folder:'Builds'})),...LIBRARY_MODULE_NAMES.map(name=>({name,folder:'Modules'}))].filter(x=>!BUNDLED.some(b=>b.source===x.name));
const APP_TEMPLATES = [
 ['checklist','Checklist','Check and finish tasks','Task one\nTask two\nTask three'],
 ['inventory','Inventory','Track equipment and quantities','Ladder | 3\nPressure washer | 2\nSafety cones | 8'],
 ['field','Field log','Keep dated job notes','Arrival and setup\nWork completed\nFollow-up'],
 ['quote','Service quote','Calculate itemized estimates','Gutter cleaning | 1 | 150\nWindow cleaning | 1 | 125'],
 ['flashcards','Study cards','Review question and answer cards','What is offline-first? | Core functions work without internet\nWhat is zero trust? | Verify access on each boundary'],
 ['goals','Goal tracker','Track milestones and habits','Revenue target\nHealth and training\nProduct testing'],
 ['links','Resource library','Organize URLs locally','KJV | https://www.gutenberg.org\nDocumentation | https://developer.mozilla.org'],
 ['intake','Customer intake','Record local contact requests','Name\nPhone\nService needed\nAddress'],
 ['schedule','Daily schedule','Plan time blocks','08:00 | Training\n10:00 | Jobs\n17:00 | Build review'],
 ['prompts','Prompt library','Store repeatable instructions','Test boundaries | State objective, constraints, assumptions and tests\nRelease gate | List evidence and blockers']
].map(([id,label,description,seed])=>({id,label,description,seed}));
