# ATLAS Android v0.3.3 — converged phone source

Status: **STAGED PRIVATE / SOURCE TESTED / NOT COMPILED / NOT INSTALLED / NOT REAL-DEVICE TESTED**.

Deep Sync re-read the actual canonical v0.3.2 frontier rather than trusting filename/version recency. The canonical baseline is `ATLAS_ANDROID_SOURCE_v0.3.2.zip`, SHA-256 `f804b8e602c624cc39e09dc8f2c181a8494d6397bc4f364e239a89e51034219e`, 1,747,558 bytes. v0.3.3 is a deliberate superset candidate built from that verified behavior plus the newer owner/frame/transcript voice work.

## Preserved from canonical v0.3.2
- strict transcript-start/boundary `Hey Atlas` / `OK Atlas` / `Okay Atlas` wake policy;
- partial hypotheses never execute; duplicate final commands are suppressed;
- wake service broadcasts exactly one event and does not directly execute `CommandRouter`;
- one-shot SpeechRecognizer, TTS, barge-in, mic arbitration, Assistant re-entry handling and explicit Stop control;
- typed local parser, malformed/control/oversize rejection, fail-closed ambiguous app matching;
- ACTION_DIAL and message-composer confirmation boundaries;
- bounded/path-safe private-seed import;
- WebView internal-file boundary, HTTP(S)-only external routing, unknown-scheme block, media-resource allowlist;
- backups and cleartext traffic disabled;
- build/toolchain gates and originality/benchmark policy.

## v0.3.3 additions
- confidence-aware final transcript selection;
- frame classification for REAL_WORLD / FICTION_LORE / SHAUN_PRIVATE / DEVICE_ACTION / HIGH_STAKES;
- spoken-output cleanup for concise TTS;
- expiring native owner-session mirror that also fails closed while Android is device-locked;
- native owner-session checks on private voice, device commands and vault bridge paths;
- lock-safe command subset;
- wake and Assistant UI paths re-check native owner-session state before opening/acting;
- expanded adversarial source checks and 70-case real-device acceptance matrix.

## Reconciliation hardening
A direct diff against the canonical v0.3.2 source found several defensive exception/intent-handling protections that had weakened in an intermediate manual merge. v0.3.3 restores them: guarded SpeechRecognizer destruction, external-intent `resolveActivity` checks, permission-denial feedback, null-safe back navigation, nonfatal persistable-URI permission failure, offline speech preference, canonical wake restart timing, and page-ready seed-import event dispatch. This is why the canonical source was re-read before promotion.

## Shipping rule
No further source version is justified merely because another scheduled cycle ran. The next valid promotion is **APK COMPILED from this exact source**, followed by exact-APK install and S20 Ultra acceptance. If the build path remains unavailable, work should reduce the build blocker rather than generate cosmetic versions.
