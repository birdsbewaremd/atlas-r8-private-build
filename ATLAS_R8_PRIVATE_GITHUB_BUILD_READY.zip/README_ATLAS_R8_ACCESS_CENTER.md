# ATLAS ONE R8 — Native Access Center

**Owner-private source candidate, October 25, 2026; NOT an APK.**

R8 continues the exact R7/R6 Android project. The native real-Android Home/launcher, app list/search/pins, Phone and Google Messages launchers, private MainActivity, voice systems, and original assets remain in the project. New: one purple native **ATLAS Access Center** opened from R7 Universe and private WebView. It shows **live OS permission/role status** when installed and guides the user through each Android-owned permission or role prompt. There is no automatic access grant or permanent device control.

## Supported access review (after future official SDK build and device approval)

- Default Android Home role, with Samsung One UI restore route
- Android Assistant role, separate from opt-in wake listening
- Microphone, camera, notifications — explain first, then Android runtime dialog upon the owner's tap
- Optional Usage Access — Android Settings only, with status read; existing one-shot usage reader is still owner-authenticated
- ATLAS App details / Permissions / revoke shortcut
- Bluetooth system settings
- Wallpaper / lock-screen appearance settings (does not replace Samsung fingerprint/PIN keyguard)
- Existing Google Messages and Phone app handoffs, and selected-file import via private ATLAS Core
- STOP for the existing ATLAS wake service (reversible, no access granted)
- Unsupported: unrestricted access to other apps' private data, SMS database, notification reader, unseen Accessibility service, all-files bypass, or secure keyguard takeover

## One-step setup in a *compiled* R8 APK

ATLAS Universe → **Access Center · Grant and review permissions** → select a feature → **Review with Android** → explicitly approve/deny in Android. Live statuses refresh on returning without resetting scroll position.

Current earlier ATLAS 0.8.3/R6 test APKs do **not** include this new native R8 screen. Installing this source ZIP on an Android phone does not add the feature. Do not uninstall working ATLAS builds to force the source ZIP to work.

## Local test evidence and build

- `scripts/build-r8-private.sh --source-check-only` — static and Java source syntax check, no APK
- `scripts/test-r8-access-center-browser.py` — mock bridge/UI, no native phone access
- `scripts/test-r8-access-source.py` — manifest/exported/permission/role invariants
- `scripts/test-r8-access-android-host.py` and `scripts/test-r8-launcher-java-host.py` — Java fake Android API host compile, NOT SDK build
- `scripts/build-r8-private.sh` — must run on trusted Android SDK API35 + Gradle 8.11.1 environment, assemble debug `.candidate` package, verify with official apksigner/aapt; **not run successfully here**
- `.github/workflows/build-r8-private.yml` — optional *manual* action for a private repo, not deployed or triggered. Requires separate owner approval to upload private source to any remote host.

No Android settings changed, no APK compiled or installed, no signing keys packaged. If the developer signing identity is unavailable, testing builds may have a distinct signer and cannot silently update the existing APK. Do not change default Home, microphone, notification/usage, device security, or any account automatically. Owner control; ATLAS can make mistakes.
