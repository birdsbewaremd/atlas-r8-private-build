# ATLAS current source: 0.8.0

Start with ../README_0.8.0.md and ../BUILD_RECEIPT_0.8.0.json in the recovery package. Earlier READMEs and release notes are retained as historical evidence. Current app version is0.8.0-test, code39, package com.sbh.atlasos.candidate. The native online text transport is implemented but no owner account is configured or verified. Do not infer phone acceptance from compilation or browser tests.
