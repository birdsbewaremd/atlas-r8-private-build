# RC4 review — October 10, 2026

Scope: isolated continuation of the supplied rc3 source ZIP. Not canonical HEAD.
No code from a parallel learning candidate was overwritten or silently merged.

## Root cause and correction

MainActivity created its key with setRandomizedEncryptionRequired(true), then
initialized encryption with a caller-generated IV in GCMParameterSpec. Android's
API explicitly rejects caller-provided encryption IVs under that setting. The
correction is cipher.init(ENCRYPT_MODE, key), followed by cipher.getIV(). The key
restriction remains enabled. Source inspection + API contract establish this
mismatch; actual Android reproduction is pending the included probe.

The earlier rc3 import tests used a synthetic byte writer and therefore did not
execute this cipher setup. Passing those tests never established working native
encryption. This is a test-coverage failure, not a user-caused failure.

VaultFileCodec is shared by the application adapter and new host tests. Thirty
named cases exercise actual AES-GCM, varying input lengths, legacy framing,
truncation, altered ciphertext/IV/tag, wrong keys, bounded reads, short/zero reads,
write errors, preservation of existing files, authorization loss and transactional
ZIP imports/rollback with real encryption. The provider is host SunJCE, not
Android Keystore. Test keys and data are synthetic and temporary.

Decryption now uses Cipher.doFinal directly. Oracle documents that CipherInputStream
can suppress integrity exceptions and may be unsuitable for authenticated modes.
This change does not assert that every Android version exhibited that behavior;
it removes reliance on wrapper-specific authentication/error semantics.

## Compatibility and risk

ATL1 format is retained. Existing successful synthetic legacy-format files remain
readable. No live migration, credential change, new owner key or recovery-code
creation occurred. New writes never overwrite existing destinations. Preview caps
are 1 MiB text and 8 MiB images; larger imported files are retained but not previewed
through these bridge calls. The file name/path is not cryptographically bound to
the ciphertext. Power-loss/fsync guarantees and all Android provider behavior are
still unverified. Java buffer wiping is best effort, not assured memory erasure.

The prepared seven-case Android probe refuses the owner package, uses a uniquely
named temporary key/cache directory, and separately attempts both file and key
cleanup. It is not compiled or executed here and does not close an Android gate.

A separate deferred-native-media defect was reproduced with the exact rc3
startVoiceTurn method and the real OwnerSessionGate against fake Android APIs
and a deterministic task queue. The old queued runnable did not recheck access
before startListening. rc4 captures a login generation plus request ticket and
rechecks them along with Activity/recognizer lifetime before starting. Cancel,
background, teardown, expiration and replacement login/request paths are covered
in that host suite. Wake restart is also token-bound in source. This does not
prove actual Android permission callbacks, recognizer callbacks or microphone
shutdown behavior. Those remain device-test gates.

The release gate remains BLOCKED until actual Android build/lint/signing and
isolated-device tests are completed. Native vault improvements do not encrypt
browser notes/tasks, provide friend accounts or make a complete device backup.

## Primary references, retrieved October 10, 2026

Android KeyGenParameterSpec.Builder, setRandomizedEncryptionRequired:
https://developer.android.com/reference/android/security/keystore/KeyGenParameterSpec.Builder#setRandomizedEncryptionRequired(boolean)

Oracle Java 21 CipherInputStream API, authenticated-mode caveat:
https://docs.oracle.com/en/java/javase/21/docs/api/java.base/javax/crypto/CipherInputStream.html

Android AGP 8.9 compatibility table:
https://developer.android.com/build/releases/agp-8-9-0-release-notes

Android command-line build documentation:
https://developer.android.com/build/building-cmdline
