# Routing Safety Integration — 2026-10-10

Parent: `0.3.8-rc2-trust1-hi1`.

A frozen 52-case pure-Java semantic preflight discovered two false-positive local-device routes:
- `AI-A18` (`Launch ... but ...`) -> OPEN_APP
- `A12` (`Text ... even though ... do not contact ...`) -> TEXT

Cause: `CommandParser` treated any string beginning with `launch/open/text/...` as a local imperative, even when the remainder contained a contradictory/explanatory clause requiring higher-level reasoning.

Repair: argument-action verbs now fall back to UNKNOWN/brain handoff when the text contains conflict/rationale/condition markers such as `but`, `even though`, `because`, `without`, or explicit negation. This intentionally trades some local convenience for safer routing.

Truth boundary: the local command lane already required owner session and confirmation for text/dial; this repair further prevents the lane from being selected for these reasoning-heavy inputs. It is not proof of Android runtime or workflow correctness.
